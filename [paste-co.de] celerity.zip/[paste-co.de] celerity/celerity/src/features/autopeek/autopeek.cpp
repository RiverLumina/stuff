#include "autopeek.hpp"

#include "../../core/main.hpp"
#include "../../sdk/memsafe.hpp"
#include "../../sdk/valve/interfaces/interfaces.hpp"
#include "../../sdk/valve/classes/c_cs_player_pawn.hpp"
#include "../../sdk/valve/interfaces/vtables/i_csgo_input.hpp"
#include "../shared/input_buttons.hpp"
#include "../prediction/prediction.hpp"
#include "../../../ui/menu/elements/bind.h"

#include <algorithm>
#include <cmath>

namespace {
constexpr float k_pi = 3.14159265358979323846f;
constexpr float k_arrive_radius = 10.f;   // stop steering inside this
constexpr float k_brake_radius = 55.f;    // start counter-strafing here
constexpr float k_wish = 450.f;

float yaw_rad(float deg) { return deg * (k_pi / 180.f); }
} // namespace

void c_autopeek::run(c_user_cmd* cmd) {
	const bool cfg_on = g_cfg && g_cfg->movement.m_autopeek;
	const bool bind_on = cfg_on && UI::IsBindActive("autopeek");

	if (!cfg_on || !bind_on) {
		m_active = false;
		m_returning = false;
		return;
	}

	if (!cmd || !g_ctx || !g_ctx->m_local_pawn) {
		m_active = false;
		m_returning = false;
		return;
	}

	auto* local = reinterpret_cast<c_cs_player_pawn*>(g_ctx->m_local_pawn);
	if (!memsafe::valid_entity(local) || !local->is_alive() || local->m_health() <= 0) {
		m_active = false;
		m_returning = false;
		return;
	}

	vec3_t origin{};
	if (auto* node = local->m_scene_node())
		origin = node->m_abs_origin();
	if (!origin.is_valid() || origin.is_zero()) {
		m_active = false;
		m_returning = false;
		return;
	}

	const bool on_ground = (local->m_flags() & FL_ONGROUND) != 0;

	// Anchor on first activation (grounded only — never anchor mid-air).
	if (!m_active) {
		if (!on_ground)
			return;
		m_anchor = origin;
		m_active = true;
		m_returning = false;
		return;
	}

	// Any shot this tick starts the pull-back (rage silent fire or manual).
	if (cmd->m_button_state.m_button_state & IN_ATTACK)
		m_returning = true;

	if (!m_returning)
		return;

	vec3_t to_anchor = m_anchor - origin;
	to_anchor.z = 0.f;
	const float dist = to_anchor.length_2d();

	auto* base = cmd->get_base_cmd();
	if (!base)
		return;

	float view_yaw = 0.f;
	if (base->has_viewangles())
		view_yaw = base->viewangles().y();
	else if (g_interfaces && g_interfaces->m_csgo_input)
		view_yaw = g_interfaces->m_csgo_input->get_view_angles().y;

	const float yr = yaw_rad(view_yaw);
	const float sy = std::sinf(yr);
	const float cy = std::cosf(yr);
	const vec3_t fwd(cy, sy, 0.f);
	const vec3_t right(-sy, cy, 0.f);

	auto write_moves = [&](float fmove, float smove) {
		base->set_forwardmove(fmove);
		base->set_leftmove(smove);
		base->set_upmove(0.f);
		movement_input::set_button(cmd, IN_FORWARD, fmove > 1.f);
		movement_input::set_button(cmd, IN_BACK, fmove < -1.f);
		movement_input::set_button(cmd, IN_MOVELEFT, smove > 1.f);
		movement_input::set_button(cmd, IN_MOVERIGHT, smove < -1.f);
	};

	vec3_t vel = local->m_vec_abs_velocity();
	if (g_prediction) {
		if (const auto* pred = g_prediction->get_local_data()) {
			if (pred->m_valid && pred->m_velocity.is_valid())
				vel = pred->m_velocity;
		}
	}
	vel.z = 0.f;
	const float speed = vel.length_2d();

	if (dist <= k_arrive_radius) {
		// Arrived: counter-strafe to a hard stop, then idle at the anchor.
		if (speed > 12.f) {
			const float f = -vel.dot(fwd);
			const float s = -vel.dot(right);
			const float len = std::sqrt(f * f + s * s);
			if (len > 1e-4f)
				write_moves((f / len) * k_wish, (s / len) * k_wish);
		} else {
			write_moves(0.f, 0.f);
			m_returning = false; // ready for the next peek
		}
		return;
	}

	// Steer toward the anchor; blend in braking near it so we don't orbit.
	vec3_t dir = to_anchor * (1.f / dist);
	if (dist < k_brake_radius && speed > 1.f) {
		// Approach vector = desired velocity (capped) minus current velocity.
		const float want_speed = (std::min)(speed + 60.f, dist * 6.f);
		const vec3_t want = dir * want_speed;
		vec3_t steer = want - vel;
		const float sl = steer.length_2d();
		if (sl > 1.f)
			dir = steer * (1.f / sl);
	}

	const float f = dir.dot(fwd);
	const float s = dir.dot(right);
	const float len = std::sqrt(f * f + s * s);
	if (len > 1e-4f)
		write_moves((f / len) * k_wish, (s / len) * k_wish);
}
