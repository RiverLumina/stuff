#pragma once
#include <memory>
#include "../../sdk/typedefs/vec_t.hpp"

class c_user_cmd;

// Hold-bind autopeek: anchors your position when the bind goes down, shows a
// 3D circle at the anchor, and walks you back to it after every shot.
class c_autopeek {
public:
	void run(c_user_cmd* cmd); // CreateMove, after ragebot

	bool   active() const { return m_active; }
	bool   returning() const { return m_returning; }
	vec3_t anchor() const { return m_anchor; }

private:
	bool   m_active = false;
	bool   m_returning = false;
	vec3_t m_anchor{};
};

inline const auto g_autopeek = std::make_unique<c_autopeek>();
