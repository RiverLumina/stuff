﻿#include "autostrafe.hpp"
#include "../../core/main.hpp"
#include "../../sdk/memsafe.hpp"
#include "../../sdk/valve/interfaces/interfaces.hpp"
#include "../../sdk/valve/classes/c_cs_player_pawn.hpp"
#include "../../sdk/valve/interfaces/vtables/i_csgo_input.hpp"
#include "../shared/input_buttons.hpp"
#include "../prediction/prediction.hpp"
#include <algorithm>
#include <cmath>
#include <Windows.h>

namespace {
constexpr float k_pi = 3.14159265358979323846f;
constexpr float k_rad2deg = 180.f / k_pi;
constexpr float k_deg2rad = k_pi / 180.f;
constexpr float k_air_wishspeed = 30.f;
constexpr float k_air_accelerate = 12.f; // sv_airaccelerate default
constexpr float k_tick = 1.f / 64.f;
constexpr float k_move_unit = 1.f;
constexpr std::uint64_t k_wasd = IN_FORWARD | IN_BACK | IN_MOVELEFT | IN_MOVERIGHT;

float normalize_yaw(float yaw) {
	while (yaw > 180.f) yaw -= 360.f;
	while (yaw < -180.f) yaw += 360.f;
	return yaw;
}

void apply_wish_moves(c_user_cmd* cmd, float fmove, float smove) {
	auto* base = cmd->get_base_cmd();
	if (!base)
		return;

	const float len = std::sqrt(fmove * fmove + smove * smove);
	if (len > 1e-4f) {
		fmove = (fmove / len) * k_move_unit;
		smove = (smove / len) * k_move_unit;
	}
	fmove = std::clamp(fmove, -k_move_unit, k_move_unit);
	smove = std::clamp(smove, -k_move_unit, k_move_unit);

	base->set_forwardmove(fmove);
	base->set_leftmove(smove);

	if (g_interfaces && g_interfaces->m_csgo_input) {
		g_interfaces->m_csgo_input->forward_move = fmove;
		g_interfaces->m_csgo_input->left_move = smove;
	}

	movement_input::set_button(cmd, IN_FORWARD, fmove > 0.15f);
	movement_input::set_button(cmd, IN_BACK, fmove < -0.15f);
	movement_input::set_button(cmd, IN_MOVELEFT, smove > 0.15f);
	movement_input::set_button(cmd, IN_MOVERIGHT, smove < -0.15f);
}

float ideal_strafe_delta_deg(float speed) {
	const float accel_speed = k_air_accelerate * k_air_wishspeed * k_tick;
	if (speed <= k_air_wishspeed + 1.f)
		return 90.f;
	const float arg = std::clamp((k_air_wishspeed - accel_speed) / speed, -1.f, 1.f);
	return std::acos(arg) * k_rad2deg;
}

void read_user_wasd(c_user_cmd* cmd, float& fwd, float& side, std::uint64_t& buttons) {
	fwd = 0.f;
	side = 0.f;
	buttons = 0;
	if (!cmd)
		return;

	buttons = cmd->m_button_state.m_button_state & k_wasd;
	if (buttons & IN_FORWARD) fwd += 1.f;
	if (buttons & IN_BACK) fwd -= 1.f;
	if (buttons & IN_MOVELEFT) side += 1.f;
	if (buttons & IN_MOVERIGHT) side -= 1.f;

	auto* base = cmd->get_base_cmd();
	if (base) {
		const float uf = base->has_forwardmove() ? base->forwardmove() : 0.f;
		const float us = base->has_leftmove() ? base->leftmove() : 0.f;
		if (std::fabs(uf) > 0.05f || std::fabs(us) > 0.05f) {
			fwd = uf;
			side = us;
			const float m = (std::max)(std::fabs(fwd), std::fabs(side));
			if (m > 1.5f) {
				fwd /= 450.f;
				side /= 450.f;
			}
		}
	}
}

void run_legit(c_user_cmd* cmd) {
	auto* base = cmd->get_base_cmd();
	if (!base)
		return;

	int mouse_delta = base->has_mousedx() ? base->mousedx() : 0;
	if (mouse_delta == 0 && g_interfaces && g_interfaces->m_csgo_input)
		mouse_delta = g_interfaces->m_csgo_input->mouse_delta_x;

	float left_move = 0.0f;
	if (mouse_delta > 1)
		left_move = -1.0f;
	else if (mouse_delta < -1)
		left_move = 1.0f;
	else
		left_move = (cmd->m_command_number % 2 == 0) ? 1.0f : -1.0f;

	apply_wish_moves(cmd, 0.f, left_move);
}

// Rage strafe — standard air-strafe theory:
//  - Max speed GAIN happens with the wish at ±gamma from velocity, where
//    gamma = acos((30 - accelspeed) / speed) (the "ideal" strafe angle).
//  - Steering: rotate velocity toward the intended travel yaw by putting the
//    wish on the side of the intent; once the remaining turn is smaller than
//    gamma, aim the wish AT the intent so the path converges instead of
//    oscillating ±gamma around it forever (the old wobble).
//  - Intent = view yaw + WASD offset when keys are held, otherwise keep the
//    current velocity direction (persistent side, no per-tick flip-flop).
void run_rage(c_user_cmd* cmd, c_cs_player_pawn* local) {
	auto* base = cmd->get_base_cmd();
	if (!base)
		return;

	vec3_t vel = local->m_vec_abs_velocity();
	if (g_prediction) {
		if (const auto* pred = g_prediction->get_local_data()) {
			if (pred->m_valid && pred->m_velocity.is_valid())
				vel = pred->m_velocity;
		}
	}
	vel.z = 0.f;
	const float speed2d = vel.length_2d();

	float view_yaw = 0.f;
	if (base->has_viewangles())
		view_yaw = base->viewangles().y();
	else if (g_interfaces && g_interfaces->m_csgo_input)
		view_yaw = g_interfaces->m_csgo_input->get_view_angles().y;

	float user_fwd = 0.f, user_side = 0.f;
	std::uint64_t user_buttons = 0;
	read_user_wasd(cmd, user_fwd, user_side, user_buttons);

	int mouse_delta = base->has_mousedx() ? base->mousedx() : 0;
	if (mouse_delta == 0 && g_interfaces && g_interfaces->m_csgo_input)
		mouse_delta = g_interfaces->m_csgo_input->mouse_delta_x;

	const float vel_yaw = (speed2d > 1.f)
		? (std::atan2(vel.y, vel.x) * k_rad2deg)
		: view_yaw;
	const float gamma = ideal_strafe_delta_deg((std::max)(speed2d, 1.f));

	const bool has_dir = (user_buttons & k_wasd) != 0
		|| std::fabs(user_fwd) > 0.05f || std::fabs(user_side) > 0.05f;

	// Intended travel yaw. WASD wins; mouse steers; otherwise hold course.
	static float s_hold_yaw = 0.f;
	static bool s_have_hold = false;
	float intended;
	if (has_dir) {
		const float user_delta = normalize_yaw(std::atan2(user_side, user_fwd) * k_rad2deg);
		intended = normalize_yaw(view_yaw + user_delta);
		s_hold_yaw = intended;
		s_have_hold = true;
	} else if (mouse_delta != 0) {
		// Mouse steering: intent follows the camera turn.
		intended = normalize_yaw(vel_yaw - static_cast<float>(mouse_delta) * 0.6f);
		s_hold_yaw = intended;
		s_have_hold = true;
	} else {
		intended = s_have_hold ? s_hold_yaw : vel_yaw;
		if (!s_have_hold) {
			s_hold_yaw = vel_yaw;
			s_have_hold = true;
		}
	}

	float wish_yaw;
	const float diff = normalize_yaw(intended - vel_yaw);
	if (speed2d <= k_air_wishspeed + 2.f) {
		// Below wishspeed there is no gamma cone — push straight at the intent.
		wish_yaw = intended;
	} else if (std::fabs(diff) <= gamma) {
		// Converged: wishing at the intent still gains (inside the gain cone)
		// and the velocity settles exactly on course — no ±gamma wobble.
		wish_yaw = intended;
	} else {
		// Turn toward the intent at max gain: wish at gamma on the intent side.
		wish_yaw = normalize_yaw(vel_yaw + (diff > 0.f ? gamma : -gamma));
	}

	const float delta = normalize_yaw(wish_yaw - view_yaw) * k_deg2rad;
	apply_wish_moves(cmd, std::cos(delta) * k_move_unit, std::sin(delta) * k_move_unit);
}
} // namespace

void c_autostrafe::run(c_user_cmd* cmd) {
	if (!cmd || !g_cfg || !g_cfg->movement.m_autostrafe)
		return;
	if (!g_ctx || !g_ctx->m_local_pawn)
		return;

	auto* local_pawn = reinterpret_cast<c_cs_player_pawn*>(g_ctx->m_local_pawn);
	if (!memsafe::valid_entity(local_pawn) || local_pawn->m_health() <= 0)
		return;

	// Airborne is the only gate — a hardcoded SPACE hold broke autostrafe for
	// scroll-jump / bound-jump users entirely.
	if (local_pawn->m_flags() & FL_ONGROUND)
		return;
	if (local_pawn->m_move_type() == MOVETYPE_LADDER || local_pawn->m_move_type() == MOVETYPE_NOCLIP)
		return;

	if (g_cfg->movement.m_autostrafe_mode == 1)
		run_rage(cmd, local_pawn);
	else
		run_legit(cmd);
}
