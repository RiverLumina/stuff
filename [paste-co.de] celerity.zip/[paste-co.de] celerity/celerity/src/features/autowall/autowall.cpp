#include "autowall.hpp"

#include "../../core/main.hpp"
#include "../../sdk/memsafe.hpp"
#include "../../utils/utils.hpp"

#include <Windows.h>
#include <algorithm>
#include <cmath>
#include <cstring>

namespace autowall {
namespace {

// Lefrizzel / IDA FireBullet path (client.dll):
//   InitTraceData → InitFilter(0x1C300B,3,15) → CreateTrace → DamageToPoint → GetTraceInfo → FreeTraceData
constexpr const char* k_pat_init_trace_data =
	"48 89 5C 24 08 48 89 74 24 10 57 48 83 EC 20 48 8D 79 08 33 F6 C7 47 08 80 00 00 00";
constexpr const char* k_pat_init_trace_data_loose =
	"48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC 20 48 8D 79 ? 33 F6 C7 47";
constexpr const char* k_pat_create_trace =
	"48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 41 56 41 57 48 83 EC 40 F2 0F 10 02";
constexpr const char* k_pat_create_trace_loose =
	"48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 41 56 41 57 48 83 EC ? F2 0F 10 02";
constexpr const char* k_pat_damage_to_point =
	"40 53 57 41 56 48 83 EC 50 8B 84 24 90 00 00 00";
constexpr const char* k_pat_damage_to_point_loose =
	"40 53 57 41 56 48 83 EC ? 8B 84 24";
constexpr const char* k_pat_get_trace_info =
	"48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 81 EC 80 00 00 00 48 8B E9 0F 29 74 24";
constexpr const char* k_pat_get_trace_info_loose =
	"48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 81 EC ? ? ? ? 48 8B E9 0F 29 74 24";
constexpr const char* k_pat_init_filter =
	"48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 0F B6 41 ? 33 FF 24 C9 C7 41 ?";
constexpr const char* k_pat_init_filter_loose =
	"48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 0F B6 41 ? 33 FF 24";
constexpr const char* k_pat_free_trace_data =
	"48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC 20 33 F6 48 8D B9 38 1C 00 00";

constexpr std::size_t k_off_surfaces_count = 0x1C20;
constexpr std::size_t k_off_surfaces_ptr = 0x1C28;
constexpr std::size_t k_off_segments_ptr = 0x08;
constexpr std::size_t k_seg_stride = 56;
constexpr std::size_t k_trace_data_size = 0x2200;
constexpr std::size_t k_filter_size = 0x70;
constexpr std::uint64_t k_mask_shot_pen = 0x1C300Bull;

struct trace_info_aw_t {
	float unk{};
	float distance{};
	float damage{};
	std::int32_t pen_count{};
	std::uint16_t enter_idx{};
	std::uint16_t exit_idx{};
	std::uint32_t flags{};
};
static_assert(sizeof(trace_info_aw_t) == 24);

struct game_trace_aw_t {
	void* surface{};
	void* hit_entity{};
	void* hitbox_data{};
	std::uint8_t pad[0xC0]{};
};

using fn_init_trace_data = void*(__fastcall*)(void* trace);
using fn_create_trace = void(__fastcall*)(void* trace, const vec3_t* start, const vec3_t* delta,
	void* filter, int pen_count, bool unk);
using fn_damage_to_point = void(__fastcall*)(void* trace, float damage, float pen, float range_mod,
	int pen_count, int team, void* unused);
using fn_get_trace_info = void(__fastcall*)(void* trace, game_trace_aw_t* out, float distance, void* seg);
using fn_init_filter = void(__fastcall*)(void* filter, void* skip, std::uint64_t mask, int layer, std::uint16_t a5);
using fn_free_trace_data = void(__fastcall*)(void* trace);

using fn_trace_shape = bool(__fastcall*)(void* world, const void* ray, const vec3_t* start,
	const vec3_t* end, const void* filter, void* out);

struct fns_t {
	fn_init_trace_data init_trace_data = nullptr;
	fn_create_trace create_trace = nullptr;
	fn_damage_to_point damage_to_point = nullptr;
	fn_get_trace_info get_trace_info = nullptr;
	fn_init_filter init_filter = nullptr;
	fn_free_trace_data free_trace_data = nullptr;
	fn_trace_shape trace_shape = nullptr;
	void** trace_mgr = nullptr;
	bool resolved = false;
	bool game_path = false;
	bool shape_ready = false;
};

void* scan_pat(const char* a, const char* b = nullptr) {
	void* p = g_opcodes->scan("client.dll", a);
	if (!p && b)
		p = g_opcodes->scan("client.dll", b);
	return p;
}

fns_t& funcs() {
	static fns_t f;
	if (f.resolved)
		return f;
	f.resolved = true;

	f.init_trace_data = reinterpret_cast<fn_init_trace_data>(
		scan_pat(k_pat_init_trace_data, k_pat_init_trace_data_loose));
	f.create_trace = reinterpret_cast<fn_create_trace>(
		scan_pat(k_pat_create_trace, k_pat_create_trace_loose));
	f.damage_to_point = reinterpret_cast<fn_damage_to_point>(
		scan_pat(k_pat_damage_to_point, k_pat_damage_to_point_loose));
	f.get_trace_info = reinterpret_cast<fn_get_trace_info>(
		scan_pat(k_pat_get_trace_info, k_pat_get_trace_info_loose));
	f.init_filter = reinterpret_cast<fn_init_filter>(
		scan_pat(k_pat_init_filter, k_pat_init_filter_loose));
	f.free_trace_data = reinterpret_cast<fn_free_trace_data>(
		scan_pat(k_pat_free_trace_data));
	f.trace_shape = reinterpret_cast<fn_trace_shape>(
		scan_pat(
			"48 89 54 24 ? 48 89 4C 24 ? 55 53 56 57 41 56 41 57 48 8D AC 24 ? ? ? ? B8 E8 24 00 00",
			"48 89 54 24 ? 48 89 4C 24 ? 55 53 56 57 41 56 41 57 48 8D AC 24 ? ? ? ? B8"));

	const auto mgr = g_opcodes->scan_absolute(
		"client.dll", "48 8B 0D ? ? ? ? 48 8B D0 C7 44 24 ? 04 00 00 00", 0x3, 0x7);
	if (mgr)
		f.trace_mgr = reinterpret_cast<void**>(mgr);

	f.game_path = f.init_trace_data && f.create_trace && f.damage_to_point
		&& f.get_trace_info && f.init_filter && f.free_trace_data;
	// TraceShape AV's with current ray/filter/mgr wiring (debugger + SEH). Disabled —
	// fire_bullet uses CreateTrace/DamageToPoint + EstimateVisible instead.
	f.shape_ready = false;
	(void)f.trace_shape;
	(void)f.trace_mgr;
	return f;
}

bool pen_ready_internal() {
	auto& f = funcs();
	return f.game_path || f.shape_ready;
}

struct shape_trace_t {
	alignas(16) std::uint8_t raw[0x200]{};
	void* hit_entity() const {
		return *reinterpret_cast<void* const*>(raw + 0x08);
	}
	float fraction() const {
		return *reinterpret_cast<const float*>(raw + 0xAC);
	}
	bool startsolid() const { return raw[0xBB] != 0; }
	bool did_hit() const { return fraction() < 1.f || startsolid(); }
};

struct shape_ray_t {
	alignas(16) std::uint8_t raw[0x30]{};
	void set_line() {
		std::memset(raw, 0, sizeof(raw));
		raw[0x28] = 0;
	}
	void set_hull(const vec3_t& mins, const vec3_t& maxs) {
		std::memset(raw, 0, sizeof(raw));
		std::memcpy(raw + 0x00, &mins, sizeof(float) * 3);
		std::memcpy(raw + 0x0C, &maxs, sizeof(float) * 3);
		raw[0x28] = 1;
	}
};

bool trace_line_shape(const vec3_t& start, const vec3_t& end, void* skip, shape_trace_t& out) {
	auto& f = funcs();
	if (!f.shape_ready || !f.trace_mgr || !*f.trace_mgr || !f.trace_shape || !f.init_filter)
		return false;
	if (!std::isfinite(start.x) || !std::isfinite(start.y) || !std::isfinite(start.z)
		|| !std::isfinite(end.x) || !std::isfinite(end.y) || !std::isfinite(end.z))
		return false;
	if (skip && !memsafe::is_user_ptr(skip))
		return false;

	shape_ray_t ray{};
	ray.set_line();
	alignas(16) std::uint8_t filter[k_filter_size]{};
	std::memset(&out, 0, sizeof(out));
	*reinterpret_cast<float*>(out.raw + 0xAC) = 1.f;

	vec3_t s = start, e = end;
	f.init_filter(filter, skip, k_mask_shot_pen, 4, 0);
	f.trace_shape(*f.trace_mgr, &ray, &s, &e, filter, &out);
	return true;

}

bool trace_hull_shape(const vec3_t& start, const vec3_t& end, void* skip, shape_trace_t& out) {
	auto& f = funcs();
	if (!f.shape_ready || !f.trace_mgr || !*f.trace_mgr || !f.trace_shape || !f.init_filter)
		return false;
	if (!std::isfinite(start.x) || !std::isfinite(start.y) || !std::isfinite(start.z)
		|| !std::isfinite(end.x) || !std::isfinite(end.y) || !std::isfinite(end.z))
		return false;
	if (skip && !memsafe::is_user_ptr(skip))
		return false;

	const vec3_t mins{ -0.5f, -0.5f, -0.5f };
	const vec3_t maxs{ 0.5f, 0.5f, 0.5f };
	shape_ray_t ray{};
	ray.set_hull(mins, maxs);
	alignas(16) std::uint8_t filter[k_filter_size]{};
	std::memset(&out, 0, sizeof(out));
	*reinterpret_cast<float*>(out.raw + 0xAC) = 1.f;

	vec3_t s = start, e = end;
	f.init_filter(filter, skip, k_mask_shot_pen, 4, 0);
	f.trace_shape(*f.trace_mgr, &ray, &s, &e, filter, &out);
	return true;
}

int hitbox_to_hitgroup(int hb) {
	switch (hb) {
	case HITBOX_HEAD: return HITGROUP_HEAD;
	case HITBOX_NECK: return HITGROUP_NECK;
	case HITBOX_CHEST:
	case HITBOX_UPPER_CHEST:
	case HITBOX_LOWER_CHEST: return HITGROUP_CHEST;
	case HITBOX_STOMACH:
	case HITBOX_PELVIS: return HITGROUP_STOMACH;
	case HITBOX_RIGHT_UPPER_ARM:
	case HITBOX_RIGHT_FOREARM: return HITGROUP_RIGHTARM;
	case HITBOX_LEFT_UPPER_ARM:
	case HITBOX_LEFT_FOREARM: return HITGROUP_LEFTARM;
	case HITBOX_RIGHT_THIGH:
	case HITBOX_RIGHT_CALF: return HITGROUP_RIGHTLEG;
	case HITBOX_LEFT_THIGH:
	case HITBOX_LEFT_CALF: return HITGROUP_LEFTLEG;
	default: return HITGROUP_CHEST;
	}
}

pen_result_t estimate_visible(
	const vec3_t& eye,
	const vec3_t& aim,
	c_cs_player_pawn* target,
	c_cs_weapon_base_v_data* weapon_data,
	int hitbox_id,
	c_autowall* self)
{
	pen_result_t r{};
	if (!target || !weapon_data || !self)
		return r;

	const float dist = (aim - eye).length();
	float dmg = static_cast<float>(weapon_data->m_damage());
	dmg *= std::pow(weapon_data->m_range_modifier(), dist / 500.f);
	const int hg = hitbox_to_hitgroup(hitbox_id);
	self->scale_damage(hg, target, weapon_data, dmg);
	r.damage = (std::max)(dmg, 1.f);
	r.hitgroup = hg;
	r.hitbox = hitbox_id;
	r.hit = true;
	r.penetrated = false;
	return r;
}

bool same_target(void* hit, c_cs_player_pawn* target) {
	// Hit may be pawn, weapon, or attachment — walk owner like Lefrizzel HitsTarget.
	constexpr std::uint32_t k_owner_off = 0x520; // C_BaseEntity::m_hOwnerEntity
	if (!hit || !target)
		return false;
	if (hit == target)
		return true;
	if (!memsafe::is_user_ptr(hit) || !memsafe::is_user_ptr(target))
		return false;

	void* cur = hit;
	for (int depth = 0; depth < 6 && cur && memsafe::is_user_ptr(cur); ++depth) {
		if (cur == target)
			return true;

		const c_base_handle owner = *reinterpret_cast<c_base_handle*>(
			reinterpret_cast<std::uint8_t*>(cur) + k_owner_off);
		if (!owner.is_valid() || !g_interfaces || !g_interfaces->m_entity_system)
			break;
		void* next = g_interfaces->m_entity_system->get_base_entity(owner.get_entry_index());
		if (!next || next == cur)
			break;
		cur = next;
	}
	return false;
}

// POD inputs/outputs for the game FireBullet path (no C++ dtors).
struct fire_in_t {
	const vec3_t* eye{};
	const vec3_t* delta{};
	void* filter{};
	void* local{};
	void* target{};
	float damage{};
	float pen{};
	float range_mod{};
	int pens{};
	int team{};
};

struct fire_out_t {
	float raw_dmg{};
	bool raw_pen{};
	bool raw_ok{};
	int hitgroup{};
	int hitbox{};
};

fire_out_t fire_game(const fire_in_t& in) {
	fire_out_t out{};
	auto& f = funcs();
	if (!f.game_path || !in.eye || !in.delta || !in.filter || !in.local)
		return out;

	alignas(16) std::uint8_t trace_buf[k_trace_data_size];
	std::memset(trace_buf, 0, sizeof(trace_buf));

	float prior_max = 0.f;
	int target_idx = -1;

	f.init_trace_data(trace_buf);

	f.init_filter(in.filter, in.local, k_mask_shot_pen, 3, 15);
	{
		auto* fb = static_cast<std::uint8_t*>(in.filter);
		*reinterpret_cast<std::uint64_t*>(fb + 16) |= 0x4000000000ull;
		fb[57] |= 2;
	}

	f.create_trace(trace_buf, in.eye, in.delta, in.filter, in.pens, true);
	f.damage_to_point(trace_buf, in.damage, in.pen, in.range_mod, in.pens, in.team, nullptr);

	const int surfaces = *reinterpret_cast<int*>(trace_buf + k_off_surfaces_count);
	auto* infos = *reinterpret_cast<trace_info_aw_t**>(trace_buf + k_off_surfaces_ptr);
	void* segs = *reinterpret_cast<void**>(trace_buf + k_off_segments_ptr);

	// ONLY accept when GetTraceInfo entity matches target (no invent dmg).
	if (infos && surfaces > 0 && surfaces <= 64 && f.get_trace_info && segs && in.target) {
		for (int i = 0; i < surfaces; ++i) {
			const auto& info = infos[i];
			if (info.damage >= 1.f && info.damage > prior_max)
				prior_max = info.damage;

			const std::uint16_t idx = info.exit_idx ? info.exit_idx : info.enter_idx;
			if (idx >= 128)
				continue;

			auto* seg = reinterpret_cast<std::uint8_t*>(segs)
				+ k_seg_stride * static_cast<std::size_t>(idx);
			alignas(16) game_trace_aw_t gt{};
			f.get_trace_info(trace_buf, &gt, info.distance, seg);
			if (same_target(gt.hit_entity, reinterpret_cast<c_cs_player_pawn*>(in.target))) {
				target_idx = i;
				if (info.damage >= 1.f)
					prior_max = info.damage;
				if (gt.hitbox_data) {
					const int hg = *reinterpret_cast<int*>(
						reinterpret_cast<std::uint8_t*>(gt.hitbox_data) + 0x38);
					const int hb = *reinterpret_cast<int*>(
						reinterpret_cast<std::uint8_t*>(gt.hitbox_data) + 0x40);
					if (hg >= 0 && hg <= 10)
						out.hitgroup = hg;
					if (hb >= 0 && hb < 20)
						out.hitbox = hb;
				}
			}
		}

		if (target_idx >= 0) {
			const auto& ti = infos[target_idx];
			const float dmg = ti.damage;
			if (dmg < 1.f) {
				out.raw_ok = false;
			} else {
				const bool did_pen = (target_idx > 0) || (ti.pen_count < in.pens);
				if (in.pens > 0 && !did_pen && target_idx == 0) {
					out.raw_ok = true;
					out.raw_dmg = dmg;
					out.raw_pen = false;
				} else if (in.pens > 0 && !did_pen) {
					out.raw_ok = false;
				} else {
					out.raw_ok = true;
					out.raw_dmg = dmg;
					out.raw_pen = did_pen || (in.pens == 0);
				}
			}
		}
		(void)prior_max;
	}

	if (f.free_trace_data)
		f.free_trace_data(trace_buf);

	return out;
}

} // namespace

bool c_autowall::pen_ready() const {
	return pen_ready_internal();
}

void c_autowall::scale_damage(int hitgroup, c_cs_player_pawn* entity, c_cs_weapon_base_v_data* weapon_data, float& damage) {
	if (!entity || !weapon_data || damage <= 0.f)
		return;

	union cvar_value_t {
		bool b_value;
		float fl_value;
		int i_value;
		const char* sz_value;
	};
	struct convar_t {
		const char* name;
		cvar_value_t* default_value;
		std::uint8_t pad_0010[0x10];
		const char* description;
		std::uint32_t type;
		std::uint32_t registered;
		std::uint32_t flags;
		std::uint8_t pad_0034[0x24];
		cvar_value_t value;
	};

	auto find_cvar = [](const char* name) -> convar_t* {
		static void* cvar = nullptr;
		static auto get_first = reinterpret_cast<void(__fastcall*)(void*, std::uint64_t*)>(nullptr);
		static auto get_next = reinterpret_cast<void(__fastcall*)(void*, std::uint64_t*, std::uint64_t)>(nullptr);
		static auto find_by_index = reinterpret_cast<convar_t*(__fastcall*)(void*, std::uint64_t)>(nullptr);
		static bool tried = false;
		if (!tried) {
			tried = true;
			HMODULE tier0 = GetModuleHandleA("tier0.dll");
			if (tier0) {
				using create_interface_t = void* (*)(const char*, int*);
				auto create_interface = reinterpret_cast<create_interface_t>(GetProcAddress(tier0, "CreateInterface"));
				if (create_interface)
					cvar = create_interface("VEngineCvar007", nullptr);
			}
			get_first = reinterpret_cast<decltype(get_first)>(
				g_opcodes->scan("tier0.dll", "48 89 74 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 48 8B F2 48 8D B9"));
			get_next = reinterpret_cast<decltype(get_next)>(
				g_opcodes->scan("tier0.dll", "40 53 55 56 41 56 41 57 48 83 EC ? 49 8B D8 48 8D B1 ? ? ? ? 4C 8B F2 48 8B E9 FF 15 ? ? ? ? 8B D0 39 46 ? 75 ? 66 FF 46 ? EB ? 8B 06 90 85 C0 75 ? B9 ? ? ? ? F0 0F B1 0E 75 ? 66 C7 46 ? ? ? 89 56 ? EB ? 48 8B CE E8 ? ? ? ? 41 BF ? ? ? ? 48 89 7C 24 ? 4C 89 6C 24 ? 66 41 3B DF 74 ? 41 BD ? ? ? ? 66 44 85 6D"));
			find_by_index = reinterpret_cast<decltype(find_by_index)>(
				g_opcodes->scan("tier0.dll", "48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B DA 48 8D B9 ? ? ? ? 48 8B F1 FF 15 ? ? ? ? 8B D0 39 47 ? 75 ? 66 FF 47 ? EB ? 8B 07 90 85 C0 75 ? B9 ? ? ? ? F0 0F B1 0F 75 ? 66 C7 47 ? ? ? 89 57 ? EB ? 48 8B CF E8 ? ? ? ? BA"));
		}
		if (!cvar || !get_first || !get_next || !find_by_index || !name)
			return nullptr;
		std::uint64_t index = 0;
		get_first(cvar, &index);
		while (index != 0xFFFFFFFFull) {
			auto* var = find_by_index(cvar, index);
			if (var && var->name && std::strcmp(var->name, name) == 0)
				return var;
			get_next(cvar, &index, index);
		}
		return nullptr;
	};

	auto cvar_float = [&](const char* name, float fallback) {
		if (auto* v = find_cvar(name))
			return v->value.fl_value;
		return fallback;
	};

	const bool has_heavy = entity->m_armor_value() > 0;
	(void)has_heavy;

	float head_scale = cvar_float("mp_damage_scale_ct_head", 1.f);
	if (entity->m_team_num() == 2)
		head_scale = cvar_float("mp_damage_scale_t_head", 1.f);
	float body_scale = cvar_float("mp_damage_scale_ct_body", 1.f);
	if (entity->m_team_num() == 2)
		body_scale = cvar_float("mp_damage_scale_t_body", 1.f);

	switch (hitgroup) {
	case HITGROUP_HEAD:
		damage *= weapon_data->m_headshot_multiplier() * head_scale;
		break;
	case HITGROUP_STOMACH:
		damage *= 1.25f * body_scale;
		break;
	case HITGROUP_LEFTLEG:
	case HITGROUP_RIGHTLEG:
		damage *= 0.75f;
		break;
	case HITGROUP_CHEST:
	case HITGROUP_LEFTARM:
	case HITGROUP_RIGHTARM:
	case HITGROUP_NECK:
	default:
		damage *= body_scale;
		break;
	}

	if (!entity->has_armor(hitgroup))
		return;

	constexpr float armor_bonus = 0.5f;
	const float armor_ratio = weapon_data->m_armor_ratio() * 0.5f;
	float damage_to_health = damage * armor_ratio;
	const float damage_to_armor = (damage - damage_to_health) * armor_bonus;
	const float armor_val = static_cast<float>(entity->m_armor_value());
	if (damage_to_armor > armor_val)
		damage_to_health = damage - armor_val / armor_bonus;
	damage = damage_to_health;
}

pen_result_t c_autowall::fire_bullet(
	const vec3_t& start,
	const vec3_t& end,
	c_cs_player_pawn* local,
	c_cs_player_pawn* target,
	c_cs_weapon_base_v_data* weapon_data,
	bool allow_penetration,
	int hitbox_id)
{
	pen_result_t r{};
	if (!local || !target || !weapon_data)
		return r;

	auto& f = funcs();
	const float dist = (end - start).length();
	if (dist < 1.f)
		return r;

	auto run_game_pen = [&](bool require_pen_proof, int pens) -> pen_result_t {
		pen_result_t out{};
		if (!f.game_path)
			return out;

		vec3_t delta = end - start;
		const float range = weapon_data->m_range();
		delta = delta * (range / dist);

		alignas(16) std::uint8_t filter[k_filter_size]{};
		fire_in_t in{};
		in.eye = &start;
		in.delta = &delta;
		in.filter = filter;
		in.local = local;
		in.target = target;
		in.damage = static_cast<float>(weapon_data->m_damage());
		in.pen = weapon_data->m_penetration();
		in.range_mod = weapon_data->m_range_modifier();
		in.pens = pens;
		in.team = local->m_team_num();

		const fire_out_t o = fire_game(in);
		if (!o.raw_ok || o.raw_dmg < 1.f)
			return out;
		if (require_pen_proof && !o.raw_pen)
			return out;

		float dmg = o.raw_dmg;
		int hg = o.hitgroup;
		if (hg <= 0)
			hg = hitbox_to_hitgroup(hitbox_id);
		scale_damage(hg, target, weapon_data, dmg);
		if (dmg < 1.f)
			return out;

		out.damage = dmg;
		out.hitgroup = hg;
		// Never trust garbage hitbox ids from GetTraceInfo (seen 1.8e9 in logs).
		out.hitbox = (o.hitbox >= 0 && o.hitbox < 20) ? o.hitbox : hitbox_id;
		out.hit = true;
		out.penetrated = o.raw_pen;
		return out;
	};

	// TraceShape disabled. Without LOS classify:
	//   1) pens=0  → visible only (stops at first wall)
	//   2) pens=4  → wallbang, but ONLY if game reports real pen
	// NEVER EstimateVisible after a game miss — that invented full dmg through walls.
	if (f.game_path) {
		const pen_result_t visible = run_game_pen(false, 0);
		if (visible.hit)
			return visible;

		if (allow_penetration && weapon_data->m_penetration() >= 0.05f) {
			const pen_result_t wall = run_game_pen(true, 4);
			if (wall.hit && wall.penetrated)
				return wall;
		}
		return r;
	}

	// Signatures unresolved: visible-only estimate; never invent wallbang.
	if (!allow_penetration)
		return estimate_visible(start, end, target, weapon_data, hitbox_id, this);

	return r;
}

} // namespace autowall
