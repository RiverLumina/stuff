#pragma once

#include "../../sdk/typedefs/vec_t.hpp"
#include "../../sdk/valve/classes/c_cs_player_pawn.hpp"

#include <array>
#include <cstdint>
#include <memory>

namespace autowall {

constexpr std::uint64_t k_mask_shot_hull = 0x1C300Bu;
constexpr std::uint32_t k_ent_entry_mask = 0x7FFFu;

struct ray_t {
	vec3_t start{};
	vec3_t end{};
	vec3_t mins{};
	vec3_t maxs{};
	char pad[0x4]{};
	std::uint8_t type{};
};
static_assert(sizeof(ray_t) == 0x38);

struct trace_hitbox_data_t {
	char pad0[0x38]{};
	int hitgroup{};
	char pad1[0x4]{};
	int hitbox_id{};
};

struct game_trace_t {
	void* surface{};
	c_cs_player_pawn* hit_entity{};
	trace_hitbox_data_t* hitbox_data{};
	char pad0[0x38]{};
	std::uint32_t contents{};
	char pad1[0x24]{};
	vec3_t start{};
	vec3_t end{};
	vec3_t normal{};
	vec3_t pos{};
	char pad2[0x4]{};
	float fraction{ 1.f };
	char pad3[0x6]{};
	bool all_solid{};
	char pad4[0x4D]{};

	int hitgroup() const { return hitbox_data ? hitbox_data->hitgroup : 0; }
	int hitbox_id() const { return hitbox_data ? hitbox_data->hitbox_id : 0; }
};
static_assert(sizeof(game_trace_t) == 0x108);

struct trace_filter_t {
	char pad0[8]{};
	std::int64_t mask{};
	std::int64_t ptr[2]{};
	std::int32_t skip_handles[4]{};
	std::int16_t collisions[2]{};
	std::uint8_t b0{}, b1{}, b2{}, b3{}, b4{}, b5{};
	char pad1[6]{};
	std::uint8_t collision{};
};
static_assert(sizeof(trace_filter_t) == 0x48);

struct update_value_t {
	float previous_length{};
	float current_length{};
	char pad0[0x8]{};
	std::int16_t handle_index{};
	char pad1[0x6]{};
};

struct trace_arr_element_t {
	char pad[0x30]{};
};

struct trace_data_t {
	std::int32_t uk1{};
	float uk2{ 52.f };
	void* arr_pointer{};
	std::int32_t uk3{ 128 };
	std::int32_t uk4{ static_cast<std::int32_t>(0x80000000) };
	std::array<trace_arr_element_t, 0x80> arr{};
	char pad0[0x8]{};
	std::int64_t num_update{};
	void* pointer_update_value{};
	char pad1[0xC8]{};
	vec3_t start{};
	vec3_t end{};
	char pad2[0x50]{};
};

struct bullet_pen_data_t {
	float damage{};
	float penetration{};
	float range_modifier{};
	float range{};
	int pen_count{};
	bool failed{};
};

struct pen_result_t {
	float damage{ 0.f };
	int hitgroup{ 0 };
	int hitbox{ 0 };
	bool hit{ false };
	bool penetrated{ false };
};

class c_autowall {
public:
	void scale_damage(int hitgroup, c_cs_player_pawn* entity, c_cs_weapon_base_v_data* weapon_data, float& damage);

	// True when TraceShape and/or DamageToPoint path can evaluate a shot.
	bool pen_ready() const;

	// Lefrizzel Fire(): TraceShape LOS → EstimateVisible; wall → DamageToPoint.
	// hitbox_id used for visible damage scale (HITBOX_*). -1 = chest.
	pen_result_t fire_bullet(
		const vec3_t& start,
		const vec3_t& end,
		c_cs_player_pawn* local,
		c_cs_player_pawn* target,
		c_cs_weapon_base_v_data* weapon_data,
		bool allow_penetration = true,
		int hitbox_id = -1);
};

} // namespace autowall

inline const auto g_autowall = std::make_unique<autowall::c_autowall>();
