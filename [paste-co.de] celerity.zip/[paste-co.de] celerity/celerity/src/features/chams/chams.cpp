#include "chams.hpp"
#include "chams_material.hpp"

#include "../../config.hpp"
#include "../../core/main.hpp"
#include "../../hooks/hooks.hpp"
#include "../../sdk/memsafe.hpp"
#include "../../sdk/typedefs/c_handle.hpp"
#include "../../sdk/valve/classes/c_cs_player_pawn.hpp"
#include "../../sdk/valve/interfaces/interfaces.hpp"
#include "../../sdk/includes/imgui/imgui.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <iterator>
#include <string>
#include <utility>

namespace {
	std::uint8_t to_u8(float v) {
		return static_cast<std::uint8_t>(std::clamp(v, 0.0f, 1.0f) * 255.0f + 0.5f);
	}

	std::uint32_t rgba_key(const ImVec4& c) {
		return (static_cast<std::uint32_t>(to_u8(c.x)) << 24)
			| (static_cast<std::uint32_t>(to_u8(c.y)) << 16)
			| (static_cast<std::uint32_t>(to_u8(c.z)) << 8)
			| static_cast<std::uint32_t>(to_u8(c.w < 0.15f ? 1.f : c.w));
	}

	chams_mesh_color_t to_mesh_color(const ImVec4& c) {
		const float a = (c.w < 0.15f) ? 1.f : c.w;
		return { to_u8(c.x), to_u8(c.y), to_u8(c.z), to_u8(a) };
	}

	// Bake RGB into g_vColorTint — vertex colour alone is ignored on many CS2 builds.
	std::string make_flat_kv(float r, float g, float b, bool ignore_z) {
		char buf[2048];
		std::snprintf(buf, sizeof(buf),
R"(<!-- kv3 encoding:text:version{e21c7f3c-8a33-41c5-9977-a76d3a32aa0d} format:generic:version{7412167c-06e9-4698-aff2-e63eb59037e7} -->
{
	Shader = "csgo_unlitgeneric.vfx"
	F_DISABLE_Z_BUFFERING = %d
	F_BLEND_MODE = 1
	F_TRANSLUCENT = 1
	g_vColorTint = [%.6f, %.6f, %.6f, 1.000000]
	g_tColor = resource:"materials/dev/primary_white_color_tga_f7b257f6.vtex"
	g_tNormal = resource:"materials/default/default_normal_tga_7652cb.vtex"
	g_tRoughness = resource:"materials/default/default_normal_tga_b3f4ec4c.vtex"
})",
			ignore_z ? 1 : 0, r, g, b);
		return buf;
	}

	std::string make_glow_kv(float r, float g, float b, bool ignore_z) {
		char buf[2560];
		std::snprintf(buf, sizeof(buf),
R"(<!-- kv3 encoding:text:version{e21c7f3c-8a33-41c5-9977-a76d3a32aa0d} format:generic:version{7412167c-06e9-4698-aff2-e63eb59037e7} -->
{
	Shader = "csgo_effects.vfx"
	g_flFresnelExponent = 7.0
	g_flFresnelFalloff = 10.0
	g_flFresnelMax = 0.1
	g_flFresnelMin = 1.0
	g_tColor = resource:"materials/dev/primary_white_color_tga_21186c76.vtex"
	g_tMask1 = resource:"materials/default/default_mask_tga_fde710a5.vtex"
	g_tMask2 = resource:"materials/default/default_mask_tga_fde710a5.vtex"
	g_tMask3 = resource:"materials/default/default_mask_tga_fde710a5.vtex"
	g_tSceneDepth = resource:"materials/default/default_mask_tga_fde710a5.vtex"
	g_flToolsVisCubemapReflectionRoughness = 1.0
	g_flBeginMixingRoughness = 1.0
	g_vColorTint = [ %.6f, %.6f, %.6f, 1.000000 ]
	F_IGNOREZ = %d
	F_DISABLE_Z_WRITE = %d
	F_DISABLE_Z_BUFFERING = %d
	F_RENDER_BACKFACES = 0
})",
			r, g, b, ignore_z ? 1 : 0, ignore_z ? 1 : 0, ignore_z ? 1 : 0);
		return buf;
	}

	std::string make_ghost_kv(float r, float g, float b, bool ignore_z) {
		char buf[2560];
		std::snprintf(buf, sizeof(buf),
R"(<!-- kv3 encoding:text:version{e21c7f3c-8a33-41c5-9977-a76d3a32aa0d} format:generic:version{7412167c-06e9-4698-aff2-e63eb59037e7} -->
{
	Shader = "csgo_effects.vfx"
	g_tColor = resource:"materials/dev/primary_white_color_tga_21186c76.vtex"
	g_tNormal = resource:"materials/default/default_normal_tga_7652cb.vtex"
	g_tMask1 = resource:"materials/default/default_mask_tga_344101f8.vtex"
	g_tMask2 = resource:"materials/default/default_mask_tga_344101f8.vtex"
	g_tMask3 = resource:"materials/default/default_mask_tga_344101f8.vtex"
	g_flOpacityScale = 0.45
	g_flFresnelExponent = 0.75
	g_flFresnelFalloff = 1
	g_flFresnelMax = 0.0
	g_flFresnelMin = 1
	F_ADDITIVE_BLEND = 1
	F_BLEND_MODE = 0
	F_TRANSLUCENT = 1
	F_IGNOREZ = %d
	F_DISABLE_Z_WRITE = %d
	F_DISABLE_Z_BUFFERING = %d
	F_RENDER_BACKFACES = 1
	g_vColorTint = [%.6f, %.6f, %.6f, 1.000000]
})",
			ignore_z ? 1 : 0, ignore_z ? 1 : 0, ignore_z ? 1 : 0, r, g, b);
		return buf;
	}

	std::string make_solid_kv(float r, float g, float b, bool ignore_z) {
		char buf[2560];
		std::snprintf(buf, sizeof(buf),
R"(<!-- kv3 encoding:text:version{e21c7f3c-8a33-41c5-9977-a76d3a32aa0d} format:generic:version{7412167c-06e9-4698-aff2-e63eb59037e7} -->
{
	Shader = "solidcolor.vfx"
	F_BLEND_MODE = 1
	g_tColor = resource:"materials/dev/primary_white_color_tga_21186c76.vtex"
	g_tNormal = resource:"materials/default/default_normal_tga_7652cb.vtex"
	g_tRoughness = resource:"materials/default/default_normal_tga_b3f4ec4c.vtex"
	g_tMetalness = resource:"materials/default/default_normal_tga_b3f4ec4c.vtex"
	g_tAmbientOcclusion = resource:"materials/default/default_normal_tga_b3f4ec4c.vtex"
	F_IGNOREZ = %d
	F_DISABLE_Z_WRITE = %d
	F_DISABLE_Z_BUFFERING = %d
	F_RENDER_BACKFACES = 0
	g_vColorTint = [%.6f, %.6f, %.6f, 1.000000]
})",
			ignore_z ? 1 : 0, ignore_z ? 1 : 0, ignore_z ? 1 : 0, r, g, b);
		return buf;
	}

	std::string make_metallic_kv(float r, float g, float b, bool ignore_z) {
		char buf[2560];
		std::snprintf(buf, sizeof(buf),
R"(<!-- kv3 encoding:text:version{e21c7f3c-8a33-41c5-9977-a76d3a32aa0d} format:generic:version{7412167c-06e9-4698-aff2-e63eb59037e7} -->
{
	Shader = "csgo_complex.vfx"
	F_TRANSLUCENT = 1
	F_DISABLE_Z_PREPASS = 1
	F_DISABLE_Z_WRITE = 1
	F_BLEND_MODE = 1
	F_DISABLE_Z_BUFFERING = %d
	F_RENDER_BACKFACES = 0
	g_vColorTint = [%.6f, %.6f, %.6f, 1.000000]
	g_bFogEnabled = 0
	g_flMetalness = 1.000
	g_flModelTintAmount = 1.000
	g_tColor = resource:"materials/dev/primary_white_color_tga_21186c76.vtex"
	g_tAmbientOcclusion = resource:"materials/default/default_ao_tga_559f1ac6.vtex"
	g_tNormal = resource:"materials/default/default_normal_tga_1b833b2a.vtex"
})",
			ignore_z ? 1 : 0, r, g, b);
		return buf;
	}

	c_base_entity* get_base_entity_safe(int index) {
		if (!g_interfaces || !g_interfaces->m_entity_system)
			return nullptr;
		__try {
			return g_interfaces->m_entity_system->get_base_entity(index);
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return nullptr;
		}
	}

	__declspec(noinline) int entry_index_of(c_entity_instance* e) {
		__try {
			if (!e)
				return -1;
			const c_base_handle handle = e->get_handle();
			return handle.is_valid() ? handle.get_entry_index() : -1;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return -1;
		}
	}

	c_cs_player_pawn* resolve_enemy_pawn(int i, c_cs_player_pawn* local) {
		__try {
			auto* entity = get_base_entity_safe(i);
			if (!entity || !entity->is_player_controller())
				return nullptr;
			auto* controller = reinterpret_cast<c_cs_player_controller*>(entity);
			const c_base_handle pawn_handle = controller->m_pawn();
			if (!pawn_handle.is_valid())
				return nullptr;
			auto* pawn = reinterpret_cast<c_cs_player_pawn*>(get_base_entity_safe(pawn_handle.get_entry_index()));
			if (!pawn || pawn->m_health() <= 0)
				return nullptr;
			if (pawn->m_team_num() == local->m_team_num())
				return nullptr;
			return pawn;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return nullptr;
		}
	}

	c_cs_player_pawn* resolve_teammate_pawn(int i, c_cs_player_pawn* local) {
		__try {
			auto* entity = get_base_entity_safe(i);
			if (!entity || !entity->is_player_controller())
				return nullptr;
			auto* controller = reinterpret_cast<c_cs_player_controller*>(entity);
			const c_base_handle pawn_handle = controller->m_pawn();
			if (!pawn_handle.is_valid())
				return nullptr;
			auto* pawn = reinterpret_cast<c_cs_player_pawn*>(get_base_entity_safe(pawn_handle.get_entry_index()));
			if (!pawn || pawn->m_health() <= 0 || pawn == local)
				return nullptr;
			if (pawn->m_team_num() != local->m_team_num())
				return nullptr;
			return pawn;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return nullptr;
		}
	}

	c_base_entity* resolve_arms_entity(c_cs_player_pawn* local) {
		__try {
			const c_base_handle arms_handle = local->m_hud_model_arms();
			if (!arms_handle.is_valid())
				return nullptr;
			return get_base_entity_safe(arms_handle.get_entry_index());
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return nullptr;
		}
	}

	// Limit depth — round/team rebuild leaves sibling/child pointers dangling.
	int collect_entity_subtree_owners(c_base_entity* entity, const void** out, int max) {
		int n = 0;
		__try {
			if (!entity || !memsafe::valid_entity(entity))
				return 0;
			auto* root = entity->m_scene_node();
			if (!root || !memsafe::valid_scene_node(root))
				return 0;
			c_game_scene_node* stack[64];
			int sp = 0;
			int visited = 0;
			stack[sp++] = root;
			while (sp > 0 && visited < 96) {
				c_game_scene_node* node = stack[--sp];
				++visited;
				if (!node || !memsafe::valid_scene_node(node))
					continue;
				int sibling_guard = 0;
				for (auto* sn = node; sn && sibling_guard < 48; sn = sn->m_next_sibling(), ++sibling_guard) {
					if (!sn || !memsafe::valid_scene_node(sn))
						break;
					if (auto* owner = sn->m_owner()) {
						if (!memsafe::valid_entity(owner))
							continue;
						bool seen = false;
						for (int i = 0; i < n; ++i) {
							if (out[i] == static_cast<const void*>(owner)) {
								seen = true;
								break;
							}
						}
						if (!seen && n < max)
							out[n++] = static_cast<const void*>(owner);
					}
					if (auto* child = sn->m_child()) {
						if (child && memsafe::valid_scene_node(child) && sp < 64)
							stack[sp++] = child;
					}
				}
			}
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return n;
		}
		return n;
	}

	// Probe several owner-handle slots — layout drifts across builds.
	std::uint32_t owner_handle_from_animatable(void* scene_animatable) {
		if (!scene_animatable)
			return 0xFFFFFFFFu;
		__try {
			auto* base = reinterpret_cast<std::uint8_t*>(scene_animatable);
			static const std::ptrdiff_t k_offs[] = {
				0xB8, 0xC0, 0xD0, 0xE0, 0xF0, 0x100, 0x110, 0x120
			};
			for (auto off : k_offs) {
				const std::uint32_t h = *reinterpret_cast<std::uint32_t*>(base + off);
				const int idx = static_cast<int>(h & 0x7FFFu);
				if (idx <= 0 || idx > 0x3FFF)
					continue;
				auto* ent = get_base_entity_safe(idx);
				if (!ent)
					continue;
				auto* pawn = reinterpret_cast<c_cs_player_pawn*>(ent);
				if (pawn->m_health() > 0 && pawn->m_team_num() >= 2)
					return h;
			}
			for (auto off : k_offs) {
				const std::uint32_t h = *reinterpret_cast<std::uint32_t*>(base + off);
				if (h && h != 0xFFFFFFFFu) {
					const int idx = static_cast<int>(h & 0x7FFFu);
					if (idx > 0 && idx <= 0x3FFF && get_base_entity_safe(idx))
						return h;
				}
			}
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
		}
		return 0xFFFFFFFFu;
	}

	void apply_color_prim(c_mesh_primitive* prim, const ImVec4& c) {
		const auto mc = to_mesh_color(c);
		prim->m_color = { mc.r, mc.g, mc.b, mc.a };
	}
}

c_material_2* c_chams::material_for(int style, bool occluded, const ImVec4& color) {
	style = std::clamp(style, 0, style_count - 1);
	const mat_cache_key key{ style, occluded, rgba_key(color) };
	auto it = m_mat_cache.find(key);
	if (it != m_mat_cache.end())
		return it->second;

	const float r = std::clamp(color.x, 0.f, 1.f);
	const float g = std::clamp(color.y, 0.f, 1.f);
	const float b = std::clamp(color.z, 0.f, 1.f);

	std::string kv;
	switch (style) {
	case style_glow:     kv = make_glow_kv(r, g, b, occluded); break;
	case style_ghost:    kv = make_ghost_kv(r, g, b, occluded); break;
	case style_textured: kv = make_solid_kv(r, g, b, occluded); break;
	case style_metallic: kv = make_metallic_kv(r, g, b, occluded); break;
	default:             kv = make_flat_kv(r, g, b, occluded); break;
	}

	char name[96];
	std::snprintf(name, sizeof(name), "materials/celerity/chams_%d_%08x.vmat",
		style | (occluded ? 0x10 : 0), key.rgba);

	c_material_2* mat = create_custom_material(name, kv.c_str());
	if (mat)
		m_mat_cache.emplace(key, mat);
	return mat;
}

void c_chams::ensure_init() {
	if (m_initialized)
		return;
	// Seed a default flat material so we know CreateMaterial/LoadKV3 work.
	ImVec4 white(1.f, 1.f, 1.f, 1.f);
	if (material_for(style_flat, false, white))
		m_initialized = true;
}

void c_chams::clear_targets() {
	std::lock_guard<std::mutex> lock(m_targets_mutex);
	m_targets.clear();
	m_target_indices.clear();
}

namespace {
	__declspec(noinline) bool engine_ready_for_chams() {
		if (!g_interfaces || !g_interfaces->m_engine)
			return false;
		__try {
			return g_interfaces->m_engine->is_in_game() && g_interfaces->m_engine->is_connected();
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return false;
		}
	}
}

void c_chams::refresh_targets() {
	if (hooks::in_entity_transition())
		return;
	if (!engine_ready_for_chams())
		return;

	struct resolved_ref { const void* ptr; int index; int target; };
	resolved_ref resolved[256];
	int resolved_count = 0;
	const auto push = [&](const void* p, int t) {
		if (p && resolved_count < static_cast<int>(std::size(resolved))) {
			const int idx = entry_index_of(reinterpret_cast<c_entity_instance*>(const_cast<void*>(p)));
			resolved[resolved_count++] = { p, idx, t };
		}
	};

	if (g_ctx && g_ctx->m_local_pawn && memsafe::valid_entity(g_ctx->m_local_pawn)
		&& g_interfaces && g_interfaces->m_entity_system) {
		auto* local = reinterpret_cast<c_cs_player_pawn*>(g_ctx->m_local_pawn);
		if (!local->m_scene_node()) {
			// Pawn half-built during map load — skip subtree walk.
		} else {
			for (int i = 1; i <= 64; ++i) {
				if (auto* pawn = resolve_enemy_pawn(i, local))
					push(pawn, target_enemy);
				else if (auto* mate = resolve_teammate_pawn(i, local))
					push(mate, target_teammate);
			}

			const void* local_owners[64] = {};
			const int local_count = collect_entity_subtree_owners(local, local_owners, 64);
			for (int k = 0; k < local_count; ++k)
				push(local_owners[k], target_arms);
			push(static_cast<const void*>(local), target_arms);

			if (auto* arms = resolve_arms_entity(local)) {
				const void* vm_owners[64] = {};
				const int vm_count = collect_entity_subtree_owners(arms, vm_owners, 64);
				for (int k = 0; k < vm_count; ++k)
					push(vm_owners[k], target_viewmodel);
				push(static_cast<const void*>(arms), target_arms);
			}
		}
	}

	std::lock_guard<std::mutex> lock(m_targets_mutex);
	for (auto it = m_targets.begin(); it != m_targets.end(); ) {
		if (--it->second.ttl <= 0)
			it = m_targets.erase(it);
		else
			++it;
	}
	for (auto it = m_target_indices.begin(); it != m_target_indices.end(); ) {
		if (--it->second.ttl <= 0)
			it = m_target_indices.erase(it);
		else
			++it;
	}
	for (int k = 0; k < resolved_count; ++k) {
		m_targets[resolved[k].ptr] = { resolved[k].target, k_target_ttl };
		if (resolved[k].index >= 0)
			m_target_indices[resolved[k].index] = { resolved[k].target, k_target_ttl };
	}
}

int c_chams::classify(const void* entity, int entry_index) {
	std::lock_guard<std::mutex> lock(m_targets_mutex);
	if (entity) {
		auto it = m_targets.find(entity);
		if (it != m_targets.end())
			return it->second.target;
	}
	if (entry_index >= 0) {
		auto it = m_target_indices.find(entry_index);
		if (it != m_target_indices.end())
			return it->second.target;
	}
	return -1;
}

bool c_chams::on_draw_object(void* desc, void* dx11, c_mesh_data* mesh, int count,
                             void* view, void* layer, void* unk, void* unk2, draw_object_fn original) {
	if (!g_cfg || !m_initialized || !mesh || !original)
		return false;
	if (hooks::in_entity_transition())
		return false;

	bool any_enabled = false;
	for (int t = 0; t < target_count; ++t) {
		const auto& ct = g_cfg->visuals.m_chams_targets[t];
		if (ct.m_visible || ct.m_occluded) {
			any_enabled = true;
			break;
		}
	}
	if (!any_enabled)
		return false;

	const std::uint32_t handle = owner_handle_from_animatable(mesh->scene_animatable_object);
	if (!handle || handle == 0xFFFFFFFFu)
		return false;

	const int owner_index = static_cast<int>(handle & 0x7FFFu);
	const void* owner_entity = get_base_entity_safe(owner_index);
	const int target = classify(owner_entity, owner_index);
	if (target < 0)
		return false;

	const auto& ct = g_cfg->visuals.m_chams_targets[target];
	if (!ct.m_visible && !ct.m_occluded)
		return false;

	__try {
		if (ct.m_occluded) {
			if (auto* mat = material_for(ct.m_occluded_material, true, ct.m_occluded_color)) {
				mesh->material = mat;
				mesh->material2 = mat;
				mesh->color = to_mesh_color(ct.m_occluded_color);
				original(desc, dx11, mesh, count, view, layer, unk, unk2);
			}
		}
		if (ct.m_visible) {
			if (auto* mat = material_for(ct.m_visible_material, false, ct.m_visible_color)) {
				mesh->material = mat;
				mesh->material2 = mat;
				mesh->color = to_mesh_color(ct.m_visible_color);
				original(desc, dx11, mesh, count, view, layer, unk, unk2);
			}
		} else if (!ct.m_occluded) {
			return false;
		}
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {
		return false;
	}
	return true;
}

bool c_chams::on_generate_primitives(c_animatable_scene_object_desc* desc, c_scene_animatable_object* object,
                                     void* a3, c_mesh_primitive_output_buffer* render_buf, generate_primitives_fn original) {
	if (!g_cfg || !m_initialized || !object || !render_buf || !original)
		return false;
	if (hooks::in_entity_transition())
		return false;

	bool any_enabled = false;
	for (int t = 0; t < target_count; ++t) {
		const auto& ct = g_cfg->visuals.m_chams_targets[t];
		if (ct.m_visible || ct.m_occluded) {
			any_enabled = true;
			break;
		}
	}
	if (!any_enabled)
		return false;

	const void* owner_entity = nullptr;
	int owner_index = -1;
	__try {
		const std::uint32_t handle = owner_handle_from_animatable(object);
		if (handle && handle != 0xFFFFFFFFu) {
			owner_index = static_cast<int>(handle & 0x7FFFu);
			owner_entity = get_base_entity_safe(owner_index);
		}
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {
		return false;
	}

	const int target = classify(owner_entity, owner_index);
	if (target < 0)
		return false;

	const auto& ct = g_cfg->visuals.m_chams_targets[target];
	if (!ct.m_visible && !ct.m_occluded)
		return false;

	const auto emit_pass = [&](c_material_2* material, const ImVec4& color) {
		if (!material)
			return;
		const int prev = render_buf->m_arr_size;
		original(desc, object, a3, render_buf);
		for (int i = prev; i < render_buf->m_arr_size; ++i) {
			c_mesh_primitive* prim = render_buf->get_primitive(i);
			if (!prim)
				continue;
			prim->m_material = material;
			prim->m_material2 = material;
			apply_color_prim(prim, color);
		}
	};

	bool drew = false;
	__try {
		if (ct.m_occluded) {
			if (auto* mat = material_for(ct.m_occluded_material, true, ct.m_occluded_color)) {
				emit_pass(mat, ct.m_occluded_color);
				drew = true;
			}
		}
		if (ct.m_visible) {
			if (auto* mat = material_for(ct.m_visible_material, false, ct.m_visible_color)) {
				emit_pass(mat, ct.m_visible_color);
				drew = true;
			}
		}
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {
		return false;
	}
	return drew;
}
