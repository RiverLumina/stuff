#pragma once

#include "chams_material.hpp"

#include <memory>
#include <mutex>
#include <unordered_map>

#include "../../sdk/includes/imgui/imgui.h"

class c_animatable_scene_object_desc;
class c_scene_animatable_object;
class c_mesh_primitive_output_buffer;

// Chams: DrawObject primary path (working CS2 internal base), with GeneratePrimitives
// kept as a secondary path. Materials bake RGB into g_vColorTint — mesh vertex colour
// alone is ignored on many CS2 builds.
class c_chams {
public:
	using generate_primitives_fn = void*(__fastcall*)(c_animatable_scene_object_desc*, c_scene_animatable_object*, void*, c_mesh_primitive_output_buffer*);
	using draw_object_fn = void(__fastcall*)(void*, void*, c_mesh_data*, int, void*, void*, void*, void*);

	enum { style_flat = 0, style_glow = 1, style_ghost = 2, style_textured = 3, style_metallic = 4, style_count = 5 };
	enum { target_enemy = 0, target_teammate = 1, target_arms = 2, target_viewmodel = 3, target_count = 4 };

	void ensure_init();
	void refresh_targets();
	void clear_targets();

	// Primary: scenesystem DrawObject. Returns true if original was already invoked.
	bool on_draw_object(void* desc, void* dx11, c_mesh_data* mesh, int count,
	                    void* view, void* layer, void* unk, void* unk2, draw_object_fn original);

	// Secondary: GeneratePrimitives material swap.
	bool on_generate_primitives(c_animatable_scene_object_desc* desc, c_scene_animatable_object* object,
	                            void* a3, c_mesh_primitive_output_buffer* render_buf, generate_primitives_fn original);

private:
	int classify(const void* entity, int entry_index);
	c_material_2* material_for(int style, bool occluded, const ImVec4& color);

	bool m_initialized = false;

	static constexpr int k_target_ttl = 8;
	struct target_entry {
		int target;
		int ttl;
	};

	std::mutex                                    m_targets_mutex;
	std::unordered_map<const void*, target_entry> m_targets;
	std::unordered_map<int, target_entry>         m_target_indices;

	// Cached baked-tint materials keyed by (style, occluded, rgba).
	struct mat_cache_key {
		int style;
		bool occluded;
		std::uint32_t rgba;
		bool operator==(const mat_cache_key& o) const {
			return style == o.style && occluded == o.occluded && rgba == o.rgba;
		}
	};
	struct mat_cache_hash {
		std::size_t operator()(const mat_cache_key& k) const {
			return (static_cast<std::size_t>(k.style) << 25)
				^ (static_cast<std::size_t>(k.occluded) << 24)
				^ k.rgba;
		}
	};
	std::unordered_map<mat_cache_key, c_material_2*, mat_cache_hash> m_mat_cache;
};

inline const auto g_chams = std::make_unique<c_chams>();
