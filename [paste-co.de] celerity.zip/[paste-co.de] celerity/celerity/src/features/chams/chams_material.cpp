#include "chams_material.hpp"

#include "../../core/main.hpp"
#include "../../sdk/valve/signatures/signatures.hpp"

#include <Windows.h>
#include <cstdio>
#include <cstring>
#include <iterator>

namespace {
	struct kv3_id_t {
		const char*   m_name;
		std::uint64_t m_unk0;
		std::uint64_t m_unk1;
	};

	struct resource_binding_t {
		void* data;
	};

	struct strong_handle_t {
		const resource_binding_t* binding = nullptr;
		void* material() const { return binding ? binding->data : nullptr; }
	};

	class utl_buffer_t {
	public:
		char _pad[0x80];
	};

	class c_key_values_3 {
	public:
		char          pad_0000[0x100];
		std::uint64_t m_key;
		void*         m_value;
		char          pad_0110[0x8];
	};

	// Matches format:generic:version{7412167c-06e9-4698-aff2-e63eb59037e7}
	constexpr kv3_id_t k_generic_kv3{ "generic", 0x469806E97412167Cull, 0xE73790B53EE6F2AFull };

	using ctor_utlbuffer_fn   = utl_buffer_t* (__fastcall*)(utl_buffer_t*, int, int, int);
	using putstring_fn        = void          (__fastcall*)(utl_buffer_t*, const char*);
	using loadkv3_buffer_fn   = bool          (__fastcall*)(c_key_values_3*, void*, utl_buffer_t*, const kv3_id_t*, const char*);
	using loadkv3_string_fn   = bool          (__cdecl*)(void*, void*, const char*, const kv3_id_t*, const char*, unsigned);
	using setkv3type_fn       = void*         (__fastcall*)(void*, unsigned int, unsigned int);
	using create_material_fn  = void          (__fastcall*)(void*, strong_handle_t*, const char*, void*, int, int);

	struct natives_t {
		ctor_utlbuffer_fn  ctor_utlbuffer   = nullptr;
		putstring_fn       put_string       = nullptr;
		loadkv3_buffer_fn  load_kv3_buffer  = nullptr;
		loadkv3_string_fn  load_kv3_string  = nullptr;
		setkv3type_fn      set_kv3_type     = nullptr;
		create_material_fn create_material  = nullptr;
		bool               tried            = false;
		bool               ok               = false;
	};

	natives_t& natives() {
		static natives_t n;
		if (n.tried)
			return n;
		n.tried = true;

		if (const HMODULE tier0 = GetModuleHandleA("tier0.dll")) {
			n.ctor_utlbuffer = reinterpret_cast<ctor_utlbuffer_fn>(
				GetProcAddress(tier0, "??0CUtlBuffer@@QEAA@HHW4BufferFlags_t@0@@Z"));
			n.put_string = reinterpret_cast<putstring_fn>(
				GetProcAddress(tier0, "?PutString@CUtlBuffer@@QEAAXPEBD@Z"));
			n.load_kv3_buffer = reinterpret_cast<loadkv3_buffer_fn>(
				GetProcAddress(tier0, "?LoadKV3@@YA_NPEAVKeyValues3@@PEAVCUtlString@@PEAVCUtlBuffer@@AEBUKV3ID_t@@PEBDI@Z"));

			// String LoadKV3 — used by the known-working CS2 internal base.
			n.load_kv3_string = reinterpret_cast<loadkv3_string_fn>(
				GetProcAddress(tier0, "?LoadKV3@@YA_NPEAVKeyValues3@@PEAVCUtlString@@PEBDAEBUKV3ID_t@@2I@Z"));
			if (!n.load_kv3_string) {
				n.load_kv3_string = reinterpret_cast<loadkv3_string_fn>(
					GetProcAddress(tier0, "?LoadKV3@@YA_NPEAVKeyValues3@@PEAVCUtlString@@PEBDAEBUKV3ID_t@@2@Z"));
			}
		}

		n.set_kv3_type = reinterpret_cast<setkv3type_fn>(SIG("KV3_SetType"));
		if (!n.set_kv3_type) {
			// Fallback: client.dll pattern from working base.
			n.set_kv3_type = reinterpret_cast<setkv3type_fn>(
				g_opcodes->scan("client.dll",
					"40 53 48 83 EC 30 80 FA 06 0F B6 C2 41 B9 16 00 00 00 48 8B D9 44 0F 45 C8"));
		}
		if (!n.set_kv3_type) {
			n.set_kv3_type = reinterpret_cast<setkv3type_fn>(
				g_opcodes->scan("client.dll", "40 53 48 83 EC 20 48 8B 01 48 8B D9 44"));
		}

		n.create_material = reinterpret_cast<create_material_fn>(SIG("CreateMaterial"));

		n.ok = n.create_material
			&& n.set_kv3_type
			&& (n.load_kv3_string || (n.load_kv3_buffer && n.ctor_utlbuffer && n.put_string));
		return n;
	}

	void* mem_alloc(std::size_t size) {
		if (HMODULE tier0 = GetModuleHandleA("tier0.dll")) {
			if (auto** pp = reinterpret_cast<void***>(GetProcAddress(tier0, "g_pMemAlloc"))) {
				if (*pp) {
					using alloc_fn = void*(__fastcall*)(void*, std::size_t);
					void** vt = *reinterpret_cast<void***>(*pp);
					if (vt && vt[1])
						return reinterpret_cast<alloc_fn>(vt[1])(*pp, size);
				}
			}
		}
		return VirtualAlloc(nullptr, size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	}
}

c_material_2* create_custom_material(const char* material_name, const char* kv3_buffer) {
	const natives_t& n = natives();
	if (!n.ok || !material_name || !kv3_buffer)
		return nullptr;

	__try {
		auto* raw = static_cast<std::uint8_t*>(mem_alloc(0x100 + 0x200));
		if (!raw)
			return nullptr;
		std::memset(raw, 0, 0x100 + 0x200);
		void* kv = raw + 0x100;

		if (n.set_kv3_type)
			kv = n.set_kv3_type(kv, 1U, 6U);

		bool ok = false;
		if (n.load_kv3_string) {
			ok = n.load_kv3_string(kv, nullptr, kv3_buffer, &k_generic_kv3, nullptr, 0);
			if (!ok)
				ok = n.load_kv3_string(kv, nullptr, kv3_buffer, &k_generic_kv3, "", 0);
		} else if (n.load_kv3_buffer) {
			const int len = static_cast<int>(std::strlen(kv3_buffer));
			utl_buffer_t buf{};
			n.ctor_utlbuffer(&buf, 0, len + 1, 1);
			n.put_string(&buf, kv3_buffer);
			ok = n.load_kv3_buffer(reinterpret_cast<c_key_values_3*>(kv), nullptr, &buf, &k_generic_kv3, nullptr);
		}
		if (!ok)
			return nullptr;

		strong_handle_t out{};
		n.create_material(nullptr, &out, material_name, kv, 0, 1);
		return reinterpret_cast<c_material_2*>(out.material());
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {
		return nullptr;
	}
}

namespace {
	constexpr int k_find_or_create_material_index = 14;
	using find_or_create_material_fn = void** (__fastcall*)(void* material_system, void** out, const char* name);

	void* material_system_interface() {
		static void* iface = get_interface(&g_modules->m_modules.materialsystem2_dll, xorstr_("VMaterialSystem2_001"));
		return iface;
	}

	struct sky_def_t {
		const char* label;
		const char* resource;
	};

	constexpr sky_def_t k_skies[] = {
		{ "space",           "materials/skybox/space.vmat"           },
		{ "vaporwave",       "materials/skybox/vaporwave.vmat"       },
		{ "nebula",          "materials/skybox/nebula.vmat"          },
		{ "aurora",          "materials/skybox/aurora.vmat"          },
		{ "clear sky",       "materials/skybox/clearsky.vmat"        },
		{ "evening",         "materials/skybox/evening.vmat"         },
		{ "ocean sunset",    "materials/skybox/ocean_sunset.vmat"    },
		{ "northern lights", "materials/skybox/northern_lights.vmat" },
		{ "red planet",      "materials/skybox/red_planet.vmat"      },
		{ "miramar",         "materials/skybox/miramar.vmat"         },
	};
	static_assert(std::size(k_skies) + 1 == k_sky_override_count);
}

c_material_2* find_material_by_path(const char* path) {
	if (!path)
		return nullptr;

	void* material_system = material_system_interface();
	if (!material_system)
		return nullptr;

	__try {
		char name[256];
		std::strncpy(name, path, sizeof(name) - 1);
		name[sizeof(name) - 1] = '\0';
		const std::size_t len = std::strlen(name);
		if (len >= 2 && name[len - 2] == '_' && name[len - 1] == 'c')
			name[len - 2] = '\0';

		auto fn = vmt::get_v_method<find_or_create_material_fn>(material_system, k_find_or_create_material_index);
		if (!fn)
			return nullptr;

		void* out = nullptr;
		void** result = fn(material_system, &out, name);
		if (!result)
			return nullptr;
		return *reinterpret_cast<c_material_2**>(result);
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {
		return nullptr;
	}
}

const char* const* sky_override_names() {
	static const char* names[k_sky_override_count] = { "none" };
	static bool built = false;
	if (!built) {
		for (int i = 0; i < static_cast<int>(std::size(k_skies)); ++i)
			names[i + 1] = k_skies[i].label;
		built = true;
	}
	return names;
}

c_material_2* get_override_sky_material(int index) {
	if (index <= 0 || index >= k_sky_override_count)
		return nullptr;

	static c_material_2* cache[k_sky_override_count] = {};
	if (cache[index])
		return cache[index];

	cache[index] = find_material_by_path(k_skies[index - 1].resource);
	return cache[index];
}
