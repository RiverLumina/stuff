#pragma once

#include "../../sdk/valve/classes/c_scene_object.hpp"   // c_scene_animatable_object, c_material_2

#include <cstddef>
#include <cstdint>

struct chams_mesh_color_t {
	std::uint8_t r, g, b, a;
};

// DrawObject mesh descriptor — colour is INLINE at 0x40 (matches working CS2 internal base).
class c_mesh_data {
public:
	char                       pad_0[0x18];             // 0x00
	c_scene_animatable_object* scene_animatable_object; // 0x18
	c_material_2*              material;                // 0x20
	c_material_2*              material2;               // 0x28
	char                       pad_1[0x10];             // 0x30
	chams_mesh_color_t         color;                   // 0x40
};

static_assert(offsetof(c_mesh_data, scene_animatable_object) == 0x18);
static_assert(offsetof(c_mesh_data, material) == 0x20);
static_assert(offsetof(c_mesh_data, color) == 0x40);

// Build a custom material from a KV3 (.vmat) text buffer. Frame-safe context only.
c_material_2* create_custom_material(const char* material_name, const char* kv3_buffer);

c_material_2* find_material_by_path(const char* path);

inline constexpr int k_sky_override_count = 11;
const char* const* sky_override_names();
c_material_2*      get_override_sky_material(int index);
