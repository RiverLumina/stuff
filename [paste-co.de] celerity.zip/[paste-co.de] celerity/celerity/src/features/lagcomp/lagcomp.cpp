#include "lagcomp.hpp"

#include "../prediction/prediction.hpp"
#include "../../core/main.hpp"
#include "../../sdk/memsafe.hpp"
#include "../../sdk/valve/classes/c_cs_player_pawn.hpp"

#include <algorithm>
#include <cmath>
#include <cstring>

namespace {
void* entity_by_index(int index) {
	if (!g_interfaces || !g_interfaces->m_entity_system)
		return nullptr;
	return g_interfaces->m_entity_system->get_base_entity(index);
}

c_bone_data* live_bone_array(c_cs_player_pawn* pawn, int& out_count) {
	out_count = 0;
	if (!pawn || !memsafe::valid_entity(pawn))
		return nullptr;

	auto* scene = pawn->m_scene_node();
	if (!scene || !memsafe::valid_scene_node(scene))
		return nullptr;

	auto* skeleton = scene->get_skeleton_instance();
	if (!skeleton)
		return nullptr;

	auto* bones = skeleton->m_model_state().get_bone_data();
	if (!bones)
		return nullptr;

	// Bone count isn't a reliable SCHEMA field on this build — clamp to max.
	out_count = lag_record_t::k_max_bones;
	return bones;
}
} // namespace

c_lagcomp::c_lagcomp()
	: m_players(std::make_unique<player_history_t[]>(k_max_players)) {
}

c_lagcomp::~c_lagcomp() = default;

bool lag_record_t::store(c_cs_player_pawn* pawn) {
	m_valid = false;
	m_bone_count = 0;
	m_head = {};

	if (!pawn || !memsafe::valid_entity(pawn) || !pawn->is_alive())
		return false;

	auto* scene = pawn->m_scene_node();
	if (!scene || !memsafe::valid_scene_node(scene))
		return false;

	auto* skeleton = scene->get_skeleton_instance();
	if (!skeleton)
		return false;

	m_origin = scene->m_abs_origin();
	if (!m_origin.is_valid())
		return false;

	m_velocity = pawn->m_vec_abs_velocity();
	if (!m_velocity.is_valid())
		m_velocity = {};

	m_flags = pawn->m_flags();
	m_simulation_time = pawn->m_sim_time();
	m_throwing = pawn->is_throwing();

	if (auto* col = pawn->m_collision()) {
		m_mins = col->m_mins();
		m_maxs = col->m_maxs();
	}

	int live_count = 0;
	c_bone_data* live = live_bone_array(pawn, live_count);
	if (!live || live_count <= 0)
		return false;

	m_bone_count = live_count;
	std::memcpy(m_bones, live, sizeof(c_bone_data) * static_cast<std::size_t>(m_bone_count));

	// Drop records with garbage bone positions (avoids poisoning HC).
	for (int i = 0; i < m_bone_count; ++i) {
		if (!m_bones[i].m_pos.is_valid())
			return false;
	}

	if (m_bone_count > 6 && m_bones[6].m_pos.is_valid() && !m_bones[6].m_pos.is_zero())
		m_head = m_bones[6].m_pos;
	else
		m_head = { m_origin.x, m_origin.y, m_origin.z + 72.f };

	m_valid = m_simulation_time > 0.f;
	return m_valid;
}

bool lag_record_t::is_valid(float reference_time, float max_unlag) const {
	if (!m_valid || m_simulation_time <= 0.f || reference_time <= 0.f)
		return false;

	// reference_time ≈ server time when THIS cmd gets processed (local tick
	// base). The server can only rewind a shot to poses younger than
	// sv_maxunlag at arrival — so a record is shootable iff its age at that
	// moment is inside the window. The old "+0.05" slack let us aim at poses
	// the server had already discarded (guaranteed miss on max backtrack).
	const float delta = reference_time - m_simulation_time;
	if (delta < -0.02f || delta > max_unlag - 2.f * INTERVAL_PER_TICK)
		return false;
	return true;
}

void c_lagcomp::set_max_unlag(float seconds) {
	m_max_unlag = std::clamp(seconds, 0.05f, 1.0f);
}

int c_lagcomp::max_ticks() const {
	return std::clamp(TIME_TO_TICKS(m_max_unlag), 2, k_max_records - 1);
}

void c_lagcomp::reset() {
	if (!m_players)
		return;
	for (int i = 0; i < k_max_players; ++i) {
		m_players[i] = {};
	}
	m_applied_record = nullptr;
	m_applied_pawn = nullptr;
	m_apply_backup_count = 0;
}

float c_lagcomp::reference_time() const {
	if (g_prediction) {
		if (const auto* data = g_prediction->get_local_data()) {
			if (data->m_tick_base > 0)
				return static_cast<float>(data->m_tick_base) * INTERVAL_PER_TICK;
		}
	}

	if (g_ctx) {
		if (auto* controller = reinterpret_cast<c_cs_player_controller*>(g_ctx->m_local_controller)) {
			if (memsafe::valid_entity(controller)) {
				const int tb = static_cast<int>(controller->m_tick_base());
				if (tb > 0)
					return static_cast<float>(tb) * INTERVAL_PER_TICK;
			}
		}

		if (auto* pawn = reinterpret_cast<c_cs_player_pawn*>(g_ctx->m_local_pawn)) {
			if (memsafe::valid_entity(pawn)) {
				const float sim = pawn->m_sim_time();
				if (sim > 0.f)
					return sim;
			}
		}
	}

	if (g_interfaces && g_interfaces->m_global_vars && g_interfaces->m_global_vars->m_current_time > 0.f)
		return g_interfaces->m_global_vars->m_current_time;

	return 0.f;
}

bool c_lagcomp::apply(lag_record_t* record, c_cs_player_pawn* pawn) {
	(void)record;
	(void)pawn;
	// Disabled: never memcpy recorded bones onto live skeleton (causes floor/warp models).
	return false;
}

void c_lagcomp::reset_applied(c_cs_player_pawn* pawn) {
	(void)pawn;
	m_applied_record = nullptr;
	m_applied_pawn = nullptr;
	m_apply_backup_count = 0;
}

void c_lagcomp::force_reset() {
	reset_applied(nullptr);
}

void c_lagcomp::on_net_update() {
	if (!m_players || !g_interfaces || !g_interfaces->m_entity_system || !g_ctx)
		return;

	auto* local_pawn = reinterpret_cast<c_cs_player_pawn*>(g_ctx->m_local_pawn);
	auto* local_controller = reinterpret_cast<c_cs_player_controller*>(g_ctx->m_local_controller);
	if (!local_pawn || !local_controller)
		return;
	if (!memsafe::valid_entity(local_pawn) || !memsafe::valid_entity(local_controller))
		return;
	if (local_pawn->m_health() <= 0)
		return;

	const int local_team = local_pawn->m_team_num();
	bool alive[k_max_players]{};

	for (int i = 1; i < k_max_players; ++i) {
		auto* controller = reinterpret_cast<c_cs_player_controller*>(entity_by_index(i));
		if (!controller || !memsafe::valid_entity(controller) || controller == local_controller)
			continue;

		const std::uint32_t handle = static_cast<std::uint32_t>(controller->get_handle().to_int());
		auto& hist = m_players[i];

		if (!controller->m_pawn_is_alive()) {
			if (hist.handle == handle)
				hist = {};
			continue;
		}

		auto* pawn = reinterpret_cast<c_cs_player_pawn*>(
			entity_by_index(controller->m_pawn().get_entry_index()));
		if (!pawn || !memsafe::valid_entity(pawn) || !pawn->is_alive() || pawn->m_team_num() == local_team)
			continue;

		alive[i] = true;

		if (hist.handle != handle)
			hist = {};
		hist.handle = handle;

		lag_record_t rec{};
		if (!rec.store(pawn))
			continue;

		const int prev = (hist.write + k_max_records - 1) % k_max_records;
		if (hist.records[prev].m_valid
			&& std::fabs(hist.records[prev].m_simulation_time - rec.m_simulation_time) < 0.0001f)
			continue;

		// Teleport breaks server-side lag compensation (origin jump > 64u
		// between consecutive snapshots) — poses older than the break are
		// unreachable, so drop them instead of offering guaranteed misses.
		if (hist.records[prev].m_valid) {
			const vec3_t jump = rec.m_origin - hist.records[prev].m_origin;
			if (jump.length_sqr() > 64.f * 64.f) {
				const std::uint32_t keep = hist.handle;
				hist = {};
				hist.handle = keep;
			}
		}

		const int slot = hist.write % k_max_records;
		hist.records[slot] = rec;
		hist.write = (slot + 1) % k_max_records;
	}

	for (int i = 1; i < k_max_players; ++i) {
		if (!alive[i] && m_players[i].handle != 0)
			m_players[i] = {};
	}
}

lag_record_t* c_lagcomp::select(int controller_index, select_mode mode) {
	if (!m_players || controller_index <= 0 || controller_index >= k_max_players)
		return nullptr;

	const float ref = reference_time();
	lag_record_t* best = nullptr;
	const int cap = max_ticks();
	auto& hist = m_players[controller_index];

	for (int i = 0; i < cap; ++i) {
		const int slot = (hist.write + k_max_records - 1 - i) % k_max_records;
		auto& rec = hist.records[slot];
		if (!rec.is_valid(ref, m_max_unlag))
			continue;

		if (mode == select_mode::first)
			return &rec;

		if (!best) {
			best = &rec;
			continue;
		}

		if (mode == select_mode::newest) {
			if (rec.m_simulation_time > best->m_simulation_time)
				best = &rec;
		} else if (mode == select_mode::oldest) {
			if (rec.m_simulation_time < best->m_simulation_time)
				best = &rec;
		}
	}

	return best;
}

lag_record_t* c_lagcomp::select_handle(std::uint32_t handle, select_mode mode) {
	if (!m_players || !handle)
		return nullptr;

	for (int i = 1; i < k_max_players; ++i) {
		if (m_players[i].handle == handle)
			return select(i, mode);
	}
	return nullptr;
}
