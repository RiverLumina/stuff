#pragma once

#include "../../sdk/tick.hpp"
#include "../../sdk/typedefs/vec_t.hpp"

#include <cstdint>
#include <memory>

class c_cs_player_pawn;

// Per-tick snapshot of an enemy pose for lag compensation / backtrack.
struct lag_record_t {
	static constexpr int k_max_bones = 128;

	bool     m_valid = false;
	float    m_simulation_time = 0.f;
	vec3_t   m_origin{};
	vec3_t   m_velocity{};
	vec3_t   m_mins{};
	vec3_t   m_maxs{};
	vec3_t   m_head{};
	int      m_flags = 0;
	bool     m_throwing = false;
	int      m_bone_count = 0;
	c_bone_data m_bones[k_max_bones]{};

	bool store(c_cs_player_pawn* pawn);
	bool is_valid(float reference_time, float max_unlag = 0.2f) const;
};

// Fixed ring-buffer lag compensation. Pointers from select() stay valid until
// the same slot is overwritten on a later net-update (safe inside CreateMove).
class c_lagcomp {
public:
	static constexpr int   k_max_players = 65;
	static constexpr int   k_max_records = 24;
	static constexpr float k_default_max_unlag = 0.2f;

	enum class select_mode {
		newest,
		oldest,
		first,
	};

	c_lagcomp();
	~c_lagcomp();

	void reset();
	void on_net_update(); // FRAME_NET_UPDATE_END (stage 7)

	float max_unlag() const { return m_max_unlag; }
	void  set_max_unlag(float seconds);
	int   max_ticks() const;

	lag_record_t* select(int controller_index, select_mode mode = select_mode::newest);
	lag_record_t* select_handle(std::uint32_t handle, select_mode mode = select_mode::newest);

	// Apply path disabled — never swap recorded bones onto the live pawn.
	bool apply(lag_record_t* record, c_cs_player_pawn* pawn);
	void reset_applied(c_cs_player_pawn* pawn);
	void force_reset(); // clear apply state only (no live-bone restore)

	template <typename Fn>
	void for_each_valid(int controller_index, Fn&& fn) {
		if (!m_players || controller_index <= 0 || controller_index >= k_max_players)
			return;
		const float ref = reference_time();
		const int cap = max_ticks();
		auto& hist = m_players[controller_index];
		for (int i = 0; i < cap; ++i) {
			const int slot = (hist.write + k_max_records - 1 - i) % k_max_records;
			auto& rec = hist.records[slot];
			if (rec.is_valid(ref, m_max_unlag))
				fn(rec);
		}
	}

private:
	struct player_history_t {
		lag_record_t  records[k_max_records]{};
		int           write = 0;
		std::uint32_t handle = 0;
	};

	float reference_time() const;

	std::unique_ptr<player_history_t[]> m_players;
	float m_max_unlag = k_default_max_unlag;

	lag_record_t* m_applied_record = nullptr;
	c_cs_player_pawn* m_applied_pawn = nullptr;
	c_bone_data   m_apply_backup[lag_record_t::k_max_bones]{};
	int           m_apply_backup_count = 0;
};

inline const auto g_lagcomp = std::make_unique<c_lagcomp>();

// Apply path disabled — constructor never calls apply / never touches live bones.
struct lagcomp_apply_guard {
	c_cs_player_pawn* pawn = nullptr;
	bool active = false;

	lagcomp_apply_guard(lag_record_t* record, c_cs_player_pawn* target)
		: pawn(target)
		, active(false) {
		(void)record;
	}

	~lagcomp_apply_guard() {
		if (active && g_lagcomp)
			g_lagcomp->reset_applied(pawn);
		active = false;
	}

	lagcomp_apply_guard(const lagcomp_apply_guard&) = delete;
	lagcomp_apply_guard& operator=(const lagcomp_apply_guard&) = delete;
};
