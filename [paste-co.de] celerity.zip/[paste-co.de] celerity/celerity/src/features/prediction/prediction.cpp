#include "prediction.hpp"

#include "../../core/main.hpp"
#include "../../sdk/memsafe.hpp"
#include "../../sdk/valve/classes/c_cs_player_pawn.hpp"
#include "../../sdk/valve/interfaces/vtables/i_csgo_input.hpp"
#include "../../sdk/valve/signatures/signatures.hpp"

#include <cmath>
#include <cstring>

// CS2 (2025–2026): Axion / UC / YouGame consensus —
// do NOT call PhysicsRunThink / SetPredictionCommand / ResetPredictionCommand from
// CreateMove. Those mutate weapon clip/reserve + tickbase and thrash the ammo HUD.
// Rage only needs a read-only snapshot (eye, ticks, spread) like Axion's engpred.

prediction_guard::prediction_guard() {
	if (g_prediction)
		g_prediction->begin();
}

prediction_guard::~prediction_guard() {
	if (g_prediction)
		g_prediction->end();
}

void c_prediction::begin() {
	++m_depth;
	if (m_depth != 1)
		return;

	const int prev_shoot = m_data.m_shoot_tick;

	m_data = {};
	m_data.m_shoot_tick = prev_shoot;
	m_active = false;

	if (!g_interfaces || !g_ctx)
		return;

	auto* engine = g_interfaces->m_engine;
	if (!engine || !engine->is_in_game() || !engine->is_connected())
		return;

	auto* pawn = reinterpret_cast<c_cs_player_pawn*>(g_ctx->m_local_pawn);
	auto* controller = reinterpret_cast<c_cs_player_controller*>(g_ctx->m_local_controller);
	if (!pawn || !controller || !pawn->is_alive())
		return;

	if (g_interfaces->m_global_vars) {
		m_data.m_absolute_frame_time = g_interfaces->m_global_vars->m_absolute_frame_time;
		m_data.m_absolute_frame_start_time_std_dev = g_interfaces->m_global_vars->m_absolute_frame_start_time_std_dev;
		m_data.m_current_time = g_interfaces->m_global_vars->m_current_time;
	}

	m_data.m_tick_base = static_cast<int>(controller->m_tick_base());
	if (m_data.m_tick_base > 0)
		m_data.m_shoot_tick = m_data.m_tick_base - 1;
	else if (prev_shoot > 0)
		m_data.m_shoot_tick = prev_shoot;

	if (auto* scene = pawn->m_scene_node())
		m_data.m_origin = scene->m_abs_origin();
	{
		using fn_abs_t = vec3_t*(__fastcall*)(void*);
		static const auto get_abs = reinterpret_cast<fn_abs_t>(SIG("GetAbsOrigin"));
		if (get_abs) {
			if (vec3_t* p = get_abs(pawn)) {
				if (p && memsafe::is_user_ptr(p) && p->is_valid() && !p->is_zero())
					m_data.m_origin = *p;
			}
		}
	}

	// Prefer abs velocity (sdk-info 0x3F8); fall back to networked m_vecVelocity.
	m_data.m_velocity = pawn->m_vec_abs_velocity();
	if (!m_data.m_velocity.is_valid() || m_data.m_velocity.length_sqr() < 0.01f) {
		const vec3_t net_vel = pawn->m_vec_velocity();
		if (net_vel.is_valid())
			m_data.m_velocity = net_vel;
	}
	m_data.m_flags = pawn->m_flags();

	c_networked_client_info client_info{};
	bool got_net = g_interfaces->m_engine->get_networked_client_info(client_info);
	if (got_net) {
		m_data.m_player_tick = client_info.m_player_tick_count;
		m_data.m_player_tick_fraction = client_info.m_player_tick_fraction;
		m_data.m_render_tick = client_info.m_render_tick;
		m_data.m_render_tick_fraction = client_info.m_render_tick_fraction;
	} else {
		m_data.m_player_tick = m_data.m_tick_base;
		m_data.m_player_tick_fraction = 0.f;
		m_data.m_render_tick = m_data.m_tick_base;
		m_data.m_render_tick_fraction = 0.f;
	}

	// Live eye = abs + viewoffset (validated shoot-history inside resolver).
	m_data.m_eye_pos = pawn->get_eye_position_world();

	// Prefer engine LocalData.ShootPosition when it sits near live eye.
	vec3_t net_shoot{};
	if (engine->get_local_shoot_position(net_shoot) && net_shoot.is_valid()) {
		if (m_data.m_eye_pos.is_valid() && !m_data.m_eye_pos.is_zero()) {
			const vec3_t d = net_shoot - m_data.m_eye_pos;
			if (d.length_sqr() <= (48.f * 48.f))
				m_data.m_eye_pos = net_shoot;
		} else {
			m_data.m_eye_pos = net_shoot;
		}
	} else if (got_net && client_info.m_local_data && memsafe::is_user_ptr(client_info.m_local_data)) {
		const vec3_t sp = client_info.m_local_data->m_eye_pos;
		if (engine->valid_shoot_vec(sp) && m_data.m_eye_pos.is_valid()) {
			const vec3_t d = sp - m_data.m_eye_pos;
			if (d.length_sqr() <= (48.f * 48.f))
				m_data.m_eye_pos = sp;
		}
	}

	// Local-only fraction bump for shoot_tick math — never write controller tickbase.
	if (m_data.m_player_tick_fraction > (1.f - 0.01f) && m_data.m_tick_base > 0) {
		++m_data.m_tick_base;
		m_data.m_shoot_tick = m_data.m_tick_base - 1;
	}

	// Freeze teleport / round rebuild can leave weapon services mid-swap.
	// Keep UpdateAccuracyPenalty — only call it on a fully resolved weapon+VData.
	if (auto* base_weapon = pawn->get_active_weapon()) {
		if (memsafe::valid_entity(base_weapon)) {
			auto* weapon = static_cast<c_cs_weapon_base*>(base_weapon);
			auto* wdata = weapon ? weapon->get_weapon_data() : nullptr;
			if (weapon && wdata && memsafe::valid_entity(wdata)) {
				weapon->update_accuracy_penalty();
				m_data.m_spread = weapon->get_spread();
				m_data.m_inaccuracy = weapon->get_inaccuracy();
				if (!std::isfinite(m_data.m_spread) || m_data.m_spread < 0.f || m_data.m_spread > 1.f)
					m_data.m_spread = 0.f;
				if (!std::isfinite(m_data.m_inaccuracy) || m_data.m_inaccuracy < 0.f || m_data.m_inaccuracy > 1.f)
					m_data.m_inaccuracy = 0.f;
			}
		}
	}

	m_data.m_valid = m_data.m_eye_pos.is_valid()
		&& !m_data.m_eye_pos.is_zero()
		&& !(std::fabs(m_data.m_eye_pos.x) < 1.f && std::fabs(m_data.m_eye_pos.z) < 1.f);
	m_active = m_data.m_valid;
}

void c_prediction::end() {
	if (m_depth <= 0)
		return;

	--m_depth;
	if (m_depth != 0)
		return;

	// Read-only snapshot — nothing to restore on weapon/tickbase/globals.
	m_active = false;
}
