#pragma once

#include "../../sdk/typedefs/vec_t.hpp"

#include <cstdint>
#include <memory>

// Read-only local snapshot for rage (Axion / cs2-internal style).
// Intentionally does NOT call PhysicsRunThink / SetPredictionCommand — those
// desync clip/reserve HUD on current CS2 (confirmed vs weave/axion/UC/YouGame).
class c_prediction {
public:
	struct local_data_t {
		bool  m_valid = false;

		float m_absolute_frame_time{};
		float m_absolute_frame_start_time_std_dev{};
		float m_current_time{};

		int   m_tick_base{};
		int   m_shoot_tick{};
		int   m_player_tick{};
		float m_player_tick_fraction{};
		int   m_render_tick{};
		float m_render_tick_fraction{};

		float m_spread{};
		float m_inaccuracy{};

		vec3_t m_eye_pos{};
		vec3_t m_origin{};
		vec3_t m_velocity{};
		int    m_flags{};
	};

	void begin();
	void end();

	// SEH recovery: re-balance depth if an exception skipped end().
	void force_end() {
		m_depth = 0;
		m_active = false;
	}

	bool active() const { return m_depth > 0 && m_data.m_valid; }
	local_data_t* get_local_data() { return &m_data; }
	const local_data_t* get_local_data() const { return &m_data; }

	vec3_t eye() const { return m_data.m_eye_pos; }
	int    tick_base() const { return m_data.m_tick_base; }
	int    shoot_tick() const { return m_data.m_shoot_tick; }

private:
	local_data_t m_data{};
	int          m_depth = 0;
	bool         m_active = false;
};

struct prediction_guard {
	prediction_guard();
	~prediction_guard();
	prediction_guard(const prediction_guard&) = delete;
	prediction_guard& operator=(const prediction_guard&) = delete;
};

inline const auto g_prediction = std::make_unique<c_prediction>();
