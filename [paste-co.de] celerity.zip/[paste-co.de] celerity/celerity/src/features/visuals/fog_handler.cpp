﻿#include "fog_handler.hpp"

#include "../../sdk/valve/classes/c_gradient_fog.hpp"
#include "../../sdk/valve/interfaces/interfaces.hpp"
#include "../../sdk/valve/interfaces/vtables/i_entity_system.hpp"
#include "../../sdk/memsafe.hpp"
#include "../../config.hpp"
#include "../../core/main.hpp"
#include "../../sdk/valve/classes/c_cs_player_pawn.hpp"

#include <algorithm>

void c_fog_handler::invalidate() {
	// Drop handle only — never remove()/network-destroy during rebuild.
	m_gradient_fog = nullptr;
	m_last_start = m_last_end = m_last_falloff = -1.f;
	m_last_color[0] = m_last_color[1] = m_last_color[2] = m_last_color[3] = -1.f;
}

void c_fog_handler::defer_create(int frames) {
	invalidate();
	m_create_cooldown = (std::max)(m_create_cooldown, frames);
}

void c_fog_handler::fog_controller() {
	if (!g_interfaces || !g_interfaces->m_engine || !g_interfaces->m_entity_system)
		return;
	if (!g_interfaces->m_engine->is_in_game() || !g_interfaces->m_engine->is_connected())
		return;
	if (!g_cfg)
		return;

	// Lefrizzel: fog runs from World::Update (render path), never while local is mid-rebuild.
	if (!g_ctx || !g_ctx->m_local_pawn || !memsafe::valid_entity(g_ctx->m_local_pawn))
		return;
	auto* local = reinterpret_cast<c_cs_player_pawn*>(g_ctx->m_local_pawn);
	if (!local->is_alive() || local->m_health() <= 0)
		return;
	if (!local->m_scene_node() || !memsafe::valid_entity(local->m_scene_node()))
		return;

	const auto& wm = g_cfg->visuals.m_world_modulation;

	if (!wm.m_enable_custom_fog) {
		invalidate();
		return;
	}

	const ImVec4& color = wm.m_fog_color;
	const float start = wm.m_fog_start;
	const float end = wm.m_fog_end;
	const float falloff = wm.m_fog_falloff;

	const bool changed =
		m_last_start != start ||
		m_last_end != end ||
		m_last_falloff != falloff ||
		m_last_color[0] != color.x ||
		m_last_color[1] != color.y ||
		m_last_color[2] != color.z ||
		m_last_color[3] != color.w;

	if (changed)
		invalidate(); // param change — recreate next pass, no long cooldown

	if (m_create_cooldown > 0) {
		--m_create_cooldown;
		return;
	}

	if (!m_gradient_fog) {
		// create_entity during network rebuild (round/map) → client.dll AV from FSN stack.
		m_gradient_fog = g_interfaces->m_entity_system->create_entity_by_class_name("env_gradient_fog");
		if (!m_gradient_fog || !memsafe::valid_entity(m_gradient_fog)) {
			m_gradient_fog = nullptr;
			m_create_cooldown = 64; // backoff only for fog create — not a feature lock
			return;
		}
	} else if (!memsafe::valid_entity(m_gradient_fog)) {
		m_gradient_fog = nullptr;
		m_create_cooldown = 32;
		return;
	}

	auto fog = reinterpret_cast<c_gradient_fog*>(m_gradient_fog);
	fog->m_is_enabled() = true;
	fog->m_fog_start_distance() = start;
	fog->m_fog_end_distance() = end;
	fog->m_fog_strength() = 1.f;
	fog->m_fog_falloff_exponent() = falloff;
	fog->m_fog_max_opacity() = color.w;
	fog->m_fog_color().r = static_cast<std::uint8_t>(std::clamp(color.x, 0.0f, 1.0f) * 255.0f + 0.5f);
	fog->m_fog_color().g = static_cast<std::uint8_t>(std::clamp(color.y, 0.0f, 1.0f) * 255.0f + 0.5f);
	fog->m_fog_color().b = static_cast<std::uint8_t>(std::clamp(color.z, 0.0f, 1.0f) * 255.0f + 0.5f);
	fog->m_fog_color().a = static_cast<std::uint8_t>(std::clamp(color.w, 0.0f, 1.0f) * 255.0f + 0.5f);
	// Lefrizzel: write schema fields only — no VMT notify (index 10 was crashing client.dll).

	m_last_start = start;
	m_last_end = end;
	m_last_falloff = falloff;
	m_last_color[0] = color.x;
	m_last_color[1] = color.y;
	m_last_color[2] = color.z;
	m_last_color[3] = color.w;
}

void c_fog_handler::remove_fog() {
	invalidate();
}
