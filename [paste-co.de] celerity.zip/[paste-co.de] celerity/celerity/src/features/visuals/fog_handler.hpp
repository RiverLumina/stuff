﻿#pragma once

#include <memory>

class c_base_entity;
class c_gradient_fog;

class c_fog_handler {
public:
	void fog_controller();
	void remove_fog();
	void invalidate(); // drop stale ptr without calling remove() on freed entity
	void defer_create(int frames = 96); // after map/round rebuild — delay create only

private:
	c_base_entity* m_gradient_fog = nullptr;
	int m_create_cooldown = 0;

	float m_last_start = 0.f;
	float m_last_end = 0.f;
	float m_last_falloff = 0.f;
	float m_last_color[4] = {};
};

inline const auto g_fog_handler = std::make_unique<c_fog_handler>();
