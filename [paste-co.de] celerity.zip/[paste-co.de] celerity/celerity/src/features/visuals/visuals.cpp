﻿#include "visuals.hpp"
#include "../../core/main.hpp"
#include "../../hooks/hooks.hpp"
#pragma warning(disable : 4324)
#pragma warning(disable : 4505)
#include "../../config.hpp"
#include "../../sdk/verified_features.hpp"
#include "../../sdk/offsets.hpp"
#include "../../sdk/valve/interfaces/interfaces.hpp"
#include "../../sdk/valve/classes/c_cs_player_pawn.hpp"
#include "../../sdk/memsafe.hpp"
#include "../../sdk/valve/signatures/signatures.hpp"
#include "../../../ui/menu/menu.hpp"
#include "../../../ui/assets/weapon_icons.hpp"
#include "../autopeek/autopeek.hpp"
#include <cmath>
#include <string>
#include <algorithm>
#include <vector>
#include <array>
#include "pixel_font.hpp"
#include <cstring>
#include <cstdint>

namespace {
	template <typename T>
	T read(std::uintptr_t address) {
		if (!address)
			return {};
		__try {
			return *reinterpret_cast<T*>(address);
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return {};
		}
	}

	template <typename T>
	void write(std::uintptr_t address, const T& value) {
		if (!address)
			return;
		__try {
			*reinterpret_cast<T*>(address) = value;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {}
	}

	float* get_view_matrix();
	bool world_to_screen(const vec3_t& in, ImVec2& out);

	static bool is_in_active_game() {
		if (hooks::in_entity_transition())
			return false;
		if (!g_interfaces || !g_interfaces->m_engine)
			return false;
		__try {
			if (!g_interfaces->m_engine->is_in_game() || !g_interfaces->m_engine->is_connected())
				return false;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return false;
		}
		if (!g_ctx || !g_ctx->m_local_pawn || !memsafe::valid_entity(g_ctx->m_local_pawn))
			return false;

		auto* local_pawn = reinterpret_cast<c_cs_player_pawn*>(g_ctx->m_local_pawn);
		// sdk-info: C_BaseEntity::m_iTeamNum @ 0x3E7 (uint8) — never SCHEMA on Present during load.
		std::uint8_t team = 0;
		if (!memsafe::read_field(local_pawn, 0x3E7, team))
			return false;
		return team == 2 || team == 3;
	}

	static float g_esp_alpha_mul = 1.0f;

	// Separate from draw_world — MSVC C2712: no __try in functions with C++ unwind.
	static vec3_t safe_pawn_abs_origin(c_cs_player_pawn* pawn) {
		vec3_t origin{};
		if (!pawn)
			return origin;
		__try {
			const auto scene_node = pawn->m_scene_node();
			if (scene_node)
				origin = scene_node->m_abs_origin();
			if (!origin.is_valid())
				origin = pawn->get_eye_pos();
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			origin = {};
		}
		return origin;
	}

	static float read_grenade_time_left(c_entity_instance* entity) {
		if (!entity || !g_interfaces || !g_interfaces->m_global_vars)
			return -1.f;
		// C_BaseGrenade::m_flDetonateTime — sdk-info 0x1188
		static std::uint32_t k_off_detonate = 0;
		if (!k_off_detonate) {
			k_off_detonate = schema_get_offset("client.dll", "C_BaseGrenade", "m_flDetonateTime");
			if (!k_off_detonate || k_off_detonate == 0x1160)
				k_off_detonate = 0x1188;
		}
		const float det = read<float>(reinterpret_cast<std::uintptr_t>(entity) + k_off_detonate);
		const float now = g_interfaces->m_global_vars->m_current_time;
		if (det > 0.f && now > 0.f)
			return det - now;
		return -1.f;
	}

	static int pack_color(const ImVec4& color) {
		const auto r = static_cast<int>(std::clamp(color.x, 0.0f, 1.0f) * 255.0f);
		const auto g = static_cast<int>(std::clamp(color.y, 0.0f, 1.0f) * 255.0f);
		const auto b = static_cast<int>(std::clamp(color.z, 0.0f, 1.0f) * 255.0f);
		const auto a = static_cast<int>(std::clamp(color.w * g_esp_alpha_mul, 0.0f, 1.0f) * 255.0f);
		return r | (g << 8) | (b << 16) | (a << 24);
	}

	static ImU32 color_with_alpha(const ImVec4& color) {
		return static_cast<ImU32>(pack_color(color));
	}

	static ImU32 scale_imu32_alpha(ImU32 col) {
		const int a = static_cast<int>(((col >> 24) & 0xFF) * g_esp_alpha_mul);
		return (col & 0x00FFFFFFu) | (static_cast<ImU32>(std::clamp(a, 0, 255)) << 24);
	}

	static bool entity_is_dormant(c_entity_instance* ent) {
		if (!ent)
			return false;
		c_entity_identity* id = ent->m_entity();
		if (!id)
			return false;
		std::uint32_t flags = 0;
		if (!memsafe::read_field(id, 0x30, flags))
			return false;
		return (flags & EF_IS_DORMANT) != 0;
	}

	// Project world → screen, or clamp to screen edge when offscreen/behind.
	static bool project_or_edge(const vec3_t& world, ImVec2& out, bool& on_screen, float margin = 36.f) {
		on_screen = false;
		ImVec2 scr{};
		const ImVec2 display = ImGui::GetIO().DisplaySize;
		const float cx = display.x * 0.5f;
		const float cy = display.y * 0.5f;

		if (world_to_screen(world, scr)) {
			if (scr.x >= -margin && scr.x <= display.x + margin
				&& scr.y >= -margin && scr.y <= display.y + margin) {
				out = scr;
				on_screen = (scr.x >= 0.f && scr.x <= display.x && scr.y >= 0.f && scr.y <= display.y);
				return true;
			}
		}

		// Direction from view center using raw matrix when behind/off.
		float* matrix = get_view_matrix();
		if (!matrix)
			return false;

		const float w = matrix[12] * world.x + matrix[13] * world.y + matrix[14] * world.z + matrix[15];
		float x = matrix[0] * world.x + matrix[1] * world.y + matrix[2] * world.z + matrix[3];
		float y = matrix[4] * world.x + matrix[5] * world.y + matrix[6] * world.z + matrix[7];
		if (std::fabs(w) > 1e-5f) {
			x /= w;
			y /= w;
		}
		// NDC-ish → direction from center
		float dx = x;
		float dy = -y;
		if (w < 0.f) {
			dx = -dx;
			dy = -dy;
		}
		const float len = std::sqrt(dx * dx + dy * dy);
		if (len < 1e-5f)
			return false;
		dx /= len;
		dy /= len;

		const float radius = (std::min)(cx, cy) - margin;
		out = ImVec2(cx + dx * radius, cy + dy * radius);
		on_screen = false;
		return true;
	}

	static void draw_offscreen_arrow(ImDrawList* dl, const ImVec2& edge, float size, ImU32 col, float dist_m) {
		if (!dl)
			return;
		const ImVec2 display = ImGui::GetIO().DisplaySize;
		const float cx = display.x * 0.5f;
		const float cy = display.y * 0.5f;
		float dx = edge.x - cx;
		float dy = edge.y - cy;
		const float len = std::sqrt(dx * dx + dy * dy);
		if (len < 1.f)
			return;
		dx /= len;
		dy /= len;

		const float ring = std::clamp(g_cfg->visuals.m_esp_arrows_distance, 80.f, 480.f);
		const ImVec2 tip(cx + dx * ring, cy + dy * ring);
		const ImVec2 left(tip.x - dx * size + (-dy) * size * 0.55f,
			tip.y - dy * size + dx * size * 0.55f);
		const ImVec2 right(tip.x - dx * size - (-dy) * size * 0.55f,
			tip.y - dy * size - dx * size * 0.55f);

		dl->AddTriangleFilled(tip, left, right, col);
		dl->AddTriangle(tip, left, right, IM_COL32(0, 0, 0, 180), 1.2f);

		char buf[16];
		std::snprintf(buf, sizeof(buf), "%.0fm", dist_m);
		const ImVec2 tsz = ImGui::CalcTextSize(buf);
		dl->AddText(ImVec2(tip.x - tsz.x * 0.5f, tip.y + size * 0.35f), col, buf);
	}

	static float he_damage_raw(float dist) {
		constexpr float k_radius = 350.f;
		constexpr float k_base = 99.f;
		constexpr float k_falloff = 0.5f;
		if (dist < 0.f || dist >= k_radius)
			return 0.f;
		return k_base * std::exp(-dist * dist / (2.f * k_radius * k_radius * k_falloff));
	}

	static int apply_armor_dmg(float dmg, int armor) {
		if (dmg <= 0.f)
			return 0;
		if (armor <= 0)
			return static_cast<int>(std::ceil(dmg));
		float neu = dmg * 0.5f;
		float arm = (dmg - neu) * 0.5f;
		if (arm > static_cast<float>(armor)) {
			arm = static_cast<float>(armor) * 2.f;
			neu = dmg - arm;
		}
		return static_cast<int>(std::ceil((std::max)(0.f, neu)));
	}

	static void draw_nade_warn_badge(ImDrawList* dl, float cx, float cy, const ImVec4& col4,
		const char* icon_key, const char* /*label*/, float time_left, int dmg_to_you, bool offscreen = false)
	{
		if (!dl || !std::isfinite(cx) || !std::isfinite(cy))
			return;
		if (cx < -4000.f || cx > 8000.f || cy < -4000.f || cy > 8000.f)
			return;

		const float icon_base = std::clamp(g_cfg->visuals.m_grenade_warning_icon_size, 16.f, 56.f);
		const float r = icon_base * 0.58f;
		// Soft danger glow — red regardless of config accent (modern NL/GS look).
		const int cr = 220, cg = 48, cb = 48;
		const float t = static_cast<float>(ImGui::GetTime());
		const float pulse = 0.55f + 0.45f * std::sin(t * 5.2f);

		// Layered soft glow (no hard disc border).
		for (int i = 5; i >= 1; --i) {
			const float rr = r + static_cast<float>(i) * 5.5f;
			const int a = static_cast<int>((18.f + pulse * 10.f) * (6 - i) / 5.f);
			dl->AddCircleFilled(ImVec2(cx, cy), rr, IM_COL32(cr, cg, cb, a), 48);
		}
		dl->AddCircleFilled(ImVec2(cx, cy), r + 1.5f, IM_COL32(8, 6, 6, 160), 36);

		ImFont* icon_font = g_menu ? g_menu->get_weapon_icon_font() : nullptr;
		if (icon_font && icon_key && icon_key[0]) {
			auto it = weapon_icons::icon_table.find(icon_key);
			if (it != weapon_icons::icon_table.end() && !it->second.empty()) {
				const float icon_sz = icon_base * 0.92f;
				const ImVec2 isz = icon_font->CalcTextSizeA(icon_sz, FLT_MAX, 0.f, it->second.c_str());
				const float ix = floorf(cx - isz.x * 0.5f);
				const float iy = floorf(cy - isz.y * 0.62f);
				dl->AddText(icon_font, icon_sz, ImVec2(ix + 1.f, iy + 1.f), IM_COL32(0, 0, 0, 180), it->second.c_str());
				dl->AddText(icon_font, icon_sz, ImVec2(ix, iy), IM_COL32(255, 255, 255, 255), it->second.c_str());
			}
		}

		float text_y = cy + r * 0.15f;
		if (dmg_to_you > 0) {
			char dmg[24];
			std::snprintf(dmg, sizeof(dmg), "-%d HP", dmg_to_you);
			const ImVec2 dsz = ImGui::CalcTextSize(dmg);
			const float dx = floorf(cx - dsz.x * 0.5f);
			dl->AddText(ImVec2(dx + 1.f, text_y + 1.f), IM_COL32(0, 0, 0, 200), dmg);
			dl->AddText(ImVec2(dx, text_y), IM_COL32(255, 255, 255, 255), dmg);
			text_y += dsz.y + 1.f;
		}

		if (time_left > 0.05f && time_left < 60.f) {
			char line[16];
			std::snprintf(line, sizeof(line), "%.1f s", time_left);
			const ImVec2 tsz = ImGui::CalcTextSize(line);
			const float tx = floorf(cx - tsz.x * 0.5f);
			dl->AddText(ImVec2(tx + 1.f, text_y + 1.f), IM_COL32(0, 0, 0, 200), line);
			dl->AddText(ImVec2(tx, text_y), time_left < 0.5f ? IM_COL32(255, 90, 90, 255) : IM_COL32(240, 240, 245, 255), line);
		}

		if (offscreen) {
			const ImVec2 display = ImGui::GetIO().DisplaySize;
			const float scx = display.x * 0.5f;
			const float scy = display.y * 0.5f;
			float dx = cx - scx;
			float dy = cy - scy;
			const float len = std::sqrt(dx * dx + dy * dy);
			if (len > 1.f) {
				dx /= len; dy /= len;
				const float tip_x = cx + dx * (r + 14.f);
				const float tip_y = cy + dy * (r + 14.f);
				const ImVec2 tip(tip_x, tip_y);
				const ImVec2 left(tip_x - dx * 7.f + (-dy) * 5.f, tip_y - dy * 7.f + dx * 5.f);
				const ImVec2 right(tip_x - dx * 7.f - (-dy) * 5.f, tip_y - dy * 7.f - dx * 5.f);
				dl->AddTriangleFilled(tip, left, right, IM_COL32(255, 255, 255, 240));
				dl->AddTriangle(tip, left, right, IM_COL32(0, 0, 0, 160), 1.0f);
			}
		}

		(void)col4;
	}

	// Live dump from sdk-info/schemas.json (client.dll):
	//   AbsVelocity=0x3F8, InitPos=0x11C8, InitVel=0x11D4, Bounces=0x11E0
	// (client_dll.hpp dump is stale — do NOT use 0x3FC / 0x11AC.)
	static vec3_t projectile_sim_velocity(c_base_entity* entity, const vec3_t& origin) {
		static std::uint32_t off_abs = 0, off_init_vel = 0, off_init_pos = 0, off_bounces = 0;
		static bool once = false;
		if (!once) {
			off_abs = schema_get_offset("client.dll", "C_BaseEntity", "m_vecAbsVelocity");
			if (!off_abs) off_abs = 0x3F8;
			off_init_vel = schema_get_offset("client.dll", "C_BaseCSGrenadeProjectile", "m_vInitialVelocity");
			if (!off_init_vel) off_init_vel = 0x11D4;
			off_init_pos = schema_get_offset("client.dll", "C_BaseCSGrenadeProjectile", "m_vInitialPosition");
			if (!off_init_pos) off_init_pos = 0x11C8;
			off_bounces = schema_get_offset("client.dll", "C_BaseCSGrenadeProjectile", "m_nBounces");
			if (!off_bounces) off_bounces = 0x11E0;
			// Prefer sdk-info hardcoded if schema returns the stale client_dll set.
			if (off_abs == 0x3FC) off_abs = 0x3F8;
			if (off_init_vel == 0x11AC) off_init_vel = 0x11D4;
			if (off_init_pos == 0x11A0) off_init_pos = 0x11C8;
			if (off_bounces == 0x11B8) off_bounces = 0x11E0;
			once = true;
		}

		vec3_t vel{};
		if (!memsafe::read_field(entity, off_abs, vel) || !vel.is_valid() || vel.length_sqr() < 1.f) {
			__try {
				vel = entity->m_vec_abs_velocity();
			} __except (EXCEPTION_EXECUTE_HANDLER) { vel = {}; }
		}

		const int bounces = memsafe::read_or<int>(
			reinterpret_cast<const std::uint8_t*>(entity) + off_bounces, 0);

		// Pre-bounce: initial throw velocity is authoritative and stable for warning UI.
		if (bounces <= 0) {
			vec3_t iv{};
			vec3_t ip{};
			memsafe::read_field(entity, off_init_vel, iv);
			memsafe::read_field(entity, off_init_pos, ip);
			if (iv.is_valid() && iv.length() > 5.f && std::isfinite(iv.x) && std::isfinite(iv.y) && std::isfinite(iv.z)) {
				const float dx = origin.x - ip.x, dy = origin.y - ip.y, dz = origin.z - ip.z;
				if (!ip.is_valid() || (dx * dx + dy * dy + dz * dz) < (250.f * 250.f))
					return iv;
			}
		}

		if (vel.length() < 5.f) {
			vec3_t iv{};
			if (memsafe::read_field(entity, off_init_vel, iv) && iv.is_valid() && iv.length() > 5.f)
				vel = iv;
		}
		return vel;
	}

	static void apply_enemy_glow(c_cs_player_pawn* pawn, bool enabled) {
		if (!pawn)
			return;

		constexpr std::uintptr_t glow_offset = 0xDD8;
		constexpr std::uintptr_t glow_color_offset = 0x40;
		constexpr std::uintptr_t glow_type_offset = 0x30;
		constexpr std::uintptr_t flashing_offset = 0x44;
		constexpr std::uintptr_t eligible_offset = 0x50;
		constexpr std::uintptr_t glowing_offset = 0x51;
		const auto glow = reinterpret_cast<std::uintptr_t>(pawn) + glow_offset;
		using on_glow_type_changed_t = __int64(__fastcall*)(void*);
		static auto on_glow_type_changed = reinterpret_cast<on_glow_type_changed_t>(
			SIG("CGlowProperty_OnGlowTypeChanged")
		);

		const auto old_color = read<int>(glow + glow_color_offset);
		const auto old_type = read<int>(glow + glow_type_offset);
		const auto old_glowing = read<bool>(glow + glowing_offset);
		const auto old_eligible = read<bool>(glow + eligible_offset);

		if (!enabled) {
			if (old_glowing || old_type != 0 || old_eligible) {
				write<bool>(glow + glowing_offset, false);
				write<bool>(glow + eligible_offset, false);
				write<int>(glow + glow_type_offset, 0);
				if (on_glow_type_changed)
					on_glow_type_changed(reinterpret_cast<void*>(glow));
			}
			return;
		}

		const auto& color = g_cfg->visuals.m_enemy_glow_color;
		const int packed_color = pack_color(color);
		const bool changed = old_color != packed_color || old_type != 3 || !old_glowing || !old_eligible;

		write<int>(glow + glow_color_offset, packed_color);
		write<bool>(glow + flashing_offset, false);
		write<bool>(glow + eligible_offset, true);
		write<int>(glow + glow_type_offset, 3);
		write<bool>(glow + glowing_offset, true);

		if (changed && on_glow_type_changed)
			on_glow_type_changed(reinterpret_cast<void*>(glow));
	}

	static bool is_valid_identity(c_entity_identity* identity, bool require_safe_to_modify = false) {
		if (!identity)
			return false;

		__try {
			if (!identity->is_valid())
				return false;
			return !require_safe_to_modify || identity->is_safe_to_modify();
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return false;
		}
	}

	static c_base_entity* get_base_entity_safe(int index) {
		if (!g_interfaces || !g_interfaces->m_entity_system)
			return nullptr;

		__try {
			return g_interfaces->m_entity_system->get_base_entity(index);
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return nullptr;
		}
	}

	static int get_entity_scan_limit(int fallback = 1024) {
		if (!g_interfaces || !g_interfaces->m_entity_system)
			return fallback;

		__try {
			const int highest = g_interfaces->m_entity_system->get_highest_entity_index();
			if (highest >= fallback && highest <= ENT_MAX_NETWORKED_ENTRY)
				return highest;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {}

		return fallback;
	}

	static bool is_smoke_projectile(c_base_entity* entity) {
		if (!entity)
			return false;

		__try {
			if (const char* designer_name = entity->get_designer_name())
				if (std::strcmp(designer_name, "smokegrenade_projectile") == 0)
					return true;

			if (const char* class_name = entity->get_class_name())
				return std::strcmp(class_name, "C_SmokeGrenadeProjectile") == 0;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return false;
		}

		return false;
	}

	static int get_entity_team_safe(c_base_entity* entity) {
		if (!entity)
			return 0;

		__try {
			auto owner_handle = entity->m_owner_entity();
			if (owner_handle.is_valid()) {
				if (auto* owner = get_base_entity_safe(owner_handle.get_entry_index()))
					return owner->m_team_num();
			}

			return entity->m_team_num();
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return 0;
		}
	}

	static void set_smoke_color_safe(c_base_entity* entity, const ImVec4& color) {
		if (!entity)
			return;

		static std::uint32_t smoke_color_offset = 0;
		static bool offset_initialized = false;
		if (!offset_initialized) {
			smoke_color_offset = schema_get_offset("client.dll", "C_SmokeGrenadeProjectile", "m_vSmokeColor");
			if (!smoke_color_offset)
				smoke_color_offset = 0x125C;
			offset_initialized = true;
		}

		if (!smoke_color_offset)
			return;

		__try {
			auto* smoke_color = reinterpret_cast<vec3_t*>(reinterpret_cast<std::uintptr_t>(entity) + smoke_color_offset);
			smoke_color->x = color.x * 255.0f;
			smoke_color->y = color.y * 255.0f;
			smoke_color->z = color.z * 255.0f;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {}
	}

	static void apply_smoke_colors() {
		if (!g_cfg->visuals.m_smoke_color)
			return;

		const int scan_limit = get_entity_scan_limit();
		for (int i = 1; i <= scan_limit; ++i) {
			auto* entity = get_base_entity_safe(i);
			if (!entity || !is_smoke_projectile(entity))
				continue;

			const int team = get_entity_team_safe(entity);
			const auto& color = team == 2 ? g_cfg->visuals.m_smoke_color_t : g_cfg->visuals.m_smoke_color_ct;
			set_smoke_color_safe(entity, color);
		}
	}

	bool world_to_screen(const vec3_t& in, ImVec2& out);

	namespace grenade_prediction {
		// Lefrizzel: world/prop grenade mask (not shot mask).
		constexpr uint64_t mask_grenade = 0x2009ull;
		constexpr float visible_fraction = 0.97f;
		constexpr float sim_dt = 1.0f / 64.0f;
		constexpr int max_ticks = 1024;
		constexpr int ticks_per_point = 4;
		constexpr float gravity = 320.0f;
		constexpr float elasticity = 0.45f;
		constexpr float stop_speed_sq = 2036.0f;
		constexpr float molotov_max_slope_z = 0.8660254f;
		constexpr float steep_bounce_normal_z = 0.7f;
		constexpr float steep_bounce_speed_sq = 96000.0f;
		constexpr float grenade_hull_radius = 2.0f;
		constexpr float he_fuse_sec = 1.5f;
		constexpr int he_fuse_delay_ticks = 8;

		enum class kind {
			flashbang,
			he,
			smoke,
			decoy,
			molotov,
			incendiary
		};

		using init_trace_filter_t = void*(__fastcall*)(void* filter, void* skip, std::uint64_t mask, int layer, int a5);
		using init_trace_info_t = void*(__fastcall*)(void* tr);
		using trace_shape_t = bool(__fastcall*)(void* world, const void* ray, const vec3_t* start,
			const vec3_t* end, const void* filter, void* out);

		struct shape_trace_t {
			alignas(16) std::uint8_t raw[0x200]{};
			float fraction() const { return *reinterpret_cast<const float*>(raw + 0xAC); }
			bool startsolid() const { return raw[0xBB] != 0; }
			vec3_t endpos() const {
				const float* f = reinterpret_cast<const float*>(raw + 0x84);
				return { f[0], f[1], f[2] };
			}
			vec3_t normal() const {
				const float* f = reinterpret_cast<const float*>(raw + 0x90);
				return { f[0], f[1], f[2] };
			}
		};

		struct shape_ray_t {
			alignas(16) std::uint8_t raw[0x30]{};
			void set_hull(const vec3_t& mins, const vec3_t& maxs) {
				std::memset(raw, 0, sizeof(raw));
				std::memcpy(raw + 0x00, &mins, sizeof(float) * 3);
				std::memcpy(raw + 0x0C, &maxs, sizeof(float) * 3);
				raw[0x28] = 1;
			}
		};

		struct trace_result {
			float fraction = 1.0f;
			vec3_t end_pos{};
			vec3_t normal{};
			bool hit = false;
		};

		struct trajectory {
			std::vector<vec3_t> points;
			std::vector<vec3_t> bounces;
			vec3_t end_pos{};
			bool valid = false;
		};

		struct trace_functions {
			init_trace_filter_t init_filter = nullptr;
			init_trace_info_t init_trace_info = nullptr;
			trace_shape_t trace_shape = nullptr;
			void** pp_trace_mgr = nullptr;
			bool tried = false;
		};

		trace_functions& funcs() {
			static trace_functions f;
			if (f.tried)
				return f;
			f.tried = true;
			auto scan2 = [](const char* a, const char* b) -> void* {
				void* p = g_opcodes->scan("client.dll", a);
				if (!p && b)
					p = g_opcodes->scan("client.dll", b);
				return p;
			};
			f.trace_shape = reinterpret_cast<trace_shape_t>(scan2(
				"48 89 54 24 ? 48 89 4C 24 ? 55 53 56 57 41 56 41 57 48 8D AC 24 ? ? ? ? B8 E8 24 00 00",
				"48 89 54 24 ? 48 89 4C 24 ? 55 53 56 57 41 56 41 57 48 8D AC 24"));
			f.init_filter = reinterpret_cast<init_trace_filter_t>(scan2(
				"48 89 5C 24 08 48 89 74 24 10 57 48 83 EC 20 0F B6 41 39 33 FF 24 C9 C7",
				"48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 0F B6 41 ? 33 FF 24"));
			f.init_trace_info = reinterpret_cast<init_trace_info_t>(
				g_opcodes->scan("client.dll", "40 55 41 55 41 57 48 83 EC 30 4C 8B 3D"));
			f.pp_trace_mgr = reinterpret_cast<void**>(g_opcodes->scan_absolute(
				"client.dll",
				"48 8B 0D ? ? ? ? 48 8B D0 C7 44 24 ? 04 00 00 00",
				0x3));
			return f;
		}

		bool available() {
			auto& f = funcs();
			return f.trace_shape && f.init_filter && f.pp_trace_mgr;
		}

		void* resolve_world_arg() {
			auto& f = funcs();
			if (!f.pp_trace_mgr || !memsafe::is_user_ptr(f.pp_trace_mgr))
				return nullptr;
			void* world = *f.pp_trace_mgr;
			if (!world || !memsafe::is_user_ptr(world))
				return nullptr;
			void* iface = *reinterpret_cast<void**>(world);
			if (!iface || !memsafe::is_user_ptr(iface))
				return nullptr;
			return world;
		}

		vec3_t approx_normal_from_direction(const vec3_t& direction) {
			const float ax = std::fabs(direction.x);
			const float ay = std::fabs(direction.y);
			const float az = std::fabs(direction.z);
			if (az >= ax && az >= ay)
				return direction.z <= 0.0f ? vec3_t(0.0f, 0.0f, 1.0f) : vec3_t(0.0f, 0.0f, -1.0f);
			if (ax >= ay)
				return direction.x >= 0.0f ? vec3_t(-1.0f, 0.0f, 0.0f) : vec3_t(1.0f, 0.0f, 0.0f);
			return direction.y >= 0.0f ? vec3_t(0.0f, -1.0f, 0.0f) : vec3_t(0.0f, 1.0f, 0.0f);
		}

		bool trace_grenade(const vec3_t& start, const vec3_t& end, uintptr_t skip_pawn, trace_result& out) {
			auto& f = funcs();
			if (!available()) {
				out = { 1.0f, end, {}, false };
				return false;
			}
			void* world = resolve_world_arg();
			if (!world) {
				out = { 1.0f, end, {}, false };
				return false;
			}

			__try {
				const vec3_t mins{ -grenade_hull_radius, -grenade_hull_radius, -grenade_hull_radius };
				const vec3_t maxs{ grenade_hull_radius, grenade_hull_radius, grenade_hull_radius };
				shape_ray_t ray{};
				ray.set_hull(mins, maxs);
				alignas(16) std::uint8_t filter[0x70]{};
				shape_trace_t tr{};
				*reinterpret_cast<float*>(tr.raw + 0xAC) = 1.f;
				if (f.init_trace_info)
					f.init_trace_info(tr.raw);

				f.init_filter(filter, reinterpret_cast<void*>(skip_pawn), mask_grenade, 4, 7);
				*reinterpret_cast<std::uint64_t*>(filter + 8) = mask_grenade;
				*reinterpret_cast<std::int32_t*>(filter + 0x32) = -65536;
				*reinterpret_cast<std::int16_t*>(filter + 0x36) = 3840;
				filter[0x40] = 0;

				vec3_t s = start, e = end;
				f.trace_shape(world, &ray, &s, &e, filter, &tr);

				float fraction = std::clamp(tr.fraction(), 0.f, 1.f);
				vec3_t hit_end = tr.endpos();
				if (!hit_end.is_valid() || (std::fabs(hit_end.x) + std::fabs(hit_end.y) + std::fabs(hit_end.z)) < 1.f)
					hit_end = start + (end - start) * fraction;
				vec3_t normal = tr.normal();
				if (normal.length_sqr() <= 1e-6f)
					normal = approx_normal_from_direction(end - start);

				const bool hit = fraction < visible_fraction || tr.startsolid();
				if (hit)
					hit_end = hit_end + normal * 0.125f;
				out = { fraction, hit_end, normal, hit };
				return true;
			}
			__except (EXCEPTION_EXECUTE_HANDLER) {
				out = { 1.0f, end, {}, false };
				return false;
			}
		}

		trace_result trace_grenade_hull(const vec3_t& start, const vec3_t& end, uintptr_t skip_pawn) {
			trace_result center{};
			trace_grenade(start, end, skip_pawn, center);
			return center;
		}

		vec3_t clip_velocity(const vec3_t& velocity, const vec3_t& normal, float overbounce) {
			const float backoff = velocity.dot(normal) * overbounce;
			vec3_t out(
				velocity.x - normal.x * backoff,
				velocity.y - normal.y * backoff,
				velocity.z - normal.z * backoff
			);
			if (std::fabs(out.x) < 0.1f) out.x = 0.0f;
			if (std::fabs(out.y) < 0.1f) out.y = 0.0f;
			if (std::fabs(out.z) < 0.1f) out.z = 0.0f;
			return out;
		}

		bool is_timed_boom(kind type) {
			return type == kind::he || type == kind::flashbang;
		}

		bool should_detonate(kind type, const vec3_t& vel, int tick) {
			switch (type) {
			case kind::smoke:
			case kind::decoy: {
				constexpr int check_ticks = 12;
				const float threshold = type == kind::smoke ? 0.1f : 0.2f;
				return vel.length_2d() < threshold && (tick % check_ticks) == 0;
			}
			case kind::molotov:
			case kind::incendiary:
				return static_cast<float>(tick) * sim_dt > 2.0f;
			case kind::flashbang:
			case kind::he:
				return static_cast<float>(tick - he_fuse_delay_ticks) * sim_dt > he_fuse_sec;
			}
			return false;
		}

		// Vacuum ballistic (no TraceShape) — safe after local throw when collision mgr is busy.
		bool simulate_vacuum_end(vec3_t start, vec3_t velocity, kind type, vec3_t& out_end) {
			out_end = start;
			if (!start.is_valid() || !velocity.is_valid())
				return false;
			vec3_t pos = start;
			vec3_t vel = velocity;
			const bool timed = is_timed_boom(type);
			for (int tick = 0; tick < max_ticks; ++tick) {
				if (timed && should_detonate(type, vel, tick)) {
					out_end = pos;
					return true;
				}
				vel.z -= gravity * sim_dt;
				pos = pos + vel * sim_dt;
				if (!timed && vel.length_sqr() < stop_speed_sq) {
					out_end = pos;
					return true;
				}
			}
			out_end = pos;
			return true;
		}

		bool resolve_collision(const trace_result& trace, vec3_t& pos, vec3_t& vel, kind type, uintptr_t skip_pawn) {
			if ((type == kind::molotov || type == kind::incendiary) &&
				(trace.normal.z >= molotov_max_slope_z || vel.length_sqr() < stop_speed_sq)) {
				vel = {};
				return true;
			}

			vec3_t new_vel = clip_velocity(vel, trace.normal, 2.0f) * elasticity;
			if (trace.normal.z > steep_bounce_normal_z) {
				const float speed_sq = new_vel.length_sqr();
				if (speed_sq > steep_bounce_speed_sq) {
					const float speed = std::sqrt(speed_sq);
					const float l = new_vel.dot(trace.normal) / speed;
					if (l > 0.5f)
						new_vel *= 1.5f - l;
				}

				if (new_vel.length_sqr() < stop_speed_sq) {
					vel = {};
					return false;
				}
			}

			vel = new_vel;
			const float remaining = 1.0f - trace.fraction;
			if (remaining > 0.0f) {
				const vec3_t post_end = pos + new_vel * (remaining * sim_dt);
				trace_result post{};
				trace_grenade(pos, post_end, skip_pawn, post);
				pos = post.end_pos;
			}

			return false;
		}

		bool step(vec3_t& pos, vec3_t& vel, kind type, uintptr_t skip_pawn, bool& hit) {
			const float new_vz = vel.z - gravity * sim_dt;
			const vec3_t move_vec(vel.x * sim_dt, vel.y * sim_dt, (vel.z + new_vz) * 0.5f * sim_dt);
			vel.z = new_vz;

			const vec3_t trace_end = pos + move_vec;
			const trace_result trace = trace_grenade_hull(pos, trace_end, skip_pawn);
			pos = trace.end_pos;
			hit = trace.hit;

			if (trace.hit)
				return resolve_collision(trace, pos, vel, type, skip_pawn);
			return false;
		}

		// Warning-only: same physics as simulate(), but no std::vector (safe under SEH).
		bool simulate_end_pos(vec3_t start, vec3_t velocity, kind type, uintptr_t skip_pawn, vec3_t& out_end) {
			out_end = start;
			if (!start.is_valid() || !velocity.is_valid())
				return false;
			if (!std::isfinite(velocity.x) || !std::isfinite(velocity.y) || !std::isfinite(velocity.z))
				return false;

			vec3_t pos = start;
			vec3_t vel = velocity;
			int bounce_count = 0;
			const bool timed = is_timed_boom(type);

			for (int tick = 0; tick < max_ticks; ++tick) {
				if (timed && should_detonate(type, vel, tick)) {
					out_end = pos;
					return true;
				}

				bool hit = false;
				const bool impact_detonate = step(pos, vel, type, skip_pawn, hit);
				if (hit)
					++bounce_count;

				if (timed && vel.length_sqr() < stop_speed_sq)
					vel = {};

				const bool velocity_stopped =
					!timed &&
					std::fabs(vel.x) < 45.0f && std::fabs(vel.y) < 45.0f && vel.length_sqr() < stop_speed_sq;

				if (impact_detonate || (!timed && should_detonate(type, vel, tick)) || bounce_count > 20 || velocity_stopped) {
					out_end = pos;
					return true;
				}
			}

			out_end = pos;
			return true;
		}

		trajectory simulate(vec3_t start, vec3_t velocity, kind type, uintptr_t skip_pawn) {
			trajectory out;
			out.points.reserve(max_ticks / ticks_per_point);
			out.points.push_back(start);

			vec3_t pos = start;
			vec3_t vel = velocity;
			int bounce_count = 0;
			int tick_timer = 0;
			const bool timed = is_timed_boom(type);

			for (int tick = 0; tick < max_ticks; ++tick) {
				// HE/flash: fuse can boom mid-air — stop at current pos.
				if (timed && should_detonate(type, vel, tick)) {
					out.end_pos = pos;
					out.valid = true;
					break;
				}

				if (tick_timer == 0 && tick > 0)
					out.points.push_back(pos);

				bool hit = false;
				const bool impact_detonate = step(pos, vel, type, skip_pawn, hit);
				if (hit) {
					++bounce_count;
					out.bounces.push_back(pos);
				}

				// HE/flash on ground: zero vel but keep ticking until fuse.
				if (timed && vel.length_sqr() < stop_speed_sq)
					vel = {};

				const bool velocity_stopped =
					!timed &&
					std::fabs(vel.x) < 45.0f && std::fabs(vel.y) < 45.0f && vel.length_sqr() < stop_speed_sq;

				if (impact_detonate || (!timed && should_detonate(type, vel, tick)) || bounce_count > 20 || velocity_stopped) {
					out.end_pos = pos;
					out.valid = true;
					break;
				}

				if (hit || ++tick_timer >= ticks_per_point)
					tick_timer = 0;
			}

			if (!out.valid) {
				out.end_pos = pos;
				out.valid = !out.points.empty();
			}
			if (out.valid && !out.points.empty() && (out.points.back() - out.end_pos).length_sqr() > 1.0f)
				out.points.push_back(out.end_pos);
			return out;
		}

		bool kind_from_def_index(uint16_t def_index, kind& out) {
			switch (def_index) {
			case WEAPON_FLASHBANG: out = kind::flashbang; return true;
			case WEAPON_HEGRENADE: out = kind::he; return true;
			case WEAPON_SMOKE: out = kind::smoke; return true;
			case WEAPON_MOLOTOV: out = kind::molotov; return true;
			case WEAPON_DECOY: out = kind::decoy; return true;
			case WEAPON_INCDENDIARY: out = kind::incendiary; return true;
			default: return false;
			}
		}

		bool kind_from_projectile(c_base_entity* entity, kind& out) {
			if (!entity)
				return false;

			__try {
				const char* designer_name = entity->get_designer_name();
				const char* class_name = entity->get_class_name();
				const auto contains = [](const char* text, const char* needle) {
					return text && std::strstr(text, needle) != nullptr;
				};

				const bool is_projectile =
					contains(designer_name, "_projectile") || contains(class_name, "Projectile");
				if (!is_projectile)
					return false;

				if (contains(designer_name, "flashbang") || contains(class_name, "Flashbang") || contains(class_name, "FlashbangProjectile")) { out = kind::flashbang; return true; }
				if (contains(designer_name, "hegrenade") || contains(class_name, "HEGrenade") || contains(class_name, "HEGrenadeProjectile")) { out = kind::he; return true; }
				if (contains(designer_name, "smokegrenade") || contains(class_name, "SmokeGrenade") || contains(class_name, "SmokeGrenadeProjectile")) { out = kind::smoke; return true; }
				if (contains(designer_name, "decoy") || contains(class_name, "Decoy") || contains(class_name, "DecoyProjectile")) { out = kind::decoy; return true; }
				if (contains(designer_name, "molotov") || contains(class_name, "Molotov") || contains(class_name, "MolotovProjectile")) { out = kind::molotov; return true; }
				if (contains(designer_name, "incendiary") || contains(class_name, "Incendiary") || contains(class_name, "IncendiaryProjectile")) { out = kind::incendiary; return true; }
			}
			__except (EXCEPTION_EXECUTE_HANDLER) {
				return false;
			}
			return false;
		}

		float grenade_throw_speed(uint16_t def_index) {
			return (def_index == WEAPON_MOLOTOV || def_index == WEAPON_INCDENDIARY) ? 700.0f : 750.0f;
		}

		vec3_t forward_from_angles(vec3_t angles) {
			const float pitch = angles.x * (3.14159265358979323846f / 180.0f);
			const float yaw = angles.y * (3.14159265358979323846f / 180.0f);
			const float cp = std::cos(pitch);
			return vec3_t(cp * std::cos(yaw), cp * std::sin(yaw), -std::sin(pitch));
		}

		vec3_t compute_initial_velocity(vec3_t angles, float base_velocity, float throw_strength) {
			const float strength = std::fabs(throw_strength - 0.5f) < 0.1f ? 0.5f : throw_strength;
			angles.x -= (90.0f - std::fabs(angles.x)) * 10.0f / 90.0f;
			const float throw_velocity = std::clamp(base_velocity * 0.9f, 15.0f, 750.0f);
			const float throw_speed = (strength * 0.7f + 0.3f) * throw_velocity;
			return forward_from_angles(angles) * throw_speed;
		}

		vec3_t eye_position(c_cs_player_pawn* pawn) {
			if (!pawn)
				return {};

			vec3_t origin{};
			if (auto* node = pawn->m_scene_node())
				origin = node->m_abs_origin();
			if (!origin.is_valid() || origin.is_zero())
				origin = pawn->get_eye_pos();

			constexpr uintptr_t view_offset = 0xE78; // sdk-info m_vecViewOffset
			const vec3_t offset = read<vec3_t>(reinterpret_cast<uintptr_t>(pawn) + view_offset);
			if (offset.is_valid() && !offset.is_zero())
				return origin + offset;

			return origin;
		}

		float weapon_throw_velocity(c_base_player_weapon* weapon, uint16_t def_index) {
			static const uint32_t offset = []() {
				uint32_t off = schema_get_offset("CCSWeaponBaseVData", "m_flThrowVelocity");
				return off;
			}();
			if (weapon) {
				if (offset) {
					if (auto* data = weapon->get_weapon_data()) {
						const float value = read<float>(reinterpret_cast<uintptr_t>(data) + offset);
						if (std::isfinite(value) && value > 0.0f)
							return value;
					}
				}
			}
			return grenade_throw_speed(def_index);
		}

		void draw_trajectory(ImDrawList* draw_list, const trajectory& traj, ImU32 color, ImU32 end_color) {
			if (!draw_list || traj.points.size() < 2)
				return;

			ImVec2 prev_screen{};
			bool prev_valid = world_to_screen(traj.points.front(), prev_screen);
			for (size_t i = 1; i < traj.points.size(); ++i) {
				ImVec2 cur_screen{};
				const bool cur_valid = world_to_screen(traj.points[i], cur_screen);
				if (prev_valid && cur_valid) {
					draw_list->AddLine(prev_screen, cur_screen, IM_COL32(0, 0, 0, 180), 3.0f);
					draw_list->AddLine(prev_screen, cur_screen, color, 1.6f);
				}
				prev_screen = cur_screen;
				prev_valid = cur_valid;
			}

			for (const auto& bounce : traj.bounces) {
				ImVec2 screen{};
				if (world_to_screen(bounce, screen)) {
					draw_list->AddCircleFilled(screen, 3.0f, IM_COL32(0, 0, 0, 190), 12);
					draw_list->AddCircleFilled(screen, 2.0f, color, 12);
				}
			}

			ImVec2 end_screen{};
			if (traj.valid && world_to_screen(traj.end_pos, end_screen)) {
				draw_list->AddCircle(end_screen, 5.0f, IM_COL32(0, 0, 0, 190), 18, 2.0f);
				draw_list->AddCircle(end_screen, 4.0f, end_color, 18, 1.5f);
			}
		}

		void draw_held(c_cs_player_pawn* local_pawn, ImDrawList* draw_list, ImU32 color, ImU32 end_color) {
			if (!local_pawn || !g_interfaces || !g_interfaces->m_csgo_input)
				return;
			// Never TraceShape while throwing — release races Present → client.dll crash.
			if (local_pawn->is_throwing())
				return;

			auto* weapon = local_pawn->get_active_weapon();
			if (!weapon)
				return;

			uint16_t def_index = 0;
			if (auto* attr_mgr = weapon->m_attribute_manager())
				if (auto* item = attr_mgr->m_item())
					def_index = item->m_definition_index();

			kind type{};
			if (!kind_from_def_index(def_index, type))
				return;

			auto* grenade = reinterpret_cast<c_base_cs_grenade*>(weapon);
			if (!grenade || !grenade->m_held_by_player())
				return;

			if (!grenade->m_pin_pulled())
				return;

			const float throw_strength = std::clamp(grenade->m_throw_strength(), 0.0f, 1.0f);
			const vec3_t angles = g_interfaces->m_csgo_input->get_view_angles();
			const vec3_t forward = forward_from_angles(angles);
			const vec3_t start = eye_position(local_pawn) + forward * 16.0f + vec3_t(0.0f, 0.0f, throw_strength * 12.0f - 12.0f);
			const vec3_t velocity = compute_initial_velocity(angles, weapon_throw_velocity(weapon, def_index), throw_strength) +
				local_pawn->m_vec_abs_velocity() * 1.25f;

			// Vacuum only — TraceShape from Present during pin-hold still races throw.
			trajectory traj{};
			vec3_t end = start;
			if (simulate_vacuum_end(start, velocity, type, end)) {
				traj.valid = true;
				traj.end_pos = end;
				traj.points.push_back(start);
				traj.points.push_back(end);
			}
			draw_trajectory(draw_list, traj, color, end_color);
		}

		void draw_projectiles(c_cs_player_pawn* local_pawn, ImDrawList* draw_list, ImU32 color, ImU32 end_color) {
			if (!local_pawn)
				return;

			const int scan_limit = get_entity_scan_limit();
			for (int i = 1; i <= scan_limit; ++i) {
				auto* entity = get_base_entity_safe(i);
				if (!entity)
					continue;

				kind type{};
				if (!kind_from_projectile(entity, type))
					continue;

				auto* node = entity->m_scene_node();
				if (!node)
					continue;

				const vec3_t origin = node->m_abs_origin();
				const vec3_t velocity = projectile_sim_velocity(entity, origin);
				if (!origin.is_valid() || !velocity.is_valid())
					continue;
				if (!std::isfinite(velocity.x) || !std::isfinite(velocity.y) || !std::isfinite(velocity.z))
					continue;
				if (velocity.length() > 5000.f)
					continue;

				// Fresh throw / local-owned: TraceShape from Present races the
				// engine throw path → client.dll crash ~0.5s later. Vacuum only.
				int bounces = 0;
				memsafe::read_field(entity, 0x11E0, bounces);

				bool local_owned = false;
				{
					const auto oh = entity->m_owner_entity();
					if (oh.is_valid()) {
						auto* owner = get_base_entity_safe(oh.get_entry_index());
						if (owner && owner == reinterpret_cast<c_base_entity*>(local_pawn))
							local_owned = true;
					}
				}

				if (bounces <= 0 || local_owned) {
					trajectory traj{};
					vec3_t end = origin;
					if (simulate_vacuum_end(origin, velocity, type, end)) {
						traj.valid = true;
						traj.end_pos = end;
						traj.points.push_back(origin);
						traj.points.push_back(end);
					}
					draw_trajectory(draw_list, traj, color, end_color);
				} else {
					draw_trajectory(draw_list, simulate(origin, velocity, type, reinterpret_cast<uintptr_t>(local_pawn)), color, end_color);
				}
			}
		}
	}

	float* get_view_matrix() {
		// sdk-info offsets.json dwViewMatrix / pViewMatrix = 0x23AA340
		static float* cached = nullptr;
		if (!cached && g_modules) {
			const auto base = g_modules->m_modules.client_dll.get();
			if (base)
				cached = reinterpret_cast<float*>(base + offsets::client::pViewMatrix);
		}
		if (!cached) {
			cached = reinterpret_cast<float*>(
				g_opcodes->scan_absolute(
					g_modules->m_modules.client_dll.get_name(),
					"48 8D 0D ? ? ? ? 48 C1 E0 06",
					0x3
				)
			);
		}
		return cached;
	}

	bool world_to_screen(const vec3_t& in, ImVec2& out) {
		float* matrix = get_view_matrix();
		if (!matrix)
			return false;
		const float w = matrix[12] * in.x + matrix[13] * in.y + matrix[14] * in.z + matrix[15];
		if (w < 0.0001f)
			return false;
		const float x = matrix[0] * in.x + matrix[1] * in.y + matrix[2] * in.z + matrix[3];
		const float y = matrix[4] * in.x + matrix[5] * in.y + matrix[6] * in.z + matrix[7];
		const ImVec2 display = ImGui::GetIO().DisplaySize;
		out.x = (display.x * 0.5f) + ((x / w) * display.x * 0.5f);
		out.y = (display.y * 0.5f) - ((y / w) * display.y * 0.5f);
		return std::isfinite(out.x) && std::isfinite(out.y);
	}

	static std::string to_lower_case(const std::string& str) {
		if (str.empty())
			return str;

		bool ascii_only = true;
		bool has_upper = false;
		for (const unsigned char c : str) {
			if (c >= 0x80) {
				ascii_only = false;
				break;
			}
			if (c >= 'A' && c <= 'Z')
				has_upper = true;
		}

		if (ascii_only) {
			if (!has_upper)
				return str;

			std::string result = str;
			for (char& c : result)
				if (c >= 'A' && c <= 'Z')
					c = static_cast<char>(c + 32);
			return result;
		}

		const auto size = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, nullptr, 0);
		std::wstring wstr(size, 0);
		MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, &wstr[0], size);
		CharLowerW(&wstr[0]);
		const auto size2 = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, nullptr, 0, nullptr, nullptr);
		std::string result(size2 - 1, 0);
		WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), -1, &result[0], size2, nullptr, nullptr);
		return result;
	}

	static bool copy_c_string(char* out, std::size_t out_size, const char* str, std::size_t* out_len) {
		if (!out || out_size == 0 || !str || !out_len)
			return false;

		*out_len = 0;
		out[0] = '\0';
		const std::size_t capped_len = out_size - 1;
		__try {
			for (; *out_len < capped_len && str[*out_len] != '\0'; ++(*out_len))
				out[*out_len] = str[*out_len];
			out[*out_len] = '\0';
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			*out_len = 0;
			out[0] = '\0';
			return false;
		}

		return true;
	}

	static std::string read_c_string(const char* str) {
		if (!str)
			return {};

		char buffer[128] = {};
		std::size_t len = 0;
		if (!copy_c_string(buffer, sizeof(buffer), str, &len))
			return {};
		return std::string(buffer, len);
	}

	static std::string normalize_weapon_name(std::string name) {
		if (name.empty())
			return {};

		name = to_lower_case(name);
		const char* prefixes[] = {
			"weapon_",
			"item_",
			"c_",
		};

		for (auto prefix : prefixes) {
			const std::size_t len = std::strlen(prefix);
			if (name.rfind(prefix, 0) == 0) {
				name.erase(0, len);
				break;
			}
		}

		return name;
	}

	static std::string get_weapon_key(c_base_player_weapon* weapon) {
		if (!weapon)
			return {};

		if (auto* weapon_data = weapon->get_weapon_data()) {
			auto key = normalize_weapon_name(read_c_string(weapon_data->m_name()));
			if (!key.empty())
				return key;
		}

		if (auto* attr_mgr = weapon->m_attribute_manager()) {
			auto* item = attr_mgr->m_item();
			if (item) {
				if (auto* static_data = item->get_static_data()) {
					auto key = normalize_weapon_name(read_c_string(static_data->get_simple_weapon_name()));
					if (!key.empty())
						return key;

					key = normalize_weapon_name(read_c_string(static_data->get_weapon_name()));
					if (!key.empty())
						return key;
				}
			}
		}

		return {};
	}

	static const char* get_weapon_text(const std::string& weapon_key) {
		auto it = weapon_icons::display_table.find(weapon_key);
		if (it != weapon_icons::display_table.end() && it->second && it->second[0] != '\0')
			return it->second;
		return weapon_key.c_str();
	}

	static const char* get_weapon_icon(const std::string& weapon_key) {
		auto it = weapon_icons::icon_table.find(weapon_key);
		if (it != weapon_icons::icon_table.end() && !it->second.empty())
			return it->second.c_str();
		return nullptr;
	}

	static const char* get_class_name_safe(c_base_entity* entity) {
		__try {
			return entity ? entity->get_class_name() : nullptr;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return nullptr;
		}
	}

	static uint16_t get_weapon_definition_index(c_base_player_weapon* weapon) {
		if (!weapon)
			return 0;

		__try {
			if (auto* attr_mgr = weapon->m_attribute_manager()) {
				if (auto* econ_view = attr_mgr->m_item())
					return econ_view->m_definition_index();
			}
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {}

		return 0;
	}

	static bool is_c4_weapon(c_base_player_weapon* weapon, c_base_entity* entity, const char* designer_name) {
		(void)designer_name;
		constexpr uint16_t c4_definition_index = 49;
		if (get_weapon_definition_index(weapon) == c4_definition_index)
			return true;

		__try {
			const char* class_name = entity ? entity->get_class_name() : nullptr;
			return class_name && std::strcmp(class_name, "C_C4") == 0;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return false;
		}
	}

	static bool is_planted_c4_entity(c_base_entity* entity, const char* designer_name) {
		if (designer_name && std::strcmp(designer_name, "planted_c4") == 0)
			return true;

		__try {
			const char* class_name = entity ? entity->get_class_name() : nullptr;
			return class_name && std::strcmp(class_name, "C_PlantedC4") == 0;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return false;
		}
	}

	static bool is_grenade_weapon(c_base_player_weapon* weapon, const char* designer_name) {
		switch (get_weapon_definition_index(weapon)) {
		case WEAPON_FLASHBANG:
		case WEAPON_HEGRENADE:
		case WEAPON_SMOKE:
		case WEAPON_MOLOTOV:
		case WEAPON_DECOY:
		case WEAPON_INCDENDIARY:
			return true;
		default:
			break;
		}

		return designer_name &&
			(std::strstr(designer_name, "flashbang") || std::strstr(designer_name, "hegrenade") ||
			 std::strstr(designer_name, "smokegrenade") || std::strstr(designer_name, "molotov") ||
			 std::strstr(designer_name, "decoy") || std::strstr(designer_name, "incgrenade") ||
			 std::strstr(designer_name, "incendiary"));
	}

	static bool is_grenade_weapon_entity(c_base_entity* entity, const char* designer_name) {
		if (designer_name &&
			(std::strstr(designer_name, "flashbang") || std::strstr(designer_name, "hegrenade") ||
			 std::strstr(designer_name, "smokegrenade") || std::strstr(designer_name, "molotov") ||
			 std::strstr(designer_name, "decoy") || std::strstr(designer_name, "incgrenade") ||
			 std::strstr(designer_name, "incendiary"))) {
			return !std::strstr(designer_name, "projectile");
		}

		__try {
			const char* class_name = entity ? entity->get_class_name() : nullptr;
			if (!class_name || std::strstr(class_name, "Projectile"))
				return false;

			return std::strstr(class_name, "Flashbang") || std::strstr(class_name, "HEGrenade") ||
				std::strstr(class_name, "SmokeGrenade") || std::strstr(class_name, "Molotov") ||
				std::strstr(class_name, "Decoy") || std::strstr(class_name, "Incendiary");
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return false;
		}
	}

	static std::string get_grenade_weapon_key(c_base_player_weapon* weapon, c_base_entity* entity, const char* designer_name) {
		switch (get_weapon_definition_index(weapon)) {
		case WEAPON_FLASHBANG: return "flashbang";
		case WEAPON_HEGRENADE: return "hegrenade";
		case WEAPON_SMOKE: return "smokegrenade";
		case WEAPON_MOLOTOV: return "molotov";
		case WEAPON_DECOY: return "decoy";
		case WEAPON_INCDENDIARY: return "incgrenade";
		default:
			break;
		}

		const char* text = designer_name;
		if (!text || !text[0])
			text = get_class_name_safe(entity);

		if (!text)
			return {};

		if (std::strstr(text, "flashbang") || std::strstr(text, "Flashbang")) return "flashbang";
		if (std::strstr(text, "hegrenade") || std::strstr(text, "HEGrenade")) return "hegrenade";
		if (std::strstr(text, "smokegrenade") || std::strstr(text, "SmokeGrenade")) return "smokegrenade";
		if (std::strstr(text, "molotov") || std::strstr(text, "Molotov")) return "molotov";
		if (std::strstr(text, "decoy") || std::strstr(text, "Decoy")) return "decoy";
		if (std::strstr(text, "incgrenade") || std::strstr(text, "incendiary") || std::strstr(text, "Incendiary")) return "incgrenade";
		return {};
	}

	static bool is_weapon_entity_name(c_base_entity* entity, const char* designer_name) {
		if (designer_name && std::strstr(designer_name, "weapon_"))
			return true;
		if (is_grenade_weapon_entity(entity, designer_name))
			return true;

		__try {
			const char* class_name = entity ? entity->get_class_name() : nullptr;
			if (!class_name || std::strstr(class_name, "Projectile"))
				return false;

			return std::strcmp(class_name, "C_Flashbang") == 0 ||
				std::strcmp(class_name, "C_HEGrenade") == 0 ||
				std::strcmp(class_name, "C_SmokeGrenade") == 0 ||
				std::strcmp(class_name, "C_MolotovGrenade") == 0 ||
				std::strcmp(class_name, "C_DecoyGrenade") == 0 ||
				std::strcmp(class_name, "C_IncendiaryGrenade") == 0 ||
				std::strcmp(class_name, "C_C4") == 0;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return false;
		}
	}

	static bool is_weapon_in_player_inventory(c_base_player_weapon* weapon) {
		if (!weapon || !g_interfaces || !g_interfaces->m_entity_system)
			return false;

		__try {
			if (g_ctx && g_ctx->m_local_pawn) {
				auto* local_pawn = reinterpret_cast<c_cs_player_pawn*>(g_ctx->m_local_pawn);
				if (local_pawn->get_active_weapon() == weapon)
					return true;

				if (auto* weapon_services = local_pawn->m_weapon_services()) {
					auto& weapons = weapon_services->my_weapons();
					if (weapons.m_elements && weapons.m_size > 0 && weapons.m_size <= 64) {
						for (unsigned int j = 0; j < weapons.m_size; ++j) {
							const auto weapon_handle = weapons.m_elements[j];
							if (!weapon_handle.is_valid())
								continue;

							if (get_base_entity_safe(weapon_handle.get_entry_index()) == weapon)
								return true;
						}
					}
				}
			}

			for (int i = 1; i <= 64; ++i) {
				auto* entity = get_base_entity_safe(i);
				if (!entity || !entity->is_player_controller())
					continue;

				auto* controller = reinterpret_cast<c_cs_player_controller*>(entity);
				const auto pawn_handle = controller->m_pawn();
				if (!pawn_handle.is_valid())
					continue;

				auto* pawn = reinterpret_cast<c_cs_player_pawn*>(get_base_entity_safe(pawn_handle.get_entry_index()));
				if (!pawn)
					continue;

				if (pawn->get_active_weapon() == weapon)
					return true;

				auto* weapon_services = pawn->m_weapon_services();
				if (!weapon_services)
					continue;

				auto& weapons = weapon_services->my_weapons();
				if (!weapons.m_elements || weapons.m_size == 0 || weapons.m_size > 64)
					continue;

				for (unsigned int j = 0; j < weapons.m_size; ++j) {
					const auto weapon_handle = weapons.m_elements[j];
					if (!weapon_handle.is_valid())
						continue;

					if (get_base_entity_safe(weapon_handle.get_entry_index()) == weapon)
						return true;
				}
			}
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return false;
		}

		return false;
	}

	static bool is_dropped_weapon(c_base_player_weapon* weapon, const char* designer_name, bool grenade_weapon_entity = false) {
		if (!weapon)
			return false;
		(void)designer_name;
		(void)grenade_weapon_entity;

		if (is_weapon_in_player_inventory(weapon))
			return false;

		__try {
			const auto owner_handle = weapon->m_owner_entity();
			if (owner_handle.is_valid())
				return false;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return false;
		}

		return true;
	}

	static void draw_centered_text(ImDrawList* draw_list, ImFont* font, float font_size, const ImVec2& pos, ImU32 color, const char* text) {
		if (!text || text[0] == '\0')
			return;

		const auto text_size = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, text);
		const auto x = floorf(pos.x - text_size.x * 0.5f);
		const auto y = floorf(pos.y);
		draw_list->AddText(font, font_size, ImVec2(x + 1.0f, y + 1.0f), IM_COL32(0, 0, 0, 255), text);
		draw_list->AddText(font, font_size, ImVec2(x, y), color, text);
	}

	static unsigned int utf8_first_codepoint(const char* text) {
		if (!text || !text[0])
			return 0;

		const unsigned char b0 = static_cast<unsigned char>(text[0]);
		if (b0 < 0x80)
			return b0;
		if ((b0 & 0xE0) == 0xC0)
			return ((b0 & 0x1F) << 6) | (static_cast<unsigned char>(text[1]) & 0x3F);
		if ((b0 & 0xF0) == 0xE0)
			return ((b0 & 0x0F) << 12) | ((static_cast<unsigned char>(text[1]) & 0x3F) << 6) | (static_cast<unsigned char>(text[2]) & 0x3F);
		if ((b0 & 0xF8) == 0xF0)
			return ((b0 & 0x07) << 18) | ((static_cast<unsigned char>(text[1]) & 0x3F) << 12) | ((static_cast<unsigned char>(text[2]) & 0x3F) << 6) | (static_cast<unsigned char>(text[3]) & 0x3F);
		return 0;
	}

	static void draw_centered_icon(ImDrawList* draw_list, ImFont* font, float font_size, const ImVec2& pos, ImU32 color, const char* icon) {
		if (!font || !icon || icon[0] == '\0')
			return;

		const auto codepoint = utf8_first_codepoint(icon);
		const ImFontGlyph* glyph = codepoint ? font->FindGlyph(static_cast<ImWchar>(codepoint)) : nullptr;
		if (!glyph) {
			draw_centered_text(draw_list, font, font_size, pos, color, icon);
			return;
		}

		const float scale = font_size / font->FontSize;
		const float x = floorf(pos.x - ((glyph->X0 + glyph->X1) * scale) * 0.5f);
		const float y = floorf(pos.y);
		draw_list->AddText(font, font_size, ImVec2(x + 1.0f, y + 1.0f), IM_COL32(0, 0, 0, 255), icon);
		draw_list->AddText(font, font_size, ImVec2(x, y), color, icon);
	}

	static const pixel_font_5x5::glyph_t* pixel_glyph(char c) {
		const char lower = (c >= 'A' && c <= 'Z') ? static_cast<char>(c + 32) : c;
		const auto& g = pixel_font_5x5::glyphs[static_cast<unsigned char>(lower)];
		return g.width > 0 ? &g : nullptr;
	}

	static void draw_pixel_text(ImDrawList* draw_list, const ImVec2& pos, ImU32 color, const char* text) {
		float x = pos.x;
		float y = pos.y;
		const float pixel_size = 1.0f;
		const float char_spacing = 1.0f;
		const ImU32 outline = IM_COL32(0, 0, 0, 255);

		for (const char* c = text; *c != '\0'; ++c) {
			const auto* glyph_ptr = pixel_glyph(*c);
			if (!glyph_ptr) {
				x += 4.0f + char_spacing;
				continue;
			}

			const auto& glyph = *glyph_ptr;
			const auto pixel_at = [&](int px, int py) {
				return (glyph.rows[py] >> (glyph.width - 1 - px)) & 1;
			};

			for (int py = 0; py < glyph.height; ++py) {
				for (int px = 0; px < glyph.width; ++px) {
					if (pixel_at(px, py)) {
						float px_x = x + px * pixel_size;
						float px_y = y + py * pixel_size;

						for (int dy = -1; dy <= 1; ++dy) {
							for (int dx = -1; dx <= 1; ++dx) {
								if (dx == 0 && dy == 0) continue;
								int nx = px + dx;
								int ny = py + dy;
								bool is_empty = (nx < 0 || nx >= glyph.width ||
								                ny < 0 || ny >= glyph.height ||
								                !pixel_at(nx, ny));
								if (is_empty) {
									draw_list->AddRectFilled(
										ImVec2(px_x + dx * pixel_size, px_y + dy * pixel_size),
										ImVec2(px_x + dx * pixel_size + pixel_size, px_y + dy * pixel_size + pixel_size),
										outline
									);
								}
							}
						}
					}
				}
			}

			for (int py = 0; py < glyph.height; ++py) {
				for (int px = 0; px < glyph.width; ++px) {
					if (pixel_at(px, py)) {
						draw_list->AddRectFilled(
							ImVec2(x + px * pixel_size, y + py * pixel_size),
							ImVec2(x + px * pixel_size + pixel_size, y + py * pixel_size + pixel_size),
							color
						);
					}
				}
			}

			x += glyph.width * pixel_size + char_spacing;
		}
	}

	static ImVec2 calc_pixel_text_size(const char* text) {
		float width = 0.0f;
		const float pixel_size = 1.0f;
		const float char_spacing = 1.0f;

		for (const char* c = text; *c != '\0'; ++c) {
			const auto* glyph = pixel_glyph(*c);
			if (glyph) {
				width += glyph->width * pixel_size + char_spacing;
			} else {
				width += 4.0f + char_spacing;
			}
		}

		return ImVec2(width, 5.0f * pixel_size);
	}

	static float get_pixel_font_height() {
		return 5.0f;
	}

	static void draw_small_text(ImDrawList* draw_list, const ImVec2& pos, ImU32 color, const char* text) {
		draw_pixel_text(draw_list, pos, color, text);
	}

	static bool draw_bomb_world_esp(ImDrawList* draw_list, const vec3_t& bomb_origin, const vec3_t& local_origin, float remaining = -1.0f) {
		if (!draw_list || !g_cfg || !bomb_origin.is_valid())
			return false;

		ImVec2 screen_pos{};
		if (!world_to_screen(bomb_origin, screen_pos))
			return false;

		const ImU32 color = ImGui::ColorConvertFloat4ToU32(g_cfg->visuals.m_bomb_esp_color);
		float y_offset = 0.0f;

		if (g_cfg->visuals.m_bomb_esp_type & (1 << 0)) {
			if (auto* icon = get_weapon_icon("c4")) {
				if (g_menu) {
					if (auto* icon_font = g_menu->get_weapon_icon_font()) {
						draw_centered_icon(draw_list, icon_font, icon_font->FontSize, ImVec2(screen_pos.x, screen_pos.y + y_offset), color, icon);
						y_offset += icon_font->FontSize + 2.0f;
					}
				}
			}
		}

		if (g_cfg->visuals.m_bomb_esp_type & (1 << 1)) {
			const auto text_size = calc_pixel_text_size("c4");
			const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
			draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, "c4");
			y_offset += get_pixel_font_height() + 2.0f;
		}

		if ((g_cfg->visuals.m_bomb_esp_type & (1 << 2)) && std::isfinite(remaining) && remaining > 0.0f) {
			char timer_text[64];
			snprintf(timer_text, sizeof(timer_text), "%.1fs", remaining);
			const auto text_size = calc_pixel_text_size(timer_text);
			const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
			draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, timer_text);
			y_offset += get_pixel_font_height() + 2.0f;
		}

		if ((g_cfg->visuals.m_bomb_esp_type & (1 << 3)) && local_origin.is_valid()) {
			const float distance = sqrtf(
				(bomb_origin.x - local_origin.x) * (bomb_origin.x - local_origin.x) +
				(bomb_origin.y - local_origin.y) * (bomb_origin.y - local_origin.y) +
				(bomb_origin.z - local_origin.z) * (bomb_origin.z - local_origin.z)
			) * 0.0254f;
			char buf[32];
			snprintf(buf, sizeof(buf), "%.0fm", distance);
			const auto text_size = calc_pixel_text_size(buf);
			const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
			draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, buf);
		}

		return true;
	}

	static bool draw_planted_c4_from_address(ImDrawList* draw_list, uintptr_t planted_c4, c_cs_player_pawn* local_pawn, const vec3_t& local_origin) {
		if (!planted_c4 || !draw_list || !local_pawn)
			return false;

		const auto* entity = reinterpret_cast<c_base_entity*>(planted_c4);
		if (!is_planted_c4_entity(const_cast<c_base_entity*>(entity), nullptr))
			return false;

		constexpr uintptr_t m_bBombTicking = 0x1160;
		constexpr uintptr_t m_flC4Blow = 0x1190;
		constexpr uintptr_t m_pGameSceneNode = 0x330;
		constexpr uintptr_t m_vecAbsOrigin = 0xC8;
		constexpr uintptr_t m_flSimulationTime = 0x3B8;

		const bool is_ticking = read<bool>(planted_c4 + m_bBombTicking);
		if (!is_ticking)
			return false;

		const uintptr_t scene_node = read<uintptr_t>(planted_c4 + m_pGameSceneNode);
		if (!scene_node)
			return false;

		const vec3_t origin = read<vec3_t>(scene_node + m_vecAbsOrigin);
		if (!origin.is_valid())
			return false;

		float remaining = -1.0f;
		if (is_ticking) {
			const float c4_blow_time = read<float>(planted_c4 + m_flC4Blow);
			const float current_time = read<float>(reinterpret_cast<uintptr_t>(local_pawn) + m_flSimulationTime);
			const float candidate = c4_blow_time - current_time;
			if (std::isfinite(candidate) && candidate > 0.0f && candidate < 120.0f)
				remaining = candidate;
		}

		return draw_bomb_world_esp(draw_list, origin, local_origin, remaining);
	}

	static const char* get_grenade_name(grenade_prediction::kind type) {
		switch (type) {
		case grenade_prediction::kind::flashbang: return "flashbang";
		case grenade_prediction::kind::he: return "he grenade";
		case grenade_prediction::kind::smoke: return "smoke";
		case grenade_prediction::kind::decoy: return "decoy";
		case grenade_prediction::kind::molotov: return "molotov";
		case grenade_prediction::kind::incendiary: return "incendiary";
		default: return "grenade";
		}
	}

	static const char* get_grenade_icon_key(grenade_prediction::kind type) {
		switch (type) {
		case grenade_prediction::kind::flashbang: return "flashbang";
		case grenade_prediction::kind::he: return "hegrenade";
		case grenade_prediction::kind::smoke: return "smokegrenade";
		case grenade_prediction::kind::molotov: return "molotov";
		case grenade_prediction::kind::decoy: return "decoy";
		case grenade_prediction::kind::incendiary: return "incgrenade";
		default: return "";
		}
	}

	static bool is_grenade_held_by_player(c_base_entity* entity) {
		if (!entity)
			return false;
		__try {
			// Flying projectiles are never "held" — don't SCHEMA-read weapon fields on them.
			const char* designer = entity->get_designer_name();
			const char* cls = entity->get_class_name();
			if ((designer && std::strstr(designer, "_projectile")) ||
				(cls && std::strstr(cls, "Projectile")))
				return false;

			auto* grenade_weapon = reinterpret_cast<c_base_cs_grenade*>(entity);
			if (grenade_weapon && grenade_weapon->m_held_by_player())
				return true;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return false;
		}
		return false;
	}

	// Isolated so SEH never wraps std::vector / ImGui C++ frames from simulate().
	__declspec(noinline) static bool safe_nade_land_pos(
		c_base_entity* entity,
		c_cs_player_pawn* local_pawn,
		grenade_prediction::kind type,
		const vec3_t& origin,
		vec3_t& out_land)
	{
		out_land = origin;
		if (!entity || !local_pawn || !origin.is_valid())
			return false;
		if (!grenade_prediction::available())
			return false;

		static std::uint32_t off_init_vel = 0, off_init_pos = 0, off_bounces = 0;
		static bool once = false;
		if (!once) {
			off_init_vel = 0x11D4;
			off_init_pos = 0x11C8;
			off_bounces = 0x11E0;
			once = true;
		}

		int bounces = 0;
		memsafe::read_field(entity, off_bounces, bounces);

		vec3_t start = origin;
		vec3_t vel{};
		__try {
			vel = projectile_sim_velocity(entity, origin);
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			return false;
		}

		// Pre-bounce: predict from throw origin + initial velocity (stable badge).
		if (bounces <= 0) {
			vec3_t iv{}, ip{};
			if (memsafe::read_field(entity, off_init_vel, iv) && memsafe::read_field(entity, off_init_pos, ip)
				&& iv.is_valid() && iv.length() > 5.f && ip.is_valid()) {
				start = ip;
				vel = iv;
			}
		}

		if (!vel.is_valid() || vel.length() < 0.5f)
			return false;
		if (!std::isfinite(vel.x) || !std::isfinite(vel.y) || !std::isfinite(vel.z))
			return false;
		if (vel.length() > 5000.f)
			return false;

		vec3_t end = start;
		bool ok = false;
		// Prefer vacuum for pre-bounce / local throw (avoids TraceShape race after throw).
		bool local_nade = false;
		{
			const auto oh = entity->m_owner_entity();
			if (oh.is_valid()) {
				auto* owner = get_base_entity_safe(oh.get_entry_index());
				if (owner && owner == reinterpret_cast<c_base_entity*>(local_pawn))
					local_nade = true;
			}
		}
		if (bounces <= 0 || local_nade)
			ok = grenade_prediction::simulate_vacuum_end(start, vel, type, end);
		else {
			__try {
				ok = grenade_prediction::simulate_end_pos(
					start, vel, type, reinterpret_cast<uintptr_t>(local_pawn), end);
			}
			__except (EXCEPTION_EXECUTE_HANDLER) {
				ok = grenade_prediction::simulate_vacuum_end(start, vel, type, end);
			}
		}

		if (ok && end.is_valid()) {
			out_land = end;
			return true;
		}
		return false;
	}

	static int safe_armor(c_cs_player_pawn* pawn) {
		int v = 0;
		if (!pawn) return v;
		__try { v = pawn->m_armor_value(); }
		__except (EXCEPTION_EXECUTE_HANDLER) { v = 0; }
		return v;
	}
	static int safe_health(c_cs_player_pawn* pawn) {
		int v = 100;
		if (!pawn) return v;
		__try { v = pawn->m_health(); }
		__except (EXCEPTION_EXECUTE_HANDLER) { v = 100; }
		return v;
	}

	struct nade_warn_cache_t {
		void* ent = nullptr;
		int bounces = -1;
		vec3_t land{};
		bool valid = false;
	};

	static void draw_grenade_warnings(c_cs_player_pawn* local_pawn, ImDrawList* draw_list, const vec3_t& local_origin) {
		if (!local_pawn || !draw_list || !g_cfg || !local_origin.is_valid())
			return;
		if (hooks::in_entity_transition())
			return;

		const float range_u = std::clamp(g_cfg->visuals.m_grenade_warning_range, 5.f, 200.f) / 0.0254f;
		const int armor = safe_armor(local_pawn);
		const int local_hp = safe_health(local_pawn);
		const int scan_limit = get_entity_scan_limit();

		static nade_warn_cache_t cache[48];

		for (int i = 1; i <= scan_limit; ++i) {
			auto* entity = get_base_entity_safe(i);
			if (!entity || !memsafe::valid_entity(entity))
				continue;

			grenade_prediction::kind type{};
			if (!grenade_prediction::kind_from_projectile(entity, type))
				continue;
			if (is_grenade_held_by_player(entity))
				continue;

			c_game_scene_node* node = entity->m_scene_node();
			if (!node)
				continue;

			vec3_t origin = node->m_abs_origin();
			if (!origin.is_valid())
				continue;

			int bounces = 0;
			memsafe::read_field(entity, 0x11E0, bounces);

			nade_warn_cache_t* slot = nullptr;
			for (auto& c : cache) {
				if (c.ent == entity) { slot = &c; break; }
			}
			if (!slot) {
				for (auto& c : cache) {
					if (!c.ent) { slot = &c; break; }
				}
				if (!slot) slot = &cache[i % 48];
				slot->ent = entity;
				slot->valid = false;
				slot->bounces = -1;
			}

			vec3_t land = origin;
			const bool need_resim = !slot->valid || slot->bounces != bounces
				|| (slot->land - origin).length_sqr() > (800.f * 800.f);
			if (need_resim) {
				if (safe_nade_land_pos(entity, local_pawn, type, origin, land) && land.is_valid()) {
					slot->land = land;
					slot->bounces = bounces;
					slot->valid = true;
				} else {
					slot->land = origin;
					slot->bounces = bounces;
					slot->valid = true;
				}
			}
			land = slot->valid ? slot->land : origin;

			const float dist_land = (land - local_origin).length();
			if (dist_land > range_u)
				continue;

			ImVec2 screen{};
			bool on_scr = false;
			if (!project_or_edge(land, screen, on_scr, 36.f))
				continue;

			const float time_left = read_grenade_time_left(entity);

			int dmg = 0;
			if (type == grenade_prediction::kind::he) {
				dmg = apply_armor_dmg(he_damage_raw(dist_land), armor);
				if (dmg > local_hp)
					dmg = local_hp;
			}

			draw_nade_warn_badge(draw_list, screen.x, screen.y,
				g_cfg->visuals.m_grenade_warning_color,
				get_grenade_icon_key(type),
				get_grenade_name(type),
				time_left,
				dmg,
				!on_scr);
		}
	}

	static void draw_grenade_esp(c_cs_player_pawn* local_pawn, ImDrawList* draw_list, ImU32 color, const vec3_t& local_pos) {
		if (!local_pawn || !draw_list || !g_cfg)
			return;

		const bool need_distance = (g_cfg->visuals.m_grenades_type & (1 << 2)) != 0;
		const bool valid_local_pos = local_pos.is_valid();

		const int scan_limit = get_entity_scan_limit();
		for (int i = 1; i <= scan_limit; ++i) {
			auto* entity = get_base_entity_safe(i);
			if (!entity)
				continue;

			auto* identity = entity->m_entity();
			if (!is_valid_identity(identity))
				continue;

			grenade_prediction::kind type{};
			if (!grenade_prediction::kind_from_projectile(entity, type))
				continue;

			auto* node = entity->m_scene_node();
			if (!node)
				continue;

			const vec3_t origin = node->m_abs_origin();
			if (!origin.is_valid())
				continue;

			ImVec2 screen_pos{};
			if (!world_to_screen(origin, screen_pos))
				continue;

			float y_offset = 0.0f;

			if (g_cfg->visuals.m_grenades_type & (1 << 0)) {
				const char* icon_key = get_grenade_icon_key(type);
				if (icon_key && icon_key[0]) {
					if (auto* icon = get_weapon_icon(icon_key)) {
						if (auto* icon_font = g_menu->get_weapon_icon_font()) {
							draw_centered_icon(draw_list, icon_font, icon_font->FontSize, ImVec2(screen_pos.x, screen_pos.y + y_offset), color, icon);
							y_offset += icon_font->FontSize + 2.0f;
						}
					}
				}
			}

			if (g_cfg->visuals.m_grenades_type & (1 << 1)) {
				const char* name = get_grenade_name(type);
				if (name && name[0]) {
					const auto text_size = calc_pixel_text_size(name);
					const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
					draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, name);
					y_offset += get_pixel_font_height() + 2.0f;
				}
			}

			if (need_distance && valid_local_pos) {
				const float distance = sqrtf(
					(origin.x - local_pos.x) * (origin.x - local_pos.x) +
					(origin.y - local_pos.y) * (origin.y - local_pos.y) +
					(origin.z - local_pos.z) * (origin.z - local_pos.z)
				) * 0.0254f;
				char buf[32];
				snprintf(buf, sizeof(buf), "%.0fm", distance);
				const auto text_size = calc_pixel_text_size(buf);
				const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
				draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, buf);
				y_offset += get_pixel_font_height() + 2.0f;
			}

			if (g_cfg->visuals.m_grenades_type & (1 << 3)) {

				constexpr uintptr_t m_flSpawnTime = 0x11D8;
				constexpr uintptr_t m_flDetonateTime = 0x1160;
				constexpr uintptr_t m_flSimulationTime = 0x3B8;

				float spawn_time = read<float>(reinterpret_cast<uintptr_t>(entity) + m_flSpawnTime);
				float detonate_time = read<float>(reinterpret_cast<uintptr_t>(entity) + m_flDetonateTime);
				float current_time = read<float>(reinterpret_cast<uintptr_t>(entity) + m_flSimulationTime);

				float time_remaining = 0.0f;

				if (detonate_time > 0.0f && current_time > 0.0f) {
					time_remaining = detonate_time - current_time;
				} else if (spawn_time > 0.0f && current_time > 0.0f) {

					float elapsed = current_time - spawn_time;
					switch (type) {
						case grenade_prediction::kind::he:
						case grenade_prediction::kind::flashbang:
							time_remaining = 1.5f - elapsed;
							break;
						case grenade_prediction::kind::smoke:
							time_remaining = 18.0f - elapsed;
							break;
						case grenade_prediction::kind::molotov:
						case grenade_prediction::kind::incendiary:
							time_remaining = 7.0f - elapsed;
							break;
						case grenade_prediction::kind::decoy:
							time_remaining = 15.0f - elapsed;
							break;
					}
				}

				if (time_remaining > 0.0f) {
					char buf[32];
					snprintf(buf, sizeof(buf), "%.1fs", time_remaining);
					const auto text_size = calc_pixel_text_size(buf);
					const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
					draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, buf);
					y_offset += get_pixel_font_height() + 2.0f;
				}
			}
		}
	}

	static ImVec2 calc_small_text_size(const char* text) {
		return calc_pixel_text_size(text);
	}

	static float get_small_font_size() {
		return get_pixel_font_height();
	}

	static void draw_health_bar(ImDrawList* draw_list, int health, float animated_health, const ImVec2& box_min, const ImVec2& box_max) {
		if (!g_cfg->visuals.m_health_bar)
			return;
		if (health <= 0 || animated_health <= 0.0f)
			return;

		const auto anim_clamped = (std::min)(animated_health, 100.0f);
		const auto frac = anim_clamped / 100.0f;
		const auto box_h = box_max.y - box_min.y;
		const float fill_h = box_h * frac;
		const float bar_x = box_min.x - 5.0f;
		const float bar_y = box_max.y - fill_h;

		bool show_bar = (g_cfg->visuals.m_health_type & (1 << 1)) != 0;
		bool show_gradient = (g_cfg->visuals.m_health_type & (1 << 2)) != 0;
		bool show_text = (g_cfg->visuals.m_health_type & (1 << 0)) != 0;

		if (show_bar) {
			const auto outline = scale_imu32_alpha(IM_COL32(0, 0, 0, 180));
			draw_list->AddRectFilled(ImVec2(bar_x - 1.0f, box_min.y - 1.0f), ImVec2(bar_x + 3.0f, box_max.y + 1.0f), outline);

			if (show_gradient) {
				const auto& low = g_cfg->visuals.m_health_low_color;
				const auto& high = g_cfg->visuals.m_health_high_color;
				const float t = frac;
				const ImVec4 top_color(
					low.x + (high.x - low.x) * t,
					low.y + (high.y - low.y) * t,
					low.z + (high.z - low.z) * t,
					low.w + (high.w - low.w) * t
				);

				draw_list->AddRectFilledMultiColor(
					ImVec2(bar_x, bar_y),
					ImVec2(bar_x + 2.0f, box_max.y),
					color_with_alpha(top_color),
					color_with_alpha(top_color),
					color_with_alpha(low),
					color_with_alpha(low)
				);
			} else {
				const auto bar_color = color_with_alpha(g_cfg->visuals.m_health_high_color);
				draw_list->AddRectFilled(ImVec2(bar_x, bar_y), ImVec2(bar_x + 2.0f, box_max.y), bar_color);
			}

		if (show_text && health < 100) {
			char buf[16];
			snprintf(buf, sizeof(buf), "%d", health);
			const auto text_size = calc_small_text_size(buf);
			const auto text_x = floorf(bar_x - text_size.x * 0.5f + 1.0f);
			const auto text_y = floorf(bar_y - text_size.y - 1.0f);
			draw_small_text(draw_list, ImVec2(text_x, text_y), scale_imu32_alpha(IM_COL32(255, 255, 255, 255)), buf);
		}
	} else if (show_text && health < 100) {
		char buf[16];
		snprintf(buf, sizeof(buf), "%d", health);
		const auto text_size = calc_small_text_size(buf);
		const auto text_x = floorf(box_min.x - 5.0f - text_size.x - 2.0f);
		const auto text_y = floorf(box_min.y - 2.0f);
		draw_small_text(draw_list, ImVec2(text_x, text_y), scale_imu32_alpha(IM_COL32(255, 255, 255, 255)), buf);
	}
	}

	static bool get_bone_position(c_cs_player_pawn* pawn, int bone, vec3_t& out) {
		if (!pawn || bone < 0)
			return false;

		auto* scene_node = pawn->m_scene_node();
		if (!scene_node)
			return false;

		const auto node = reinterpret_cast<std::uintptr_t>(scene_node);
		const auto bone_array = read<std::uintptr_t>(
			node + cs2::verified::ESP::CSkeletonInstance__m_modelState + 0x80
		);
		if (!bone_array)
			return false;

		const auto bone_data = read<c_bone_data>(bone_array + sizeof(c_bone_data) * bone);
		if (!bone_data.m_pos.is_valid() || bone_data.m_pos.is_zero())
			return false;

		out = bone_data.m_pos;
		return true;
	}

	static void draw_skeleton(ImDrawList* draw_list, c_cs_player_pawn* pawn, const ImVec2& box_min, const ImVec2& box_max) {
		if (!g_cfg->visuals.m_skeleton || !pawn)
			return;

		__try {
			auto find_bone = [&](const char* name) -> int {
				if (!name || !name[0])
					return -1;

				__try {
					const int index = pawn->get_bone_index(name);
					return index >= 0 && index < 128 ? index : -1;
				}
				__except (EXCEPTION_EXECUTE_HANDLER) {
					return -1;
				}
			};

			const int pelvis = find_bone("pelvis");
			const int spine0 = find_bone("spine_0");
			const int spine1 = find_bone("spine_1");
			const int spine2 = find_bone("spine_2");
			const int spine3 = find_bone("spine_3");
			const int neck = find_bone("neck_0");
			const int head = find_bone("head_0");
			const int l_upper_arm = find_bone("arm_upper_L");
			const int l_lower_arm = find_bone("arm_lower_L");
			const int l_hand = find_bone("hand_L");
			const int r_upper_arm = find_bone("arm_upper_R");
			const int r_lower_arm = find_bone("arm_lower_R");
			const int r_hand = find_bone("hand_R");
			const int l_upper_leg = find_bone("leg_upper_L");
			const int l_lower_leg = find_bone("leg_lower_L");
			const int l_ankle = find_bone("ankle_L");
			const int r_upper_leg = find_bone("leg_upper_R");
			const int r_lower_leg = find_bone("leg_lower_R");
			const int r_ankle = find_bone("ankle_R");

			const std::pair<int, int> bone_pairs[] = {
				{ head, neck },
				{ neck, spine3 },
				{ spine3, spine2 },
				{ spine2, spine1 },
				{ spine1, spine0 },
				{ spine0, pelvis },
				{ spine3, l_upper_arm },
				{ l_upper_arm, l_lower_arm },
				{ l_lower_arm, l_hand },
				{ spine3, r_upper_arm },
				{ r_upper_arm, r_lower_arm },
				{ r_lower_arm, r_hand },
				{ pelvis, l_upper_leg },
				{ l_upper_leg, l_lower_leg },
				{ l_lower_leg, l_ankle },
				{ pelvis, r_upper_leg },
				{ r_upper_leg, r_lower_leg },
				{ r_lower_leg, r_ankle }
			};

			const ImU32 color = color_with_alpha(g_cfg->visuals.m_skeleton_color);
			const float box_h = (std::max)(1.0f, box_max.y - box_min.y);
			const float max_segment_len = box_h * 0.48f;
			const float min_x = box_min.x - box_h * 0.35f;
			const float max_x = box_max.x + box_h * 0.35f;
			const float min_y = box_min.y - box_h * 0.08f;
			const float max_y = box_max.y + box_h * 0.08f;

			for (const auto& pair : bone_pairs) {
				if (pair.first < 0 || pair.second < 0)
					continue;

				vec3_t a_world, b_world;
				if (!get_bone_position(pawn, pair.first, a_world) || !get_bone_position(pawn, pair.second, b_world))
					continue;

				ImVec2 a_screen, b_screen;
				if (!world_to_screen(a_world, a_screen) || !world_to_screen(b_world, b_screen))
					continue;

				if (a_screen.x < min_x || a_screen.x > max_x || a_screen.y < min_y || a_screen.y > max_y ||
					b_screen.x < min_x || b_screen.x > max_x || b_screen.y < min_y || b_screen.y > max_y)
					continue;

				const float dx = a_screen.x - b_screen.x;
				const float dy = a_screen.y - b_screen.y;
				if ((dx * dx + dy * dy) > max_segment_len * max_segment_len)
					continue;

				draw_list->AddLine(a_screen, b_screen, color, 1.0f);
			}
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {}
	}

	static float draw_flags(ImDrawList* draw_list, c_cs_player_pawn* pawn, c_cs_player_controller* controller, const vec3_t& local_origin, const ImVec2& box_min, const ImVec2& box_max) {
		if (!g_cfg->visuals.m_flags || !pawn)
			return 0.0f;

		const ImU32 flags_color = ImGui::ColorConvertFloat4ToU32(g_cfg->visuals.m_flags_color);
		const float x = box_max.x + 3.0f;
		float y = box_min.y;
		float total_height = 0.0f;
		const float line_height = get_small_font_size();

		if (g_cfg->visuals.m_flags_type & (1 << 0)) {
			const auto scene_node = pawn->m_scene_node();
			if (scene_node) {
				const auto& enemy_origin = scene_node->m_abs_origin();
				const float distance = sqrtf(
					(enemy_origin.x - local_origin.x) * (enemy_origin.x - local_origin.x) +
					(enemy_origin.y - local_origin.y) * (enemy_origin.y - local_origin.y) +
					(enemy_origin.z - local_origin.z) * (enemy_origin.z - local_origin.z)
				) * 0.0254f;

				char buf[32];
				snprintf(buf, sizeof(buf), "%.0fm", distance);
				draw_small_text(draw_list, ImVec2(x, y), flags_color, buf);
				y += line_height + 2.0f;
				total_height += line_height + 2.0f;
			}
		}

		if (g_cfg->visuals.m_flags_type & (1 << 1)) {
			if (controller) {
				auto* money_services = controller->m_money_services();
				if (money_services) {
					int32_t money = money_services->m_account();
					if (money > 0) {
						char buf[32];
						snprintf(buf, sizeof(buf), "$%d", money);
						draw_small_text(draw_list, ImVec2(x, y), flags_color, buf);
						y += line_height + 2.0f;
						total_height += line_height + 2.0f;
					}
				}
			}
		}

		if (g_cfg->visuals.m_flags_type & (1 << 2)) {
			int armor = pawn->m_armor_value();
			if (armor > 0) {
				bool has_helmet = pawn->m_item_services() && pawn->m_item_services()->m_has_helmet();
				char buf[8];
				if (has_helmet) {
					snprintf(buf, sizeof(buf), "HK");
				} else {
					snprintf(buf, sizeof(buf), "K");
				}
				draw_small_text(draw_list, ImVec2(x, y), flags_color, buf);
				y += line_height + 2.0f;
				total_height += line_height + 2.0f;
			}
		}

	if (g_cfg->visuals.m_flags_type & (1 << 3)) {

		bool is_scoped = pawn->m_scoped();

		if (is_scoped) {
			const char* text = "scoped";
			draw_small_text(draw_list, ImVec2(x, y), flags_color, text);
			y += line_height + 2.0f;
			total_height += line_height + 2.0f;
		}
	}

		if (g_cfg->visuals.m_flags_type & (1 << 4)) {

			bool has_c4 = false;
			auto* weapon_services = pawn->m_weapon_services();
			if (weapon_services) {
				auto& weapons = weapon_services->my_weapons();
				for (unsigned int i = 0; i < weapons.m_size; ++i) {
					c_base_handle weapon_handle = weapons.m_elements[i];
					if (!weapon_handle.is_valid())
						continue;

					auto* weapon = reinterpret_cast<c_base_player_weapon*>(
						g_interfaces->m_entity_system->get_base_entity(weapon_handle.get_entry_index())
					);
					if (!weapon)
						continue;

					if (auto* attr_mgr = weapon->m_attribute_manager()) {
						if (auto* econ_view = attr_mgr->m_item()) {
							if (econ_view->m_definition_index() == 49) {
								has_c4 = true;
								break;
							}
						}
					}
				}
			}

			if (has_c4) {
				const char* text = "bomb";
				draw_small_text(draw_list, ImVec2(x, y), flags_color, text);
				y += line_height + 2.0f;
				total_height += line_height + 2.0f;
			}
		}

		return total_height;
	}

	static void draw_name(ImDrawList* draw_list, const char* name, const ImVec2& box_min, const ImVec2& box_max) {
		if (!g_cfg->visuals.m_name || !name || name[0] == '\0')
			return;
		auto player_name = to_lower_case(std::string(name));
		if (player_name.empty())
			return;
		auto* font = ImGui::GetFont();
		const auto font_size = ImGui::GetFontSize();
		const auto text_size = font->CalcTextSizeA(font_size, FLT_MAX, 0.0f, player_name.c_str());
		const auto x = floorf(box_min.x + (box_max.x - box_min.x - text_size.x) * 0.5f);
		const auto y = floorf(box_min.y - text_size.y - 2.0f);
		ImU32 name_color = color_with_alpha(g_cfg->visuals.m_name_color);
		draw_list->AddText(font, font_size, ImVec2(x + 1.0f, y + 1.0f), scale_imu32_alpha(IM_COL32(0, 0, 0, 255)), player_name.c_str());
		draw_list->AddText(font, font_size, ImVec2(x, y), name_color, player_name.c_str());
	}

	static float draw_weapon(ImDrawList* draw_list, c_cs_player_pawn* pawn, const ImVec2& box_min, const ImVec2& box_max, float offset_y) {
		if (!g_cfg->visuals.m_weapon || !pawn)
			return 0.0f;

		auto* weapon = pawn->get_active_weapon();
		const auto weapon_key = get_weapon_key(weapon);
		if (weapon_key.empty())
			return 0.0f;

		const ImU32 weapon_color = color_with_alpha(g_cfg->visuals.m_weapon_color);
		const auto x = box_min.x + (box_max.x - box_min.x) * 0.5f;
		auto y = box_max.y + offset_y;
		float total_height = 0.0f;

		bool show_text = (g_cfg->visuals.m_weapon_type & (1 << 0)) != 0;
		bool show_icon = (g_cfg->visuals.m_weapon_type & (1 << 1)) != 0;

		if (show_icon) {
			if (auto* icon = get_weapon_icon(weapon_key)) {
				if (auto* icon_font = g_menu->get_weapon_icon_font()) {
					draw_centered_icon(draw_list, icon_font, icon_font->FontSize, ImVec2(x, y), weapon_color, icon);
					total_height += icon_font->FontSize;
					if (show_text) {
						y += icon_font->FontSize + 2.0f;
						total_height += 2.0f;
					}
				}
			}
		}

		if (show_text) {
			const std::string text = to_lower_case(get_weapon_text(weapon_key));
			const auto text_size = calc_pixel_text_size(text.c_str());
			const auto text_x = floorf(x - text_size.x * 0.5f);
			draw_small_text(draw_list, ImVec2(text_x, y), weapon_color, text.c_str());
			total_height += get_pixel_font_height();
		}

		return total_height;
	}

	static float draw_ammo(ImDrawList* draw_list, c_cs_player_pawn* pawn, const ImVec2& box_min, const ImVec2& box_max, float offset_y) {
		if (!g_cfg->visuals.m_ammo || !pawn)
			return 0.0f;

		auto* weapon = pawn->get_active_weapon();
		if (!weapon)
			return 0.0f;

		int clip = weapon->m_clip1();
		if (clip < 0)
			return 0.0f;

		auto* weapon_data = weapon->get_weapon_data();
		if (!weapon_data)
			return 0.0f;

		int max_clip = weapon_data->m_max_clip1();
		if (max_clip <= 0)
			return 0.0f;

		const float frac = (float)clip / (float)max_clip;
		const auto box_w = box_max.x - box_min.x;
		const float fill_w = box_w * frac;
		const float bar_y = box_max.y + offset_y;
		float total_height = 0.0f;

		bool show_bar = (g_cfg->visuals.m_ammo_type & (1 << 1)) != 0;
		bool show_gradient = (g_cfg->visuals.m_ammo_type & (1 << 2)) != 0;

		if (show_bar) {
			const auto outline = IM_COL32(0, 0, 0, 180);
			draw_list->AddRectFilled(ImVec2(box_min.x - 1.0f, bar_y - 1.0f), ImVec2(box_max.x + 1.0f, bar_y + 3.0f), outline);

			if (show_gradient) {
				const auto& low = g_cfg->visuals.m_ammo_low_color;
				const auto& high = g_cfg->visuals.m_ammo_high_color;
				const float t = frac;
				const ImVec4 right_color(
					low.x + (high.x - low.x) * t,
					low.y + (high.y - low.y) * t,
					low.z + (high.z - low.z) * t,
					low.w + (high.w - low.w) * t
				);

				draw_list->AddRectFilledMultiColor(
					ImVec2(box_min.x, bar_y),
					ImVec2(box_min.x + fill_w, bar_y + 2.0f),
					ImGui::ColorConvertFloat4ToU32(low),
					ImGui::ColorConvertFloat4ToU32(right_color),
					ImGui::ColorConvertFloat4ToU32(right_color),
					ImGui::ColorConvertFloat4ToU32(low)
				);
			} else {
				const auto bar_color = ImGui::ColorConvertFloat4ToU32(g_cfg->visuals.m_ammo_high_color);
				draw_list->AddRectFilled(ImVec2(box_min.x, bar_y), ImVec2(box_min.x + fill_w, bar_y + 2.0f), bar_color);
			}
			total_height += 4.0f;
		}

		bool show_text = (g_cfg->visuals.m_ammo_type & (1 << 0)) != 0;
		if (show_text) {
			char buf[16];
			snprintf(buf, sizeof(buf), "%d / %d", clip, max_clip);
			const auto text_size = calc_small_text_size(buf);
			const auto x = box_min.x + (box_max.x - box_min.x - text_size.x) * 0.5f;
			const auto y = show_bar ? (bar_y + 4.0f) : bar_y;
			draw_small_text(draw_list, ImVec2(x, y), IM_COL32(255, 255, 255, 255), buf);
			total_height += get_small_font_size();
		}

		return total_height;
	}

	static void draw_corners(ImDrawList* dl, const ImVec2& box_min, const ImVec2& box_max, const ImU32 color, const ImU32 outline_color, float corner_length) {
		const float x1 = box_min.x;
		const float y1 = box_min.y;
		const float x2 = box_max.x;
		const float y2 = box_max.y;
		const float width = (std::max)(1.0f, x2 - x1);
		const float height = (std::max)(1.0f, y2 - y1);
		const float t = std::clamp(corner_length, 0.005f, 0.5f);
		if (t >= 0.5f) {
			dl->AddRect(ImVec2(x1 - 1.0f, y1 - 1.0f), ImVec2(x2 + 1.0f, y2 + 1.0f), outline_color);
			dl->AddRect(ImVec2(x1 + 1.0f, y1 + 1.0f), ImVec2(x2 - 1.0f, y2 - 1.0f), outline_color);
			dl->AddRect(ImVec2(x1, y1), ImVec2(x2, y2), color);
			return;
		}

		const float len = (std::min)(width, height) * t;
		const float h_len = len;
		const float v_len = len;

		dl->AddRectFilled(ImVec2(x1 - 1.0f, y1 - 1.0f), ImVec2(x1 + 1.0f + h_len, y1), outline_color);
		dl->AddRectFilled(ImVec2(x1 - 1.0f, y1 - 1.0f), ImVec2(x1, y1 + 1.0f + v_len), outline_color);
		dl->AddRectFilled(ImVec2(x1 + 1.0f, y1 + 1.0f), ImVec2(x1 + 1.0f + h_len, y1 + 2.0f), outline_color);
		dl->AddRectFilled(ImVec2(x1 + 1.0f, y1 + 1.0f), ImVec2(x1 + 2.0f, y1 + 1.0f + v_len), outline_color);
		dl->AddRectFilled(ImVec2(x1, y1), ImVec2(x1 + 1.0f + h_len, y1 + 1.0f), color);
		dl->AddRectFilled(ImVec2(x1, y1), ImVec2(x1 + 1.0f, y1 + 1.0f + v_len), color);

		dl->AddRectFilled(ImVec2(x2 - h_len, y1 - 1.0f), ImVec2(x2 + 2.0f, y1), outline_color);
		dl->AddRectFilled(ImVec2(x2 + 1.0f, y1 - 1.0f), ImVec2(x2 + 2.0f, y1 + 1.0f + v_len), outline_color);
		dl->AddRectFilled(ImVec2(x2 - h_len, y1 + 1.0f), ImVec2(x2, y1 + 2.0f), outline_color);
		dl->AddRectFilled(ImVec2(x2 - 1.0f, y1 + 1.0f), ImVec2(x2, y1 + 1.0f + v_len), outline_color);
		dl->AddRectFilled(ImVec2(x2 - h_len, y1), ImVec2(x2 + 1.0f, y1 + 1.0f), color);
		dl->AddRectFilled(ImVec2(x2, y1), ImVec2(x2 + 1.0f, y1 + 1.0f + v_len), color);

		dl->AddRectFilled(ImVec2(x1 - 1.0f, y2 + 1.0f), ImVec2(x1 + 1.0f + h_len, y2 + 2.0f), outline_color);
		dl->AddRectFilled(ImVec2(x1 - 1.0f, y2 - v_len), ImVec2(x1, y2 + 2.0f), outline_color);
		dl->AddRectFilled(ImVec2(x1 + 1.0f, y2 - 1.0f), ImVec2(x1 + 1.0f + h_len, y2), outline_color);
		dl->AddRectFilled(ImVec2(x1 + 1.0f, y2 - v_len), ImVec2(x1 + 2.0f, y2), outline_color);
		dl->AddRectFilled(ImVec2(x1, y2), ImVec2(x1 + 1.0f + h_len, y2 + 1.0f), color);
		dl->AddRectFilled(ImVec2(x1, y2 - v_len), ImVec2(x1 + 1.0f, y2 + 1.0f), color);

		dl->AddRectFilled(ImVec2(x2 - h_len, y2 + 1.0f), ImVec2(x2 + 2.0f, y2 + 2.0f), outline_color);
		dl->AddRectFilled(ImVec2(x2 + 1.0f, y2 - v_len), ImVec2(x2 + 2.0f, y2 + 2.0f), outline_color);
		dl->AddRectFilled(ImVec2(x2 - h_len, y2 - 1.0f), ImVec2(x2, y2), outline_color);
		dl->AddRectFilled(ImVec2(x2 - 1.0f, y2 - v_len), ImVec2(x2, y2), outline_color);
		dl->AddRectFilled(ImVec2(x2 - h_len, y2), ImVec2(x2 + 1.0f, y2 + 1.0f), color);
		dl->AddRectFilled(ImVec2(x2, y2 - v_len), ImVec2(x2 + 1.0f, y2 + 1.0f), color);
	}

	static void draw_box(ImDrawList* draw_list, const ImVec2& box_min, const ImVec2& box_max) {
		if (!g_cfg->visuals.m_box)
			return;
		ImU32 box_color = color_with_alpha(g_cfg->visuals.m_box_color);
		ImU32 outline = IM_COL32(0, 0, 0, static_cast<int>(180 * g_esp_alpha_mul));
		draw_corners(draw_list, box_min, box_max, box_color, outline, std::clamp(g_cfg->visuals.m_corner_length, 0.005f, 0.5f));
	}

	static ImU32 glow_color(float alpha_scale) {
		const auto& color = g_cfg->visuals.m_enemy_glow_color;
		const int r = static_cast<int>(std::clamp(color.x, 0.0f, 1.0f) * 255.0f);
		const int g = static_cast<int>(std::clamp(color.y, 0.0f, 1.0f) * 255.0f);
		const int b = static_cast<int>(std::clamp(color.z, 0.0f, 1.0f) * 255.0f);
		const int a = static_cast<int>(std::clamp(color.w * alpha_scale, 0.0f, 1.0f) * 255.0f);
		return IM_COL32(r, g, b, a);
	}

	static float cross(const ImVec2& origin, const ImVec2& a, const ImVec2& b) {
		return (a.x - origin.x) * (b.y - origin.y) - (a.y - origin.y) * (b.x - origin.x);
	}

	static std::vector<ImVec2> convex_hull(std::vector<ImVec2> points) {
		if (points.size() < 3)
			return {};

		std::sort(points.begin(), points.end(), [](const ImVec2& a, const ImVec2& b) {
			return a.x < b.x || (a.x == b.x && a.y < b.y);
		});

		std::vector<ImVec2> hull;
		hull.reserve(points.size() * 2);

		for (const auto& point : points) {
			while (hull.size() >= 2 && cross(hull[hull.size() - 2], hull.back(), point) <= 0.0f)
				hull.pop_back();
			hull.push_back(point);
		}

		const auto lower_size = hull.size();
		for (int i = static_cast<int>(points.size()) - 2; i >= 0; --i) {
			const auto& point = points[i];
			while (hull.size() > lower_size && cross(hull[hull.size() - 2], hull.back(), point) <= 0.0f)
				hull.pop_back();
			hull.push_back(point);
		}

		if (!hull.empty())
			hull.pop_back();

		return hull;
	}

	static void draw_scaled_polyline(ImDrawList* draw_list, const std::vector<ImVec2>& hull, const ImVec2& center, float scale, ImU32 color, float thickness) {
		if (hull.size() < 3)
			return;

		std::vector<ImVec2> scaled;
		scaled.reserve(hull.size());

		for (const auto& point : hull) {
			scaled.emplace_back(
				center.x + (point.x - center.x) * scale,
				center.y + (point.y - center.y) * scale
			);
		}

		draw_list->AddPolyline(scaled.data(), static_cast<int>(scaled.size()), color, ImDrawFlags_Closed, thickness);
	}

	static void draw_enemy_glow(ImDrawList* draw_list, c_cs_player_pawn* pawn, const ImVec2& box_min, const ImVec2& box_max) {
		if (!g_cfg->visuals.m_enemy_glow || !pawn)
			return;

		auto find_bone = [&](const char* name) -> int {
			if (!name || !name[0])
				return -1;

			__try {
				const int index = pawn->get_bone_index(name);
				return index >= 0 && index < 128 ? index : -1;
			}
			__except (EXCEPTION_EXECUTE_HANDLER) {
				return -1;
			}
		};

			const float box_h = (std::max)(1.0f, box_max.y - box_min.y);
			const float torso = std::clamp(box_h * 0.065f, 5.0f, 18.0f);
			const float limb = std::clamp(box_h * 0.045f, 3.5f, 12.0f);
			const float head_radius = std::clamp(box_h * 0.070f, 5.0f, 18.0f);
			std::vector<ImVec2> points;
			points.reserve(80);

			auto add_bone_shape = [&](const char* name, float radius_x, float radius_y) {
				const int bone = find_bone(name);
				if (bone < 0)
					return;

				vec3_t world;
				if (!get_bone_position(pawn, bone, world))
					return;

				ImVec2 screen;
				if (!world_to_screen(world, screen))
					return;

				points.emplace_back(screen.x - radius_x, screen.y);
				points.emplace_back(screen.x + radius_x, screen.y);
				points.emplace_back(screen.x, screen.y - radius_y);
				points.emplace_back(screen.x, screen.y + radius_y);
				points.emplace_back(screen.x - radius_x * 0.65f, screen.y - radius_y * 0.65f);
				points.emplace_back(screen.x + radius_x * 0.65f, screen.y - radius_y * 0.65f);
				points.emplace_back(screen.x - radius_x * 0.65f, screen.y + radius_y * 0.65f);
				points.emplace_back(screen.x + radius_x * 0.65f, screen.y + radius_y * 0.65f);
			};

			add_bone_shape("head_0", head_radius * 1.05f, head_radius * 1.20f);
			add_bone_shape("neck_0", torso * 0.85f, torso * 0.80f);
			add_bone_shape("spine_3", torso * 1.55f, torso);
			add_bone_shape("spine_2", torso * 1.45f, torso);
			add_bone_shape("spine_1", torso * 1.25f, torso);
			add_bone_shape("spine_0", torso * 1.05f, torso);
			add_bone_shape("pelvis", torso * 1.45f, torso * 0.95f);
			add_bone_shape("arm_upper_L", limb, limb);
			add_bone_shape("arm_lower_L", limb, limb);
			add_bone_shape("hand_L", limb * 1.15f, limb * 1.10f);
			add_bone_shape("arm_upper_R", limb, limb);
			add_bone_shape("arm_lower_R", limb, limb);
			add_bone_shape("hand_R", limb * 1.15f, limb * 1.10f);
			add_bone_shape("leg_upper_L", limb * 1.25f, limb * 1.15f);
			add_bone_shape("leg_lower_L", limb, limb * 1.20f);
			add_bone_shape("ankle_L", limb * 1.15f, limb * 0.90f);
			add_bone_shape("leg_upper_R", limb * 1.25f, limb * 1.15f);
			add_bone_shape("leg_lower_R", limb, limb * 1.20f);
			add_bone_shape("ankle_R", limb * 1.15f, limb * 0.90f);

			auto hull = convex_hull(points);
			if (hull.size() < 3)
				return;

			ImVec2 center(0.0f, 0.0f);
			for (const auto& point : hull) {
				center.x += point.x;
				center.y += point.y;
			}
			center.x /= static_cast<float>(hull.size());
			center.y /= static_cast<float>(hull.size());

			std::vector<ImVec2> fill_poly;
			fill_poly.reserve(hull.size());
			for (const auto& point : hull) {
				fill_poly.emplace_back(
					center.x + (point.x - center.x) * 1.015f,
					center.y + (point.y - center.y) * 1.015f
				);
			}

			draw_list->AddConvexPolyFilled(fill_poly.data(), static_cast<int>(fill_poly.size()), glow_color(0.055f));
			draw_scaled_polyline(draw_list, hull, center, 1.130f, glow_color(0.055f), 12.0f);
		draw_scaled_polyline(draw_list, hull, center, 1.090f, glow_color(0.090f), 8.0f);
		draw_scaled_polyline(draw_list, hull, center, 1.055f, glow_color(0.150f), 5.0f);
		draw_scaled_polyline(draw_list, hull, center, 1.020f, glow_color(0.270f), 2.0f);
	}

	union cvar_value_t {
		bool b_value;
		float fl_value;
		int i_value;
		const char* sz_value;
	};

	struct convar_t {
		const char* name;
		cvar_value_t* default_value;
		std::uint8_t pad_0010[0x10];
		const char* description;
		std::uint32_t type;
		std::uint32_t registered;
		std::uint32_t flags;
		std::uint8_t pad_0034[0x24];
		cvar_value_t value;
	};

	static void* engine_cvar() {
		static void* cvar = []() -> void* {
			HMODULE tier0 = GetModuleHandleA("tier0.dll");
			if (!tier0)
				return nullptr;

			using create_interface_t = void* (*)(const char*, int*);
			auto create_interface = reinterpret_cast<create_interface_t>(GetProcAddress(tier0, "CreateInterface"));
			if (!create_interface)
				return nullptr;

			return create_interface("VEngineCvar007", nullptr);
		}();

		return cvar;
	}

	static convar_t* find_cvar(const char* name) {
		if (!name)
			return nullptr;

		using get_first_iterator_t = void(__fastcall*)(void*, std::uint64_t*);
		using get_next_iterator_t = void(__fastcall*)(void*, std::uint64_t*, std::uint64_t);
		using find_by_index_t = convar_t* (__fastcall*)(void*, std::uint64_t);

		static auto get_first_iterator = reinterpret_cast<get_first_iterator_t>(
			g_opcodes->scan("tier0.dll", "48 89 74 24 ? 48 89 7C 24 ? 41 56 48 83 EC ? 48 8B F2 48 8D B9")
		);
		static auto get_next_iterator = reinterpret_cast<get_next_iterator_t>(
			g_opcodes->scan("tier0.dll", "40 53 55 56 41 56 41 57 48 83 EC ? 49 8B D8 48 8D B1 ? ? ? ? 4C 8B F2 48 8B E9 FF 15 ? ? ? ? 8B D0 39 46 ? 75 ? 66 FF 46 ? EB ? 8B 06 90 85 C0 75 ? B9 ? ? ? ? F0 0F B1 0E 75 ? 66 C7 46 ? ? ? 89 56 ? EB ? 48 8B CE E8 ? ? ? ? 41 BF ? ? ? ? 48 89 7C 24 ? 4C 89 6C 24 ? 66 41 3B DF 74 ? 41 BD ? ? ? ? 66 44 85 6D")
		);
		static auto find_by_index = reinterpret_cast<find_by_index_t>(
			g_opcodes->scan("tier0.dll", "48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B DA 48 8D B9 ? ? ? ? 48 8B F1 FF 15 ? ? ? ? 8B D0 39 47 ? 75 ? 66 FF 47 ? EB ? 8B 07 90 85 C0 75 ? B9 ? ? ? ? F0 0F B1 0F 75 ? 66 C7 47 ? ? ? 89 57 ? EB ? 48 8B CF E8 ? ? ? ? BA")
		);

		auto* cvar = engine_cvar();
		if (!cvar || !get_first_iterator || !get_next_iterator || !find_by_index)
			return nullptr;

		std::uint64_t index = 0;
		get_first_iterator(cvar, &index);

		while (index != 0xFFFFFFFFull) {
			auto* var = find_by_index(cvar, index);
			if (var && var->name && std::strcmp(var->name, name) == 0)
				return var;

			get_next_iterator(cvar, &index, index);
		}

		return nullptr;
	}

	static void set_cvar_float(const char* name, float value) {
		static convar_t* sv_grenade_trajectory_prac_trailtime = nullptr;

		convar_t** target = nullptr;
		if (std::strcmp(name, "sv_grenade_trajectory_prac_trailtime") == 0)
			target = &sv_grenade_trajectory_prac_trailtime;

		if (!target)
			return;

		if (!*target)
			*target = find_cvar(name);

		if (!*target)
			return;

		__try {
			(*target)->value.fl_value = value;
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {}
	}

	static void apply_grenade_trails() {
		set_cvar_float("sv_grenade_trajectory_prac_trailtime", g_cfg->visuals.m_grenade_trails ? 5.0f : 0.0f);
	}

}

void visuals::draw() {
	if (!g_interfaces || !g_interfaces->m_entity_system || !g_cfg)
		return;

	const bool draw_enemy_esp =
		(g_cfg->visuals.m_box || g_cfg->visuals.m_health_bar || g_cfg->visuals.m_skeleton ||
		 g_cfg->visuals.m_name || g_cfg->visuals.m_weapon || g_cfg->visuals.m_flags);

	if (!draw_enemy_esp && !g_cfg->visuals.m_esp_arrows)
		return;

	auto* local_controller = reinterpret_cast<c_cs_player_controller*>(
		g_interfaces->m_entity_system->get_local_controller()
	);
	if (!local_controller)
		return;

	const auto local_pawn_handle = local_controller->m_pawn();
	if (!local_pawn_handle.is_valid())
		return;

	auto* local_pawn = reinterpret_cast<c_cs_player_pawn*>(
		g_interfaces->m_entity_system->get_base_entity(local_pawn_handle.get_entry_index())
	);
	if (!local_pawn)
		return;

	const auto draw_list = ImGui::GetBackgroundDrawList();
	const auto local_team = local_pawn->m_team_num();

	vec3_t local_origin{};
	const auto local_scene_node = local_pawn->m_scene_node();
	if (local_scene_node) {
		local_origin = local_scene_node->m_abs_origin();
	}
	if (!local_origin.is_valid())
		local_origin = local_pawn->get_eye_pos();

	__try {
		for (int i = 1; i <= 64; ++i) {
			__try {
				auto* entity = get_base_entity_safe(i);
				if (!entity)
					continue;

				auto* identity = entity->m_entity();
				if (!is_valid_identity(identity))
					continue;

				if (!entity->is_player_controller())
					continue;

				auto* controller = reinterpret_cast<c_cs_player_controller*>(entity);
				if (controller == local_controller)
					continue;

				const auto pawn_handle = controller->m_pawn();
				if (!pawn_handle.is_valid())
					continue;

				auto* pawn = reinterpret_cast<c_cs_player_pawn*>(
					get_base_entity_safe(pawn_handle.get_entry_index())
				);
				if (!pawn || pawn == local_pawn)
					continue;

				auto* pawn_identity = pawn->m_entity();
				if (!is_valid_identity(pawn_identity))
					continue;

				const bool dormant = entity_is_dormant(pawn);
				if (dormant && !g_cfg->visuals.m_show_dormant)
					continue;

				const auto health = pawn->m_health();
				if (health <= 0)
					continue;

				if (pawn->m_team_num() == local_team)
					continue;

				g_esp_alpha_mul = dormant
					? std::clamp(g_cfg->visuals.m_dormant_alpha, 0.1f, 1.0f)
					: 1.0f;

				static float health_anim[65] = { 0 };
				auto& anim_hp = health_anim[i];
				const float target_hp = static_cast<float>(health);
				if (anim_hp <= 0.0f || target_hp > anim_hp)
					anim_hp = target_hp;
				else
					anim_hp += (target_hp - anim_hp) * 0.1f;

				const auto scene_node = pawn->m_scene_node();
				const auto collision = pawn->m_collision();
				if (!scene_node || !collision)
					continue;

				const auto& origin = scene_node->m_abs_origin();

				const auto height = collision->m_maxs().z - collision->m_mins().z;
				auto top_world = origin;
				top_world.z += height;

				ImVec2 screen_top, screen_bottom;
				const bool w2s_ok = world_to_screen(top_world, screen_top) && world_to_screen(origin, screen_bottom);
				const ImVec2 display_size = ImGui::GetIO().DisplaySize;
				bool on_screen = w2s_ok
					&& screen_top.x >= -100.0f && screen_top.x <= display_size.x + 100.0f
					&& screen_top.y >= -100.0f && screen_top.y <= display_size.y + 100.0f
					&& screen_bottom.x >= -100.0f && screen_bottom.x <= display_size.x + 100.0f
					&& screen_bottom.y >= -100.0f && screen_bottom.y <= display_size.y + 100.0f;

				const float dist_m = local_origin.is_valid() ? (origin - local_origin).length() * 0.01905f : 0.f;

				if (!on_screen) {
					if (g_cfg->visuals.m_esp_arrows) {
						ImVec2 edge{};
						bool edge_on = false;
						vec3_t mid = origin;
						mid.z += height * 0.5f;
						if (project_or_edge(mid, edge, edge_on, 28.f)) {
							draw_offscreen_arrow(draw_list, edge,
								std::clamp(g_cfg->visuals.m_esp_arrows_size, 6.f, 40.f),
								color_with_alpha(g_cfg->visuals.m_esp_arrows_color),
								dist_m);
						}
					}
					g_esp_alpha_mul = 1.f;
					continue;
				}

				const auto box_height = screen_bottom.y - screen_top.y;
				const auto box_width = box_height * 0.5f;
				const auto box_min = ImVec2(floorf(screen_top.x - box_width * 0.5f), floorf(screen_top.y));
				const auto box_max = ImVec2(floorf(box_min.x + box_width), floorf(box_min.y + box_height));

				if (draw_enemy_esp) {
					draw_box(draw_list, box_min, box_max);
					draw_health_bar(draw_list, health, anim_hp, box_min, box_max);
					draw_skeleton(draw_list, pawn, box_min, box_max);
					draw_name(draw_list, controller->m_player_name(), box_min, box_max);
					draw_flags(draw_list, pawn, controller, local_origin, box_min, box_max);

					float offset_y = 2.0f;
					float ammo_height = draw_ammo(draw_list, pawn, box_min, box_max, offset_y);
					if (ammo_height > 0.0f) {
						offset_y += ammo_height + 2.0f;
					}
					draw_weapon(draw_list, pawn, box_min, box_max, offset_y);
				}
				g_esp_alpha_mul = 1.f;
			}
			__except (EXCEPTION_EXECUTE_HANDLER) {
				continue;
			}
		}
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {
		return;
	}
}

void visuals::visualize_aimbot_fov() {
	if (!g_cfg)
		return;

	// Present must NOT touch pawn memory — get_local_pawn / g_ctx can be freed
	// between rounds (AV in is_alive / m_health). FOV uses shared group only.
	int fov_group_idx = c_config::aim_t::group_shared;
	const auto& fov_group = g_cfg->aim.group_for(fov_group_idx);
	if (fov_group.m_aimbot && g_cfg->aim.m_visualize_aimbot_fov && is_in_active_game()) {
		const auto screen_size = ImGui::GetIO().DisplaySize;
		const float center_x = screen_size.x * 0.5f;
		const float center_y = screen_size.y * 0.5f;

		const float camera_fov = 90.0f;
		const float radius = (fov_group.m_fov / camera_fov) * (screen_size.x < screen_size.y ? screen_size.x : screen_size.y) * 0.5f;

		if (radius > 0.0f) {
			ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(center_x, center_y), radius, pack_color(g_cfg->aim.m_visualize_aimbot_fov_color), 64, 1.0f);
		}
	}
}

void visuals::update_glow() {
	if (!g_interfaces || !g_interfaces->m_entity_system || !g_cfg)
		return;

	static bool had_enemy_glow = false;
	const bool should_update = g_cfg->visuals.m_enemy_glow || had_enemy_glow;
	if (!should_update)
		return;

	auto* local_controller = reinterpret_cast<c_cs_player_controller*>(
		g_interfaces->m_entity_system->get_local_controller()
	);
	if (!local_controller)
		return;

	const auto local_pawn_handle = local_controller->m_pawn();
	if (!local_pawn_handle.is_valid())
		return;

	auto* local_pawn = reinterpret_cast<c_cs_player_pawn*>(
		g_interfaces->m_entity_system->get_base_entity(local_pawn_handle.get_entry_index())
	);
	if (!local_pawn)
		return;

	const auto local_team = local_pawn->m_team_num();

	__try {
		for (int i = 1; i <= 64; ++i) {
			auto* entity = get_base_entity_safe(i);
			if (!entity || !entity->is_player_controller())
				continue;

			auto* controller = reinterpret_cast<c_cs_player_controller*>(entity);
			if (controller == local_controller)
				continue;

			const auto pawn_handle = controller->m_pawn();
			if (!pawn_handle.is_valid())
				continue;

			auto* pawn = reinterpret_cast<c_cs_player_pawn*>(
				get_base_entity_safe(pawn_handle.get_entry_index())
			);
			if (!pawn || pawn == local_pawn)
				continue;

			const bool is_enemy_alive = pawn->m_health() > 0 && pawn->m_team_num() != local_team;
			const bool enable_glow = g_cfg->visuals.m_enemy_glow && is_enemy_alive;

			apply_enemy_glow(pawn, enable_glow);
		}
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {}

	had_enemy_glow = g_cfg->visuals.m_enemy_glow;
}

static void draw_custom_scope() {
	if (!g_cfg->misc.m_scope_overlay)
		return;

	if (!is_in_active_game())
		return;

	if (!g_ctx || !g_ctx->m_local_pawn || !memsafe::valid_entity(g_ctx->m_local_pawn))
		return;

	auto* local_pawn = reinterpret_cast<c_cs_player_pawn*>(g_ctx->m_local_pawn);
	// Avoid SCHEMA health/alive probes on Present during round swaps — scoped flag only.
	if (!local_pawn->m_scoped())
		return;

	ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
	ImVec2 screen_size = ImGui::GetIO().DisplaySize;
	ImVec2 center = ImVec2(screen_size.x * 0.5f, screen_size.y * 0.5f);

	const auto& wm = g_cfg->misc;

	if (wm.m_scope_type == 0) {
		float line_length = static_cast<float>(wm.m_scope_length);
		float gap = static_cast<float>(wm.m_scope_gap);

		ImU32 col_in = ImGui::ColorConvertFloat4ToU32(wm.m_scope_col_inside);
		ImU32 col_out = ImGui::ColorConvertFloat4ToU32(ImVec4(wm.m_scope_col_outside.x, wm.m_scope_col_outside.y, wm.m_scope_col_outside.z, 0.0f));

		draw_list->AddRectFilledMultiColor(
			{ center.x - 0.5f, center.y - gap - line_length },
			{ center.x + 0.5f, center.y - gap },
			col_out, col_out, col_in, col_in);
		draw_list->AddRectFilledMultiColor(
			{ center.x - 0.5f, center.y + gap },
			{ center.x + 0.5f, center.y + gap + line_length },
			col_in, col_in, col_out, col_out);
		draw_list->AddRectFilledMultiColor(
			{ center.x - gap - line_length, center.y - 0.5f },
			{ center.x - gap, center.y + 0.5f },
			col_out, col_in, col_in, col_out);
		draw_list->AddRectFilledMultiColor(
			{ center.x + gap, center.y - 0.5f },
			{ center.x + gap + line_length, center.y + 0.5f },
			col_in, col_out, col_out, col_in);

		float fade = gap / 2.0f;
		draw_list->AddRectFilledMultiColor(
			{ center.x - 0.5f, center.y - gap },
			{ center.x + 0.5f, center.y - gap + fade },
			col_in, col_in, col_out, col_out);
		draw_list->AddRectFilledMultiColor(
			{ center.x - 0.5f, center.y + gap - fade },
			{ center.x + 0.5f, center.y + gap },
			col_out, col_out, col_in, col_in);
		draw_list->AddRectFilledMultiColor(
			{ center.x - gap, center.y - 0.5f },
			{ center.x - gap + fade, center.y + 0.5f },
			col_in, col_out, col_out, col_in);
		draw_list->AddRectFilledMultiColor(
			{ center.x + gap - fade, center.y - 0.5f },
			{ center.x + gap, center.y + 0.5f },
			col_out, col_in, col_in, col_out);
	} else {
		draw_list->AddLine({ 0.0f, center.y }, { screen_size.x, center.y }, IM_COL32(0, 0, 0, 255));
		draw_list->AddLine({ center.x, 0.0f }, { center.x, screen_size.y }, IM_COL32(0, 0, 0, 255));
	}
}

void visuals::draw_world() {
	if (!g_interfaces || !g_interfaces->m_entity_system || !g_cfg)
		return;

	draw_custom_scope();

	apply_grenade_trails();

	// Autopeek anchor: 3D circle where the bind was pressed.
	if (g_autopeek && g_autopeek->active()) {
		const vec3_t anchor = g_autopeek->anchor();
		if (anchor.is_valid() && !anchor.is_zero()) {
			auto* dl_peek = ImGui::GetBackgroundDrawList();
			const ImU32 col = g_autopeek->returning()
				? IM_COL32(255, 120, 60, 220)
				: IM_COL32(120, 200, 255, 220);
			const ImU32 col_fill = (col & 0x00FFFFFF) | 0x28000000;
			constexpr int k_segments = 40;
			constexpr float k_radius = 22.f;
			constexpr float k_two_pi = 6.2831853f;

			ImVec2 pts[k_segments];
			int visible = 0;
			for (int i = 0; i < k_segments; ++i) {
				const float a = k_two_pi * static_cast<float>(i) / static_cast<float>(k_segments);
				const vec3_t world{ anchor.x + std::cosf(a) * k_radius,
				                    anchor.y + std::sinf(a) * k_radius,
				                    anchor.z + 2.f };
				ImVec2 scr;
				if (!world_to_screen(world, scr))
					break;
				pts[visible++] = scr;
			}
			if (visible == k_segments) {
				dl_peek->AddConvexPolyFilled(pts, k_segments, col_fill);
				dl_peek->AddPolyline(pts, k_segments, col, ImDrawFlags_Closed, 2.f);
			}
		}
	}

	if (!g_cfg->visuals.m_smoke_color &&
		!g_cfg->visuals.m_weapon_drops && !g_cfg->visuals.m_bomb_esp &&
		!g_cfg->visuals.m_grenade_trajectory && !g_cfg->visuals.m_grenades &&
		!g_cfg->visuals.m_grenade_trails && !g_cfg->visuals.m_grenade_warning)
		return;

	auto* local_controller = reinterpret_cast<c_cs_player_controller*>(
		g_interfaces->m_entity_system->get_local_controller()
	);
	if (!local_controller)
		return;

	const auto local_pawn_handle = local_controller->m_pawn();
	if (!local_pawn_handle.is_valid())
		return;

	auto* local_pawn = reinterpret_cast<c_cs_player_pawn*>(
		g_interfaces->m_entity_system->get_base_entity(local_pawn_handle.get_entry_index())
	);
	if (!local_pawn)
		return;

	const auto draw_list = ImGui::GetBackgroundDrawList();
	const vec3_t local_origin = safe_pawn_abs_origin(local_pawn);

	if (g_cfg->visuals.m_smoke_color)
		apply_smoke_colors();

	if (g_cfg->visuals.m_grenade_trajectory && grenade_prediction::available()) {
		const ImU32 grenade_color = ImGui::ColorConvertFloat4ToU32(g_cfg->visuals.m_grenade_trajectory_color);
		const ImU32 grenade_end_color = ImGui::ColorConvertFloat4ToU32(g_cfg->visuals.m_grenade_trajectory_end_color);
		if (!local_pawn->is_throwing()) {
			grenade_prediction::draw_held(local_pawn, draw_list, grenade_color, grenade_end_color);
			grenade_prediction::draw_projectiles(local_pawn, draw_list, grenade_color, grenade_end_color);
		}
	}

	if (g_cfg->visuals.m_grenades) {
		const ImU32 grenades_color = ImGui::ColorConvertFloat4ToU32(g_cfg->visuals.m_grenades_color);
		draw_grenade_esp(local_pawn, draw_list, grenades_color, local_origin);
	}

	if (g_cfg->visuals.m_grenade_warning && !local_pawn->is_throwing())
		draw_grenade_warnings(local_pawn, draw_list, local_origin);

	bool drew_planted_c4 = false;
	if (g_cfg->visuals.m_bomb_esp) {
		static const uintptr_t client_base = reinterpret_cast<uintptr_t>(GetModuleHandleA("client.dll"));
		if (client_base) {
			constexpr uintptr_t planted_c4_offsets[] = { 0x234CF08, 0x234CF00 };
			for (const auto offset : planted_c4_offsets) {
				const uintptr_t raw = read<uintptr_t>(client_base + offset);
				if (!raw)
					continue;

				if (draw_planted_c4_from_address(draw_list, raw, local_pawn, local_origin) ||
					draw_planted_c4_from_address(draw_list, read<uintptr_t>(raw), local_pawn, local_origin)) {
					drew_planted_c4 = true;
					break;
				}
			}
		}

		if (client_base && !drew_planted_c4) {
			constexpr uintptr_t dwPlantedC4 = 0x234CF08;
			const uintptr_t planted_c4_ptr = read<uintptr_t>(client_base + dwPlantedC4);

			if (planted_c4_ptr) {
				const uintptr_t planted_c4 = read<uintptr_t>(planted_c4_ptr);

				if (planted_c4) {
					constexpr uintptr_t m_bBombTicking = 0x1160;
					constexpr uintptr_t m_flC4Blow = 0x1190;
					constexpr uintptr_t m_pGameSceneNode = 0x330;
					constexpr uintptr_t m_vecAbsOrigin = 0xC8;
					constexpr uintptr_t m_flSimulationTime = 0x3B8;

					const bool is_ticking = read<bool>(planted_c4 + m_bBombTicking);

					if (is_ticking) {
						const float c4_blow_time = read<float>(planted_c4 + m_flC4Blow);
						const float current_time = read<float>(reinterpret_cast<uintptr_t>(local_pawn) + m_flSimulationTime);
						const float remaining = c4_blow_time - current_time;

						if (std::isfinite(remaining) && remaining > 0.0f && remaining < 120.0f) {
							const uintptr_t bomb_scene_node = read<uintptr_t>(planted_c4 + m_pGameSceneNode);

							if (bomb_scene_node) {
								const vec3_t bomb_origin = read<vec3_t>(bomb_scene_node + m_vecAbsOrigin);

								ImVec2 screen_pos;
								if (world_to_screen(bomb_origin, screen_pos)) {
									drew_planted_c4 = true;
									const ImU32 color = ImGui::ColorConvertFloat4ToU32(g_cfg->visuals.m_bomb_esp_color);
									float y_offset = 0.0f;

									if (g_cfg->visuals.m_bomb_esp_type & (1 << 0)) {
										if (auto* icon = get_weapon_icon("c4")) {
											if (g_menu) {
												if (auto* icon_font = g_menu->get_weapon_icon_font()) {
													draw_centered_icon(draw_list, icon_font, icon_font->FontSize, ImVec2(screen_pos.x, screen_pos.y + y_offset), color, icon);
													y_offset += icon_font->FontSize + 2.0f;
												}
											}
										}
									}

									if (g_cfg->visuals.m_bomb_esp_type & (1 << 1)) {
										const auto text_size = calc_pixel_text_size("c4");
										const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
										draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, "c4");
										y_offset += get_pixel_font_height() + 2.0f;
									}

									if (g_cfg->visuals.m_bomb_esp_type & (1 << 2)) {
										char timer_text[64];
										snprintf(timer_text, sizeof(timer_text), "%.1fs", remaining);
										const auto text_size = calc_pixel_text_size(timer_text);
										const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
										draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, timer_text);
										y_offset += get_pixel_font_height() + 2.0f;
									}

									if (g_cfg->visuals.m_bomb_esp_type & (1 << 3)) {
										const float distance = sqrtf(
											(bomb_origin.x - local_origin.x) * (bomb_origin.x - local_origin.x) +
											(bomb_origin.y - local_origin.y) * (bomb_origin.y - local_origin.y) +
											(bomb_origin.z - local_origin.z) * (bomb_origin.z - local_origin.z)
										) * 0.0254f;
										char buf[32];
										snprintf(buf, sizeof(buf), "%.0fm", distance);
										const auto text_size = calc_pixel_text_size(buf);
										const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
										draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, buf);
									}
								}
							}
						}
					}
				}
			}
		}
	}

	if (!g_cfg->visuals.m_weapon_drops && !g_cfg->visuals.m_bomb_esp)
		return;

	const int scan_limit = get_entity_scan_limit();
	for (int i = 1; i <= scan_limit; ++i) {
		auto* entity = get_base_entity_safe(i);
		if (!entity)
			continue;

		auto* identity = entity->m_entity();
		if (!identity)
			continue;

		if (entity->is_player_controller() || entity->is_player_pawn())
			continue;

		const char* designer_name = entity->get_designer_name();

		auto* scene_node = entity->m_scene_node();
		if (!scene_node)
			continue;

		const auto& origin = scene_node->m_abs_origin();

		if (is_planted_c4_entity(entity, designer_name)) {
			if (g_cfg->visuals.m_bomb_esp && !drew_planted_c4) {
				constexpr uintptr_t m_bBombTicking = 0x1160;
				constexpr uintptr_t m_flC4Blow = 0x1190;
				constexpr uintptr_t m_flSimulationTime = 0x3B8;

				float remaining = -1.0f;
				const auto planted_c4 = reinterpret_cast<uintptr_t>(entity);
				const bool is_ticking = read<bool>(planted_c4 + m_bBombTicking);
				if (is_ticking) {
					const float c4_blow_time = read<float>(planted_c4 + m_flC4Blow);
					const float current_time = read<float>(reinterpret_cast<uintptr_t>(local_pawn) + m_flSimulationTime);
					const float candidate = c4_blow_time - current_time;
					if (std::isfinite(candidate) && candidate > 0.0f && candidate < 120.0f)
						remaining = candidate;

					drew_planted_c4 = draw_bomb_world_esp(draw_list, origin, local_origin, remaining);
				}
			}
			continue;
		}

		if (!is_valid_identity(identity))
			continue;

		const bool grenade_weapon_entity = is_grenade_weapon_entity(entity, designer_name);
		bool is_weapon = designer_name && strstr(designer_name, "weapon_") != nullptr;
		if (!is_weapon)
			is_weapon = grenade_weapon_entity;
		if (!is_weapon)
			continue;

		bool is_c4 = false;
		std::string weapon_key;

		auto* weapon = reinterpret_cast<c_base_player_weapon*>(entity);
		if (!weapon)
			continue;

		if (!is_dropped_weapon(weapon, designer_name, grenade_weapon_entity))
			continue;

		weapon_key = get_weapon_key(weapon);
		if (weapon_key.empty() && grenade_weapon_entity)
			weapon_key = get_grenade_weapon_key(weapon, entity, designer_name);
		if (weapon_key.empty())
			weapon_key = normalize_weapon_name(designer_name);

		is_c4 = is_c4_weapon(weapon, entity, designer_name);
		if (is_c4)
			weapon_key = "c4";
		else if (weapon_key == "c4" || (designer_name && std::strcmp(designer_name, "weapon_c4") == 0))
			continue;

		if (is_c4 && is_weapon_in_player_inventory(weapon))
			continue;

		if (is_c4 && !g_cfg->visuals.m_bomb_esp)
			continue;
		if (!is_c4 && !g_cfg->visuals.m_weapon_drops)
			continue;

		ImVec2 screen_pos;
		if (!world_to_screen(origin, screen_pos))
			continue;

		if (is_c4) {
			const ImU32 color = ImGui::ColorConvertFloat4ToU32(g_cfg->visuals.m_bomb_esp_color);
			float y_offset = 0.0f;

			if (g_cfg->visuals.m_bomb_esp_type & (1 << 0)) {
				if (auto* icon = get_weapon_icon("c4")) {
					if (auto* icon_font = g_menu->get_weapon_icon_font()) {
						draw_centered_icon(draw_list, icon_font, icon_font->FontSize, ImVec2(screen_pos.x, screen_pos.y + y_offset), color, icon);
						y_offset += icon_font->FontSize + 2.0f;
					}
				}
			}

			if (g_cfg->visuals.m_bomb_esp_type & (1 << 1)) {
				const auto text_size = calc_pixel_text_size("c4");
				const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
				draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, "c4");
				y_offset += get_pixel_font_height() + 2.0f;
			}

			if (g_cfg->visuals.m_bomb_esp_type & (1 << 2)) {
			}

			if (g_cfg->visuals.m_bomb_esp_type & (1 << 3)) {
				const float distance = sqrtf(
					(origin.x - local_origin.x) * (origin.x - local_origin.x) +
					(origin.y - local_origin.y) * (origin.y - local_origin.y) +
					(origin.z - local_origin.z) * (origin.z - local_origin.z)
				) * 0.0254f;
				char buf[32];
				snprintf(buf, sizeof(buf), "%.0fm", distance);
				const auto text_size = calc_pixel_text_size(buf);
				const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
				draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, buf);
			}
		}
		else {
			if (weapon_key.empty())
				continue;

			const std::string weapon_text = to_lower_case(get_weapon_text(weapon_key));
			const ImU32 color = ImGui::ColorConvertFloat4ToU32(g_cfg->visuals.m_weapon_drops_color);
			float y_offset = 0.0f;

			if (g_cfg->visuals.m_weapon_drops_type & (1 << 0)) {
				if (auto* icon = get_weapon_icon(weapon_key)) {
					if (auto* icon_font = g_menu->get_weapon_icon_font()) {
						draw_centered_icon(draw_list, icon_font, icon_font->FontSize, ImVec2(screen_pos.x, screen_pos.y + y_offset), color, icon);
						y_offset += icon_font->FontSize + 2.0f;
					}
				}
			}

			if (g_cfg->visuals.m_weapon_drops_type & (1 << 1)) {
				const auto text_size = calc_pixel_text_size(weapon_text.c_str());
				const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
				draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, weapon_text.c_str());
				y_offset += get_pixel_font_height() + 2.0f;
			}

			if (g_cfg->visuals.m_weapon_drops_type & (1 << 2)) {
				if (weapon) {
					int clip = weapon->m_clip1();
					if (clip >= 0) {
						auto* weapon_data = weapon->get_weapon_data();
						char buf[32];
						if (weapon_data) {
							int max_clip = weapon_data->m_max_clip1();
							if (max_clip > 0) {
								snprintf(buf, sizeof(buf), "%d / %d", clip, max_clip);
							} else {
								snprintf(buf, sizeof(buf), "%d", clip);
							}
						} else {
							snprintf(buf, sizeof(buf), "%d", clip);
						}
						const auto text_size = calc_pixel_text_size(buf);
						const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
						draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, buf);
						y_offset += get_pixel_font_height() + 2.0f;
					}
				}
			}

			if (g_cfg->visuals.m_weapon_drops_type & (1 << 3)) {
				const float distance = sqrtf(
					(origin.x - local_origin.x) * (origin.x - local_origin.x) +
					(origin.y - local_origin.y) * (origin.y - local_origin.y) +
					(origin.z - local_origin.z) * (origin.z - local_origin.z)
				) * 0.0254f;
				char buf[32];
				snprintf(buf, sizeof(buf), "%.0fm", distance);
				const auto text_size = calc_pixel_text_size(buf);
				const auto text_x = floorf(screen_pos.x - text_size.x * 0.5f);
				draw_small_text(draw_list, ImVec2(text_x, screen_pos.y + y_offset), color, buf);
			}
		}
	}
}
