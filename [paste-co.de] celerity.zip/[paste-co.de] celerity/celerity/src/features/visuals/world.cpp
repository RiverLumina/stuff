﻿#include "world.hpp"

#include "../../sdk/valve/classes/c_post_processing.hpp"
#include "../../sdk/valve/classes/c_scene_light_obj.hpp"
#include "../../sdk/valve/modules/modules.hpp"
#include "../../sdk/valve/signatures/signatures.hpp"
#include "../../utils/utils.hpp"
#include "../../config.hpp"

#include <algorithm>
#include <cstdint>

namespace {
// Lefrizzel / IDA: light bytes live on a CMemoryStack resolved from
// DrawAggregateSceneObjectArray — NOT SceneSystem_002+0x2A28 (stale).
constexpr std::uintptr_t k_agg_arr_data = 0x08;
constexpr std::uintptr_t k_agg_count = 0x04;
constexpr std::uintptr_t k_agg_index = 0x30;
constexpr int k_light_entry_shift = 5; // 0x20 stride
constexpr std::uintptr_t k_light_data_off = 0x18;
constexpr int k_max_agg_light_count = 2048;

void** g_pp_light_stack = nullptr;

void resolve_light_stack() {
	if (g_pp_light_stack)
		return;

	std::uintptr_t fn = 0;
	if (g_signatures) {
		if (auto* addr = g_signatures->get("DrawAggregateSceneObjectArray"))
			fn = reinterpret_cast<std::uintptr_t>(addr);
	}
	if (!fn && g_opcodes) {
		fn = reinterpret_cast<std::uintptr_t>(g_opcodes->scan(
			"scenesystem.dll",
			"48 8B C4 48 89 50 ? 48 89 48 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 0F 29 70"));
	}
	if (!fn)
		return;

	std::uintptr_t hit = 0;
	for (std::uintptr_t p = fn; p + 16 < fn + 0xC00; ++p) {
		const auto* b = reinterpret_cast<const std::uint8_t*>(p);
		if (b[0] != 0x4C || b[1] != 0x8B || b[2] != 0x35)
			continue;
		if (b[7] == 0xC1 && b[8] == 0xE0 && b[9] == 0x05
			&& b[10] == 0x48 && b[11] == 0x63 && b[12] == 0xD0
			&& b[13] == 0x49 && b[14] == 0x03 && b[15] == 0x56 && b[16] == 0x18) {
			hit = p;
			break;
		}
	}
	if (!hit && g_opcodes) {
		hit = reinterpret_cast<std::uintptr_t>(g_opcodes->scan(
			"scenesystem.dll",
			"4C 8B 35 ? ? ? ? C1 E0 05 48 63 D0 49 03 56 18"));
	}
	if (!hit)
		return;

	g_pp_light_stack = reinterpret_cast<void**>(g_opcodes->get_absolute_address(
		reinterpret_cast<unsigned char*>(hit), 3));
}

std::uint8_t* light_data_base() {
	resolve_light_stack();
	if (!g_pp_light_stack || !valid_ptr(g_pp_light_stack))
		return nullptr;
	void* stack_obj = *g_pp_light_stack;
	if (!valid_ptr(stack_obj))
		return nullptr;
	auto* base = *reinterpret_cast<std::uint8_t**>(
		reinterpret_cast<std::uintptr_t>(stack_obj) + k_light_data_off);
	if (!valid_ptr(base))
		return nullptr;
	return base;
}

void tint_aggregate_light(void* aggregate_arr, std::uint8_t r, std::uint8_t g, std::uint8_t b) {
	if (!aggregate_arr || !valid_ptr(aggregate_arr))
		return;

	void* data = *reinterpret_cast<void**>(
		reinterpret_cast<std::uintptr_t>(aggregate_arr) + k_agg_arr_data);
	if (!valid_ptr(data))
		return;

	const int count = *reinterpret_cast<int*>(reinterpret_cast<std::uintptr_t>(data) + k_agg_count);
	const int index = *reinterpret_cast<int*>(reinterpret_cast<std::uintptr_t>(data) + k_agg_index);
	if (index < 0 || count <= 0 || count > k_max_agg_light_count)
		return;

	std::uint8_t* light = light_data_base();
	if (!light)
		return;

	for (int i = 0; i < count; ++i) {
		std::uint8_t* entry = light + (static_cast<std::uintptr_t>(index + i) << k_light_entry_shift);
		entry[0] = r;
		entry[1] = g;
		entry[2] = b;
	}
}
} // namespace

void c_world::exposure(c_post_processing_volume* post_processing) {
	if (!post_processing)
		return;

	const auto& wm = g_cfg->visuals.m_world_modulation;

	if (!wm.m_enable_exposure)
		return;

	float exp = wm.m_exposure;

	post_processing->m_exposure_control() = true;
	post_processing->m_fade_speed_down() = 0.0f;
	post_processing->m_fade_speed_up() = 0.0f;
	post_processing->m_min() = exp;
	post_processing->m_max() = exp;
}

void c_world::lighting(c_scene_light_object* light) {
	if (!light)
		return;

	const auto& wm = g_cfg->visuals.m_world_modulation;

	if (!wm.m_enable_lighting) {
		auto it = m_light_originals.find(light);
		if (it != m_light_originals.end()) {
			light->m_color_r = it->second.r;
			light->m_color_g = it->second.g;
			light->m_color_b = it->second.b;
			light->m_color_a = it->second.a;
			m_light_originals.erase(it);
		}
		return;
	}

	if (m_light_originals.find(light) == m_light_originals.end())
		m_light_originals[light] = { light->m_color_r, light->m_color_g, light->m_color_b, light->m_color_a };

	// Boost like Lefrizzel so sunset/night reads on modern lighting.
	constexpr float k_boost = 2.5f;
	light->m_color_r = std::clamp(wm.m_lighting.x * k_boost, 0.0f, 1.0f);
	light->m_color_g = std::clamp(wm.m_lighting.y * k_boost, 0.0f, 1.0f);
	light->m_color_b = std::clamp(wm.m_lighting.z * k_boost, 0.0f, 1.0f);
	light->m_color_a = std::clamp(wm.m_lighting.w, 0.0f, 1.0f);
}

void c_world::reset() {
	m_light_originals.clear();
}

void c_world::aggregate_scene(c_base_scene_data* scene, int count, c_material_2* material) {
	(void)material;
	if (!scene || count <= 0)
		return;

	const auto& wm = g_cfg->visuals.m_world_modulation;
	if (!wm.m_enable_wall)
		return;

	auto to_u8 = [](float v) { return static_cast<std::uint8_t>(std::clamp(v, 0.0f, 1.0f) * 255.0f + 0.5f); };

	std::uint8_t r = to_u8(wm.m_wall.x);
	std::uint8_t g = to_u8(wm.m_wall.y);
	std::uint8_t b = to_u8(wm.m_wall.z);

	for (int i = 0; i < count; ++i) {
		auto* sc = &scene[i];
		sc->r = r;
		sc->g = g;
		sc->b = b;
		sc->a = 255;
	}
}

void c_world::tint_aggregate_array(void* aggregate_arr) {
	if (!g_cfg || !aggregate_arr)
		return;
	const auto& wm = g_cfg->visuals.m_world_modulation;
	if (!wm.m_enable_wall)
		return;

	auto to_u8 = [](float v) { return static_cast<std::uint8_t>(std::clamp(v, 0.0f, 1.0f) * 255.0f + 0.5f); };
	tint_aggregate_light(aggregate_arr, to_u8(wm.m_wall.x), to_u8(wm.m_wall.y), to_u8(wm.m_wall.z));
}
