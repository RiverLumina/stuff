﻿

#pragma once
#include "cs2sdk_macros.hpp"

namespace cs2::sdk::animationsystem {

    inline constexpr std::uint32_t CS2_BUILD = 14160;

    class CPulseCell_WaitForCursorsWithTag;
    class CPulseCell_Base;
    class CPulse_ResumePoint;
    class CPulseCell_PickBestOutflowSelector;
    class CParticleBindingRealPulse;
    class CPulseCell_WaitForObservable;
    class CPulse_OutflowConnection;
    class CPulseGraphDef;
    class CPulseCell_FireCursors;
    class CPulseCell_Timeline_TimelineEvent_t;
    class CPulseCell_IntervalTimer_CursorState_t;
    class CPulseCell_BaseRequirement;
    class CPulseCell_BaseState;
    class OutflowWithRequirements_t;
    class CPulseCell_IsRequirementValid;
    class CPulseCell_Value_Gradient;
    class CPulseCursorFuncs;
    class PulseNodeDynamicOutflows_t_DynamicOutflow_t;
    class CBasePulseGraphInstance;
    class CPulseCell_Inflow_GraphHook;
    class SignatureOutflow_Resume;
    class CPulseCell_Inflow_BaseEntrypoint;
    class CPulseCell_WaitForCursorsWithTagBase;
    class CPulse_InvokeBinding;
    class CPulseCell_IntervalTimer;
    class CPulseTestScriptLib;
    class CPulseCell_BaseLerp;
    class CPulseCell_Value_Curve;
    class CPulseCell_Inflow_EventHandler;
    class CPulseCell_BaseFlow;
    class CPulseCell_Outflow_CycleShuffled_InstanceState_t;
    class CPulseCell_BaseLerp_CursorState_t;
    class CPulseCell_WaitForCursorsWithTagBase_CursorState_t;
    class CPulseArraylib;
    class SignatureOutflow_Continue;
    class CPulseCell_Timeline;
    class CPulseCell_Inflow_EntOutputHandler;
    class CPulseCell_Outflow_CycleOrdered_InstanceState_t;
    class CParticleCollectionBindingInstance;
    class CPulseCell_LimitCount_InstanceState_t;
    class CPulseCell_Step_DebugLog;
    class CPulseCell_BaseYieldingInflow;
    class PulseNodeDynamicOutflows_t;
    class CPulseCell_IsRequirementValid_Criteria_t;
    class CPulseCell_Inflow_ObservableVariableListener;
    class CPulseCell_Outflow_CycleOrdered;
    class PulseSelectorOutflowList_t;
    class CPulseCell_Inflow_Wait;
    class CPulseCell_Outflow_CycleShuffled;
    class CPulseCell_Inflow_Method;
    class CPulseCell_BaseValue;
    class CPulseCell_BooleanSwitchState;
    class CPulseCell_Inflow_Yield;
    class CPulseMathlib;
    class CPulseCell_Unknown;
    class CPulseCell_Outflow_CycleRandom;
    class CPulseCell_Step_PublicOutput;
    class CPulse_BlackboardReference;
    class CPulseCell_Value_RandomInt;
    class CAnimationLayer;
    class CPulse_CallInfo;
    class CPulseCell_InlineNodeSkipSelector;
    class CPulseCell_LimitCount;
    class CPulseCell_Step_CallExternalMethod;
    class PulseObservableBoolExpression_t;
    class CPulseCell_LimitCount_Criteria_t;
    class CPulseCell_CursorQueue;
    class CPulseCell_Value_RandomFloat;
    class CPulseExecCursor;
    class CAnimFrameBlockAnim;
    class CZeroPoseUpdateNode;
    class CSlowDownOnSlopesUpdateNode;
    class COrientationWarpUpdateNode;
    class CAnimParameterBase;
    class CSequenceFinishedAnimTag;
    class CSceneObjectData;
    class CFootCycle;
    class CParticleModelInput;
    class CInputStreamUpdateNode;
    class CNmFootIKTask;
    class CIntAnimParameter;
    class CNmParameterizedBlendNode_CDefinition;
    class CNmScaleTask;
    class PerTickSettings_t;
    class CNmFrameSnapEvent;
    class CAnimNodePath;
    class AnimNodeOutputID;
    class CNmSyncTrack;
    class CSeqBoneMaskList;
    class CAnimEncodedFrames;
    class SampleCode;
    class CCachedPose;
    class CNmTransitionEventConditionNode_CDefinition;
    class CTaskStatusAnimTag;
    class CStateNodeInstanceData;
    class CMotionGraphConfig;
    class CMotionSearchNode;
    class CAnimActivity;
    class CAnimScriptManager;
    class AnimationDecodeDebugDumpElement_t;
    class CChoreoInstanceData;
    class PulseRuntimeVarIndex_t;
    class ConfigIndex;
    class VPhysXCollisionAttributes_t;
    class CSequenceUpdateNode;
    class CStateMachineInstanceData;
    class CNmPassthroughNode_CDefinition;
    class CNmClipReferenceNode_CDefinition;
    class CNmGraphDefinition_ExternalGraphSlot_t;
    class PulseRuntimeEntrypointIndex_t;
    class CAimCameraUpdateNode;
    class PulseRuntimeDomainValueIndex_t;
    class LookData;
    class CSeqSeqDescFlag;
    class PermModelInfo_t;
    class StanceInfo_t;
    class IKBoneNameAndIndex_t;
    class CPulse_Chunk;
    class CStanceScaleUpdateNode;
    class PulseRuntimeInvokeIndex_t;
    class CNmBoneMaskBlendNode_CDefinition;
    class CNmIDEventNode_CDefinition;
    class HitReactFixedSettings_t;
    class CNmPoseNode_CDefinition;
    class CAnimTagBase;
    class CPerParticleVecInput;
    class CMotionGraph;
    class CNmVectorInfoNode_CDefinition;
    class AnimationSnapshot_t;
    class CNmBlendTask;
    class CNmVectorValueNode_CDefinition;
    class CSeqTransition;
    class CNmPoseTask;
    class CAnimGraphSettingsGroup;
    class CNmVirtualParameterTargetNode_CDefinition;
    class CAnimGraphDebugReplay;
    class CVectorAnimParameter;
    class CNmCachedPoseReadTask;
    class CNmStateMachineNode_StateDefinition_t;
    class CStanceOverrideUpdateNode;
    class CNmGraphDefinition_ExternalPoseSlot_t;
    class PhysShapeMarkup_t;
    class CBlend2DInstanceData;
    class LookAtBone_t;
    class CDirectPlaybackInstanceData;
    class CNmTransitionNode_CDefinition;
    class PulseRuntimeRegisterIndex_t;
    class CNmFloatEaseNode_CDefinition;
    class CAnimationGraphInstance;
    class CAnimEncodeDifference;
    class CRootUpdateNode;
    class CNmTargetOffsetNode_CDefinition;
    class MotionMatchingInstanceData;
    class CMotionGraphUpdateNode;
    class CNmFloatAngleMathNode_CDefinition;
    class PulseCursorID_t;
    class CAnimParamHandle;
    class WeightList;
    class MotionIndex;
    class FollowAttachmentSettings_t;
    class CNmReferencedGraphNode_CDefinition;
    class AnimNodeID;
    class CNmClipSelectorNode_CDefinition;
    class CLookComponentUpdater;
    class CNmIsExternalPoseSetNode_CDefinition;
    class CAnimGraphNetworkSettings;
    class CSingleFrameUpdateNode;
    class CNmChainLookatNode_CDefinition;
    class CNmFollowBoneNode_CDefinition;
    class CBlockSelectionMetricEvaluator;
    class MovementData;
    class CRemapValueComponentUpdater;
    class CModelConfigList;
    class CSeqAutoLayerFlag;
    class AnimStateID;
    class CNmIDEventConditionNode_CDefinition;
    class ModelBoneFlexDriver_t;
    class CMorphData;
    class CFootPinningUpdateNode;
    class CSeqPoseSetting;
    class PulseGraphExecutionHistoryCursorDesc_t;
    class CNmVirtualParameterFloatNode_CDefinition;
    class CAttachment;
    class CSequenceUpdateNodeBase;
    class CDrawCullingData;
    class VPhysXJoint_t;
    class CStateNodeTransitionData;
    class CTimeRemainingMetricEvaluator;
    class CParticleInput;
    class CModelConfigElement;
    class CNmControlParameterVectorNode_CDefinition;
    class FootFixedSettings;
    class CNmBoneMaskSwitchNode_CDefinition;
    class CModelConfig;
    class AnimComponentID;
    class VPhysXAggregateData_t;
    class CNmGraphDefinition;
    class CNmSelectorNode_CDefinition;
    class CAnimDemoCaptureSettings;
    class IKDemoCaptureSettings_t;
    class CSeqMultiFetchFlag;
    class PulseRegisterMap_t;
    class VPhysXRange_t;
    class CStopAtGoalUpdateNode;
    class CNmIDEventPercentageThroughNode_CDefinition;
    class CAnimBoneDifference;
    class CNmCachedBoolNode_CDefinition;
    class CAnimCycle;
    class CActionComponentUpdater;
    class CDirectionalBlendInstanceData;
    class CDampedPathAnimMotorUpdater;
    class CNmCachedFloatNode_CDefinition;
    class CNmFloatSwitchNode_CDefinition;
    class CModelConfigElement_SetMaterialGroupOnAttachedModels;
    class CNmEntityAttributeEventBase;
    class CNmVirtualParameterBoneMaskNode_CDefinition;
    class SequenceData;
    class CPathHelperUpdateNode;
    class MaterialGroup_t;
    class CMorphBundleData;
    class CModelConfigElement_UserPick;
    class CSolveIKTargetHandle_t;
    class CFootAdjustmentUpdateNode;
    class CChoreoUpdateNode;
    class CAimConstraint;
    class CMaterialDrawDescriptor_RigidMeshPart_t;
    class CFootFallAnimTag;
    class CMaterialDrawDescriptor;
    class CNmSkeleton;
    class CStepsRemainingMetricEvaluator;
    class CNmVelocityBlendNode_CDefinition;
    class CNmZeroPoseTask;
    class CBodyGroupSetting;
    class CVectorQuantizer;
    class ParticleNamedValueConfiguration_t;
    class CNmVectorCreateNode_CDefinition;
    class CParticleVecInput;
    class CNmStateNode_CDefinition;
    class CNmBoneMaskSelectorNode_CDefinition;
    class CNmVirtualParameterVectorNode_CDefinition;
    class CFootCycleMetricEvaluator;
    class CNmConstIDNode_CDefinition;
    class CHitBox;
    class CNmParameterizedSelectorNode_CDefinition;
    class ModelSkeletonData_t;
    class CNmEvent;
    class NmCompressionSettings_t_QuantizationRange_t;
    class CNmBlendTaskBase;
    class TagSpan_t;
    class CNmConstTargetNode_CDefinition;
    class CRemapValueUpdateItem;
    class PermModelDataAnimatedMaterialAttribute_t;
    class CMotionDataSet;
    class CProductQuantizer;
    class CChoiceUpdateNode;
    class SkeletonAnimCapture_t_Bone_t;
    class CExpressionActionUpdater;
    class CNmFloatMathNode_CDefinition;
    class CAnimationGraphVisualizerLine;
    class CCycleControlUpdateNode;
    class CNmTargetInfoNode_CDefinition;
    class CDampedValueComponentUpdater;
    class CBaseConstraint;
    class CNmControlParameterFloatNode_CDefinition;
    class BlendItem_t;
    class DampedPathMotorInstanceData_t;
    class CNmIsExternalGraphSlotFilledNode_CDefinition;
    class CNewParticleEffect;
    class CNmClipNode_CDefinition;
    class CNmMaterialAttributeEvent;
    class CNmBlend1DNode_CDefinition;
    class CConcreteAnimParameter;
    class CNmBoneWeightList;
    class CPairedSequenceUpdateNode;
    class CModelConfigElement_RandomPick;
    class CNmReferencePoseTask;
    class CNmScaleNode_CDefinition;
    class VPhysXConstraint2_t;
    class CConstraintTarget;
    class SkeletonAnimCapture_t;
    class CAnimUser;
    class CRagdollComponentUpdater;
    class ParticleNamedValueSource_t;
    class CFootDefinition;
    class CSeqSynthAnimDesc;
    class CNmLayerBlendNode_LayerDefinition_t;
    class CAnimComponentUpdater;
    class CBlend2DUpdateNode;
    class CNmVelocityBasedSpeedScaleNode_CDefinition;
    class CNPCPhysicsHull;
    class PermModelExtPart_t;
    class CNmCachedIDNode_CDefinition;
    class CLeanMatrixUpdateNode;
    class CSymbolAnimParameter;
    class CNmFloatCurveEventNode_CDefinition;
    class IAnimationGraphInstance;
    class CNmStateMachineNode_TransitionDefinition_t;
    class CNmFloatSelectorNode_CDefinition;
    class CTargetSelectorUpdateNode;
    class SlopeData;
    class CHitBoxSetList;
    class CNmIsInactiveBranchConditionNode_CDefinition;
    class MotionDBIndex;
    class CDirectPlaybackTagData;
    class CParticleCollectionVecInput;
    class CNmGraphEventConditionNode_Condition_t;
    class CNmFloatRemapNode_RemapRange_t;
    class CNmCurrentSyncEventIDNode_CDefinition;
    class CNmStateCompletedConditionNode_CDefinition;
    class CNmTargetWarpEvent;
    class CParamSpanUpdater;
    class CAnimActionUpdater;
    class CParticleAnimTag;
    class CCycleBase;
    class FollowTargetOpFixedSettings_t;
    class CNmIDSwitchNode_CDefinition;
    class CNmRootMotionEvent;
    class CPulse_PublicOutput;
    class CChoiceInstanceData;
    class AnimationSnapshotBase_t;
    class CEmitTagActionUpdater;
    class DynamicMeshDeformParams_t;
    class CNmTimeConditionNode_CDefinition;
    class CNmSyncEventIndexConditionNode_CDefinition;
    class CAnimStateMachineUpdater;
    class CUnaryUpdateNode;
    class CNmIDToFloatNode_CDefinition;
    class PlayerInputMotorInstanceData_t;
    class CCompressorGroup;
    class CSelectorUpdateNode;
    class NmPercent_t;
    class CStateMachineComponentUpdater;
    class CAnimUpdateNodeRef;
    class CPulse_OutputConnection;
    class CPhysSurfaceProperties;
    class CNmBoneMaskValueNode_CDefinition;
    class CSeqPoseParamDesc;
    class CModelConfigElement_SetBodygroup;
    class CAnimMovement;
    class CParticleRemapFloatInput;
    class FollowAttachmentData;
    class FootStepTrigger;
    class CNmSyncTrack_EventMarker_t;
    class CPathMetricEvaluator;
    class CFootLockUpdateNode;
    class CNmOrientationWarpEvent;
    class CNmIDValueNode_CDefinition;
    class PulseGraphExecutionHistoryNodeDesc_t;
    class JiggleBoneSettings_t;
    class CJumpHelperUpdateNode;
    class CNmControlParameterBoolNode_CDefinition;
    class CNmChainLookatTask;
    class FootLockPoseOpFixedSettings;
    class CBoneVelocityMetricEvaluator;
    class CWarpSectionAnimTag;
    class SelectorInstanceData_t;
    class CModelConfigElement_RandomColor;
    class CFootMotion;
    class CJiggleBoneUpdateNode;
    class CNmConstVectorNode_CDefinition;
    class MoodAnimation_t;
    class CLODComponentUpdater;
    class CNmIsTargetSetNode_CDefinition;
    class CPhysSurfacePropertiesVehicle;
    class CAnimDataChannelDesc;
    class CPairedSequenceComponentUpdater;
    class CNmParticleEvent;
    class MotionSelection;
    class CMorphRectData;
    class CAnimFoot;
    class CParentConstraint;
    class CNmCachedVectorNode_CDefinition;
    class CNmStateNode_TimedEvent_t;
    class CFootPositionMetricEvaluator;
    class CParticleVariableRef;
    class CMoverInstanceData;
    class HSequence;
    class CDampedValueUpdateItem;
    class CAnimLocalHierarchy;
    class CBlendUpdateNode;
    class PulseGraphExecutionHistoryEntry_t;
    class CQuaternionAnimParameter;
    class PermModelData_t;
    class PulseCursorYieldToken_t;
    class CNmSampleTask;
    class CFollowPathInstanceData;
    class CStaticPoseCacheBuilder;
    class ModelMeshBufferData_t;
    class CSequenceGroupData;
    class CStateMachineUpdateNode;
    class CNmIDBasedSelectorNode_CDefinition;
    class CAimMatrixUpdateNode;
    class SkeletonAnimCapture_t_Frame_t;
    class CModelConfigElement_Command;
    class TargetSelectorInstanceData_t;
    class CAnimEventDefinition;
    class CNmRootMotionData;
    class CPulseGraphExecutionHistory;
    class AnimScriptHandle;
    class CFlexOp;
    class CHitReactUpdateNode;
    class CLookAtUpdateNode;
    class CAnimBone;
    class CAnimParameterManagerUpdater;
    class BoneDemoCaptureSettings_t;
    class PairedSequenceData;
    class CBoneConstraintPoseSpaceMorph_Input_t;
    class MoodAnimationLayer_t;
    class CSpeedScaleUpdateNode;
    class CSequenceTagSpans;
    class CModelConfigElement_SetBodygroupOnAttachedModels;
    class CCurrentVelocityMetricEvaluator;
    class CNmBoolValueNode_CDefinition;
    class CAnimReplayFrame;
    class CNmTransitionEvent;
    class CNmFloatCurveEvent;
    class CParticleTransformInput;
    class CPathAnimMotorUpdaterBase;
    class PGDInstruction_t;
    class CNmFootstepEventPercentageThroughNode_CDefinition;
    class AimCameraOpFixedSettings_t;
    class SkeletonAnimCapture_t_Camera_t;
    class CNmGraphEventConditionNode_CDefinition;
    class CFollowAttachmentUpdateNode;
    class CMovementComponentUpdater;
    class CModelConfigElement_SetMaterialGroup;
    class IParticleEffect;
    class CFutureFacingMetricEvaluator;
    class CNmIDBasedClipSelectorNode_CDefinition;
    class CLeanMatrixInstanceData;
    class NmCompressionSettings_t;
    class CPulse_Variable;
    class PARTICLE_EHANDLE__;
    class CAddUpdateNode;
    class CAnimEnum;
    class CDemoSettingsComponentUpdater;
    class CAnimDecoder;
    class CNmCachedTargetNode_CDefinition;
    class CPerParticleFloatInput;
    class CNmConstBoolNode_CDefinition;
    class CNmBitFlags;
    class CFootStride;
    class CSceneObjectData_RTProxyDrawDescriptor_t;
    class CNmLegacyEvent;
    class CStateNodeStateData;
    class CFootstepLandedAnimTag;
    class CEnumAnimParameter;
    class CHandshakeAnimTagBase;
    class AnimTagID;
    class CWayPointHelperInstanceData;
    class CAnimFrameSegment;
    class CSlopeComponentUpdater;
    class CAnimInputDamping;
    class CHitBoxSet;
    class ChainToSolveData_t;
    class CConstraintSlave;
    class PulseRuntimeOutputIndex_t;
    class CFootCycleDefinition;
    class CVirtualAnimParameter;
    class CMotionMetricEvaluator;
    class CFutureVelocityMetricEvaluator;
    class CNmSkeleton_SecondarySkeleton_t;
    class CAnimUpdateNodeBase;
    class CSetParameterActionUpdater;
    class CNmFixedWeightBoneMaskNode_CDefinition;
    class SkeletonAnimCapture_t_FrameStamp_t;
    class CPulse_DomainValue;
    class CBonePositionMetricEvaluator;
    class CRenderBufferBinding;
    class CParticleCollectionRendererFloatInput;
    class CNmParameterizedBlendNode_Parameterization_t;
    class CNmEntityAttributeIntEvent;
    class CNmNotNode_CDefinition;
    class CMeshletDescriptor;
    class CMorphSetData;
    class CNmAndNode_CDefinition;
    class CMorphConstraint;
    class CClothSettingsAnimTag;
    class CAnimDesc_Flag;
    class CNmBlend2DNode_CDefinition;
    class CBlendCurve;
    class CNmGraphNode_CDefinition;
    class CAnimationGraphVisualizerSphere;
    class CNmClip_ModelSpaceSamplingChainLink_t;
    class CAnimUserDifference;
    class CNmDurationScaleNode_CDefinition;
    class CTransitionUpdateData;
    class PulseRuntimeBlackboardReferenceIndex_t;
    class CMovementHandshakeAnimTag;
    class CBoneConstraintPoseSpaceBone_Input_t;
    class CSeqMultiFetch;
    class CPhysSurfacePropertiesSoundNames;
    class NmBoneMaskSetDefinition_t;
    class CAudioAnimTag;
    class CTurnHelperUpdateNode;
    class CAnimationGroup;
    class NmSyncTrackTime_t;
    class CNmClip;
    class CToggleComponentActionUpdater;
    class CNmOverlayBlendTask;
    class CNmSpeedScaleBaseNode_CDefinition;
    class CNmValueNode_CDefinition;
    class CAnimationGraphVisualizerPrimitiveBase;
    class CBindPoseUpdateNode;
    class NmSyncTrackTimeRange_t;
    class CAnimationGraphVisualizerText;
    class CFootTrajectory;
    class CMotionMatchingUpdateNode;
    class CNmReferencePoseNode_CDefinition;
    class CSeqS1SeqDesc;
    class CFlexController;
    class SkeletonDemoDb_t;
    class CNmFloatRangeComparisonNode_CDefinition;
    class CMotionNodeSequence;
    class CNmTwoBoneIKNode_CDefinition;
    class CNmGraphInstance;
    class CFlexDesc;
    class CRenderMesh;
    class CAnimSkeleton;
    class PulseRuntimeConstantIndex_t;
    class CFootAdjustmentInstanceData;
    class VPhysics2ShapeDef_t;
    class CNmFloatCurveNode_CDefinition;
    class CAnimationGraphVisualizerAxis;
    class CTwistConstraint;
    class PulseDocNodeID_t;
    class ModelBoneFlexDriverControl_t;
    class CParticleCollectionFloatInput;
    class CSeqCmdLayer;
    class FootPinningPoseOpFixedData_t;
    class RenderSkeletonBone_t;
    class CDistanceRemainingMetricEvaluator;
    class CDirectPlaybackUpdateNode;
    class CNmIDEvent;
    class CFlexRule;
    class ScriptInfo_t;
    class CBoneConstraintRbf;
    class CNetworkedCycle;
    class CNmSoundEvent;
    class CRenderGroom;
    class CNmParameterizedClipSelectorNode_CDefinition;
    class CTiltTwistConstraint;
    class CNmSpeedScaleNode_CDefinition;
    class CVPhysXSurfacePropertiesList;
    class CNmFloatSpringNode_CDefinition;
    class RenderHairStrandInfo_t;
    class CCycleControlClipUpdateNode;
    class CNmTargetPointNode_CDefinition;
    class CNmTargetSelectorNode_CDefinition;
    class CPulse_RegisterInfo;
    class CNmFloatValueNode_CDefinition;
    class CWarpSectionAnimTagBase;
    class CNmGraphVariationUserData;
    class CStaticPoseCache;
    class LookAtOpFixedSettings_t;
    class CRootMotion;
    class CAnimGraphSettingsManager;
    class CAnimGraphModelBinding;
    class CBoneConstraintPoseSpaceBone;
    class CNmTwoBoneIKTask;
    class MotionBlendItem;
    class CBoneConstraintPoseSpaceMorph;
    class CFloatAnimParameter;
    class CStateActionUpdater;
    class CPlayerInputAnimMotorUpdater;
    class CRenderSkeleton;
    class CSeqIKLock;
    class CAnimParamHandleMap;
    class CNmFloatClampNode_CDefinition;
    class PulseRuntimeCellIndex_t;
    class CNmExternalPoseNode_CDefinition;
    class CAnimDesc;
    class CNmRootMotionOverrideNode_CDefinition;
    class CNmTargetWarpNode_CDefinition;
    class CPhysSurfacePropertiesPhysics;
    class CAnimationGraphVisualizerPie;
    class NmFloatCurveCompressionSettings_t;
    class CBoneConstraintDotToMorph;
    class CPointConstraint;
    class CCurrentRotationVelocityMetricEvaluator;
    class TraceSettings_t;
    class ParamSpanSample_t;
    class CNmFollowBoneTask;
    class VPhysXConstraintParams_t;
    class CNmFloatComparisonNode_CDefinition;
    class CStateUpdateData;
    class CTurnHelperInstanceData;
    class CNmTargetValueNode_CDefinition;
    class COrientConstraint;
    class CCycleClipInstanceData;
    class CMoverUpdateNode;
    class CNmLayerBlendNode_CDefinition;
    class CNmFootIKNode_CDefinition;
    class CAnimMotorUpdaterBase;
    class JiggleBoneSettingsList_t;
    class CSubtractUpdateNode;
    class PulseGraphInstanceID_t;
    class CNmFloatRemapNode_CDefinition;
    class CPoseHandle;
    class CNmFootstepEventIDNode_CDefinition;
    class CSolveIKChainUpdateNode;
    class CNmOrNode_CDefinition;
    class CSeqCmdSeqDesc;
    class CBoneMaskUpdateNode;
    class CLeafUpdateNode;
    class CPulse_Constant;
    class CParticleFloatInput;
    class SolveIKChainPoseOpFixedSettings_t;
    class CNmEntityAttributeFloatEvent;
    class CNmIDSelectorNode_CDefinition;
    class TwoBoneIKSettings_t;
    class CNmCachedPoseWriteTask;
    class CAnimUpdateSharedData;
    class CAnimAttachment;
    class CFootTrajectories;
    class CNmIDComparisonNode_CDefinition;
    class PairedSequence_t;
    class CEditableMotionGraph;
    class CNmConstFloatNode_CDefinition;
    class CStringAnimTag;
    class CBoolAnimParameter;
    class CRagdollAnimTag;
    class CMotionNode;
    class CNmStateMachineNode_CDefinition;
    class CBodyGroupAnimTag;
    class CNmModelSpaceBlendTask;
    class CNmZeroPoseNode_CDefinition;
    class CNmOrientationWarpNode_CDefinition;
    class AnimParamID;
    class CNmBoneMaskNode_CDefinition;
    class ModelAnimGraph2Ref_t;
    class AnimationDecodeDebugDump_t;
    class CNmVirtualParameterIDNode_CDefinition;
    class CSeqScaleSet;
    class PulseRuntimeCallInfoIndex_t;
    class CDirectionalBlendUpdateNode;
    class CNmGraphDefinition_ReferencedGraphSlot_t;
    class ParamSpan_t;
    class CFootStepTriggerUpdateNode;
    class IKTargetSettings_t;
    class CModelConfigElement_SetRenderColor;
    class CNmAdditiveBlendTask;
    class CNmAnimationPoseNode_CDefinition;
    class CMotionSearchDB;
    class CMotionNodeBlend1D;
    class CNmCurrentSyncEventNode_CDefinition;
    class CNmControlParameterTargetNode_CDefinition;
    class SkeletonBoneBounds_t;
    class CTwoBoneIKUpdateNode;
    class VPhysXBodyPart_t;
    class PulseRuntimeChunkIndex_t;
    class CTaskHandshakeAnimTag;
    class CFollowPathUpdateNode;
    class AimMatrixOpFixedSettings_t;
    class CAnimScriptComponentUpdater;
    class CRagdollUpdateNode;
    class CBoneConstraintBase;
    class CPathAnimMotorUpdater;
    class CMaterialAttributeAnimTag;
    class CNmFootEventConditionNode_CDefinition;
    class CNmFootEvent;
    class CPhysSurfacePropertiesAudio;
    class CSeqAutoLayer;
    class ModelEmbeddedMesh_t;
    class PhysSoftbodyDesc_t;
    class CPulseRuntimeMethodArg;
    class CAnimSequenceParams;
    class CTargetWarpUpdateNode;
    class CNmVirtualParameterBoolNode_CDefinition;
    class CFollowTargetUpdateNode;
    class PulseRuntimeStateOffset_t;
    class CCPPScriptComponentUpdater;
    class NetVarConfigIndex;
    class CAnimData;
    class IKSolverSettings_t;
    class CBinaryUpdateNode;
    class CBlendNodeInstanceData;
    class CNmParameterizedBlendNode_BlendRange_t;
    class CAnimKeyData;
    class AttachmentHandle_t;
    class CAnimMorphDifference;
    class FootFixedData_t;
    class CMotionGraphGroup;
    class CPulse_InstructionDebug;
    class CNmVectorNegateNode_CDefinition;
    class CNmSyncTrack_Event_t;
    class CParticleCollectionRendererVecInput;
    class CNmTarget;
    class CNmControlParameterIDNode_CDefinition;
    class CNmBodyGroupEvent;
    class CWayPointHelperUpdateNode;
    class CMoodVData;
    class CModelConfigElement_AttachedModel;
    class CAnimTagManagerUpdater;
    class CParticleProperty;

    enum class PulseBestOutflowRules_t : std::uint32_t {
        SORT_BY_NUMBER_OF_VALID_CRITERIA = 0x0,
        SORT_BY_OUTFLOW_INDEX = 0x1,
    };

    enum class PulseCursorCancelPriority_t : std::uint32_t {
        None = 0x0,
        CancelOnSucceeded = 0x1,
        SoftCancel = 0x2,
        HardCancel = 0x3,
    };

    enum class PulseMethodCallMode_t : std::uint32_t {
        SYNC_WAIT_FOR_COMPLETION = 0x0,
        ASYNC_FIRE_AND_FORGET = 0x1,
    };

    enum class ParticleSetMethod_t : std::uint32_t {
        PARTICLE_SET_REPLACE_VALUE = 0x0,
        PARTICLE_SET_SCALE_INITIAL_VALUE = 0x1,
        PARTICLE_SET_ADD_TO_INITIAL_VALUE = 0x2,
        PARTICLE_SET_RAMP_CURRENT_VALUE = 0x3,
        PARTICLE_SET_SCALE_CURRENT_VALUE = 0x4,
        PARTICLE_SET_ADD_TO_CURRENT_VALUE = 0x5,
    };

    enum class SeqCmd_t : std::uint32_t {
        SeqCmd_Nop = 0x0,
        SeqCmd_LinearDelta = 0x1,
        SeqCmd_FetchFrameRange = 0x2,
        SeqCmd_Slerp = 0x3,
        SeqCmd_Add = 0x4,
        SeqCmd_Subtract = 0x5,
        SeqCmd_Scale = 0x6,
        SeqCmd_Copy = 0x7,
        SeqCmd_Blend = 0x8,
        SeqCmd_Worldspace = 0x9,
        SeqCmd_Sequence = 0xA,
        SeqCmd_FetchCycle = 0xB,
        SeqCmd_FetchFrame = 0xC,
        SeqCmd_IKLockInPlace = 0xD,
        SeqCmd_IKRestoreAll = 0xE,
        SeqCmd_ReverseSequence = 0xF,
        SeqCmd_Transform = 0x10,
    };

    enum class CNmEventRelevance_t : std::uint32_t {
        ClientOnly = 0x0,
        ServerOnly = 0x1,
        ClientAndServer = 0x2,
    };

    enum class BoneTransformSpace_t : std::int32_t {
        BoneTransformSpace_Invalid = -1,
        BoneTransformSpace_Parent = 0x0,
        BoneTransformSpace_Model = 0x1,
        BoneTransformSpace_World = 0x2,
    };

    enum class CAnimationGraphVisualizerPrimitiveType : std::uint32_t {
        ANIMATIONGRAPHVISUALIZERPRIMITIVETYPE_Text = 0x0,
        ANIMATIONGRAPHVISUALIZERPRIMITIVETYPE_Sphere = 0x1,
        ANIMATIONGRAPHVISUALIZERPRIMITIVETYPE_Line = 0x2,
        ANIMATIONGRAPHVISUALIZERPRIMITIVETYPE_Pie = 0x3,
        ANIMATIONGRAPHVISUALIZERPRIMITIVETYPE_Axis = 0x4,
    };

    enum class NmTransitionRule_t : std::uint8_t {
        AllowTransition = 0x0,
        ConditionallyAllowTransition = 0x1,
        BlockTransition = 0x2,
    };

    enum class BinaryNodeTiming : std::uint32_t {
        UseChild1 = 0x0,
        UseChild2 = 0x1,
        SyncChildren = 0x2,
    };

    enum class NmFollowBoneMode_t : std::uint8_t {
        RotationAndTranslation = 0x0,
        RotationOnly = 0x1,
        TranslationOnly = 0x2,
    };

    enum class SolveIKChainAnimNodeDebugSetting : std::uint32_t {
        SOLVEIKCHAINANIMNODEDEBUGSETTING_None = 0x0,
        SOLVEIKCHAINANIMNODEDEBUGSETTING_X_Axis_Circle = 0x1,
        SOLVEIKCHAINANIMNODEDEBUGSETTING_Y_Axis_Circle = 0x2,
        SOLVEIKCHAINANIMNODEDEBUGSETTING_Z_Axis_Circle = 0x3,
        SOLVEIKCHAINANIMNODEDEBUGSETTING_Forward = 0x4,
        SOLVEIKCHAINANIMNODEDEBUGSETTING_Up = 0x5,
        SOLVEIKCHAINANIMNODEDEBUGSETTING_Left = 0x6,
    };

    enum class CNmParticleEvent_e : std::uint32_t {
        Create = 0x0,
        Create_CFG = 0x1,
    };

    enum class ParticleFloatBiasType_t : std::int32_t {
        PF_BIAS_TYPE_INVALID = -1,
        PF_BIAS_TYPE_STANDARD = 0x0,
        PF_BIAS_TYPE_GAIN = 0x1,
        PF_BIAS_TYPE_EXPONENTIAL = 0x2,
        PF_BIAS_TYPE_COUNT = 0x3,
    };

    enum class CNmTargetWarpNode : std::uint8_t {
        None = 0x0,
        Recalculate = 0x1,
        Offset = 0x2,
        RecalculateOrOffset = 0x3,
    };

    enum class SharedMovementGait_t : std::int8_t {
        eInvalid = -1,
        eSlow = 0x0,
        eMedium = 0x1,
        eFast = 0x2,
        eVeryFast = 0x3,
        eCount = 0x4,
    };

    enum class OrientationWarpRootMotionSource_t : std::uint32_t {
        eAnimationOrProcedural = 0x0,
        eAnimationOnly = 0x1,
        eProceduralOnly = 0x2,
    };

    enum class PulseVariableKeysSource_t : std::uint32_t {
        PRIVATE = 0x0,
        CPP = 0x1,
        VMAP = 0x2,
        VMDL = 0x3,
        XML = 0x4,
        COUNT = 0x5,
    };

    enum class IKTargetCoordinateSystem : std::uint32_t {
        IKTARGETCOORDINATESYSTEM_WorldSpace = 0x0,
        IKTARGETCOORDINATESYSTEM_ModelSpace = 0x1,
        IKTARGETCOORDINATESYSTEM_COUNT = 0x2,
    };

    enum class ParticleFloatType_t : std::int32_t {
        PF_TYPE_INVALID = -1,
        PF_TYPE_LITERAL = 0x0,
        PF_TYPE_NAMED_VALUE = 0x1,
        PF_TYPE_RANDOM_UNIFORM = 0x2,
        PF_TYPE_RANDOM_BIASED = 0x3,
        PF_TYPE_COLLECTION_AGE = 0x4,
        PF_TYPE_ENDCAP_AGE = 0x5,
        PF_TYPE_CONTROL_POINT_COMPONENT = 0x6,
        PF_TYPE_CONTROL_POINT_CHANGE_AGE = 0x7,
        PF_TYPE_CONTROL_POINT_SPEED = 0x8,
        PF_TYPE_PARTICLE_DETAIL_LEVEL = 0x9,
        PF_TYPE_CONCURRENT_DEF_COUNT = 0xA,
        PF_TYPE_CLOSEST_CAMERA_DISTANCE = 0xB,
        PF_TYPE_SNAPSHOT_COUNT = 0xC,
        PF_TYPE_SNAPSHOT_CHANGED = 0xD,
        PF_TYPE_RENDERER_CAMERA_DISTANCE = 0xE,
        PF_TYPE_RENDERER_CAMERA_DOT_PRODUCT = 0xF,
        PF_TYPE_PARTICLE_NOISE = 0x10,
        PF_TYPE_PARTICLE_AGE = 0x11,
        PF_TYPE_PARTICLE_AGE_NORMALIZED = 0x12,
        PF_TYPE_PARTICLE_FLOAT = 0x13,
        PF_TYPE_PARTICLE_INITIAL_FLOAT = 0x14,
        PF_TYPE_PARTICLE_VECTOR_COMPONENT = 0x15,
        PF_TYPE_PARTICLE_INITIAL_VECTOR_COMPONENT = 0x16,
        PF_TYPE_PARTICLE_SPEED = 0x17,
        PF_TYPE_PARTICLE_NUMBER = 0x18,
        PF_TYPE_PARTICLE_NUMBER_NORMALIZED = 0x19,
        PF_TYPE_PARTICLE_ROPE_SEGMENT = 0x1A,
        PF_TYPE_PARTICLE_ROPE_SEGMENT_NORMALIZED = 0x1B,
        PF_TYPE_PARTICLE_SCREENSPACE_CAMERA_DISTANCE = 0x1C,
        PF_TYPE_PARTICLE_SCREENSPACE_CAMERA_DOT_PRODUCT = 0x1D,
        PF_TYPE_COUNT = 0x1E,
    };

    enum class CNmFloatAngleMathNode : std::uint8_t {
        ClampTo180 = 0x0,
        ClampTo360 = 0x1,
        FlipHemisphere = 0x2,
        FlipHemisphereNegate = 0x3,
    };

    enum class VPhysXAggregateData_t_e : std::uint32_t {
        FLAG_IS_POLYSOUP_GEOMETRY = 0x1,
        FLAG_LEVEL_COLLISION = 0x10,
        FLAG_IGNORE_SCALE_OBSOLETE_DO_NOT_USE = 0x20,
    };

    enum class CNmRootMotionOverrideNode : std::uint8_t {
        AllowMoveX = 0x0,
        AllowMoveY = 0x1,
        AllowMoveZ = 0x2,
        AllowFacingPitch = 0x3,
        ListenForEvents = 0x4,
    };

    enum class NmEasingOperation_t : std::uint8_t {
        Linear = 0x0,
        InQuad = 0x1,
        OutQuad = 0x2,
        InOutQuad = 0x3,
        InCubic = 0x4,
        OutCubic = 0x5,
        InOutCubic = 0x6,
        InQuart = 0x7,
        OutQuart = 0x8,
        InOutQuart = 0x9,
        InQuint = 0xA,
        OutQuint = 0xB,
        InOutQuint = 0xC,
        InSine = 0xD,
        OutSine = 0xE,
        InOutSine = 0xF,
        InExpo = 0x10,
        OutExpo = 0x11,
        InOutExpo = 0x12,
        InCirc = 0x13,
        OutCirc = 0x14,
        InOutCirc = 0x15,
        None = 0x16,
    };

    enum class EIKEndEffectorRotationFixUpMode : std::uint32_t {
        None = 0x0,
        MatchTargetOrientation = 0x1,
        LookAtTargetForward = 0x2,
        MaintainParentOrientation = 0x3,
        Count = 0x4,
    };

    enum class MatterialAttributeTagType_t : std::uint32_t {
        MATERIAL_ATTRIBUTE_TAG_VALUE = 0x0,
        MATERIAL_ATTRIBUTE_TAG_COLOR = 0x1,
    };

    enum class PFNoiseTurbulence_t : std::uint32_t {
        PF_NOISE_TURB_NONE = 0x0,
        PF_NOISE_TURB_HIGHLIGHT = 0x1,
        PF_NOISE_TURB_FEEDBACK = 0x2,
        PF_NOISE_TURB_LOOPY = 0x3,
        PF_NOISE_TURB_CONTRAST = 0x4,
        PF_NOISE_TURB_ALTERNATE = 0x5,
    };

    enum class NmTargetWarpAlgorithm_t : std::uint8_t {
        Lerp = 0x0,
        Hermite = 0x1,
        HermiteFeaturePreserving = 0x2,
        Bezier = 0x3,
    };

    enum class ParticleColorBlendMode_t : std::uint32_t {
        PARTICLEBLEND_DEFAULT = 0x0,
        PARTICLEBLEND_OVERLAY = 0x1,
        PARTICLEBLEND_DARKEN = 0x2,
        PARTICLEBLEND_LIGHTEN = 0x3,
        PARTICLEBLEND_MULTIPLY = 0x4,
    };

    enum class ParticleColorBlendType_t : std::uint32_t {
        PARTICLE_COLOR_BLEND_MULTIPLY = 0x0,
        PARTICLE_COLOR_BLEND_MULTIPLY2X = 0x1,
        PARTICLE_COLOR_BLEND_DIVIDE = 0x2,
        PARTICLE_COLOR_BLEND_ADD = 0x3,
        PARTICLE_COLOR_BLEND_SUBTRACT = 0x4,
        PARTICLE_COLOR_BLEND_MOD2X = 0x5,
        PARTICLE_COLOR_BLEND_SCREEN = 0x6,
        PARTICLE_COLOR_BLEND_MAX = 0x7,
        PARTICLE_COLOR_BLEND_MIN = 0x8,
        PARTICLE_COLOR_BLEND_REPLACE = 0x9,
        PARTICLE_COLOR_BLEND_AVERAGE = 0xA,
        PARTICLE_COLOR_BLEND_NEGATE = 0xB,
        PARTICLE_COLOR_BLEND_LUMINANCE = 0xC,
    };

    enum class NmTransitionRuleCondition_t : std::uint8_t {
        AnyAllowed = 0x0,
        FullyAllowed = 0x1,
        ConditionallyAllowed = 0x2,
        Blocked = 0x3,
    };

    enum class ModelMeshBufferUsage_t : std::uint8_t {
        MESH_BUFFER_USAGE_NONE = 0x0,
        MESH_BUFFER_USAGE_VB = 0x1,
        MESH_BUFFER_USAGE_IB = 0x2,
        MESH_BUFFER_USAGE_ADJACENCY = 0x4,
        MESH_BUFFER_USAGE_MESHLET_TRIS = 0x8,
        MESH_BUFFER_USAGE_RT_PROXY = 0x10,
        MESH_BUFFER_USAGE_VERTEX_ALBEDO = 0x20,
    };

    enum class NmGraphDebugMode_t : std::uint32_t {
        Off = 0x0,
        On = 0x1,
    };

    enum class TargetWarpTimingMethod : std::uint32_t {
        ReachDestinationOnRootMotionEnd = 0x0,
        ReachDestinationOnWarpTagEnd = 0x1,
    };

    enum class ScriptedMoveTo_t : std::uint32_t {
        eWait = 0x0,
        eMoveWithGait = 0x3,
        eTeleport = 0x4,
        eWaitFacing = 0x5,
        eObsoleteBackCompat1 = 0x1,
        eObsoleteBackCompat2 = 0x2,
    };

    enum class EDemoBoneSelectionMode : std::uint32_t {
        CaptureAllBones = 0x0,
        CaptureSelectedBones = 0x1,
    };

    enum class EPulseGraphExecutionHistoryFlag : std::uint32_t {
        NO_FLAGS = 0x0,
        CURSOR_ADD_TAG = 0x1,
        CURSOR_REMOVE_TAG = 0x2,
        CURSOR_RETIRED = 0x4,
        REQUIREMENT_PASS = 0x8,
        REQUIREMENT_FAIL = 0x10,
    };

    enum class StepPhase : std::uint32_t {
        StepPhase_OnGround = 0x0,
        StepPhase_InAir = 0x1,
    };

    enum class FlexOpCode_t : std::uint32_t {
        FLEX_OP_CONST = 0x1,
        FLEX_OP_FETCH1 = 0x2,
        FLEX_OP_FETCH2 = 0x3,
        FLEX_OP_ADD = 0x4,
        FLEX_OP_SUB = 0x5,
        FLEX_OP_MUL = 0x6,
        FLEX_OP_DIV = 0x7,
        FLEX_OP_NEG = 0x8,
        FLEX_OP_EXP = 0x9,
        FLEX_OP_OPEN = 0xA,
        FLEX_OP_CLOSE = 0xB,
        FLEX_OP_COMMA = 0xC,
        FLEX_OP_MAX = 0xD,
        FLEX_OP_MIN = 0xE,
        FLEX_OP_2WAY_0 = 0xF,
        FLEX_OP_2WAY_1 = 0x10,
        FLEX_OP_NWAY = 0x11,
        FLEX_OP_COMBO = 0x12,
        FLEX_OP_DOMINATE = 0x13,
        FLEX_OP_DME_LOWER_EYELID = 0x14,
        FLEX_OP_DME_UPPER_EYELID = 0x15,
        FLEX_OP_SQRT = 0x16,
        FLEX_OP_REMAPVALCLAMPED = 0x17,
        FLEX_OP_SIN = 0x18,
        FLEX_OP_COS = 0x19,
        FLEX_OP_ABS = 0x1A,
    };

    enum class NmCachedValueMode_t : std::uint32_t {
        OnEntry = 0x0,
        OnExit = 0x1,
    };

    enum class AnimNodeNetworkMode : std::uint32_t {
        ServerAuthoritative = 0x0,
        ClientSimulate = 0x1,
    };

    enum class VPhysXBodyPart_t_e : std::uint32_t {
        FLAG_STATIC = 0x1,
        FLAG_KINEMATIC = 0x2,
        FLAG_JOINT = 0x4,
        FLAG_MASS = 0x8,
        FLAG_ALWAYS_DYNAMIC_ON_CLIENT = 0x10,
        FLAG_DISABLE_CCD = 0x20,
    };

    enum class AnimParamType_t : std::uint8_t {
        ANIMPARAM_UNKNOWN = 0x0,
        ANIMPARAM_BOOL = 0x1,
        ANIMPARAM_ENUM = 0x2,
        ANIMPARAM_INT = 0x3,
        ANIMPARAM_FLOAT = 0x4,
        ANIMPARAM_VECTOR = 0x5,
        ANIMPARAM_QUATERNION = 0x6,
        ANIMPARAM_GLOBALSYMBOL = 0x7,
        ANIMPARAM_COUNT = 0x8,
    };

    enum class NmEasingFunction_t : std::uint8_t {
        Linear = 0x0,
        Quad = 0x1,
        Cubic = 0x2,
        Quart = 0x3,
        Quint = 0x4,
        Sine = 0x5,
        Expo = 0x6,
        Circ = 0x7,
        Back = 0x8,
    };

    enum class ParticleModelType_t : std::uint32_t {
        PM_TYPE_INVALID = 0x0,
        PM_TYPE_NAMED_VALUE_MODEL = 0x1,
        PM_TYPE_NAMED_VALUE_EHANDLE = 0x2,
        PM_TYPE_CONTROL_POINT = 0x3,
        PM_TYPE_COUNT = 0x4,
    };

    enum class IKTargetSource : std::uint32_t {
        IKTARGETSOURCE_Bone = 0x0,
        IKTARGETSOURCE_AnimgraphParameter = 0x1,
        IKTARGETSOURCE_COUNT = 0x2,
    };

    enum class PermModelInfo_t_e : std::uint32_t {
        FLAG_TRANSLUCENT = 0x1,
        FLAG_TRANSLUCENT_TWO_PASS = 0x2,
        FLAG_MODEL_IS_RUNTIME_COMBINED = 0x4,
        FLAG_SOURCE1_IMPORT = 0x8,
        FLAG_MODEL_PART_CHILD = 0x10,
        FLAG_NAV_GEN_NONE = 0x20,
        FLAG_NAV_GEN_HULL = 0x40,
        FLAG_NO_FORCED_FADE = 0x800,
        FLAG_HAS_SKINNED_MESHES = 0x400,
        FLAG_DO_NOT_CAST_SHADOWS = 0x20000,
        FLAG_FORCE_PHONEME_CROSSFADE = 0x1000,
        FLAG_NO_ANIM_EVENTS = 0x100000,
        FLAG_ANIMATION_DRIVEN_FLEXES = 0x200000,
        FLAG_IMPLICIT_BIND_POSE_SEQUENCE = 0x400000,
        FLAG_MODEL_DOC = 0x800000,
    };

    enum class CNmFloatMathNode : std::uint8_t {
        Add = 0x0,
        Sub = 0x1,
        Mul = 0x2,
        Div = 0x3,
        Mod = 0x4,
        Abs = 0x5,
        Negate = 0x6,
        Floor = 0x7,
        Ceiling = 0x8,
        IntegerPart = 0x9,
        FractionalPart = 0xA,
        InverseFractionalPart = 0xB,
    };

    enum class CNmSyncEventIndexConditionNode : std::uint8_t {
        ExactlyAtEventIndex = 0x0,
        GreaterThanEqualToEventIndex = 0x1,
    };

    enum class ParticleFloatRoundType_t : std::int32_t {
        PF_ROUND_TYPE_INVALID = -1,
        PF_ROUND_TYPE_NEAREST = 0x0,
        PF_ROUND_TYPE_FLOOR = 0x1,
        PF_ROUND_TYPE_CEIL = 0x2,
        PF_ROUND_TYPE_COUNT = 0x3,
    };

    enum class PFNoiseType_t : std::uint32_t {
        PF_NOISE_TYPE_PERLIN = 0x0,
        PF_NOISE_TYPE_SIMPLEX = 0x1,
        PF_NOISE_TYPE_WORLEY = 0x2,
        PF_NOISE_TYPE_CURL = 0x3,
    };

    enum class ParticleDirectionNoiseType_t : std::uint32_t {
        PARTICLE_DIR_NOISE_PERLIN = 0x0,
        PARTICLE_DIR_NOISE_CURL = 0x1,
        PARTICLE_DIR_NOISE_WORLEY_BASIC = 0x2,
    };

    enum class AnimParamNetworkSetting : std::uint32_t {
        Auto = 0x0,
        AlwaysNetwork = 0x1,
        NeverNetwork = 0x2,
    };

    enum class MorphFlexControllerRemapType_t : std::uint32_t {
        MORPH_FLEXCONTROLLER_REMAP_PASSTHRU = 0x0,
        MORPH_FLEXCONTROLLER_REMAP_2WAY = 0x1,
        MORPH_FLEXCONTROLLER_REMAP_NWAY = 0x2,
        MORPH_FLEXCONTROLLER_REMAP_EYELID = 0x3,
    };

    enum class MeshDrawPrimitiveFlags_t : std::uint32_t {
        MESH_DRAW_FLAGS_NONE = 0x0,
        MESH_DRAW_FLAGS_USE_SHADOW_FAST_PATH = 0x1,
        MESH_DRAW_FLAGS_USE_COMPRESSED_NORMAL_TANGENT = 0x2,
        MESH_DRAW_INPUT_LAYOUT_IS_NOT_MATCHED_TO_MATERIAL = 0x8,
        MESH_DRAW_FLAGS_USE_COMPRESSED_PER_VERTEX_LIGHTING = 0x10,
        MESH_DRAW_FLAGS_USE_UNCOMPRESSED_PER_VERTEX_LIGHTING = 0x20,
        MESH_DRAW_FLAGS_CAN_BATCH_WITH_DYNAMIC_SHADER_CONSTANTS = 0x40,
        MESH_DRAW_FLAGS_DRAW_LAST = 0x80,
    };

    enum class TargetWarpAngleMode_t : std::uint32_t {
        eFacingHeading = 0x0,
        eMoveHeading = 0x1,
    };

    enum class NmIKBlendMode_t : std::uint8_t {
        Effector = 0x0,
        Pose = 0x1,
    };

    enum class ModelBoneFlexComponent_t : std::int32_t {
        MODEL_BONE_FLEX_INVALID = -1,
        MODEL_BONE_FLEX_TX = 0x0,
        MODEL_BONE_FLEX_TY = 0x1,
        MODEL_BONE_FLEX_TZ = 0x2,
    };

    enum class CNmStateNode : std::uint8_t {
        LessThanEqual = 0x0,
        GreaterThanEqual = 0x1,
    };

    enum class PoseType_t : std::uint8_t {
        POSETYPE_STATIC = 0x0,
        POSETYPE_DYNAMIC = 0x1,
        POSETYPE_INVALID = 0xFF,
    };

    enum class CNmRootMotionData_e : std::uint8_t {
        Delta = 0x0,
        WorldSpace = 0x1,
    };

    enum class NmEventConditionRules_t : std::uint8_t {
        LimitSearchToSourceState = 0x0,
        IgnoreInactiveEvents = 0x1,
        PreferHighestWeight = 0x2,
        PreferHighestProgress = 0x3,
        OperatorOr = 0x4,
        OperatorAnd = 0x5,
        SearchOnlyGraphEvents = 0x6,
        SearchOnlyAnimEvents = 0x7,
        SearchBothGraphAndAnimEvents = 0x8,
    };

    enum class AnimationType_t : std::uint32_t {
        ANIMATION_TYPE_FIXED_RATE = 0x0,
        ANIMATION_TYPE_FIT_LIFETIME = 0x1,
        ANIMATION_TYPE_MANUAL_FRAMES = 0x2,
    };

    enum class AnimValueSource : std::uint32_t {
        MoveHeading = 0x0,
        MoveSpeed = 0x1,
        ForwardSpeed = 0x2,
        StrafeSpeed = 0x3,
        FacingHeading = 0x4,
        LookHeading = 0x5,
        LookHeadingNormalized = 0x6,
        LookPitch = 0x7,
        LookDistance = 0x8,
        Parameter = 0x9,
        WayPointHeading = 0xA,
        WayPointDistance = 0xB,
        BoundaryRadius = 0xC,
        TargetMoveHeading = 0xD,
        TargetMoveSpeed = 0xE,
        AccelerationHeading = 0xF,
        AccelerationSpeed = 0x10,
        SlopeHeading = 0x11,
        SlopeAngle = 0x12,
        SlopePitch = 0x13,
        SlopeYaw = 0x14,
        GoalDistance = 0x15,
        AccelerationLeftRight = 0x16,
        AccelerationFrontBack = 0x17,
        RootMotionSpeed = 0x18,
        RootMotionTurnSpeed = 0x19,
        MoveHeadingRelativeToLookHeading = 0x1A,
        MaxMoveSpeed = 0x1B,
        FingerCurl_Thumb = 0x1C,
        FingerCurl_Index = 0x1D,
        FingerCurl_Middle = 0x1E,
        FingerCurl_Ring = 0x1F,
        FingerCurl_Pinky = 0x20,
        FingerSplay_Thumb_Index = 0x21,
        FingerSplay_Index_Middle = 0x22,
        FingerSplay_Middle_Ring = 0x23,
        FingerSplay_Ring_Pinky = 0x24,
    };

    enum class CNmTimeConditionNode : std::uint8_t {
        LessThan = 0x0,
        LessThanEqual = 0x1,
        GreaterThan = 0x2,
        GreaterThanEqual = 0x3,
    };

    enum class LinearRootMotionBlendMode_t : std::uint32_t {
        LERP = 0x0,
        NLERP = 0x1,
        SLERP = 0x2,
    };

    enum class RagdollPoseControl : std::uint32_t {
        Absolute = 0x0,
    };

    enum class IKSolverType : std::uint32_t {
        IKSOLVER_Perlin = 0x0,
        IKSOLVER_TwoBone = 0x1,
        IKSOLVER_Fabrik = 0x2,
        IKSOLVER_DogLeg3Bone = 0x3,
        IKSOLVER_CCD = 0x4,
        IKSOLVER_COUNT = 0x5,
    };

    enum class TargetWarpCorrectionMethod : std::uint32_t {
        ScaleMotion = 0x0,
        AddCorrectionDelta = 0x1,
    };

    enum class TargetSelectorAngleMode_t : std::uint32_t {
        eFacingHeading = 0x0,
        eMoveHeading = 0x1,
    };

    enum class Blend2DMode : std::uint32_t {
        Blend2DMode_General = 0x0,
        Blend2DMode_Directional = 0x1,
    };

    enum class PulseCursorExecResult_t : std::uint32_t {
        Succeeded = 0x0,
        Canceled = 0x1,
        Failed = 0x2,
        OngoingNotify = 0x3,
    };

    enum class HandshakeTagState_t : std::uint8_t {
        eInactive = 0x0,
        eActive = 0x1,
        eMomentarilyInactive = 0x2,
    };

    enum class ChoiceChangeMethod : std::uint32_t {
        OnReset = 0x0,
        OnCycleEnd = 0x1,
        OnResetOrCycleEnd = 0x2,
    };

    enum class ChoiceBlendMethod : std::uint32_t {
        SingleBlendTime = 0x0,
        PerChoiceBlendTimes = 0x1,
    };

    enum class VPhysXConstraintParams_t_e : std::uint32_t {
        FLAG0_SHIFT_INTERPENETRATE = 0x0,
        FLAG0_SHIFT_CONSTRAIN = 0x1,
        FLAG0_SHIFT_BREAKABLE_FORCE = 0x2,
        FLAG0_SHIFT_BREAKABLE_TORQUE = 0x3,
    };

    enum class ParticleFloatMapType_t : std::int32_t {
        PF_MAP_TYPE_INVALID = -1,
        PF_MAP_TYPE_DIRECT = 0x0,
        PF_MAP_TYPE_MULT = 0x1,
        PF_MAP_TYPE_REMAP = 0x2,
        PF_MAP_TYPE_REMAP_BIASED = 0x3,
        PF_MAP_TYPE_CURVE = 0x4,
        PF_MAP_TYPE_NOTCHED = 0x5,
        PF_MAP_TYPE_ROUND = 0x6,
        PF_MAP_TYPE_COUNT = 0x7,
    };

    enum class AnimParamVectorType_t : std::uint32_t {
        ANIMPARAM_VECTOR_TYPE_NONE = 0x0,
        ANIMPARAM_VECTOR_TYPE_POSITION_WS = 0x1,
        ANIMPARAM_VECTOR_TYPE_POSITION_LS = 0x2,
        ANIMPARAM_VECTOR_TYPE_DIRECTION_WS = 0x3,
        ANIMPARAM_VECTOR_TYPE_DIRECTION_LS = 0x4,
    };

    enum class CNmCurrentSyncEventNode : std::uint8_t {
        IndexAndPercentage = 0x0,
        IndexOnly = 0x1,
        PercentageOnly = 0x2,
    };

    enum class BlendKeyType : std::uint32_t {
        BlendKey_UserValue = 0x0,
        BlendKey_Velocity = 0x1,
        BlendKey_Distance = 0x2,
        BlendKey_RemainingDistance = 0x3,
    };

    enum class StateActionBehavior : std::uint32_t {
        STATETAGBEHAVIOR_ACTIVE_WHILE_CURRENT = 0x0,
        STATETAGBEHAVIOR_FIRE_ON_ENTER = 0x1,
        STATETAGBEHAVIOR_FIRE_ON_EXIT = 0x2,
        STATETAGBEHAVIOR_FIRE_ON_ENTER_AND_EXIT = 0x3,
        STATETAGBEHAVIOR_ACTIVE_WHILE_FULLY_BLENDED = 0x4,
    };

    enum class NmRootMotionBlendMode_t : std::uint8_t {
        Blend = 0x0,
        Additive = 0x1,
        IgnoreSource = 0x2,
        IgnoreTarget = 0x3,
    };

    enum class NmFootPhaseCondition_t : std::uint8_t {
        LeftFootDown = 0x0,
        LeftFootPassing = 0x1,
        LeftPhase = 0x4,
        RightFootDown = 0x2,
        RightFootPassing = 0x3,
        RightPhase = 0x5,
        None = 0x6,
    };

    enum class ModelSkeletonData_t_e : std::uint32_t {
        FLAG_NO_BONE_FLAGS = 0x0,
        FLAG_BONEFLEXDRIVER = 0x4,
        FLAG_CLOTH = 0x8,
        FLAG_PHYSICS = 0x10,
        FLAG_ATTACHMENT = 0x20,
        FLAG_ANIMATION = 0x40,
        FLAG_MESH = 0x80,
        FLAG_HITBOX = 0x100,
        FLAG_BONE_USED_BY_VERTEX_LOD0 = 0x400,
        FLAG_BONE_USED_BY_VERTEX_LOD1 = 0x800,
        FLAG_BONE_USED_BY_VERTEX_LOD2 = 0x1000,
        FLAG_BONE_USED_BY_VERTEX_LOD3 = 0x2000,
        FLAG_BONE_USED_BY_VERTEX_LOD4 = 0x4000,
        FLAG_BONE_USED_BY_VERTEX_LOD5 = 0x8000,
        FLAG_BONE_USED_BY_VERTEX_LOD6 = 0x10000,
        FLAG_BONE_USED_BY_VERTEX_LOD7 = 0x20000,
        FLAG_BONE_MERGE_READ = 0x40000,
        FLAG_BONE_MERGE_WRITE = 0x80000,
        FLAG_ALL_BONE_FLAGS = 0xFFFFF,
        BLEND_PREALIGNED = 0x100000,
        FLAG_RIGIDLENGTH = 0x200000,
        FLAG_PROCEDURAL = 0x400000,
    };

    enum class GPUParticleCollisionMode_t : std::uint32_t {
        PARTICLE_GPU_COLLISION_MODE_RT = 0x0,
        PARTICLE_GPU_COLLISION_MODE_DEPTH = 0x1,
        PARTICLE_GPU_COLLISION_MODE_HYBRID = 0x2,
    };

    enum class MorphBundleType_t : std::uint32_t {
        MORPH_BUNDLE_TYPE_NONE = 0x0,
        MORPH_BUNDLE_TYPE_POSITION_SPEED = 0x1,
        MORPH_BUNDLE_TYPE_NORMAL_WRINKLE = 0x2,
        MORPH_BUNDLE_TYPE_COUNT = 0x3,
    };

    enum class CNmIDComparisonNode : std::uint8_t {
        Matches = 0x0,
        DoesntMatch = 0x1,
    };

    enum class NmPoseBlendMode_t : std::uint8_t {
        Overlay = 0x0,
        Additive = 0x1,
        ModelSpace = 0x2,
    };

    enum class ParticleFloatInputMode_t : std::int32_t {
        PF_INPUT_MODE_INVALID = -1,
        PF_INPUT_MODE_CLAMPED = 0x0,
        PF_INPUT_MODE_LOOPED = 0x1,
        PF_INPUT_MODE_COUNT = 0x2,
    };

    enum class ResetCycleOption : std::uint32_t {
        Beginning = 0x0,
        SameCycleAsSource = 0x1,
        InverseSourceCycle = 0x2,
        FixedValue = 0x3,
        SameTimeAsSource = 0x4,
    };

    enum class CNmVectorInfoNode : std::uint8_t {
        X = 0x0,
        Y = 0x1,
        Z = 0x2,
        Length = 0x3,
        AngleHorizontal = 0x4,
        AngleVertical = 0x5,
    };

    enum class IKChannelMode : std::uint32_t {
        TwoBone = 0x0,
        TwoBone_Translate = 0x1,
        OneBone = 0x2,
        OneBone_Translate = 0x3,
    };

    enum class NmGraphValueType_t : std::uint8_t {
        Unknown = 0x0,
        Bool = 0x1,
        ID = 0x2,
        Float = 0x3,
        Vector = 0x4,
        Target = 0x5,
        BoneMask = 0x6,
        Pose = 0x7,
        Special = 0x8,
    };

    enum class ParticleFloatRandomMode_t : std::int32_t {
        PF_RANDOM_MODE_INVALID = -1,
        PF_RANDOM_MODE_CONSTANT = 0x0,
        PF_RANDOM_MODE_VARYING = 0x1,
        PF_RANDOM_MODE_COUNT = 0x2,
    };

    enum class PulseValueType_t : std::int32_t {
        PVAL_VOID = -1,
        PVAL_BOOL = 0x0,
        PVAL_INT = 0x1,
        PVAL_FLOAT = 0x2,
        PVAL_STRING = 0x3,
        PVAL_VEC2 = 0x4,
        PVAL_VEC3 = 0x5,
        PVAL_QANGLE = 0x6,
        PVAL_VEC3_WORLDSPACE = 0x7,
        PVAL_VEC4 = 0x8,
        PVAL_TRANSFORM = 0x9,
        PVAL_TRANSFORM_WORLDSPACE = 0xA,
        PVAL_COLOR_RGB = 0xB,
        PVAL_GAMETIME = 0xC,
        PVAL_EHANDLE = 0xD,
        PVAL_RESOURCE = 0xE,
        PVAL_RESOURCE_NAME = 0xF,
        PVAL_SNDEVT_GUID = 0x10,
        PVAL_SNDEVT_NAME = 0x11,
        PVAL_ENTITY_NAME = 0x12,
        PVAL_OPAQUE_HANDLE = 0x13,
        PVAL_TYPESAFE_INT = 0x14,
        PVAL_MODEL_MATERIAL_GROUP = 0x15,
        PVAL_CURSOR_FLOW = 0x16,
        PVAL_VARIANT = 0x17,
        PVAL_UNKNOWN = 0x18,
        PVAL_SCHEMA_ENUM = 0x19,
        PVAL_PANORAMA_PANEL_HANDLE = 0x1A,
        PVAL_TEST_HANDLE = 0x1B,
        PVAL_ARRAY = 0x1C,
        PVAL_TYPESAFE_INT64 = 0x1D,
        PVAL_PARTICLE_EHANDLE = 0x1E,
        PVAL_COUNT = 0x1F,
    };

    enum class PFNoiseModifier_t : std::uint32_t {
        PF_NOISE_MODIFIER_NONE = 0x0,
        PF_NOISE_MODIFIER_LINES = 0x1,
        PF_NOISE_MODIFIER_CLUMPS = 0x2,
        PF_NOISE_MODIFIER_RINGS = 0x3,
    };

    enum class ParticleVecType_t : std::int32_t {
        PVEC_TYPE_INVALID = -1,
        PVEC_TYPE_LITERAL = 0x0,
        PVEC_TYPE_LITERAL_COLOR = 0x1,
        PVEC_TYPE_NAMED_VALUE = 0x2,
        PVEC_TYPE_PARTICLE_VECTOR = 0x3,
        PVEC_TYPE_PARTICLE_INITIAL_VECTOR = 0x4,
        PVEC_TYPE_PARTICLE_VELOCITY = 0x5,
        PVEC_TYPE_PARTICLE_GRAVITY = 0x6,
        PVEC_TYPE_CP_VALUE = 0x7,
        PVEC_TYPE_CP_RELATIVE_POSITION = 0x8,
        PVEC_TYPE_CP_RELATIVE_DIR = 0x9,
        PVEC_TYPE_CP_RELATIVE_RANDOM_DIR = 0xA,
        PVEC_TYPE_FLOAT_COMPONENTS = 0xB,
        PVEC_TYPE_FLOAT_INTERP_CLAMPED = 0xC,
        PVEC_TYPE_FLOAT_INTERP_OPEN = 0xD,
        PVEC_TYPE_FLOAT_INTERP_GRADIENT = 0xE,
        PVEC_TYPE_RANDOM_UNIFORM = 0xF,
        PVEC_TYPE_RANDOM_UNIFORM_OFFSET = 0x10,
        PVEC_TYPE_CP_DELTA = 0x11,
        PVEC_TYPE_CLOSEST_CAMERA_POSITION = 0x12,
        PVEC_TYPE_COUNT = 0x13,
    };

    enum class NmFootPhase_t : std::uint8_t {
        LeftFootDown = 0x0,
        RightFootPassing = 0x1,
        RightFootDown = 0x2,
        LeftFootPassing = 0x3,
        None = 0x4,
    };

    enum class CNmTargetInfoNode : std::uint32_t {
        AngleHorizontal = 0x0,
        AngleVertical = 0x1,
        Distance = 0x2,
        DistanceHorizontalOnly = 0x3,
        DistanceVerticalOnly = 0x4,
        DeltaOrientationX = 0x5,
        DeltaOrientationY = 0x6,
        DeltaOrientationZ = 0x7,
    };

    enum class FootstepLandedFootSoundType_t : std::uint32_t {
        FOOTSOUND_Left = 0x0,
        FOOTSOUND_Right = 0x1,
        FOOTSOUND_UseOverrideSound = 0x2,
    };

    enum class FootLockSubVisualization : std::uint32_t {
        FOOTLOCKSUBVISUALIZATION_ReachabilityAnalysis = 0x0,
        FOOTLOCKSUBVISUALIZATION_IKSolve = 0x1,
    };

    enum class CNmSoundEvent_e : std::uint32_t {
        None = 0x0,
        World = 0x1,
        EntityPos = 0x2,
        EntityEyePos = 0x3,
        EntityAttachment = 0x4,
    };

    enum class FootstepJumpPhase_t : std::uint8_t {
        Unknown = 0x0,
        NotJumping = 0x1,
        Jumping = 0x2,
        Landing = 0x4,
    };

    enum class NmFrameSnapEventMode_t : std::uint32_t {
        Floor = 0x0,
        Round = 0x1,
    };

    enum class FootPinningTimingSource : std::uint32_t {
        FootMotion = 0x0,
        Tag = 0x1,
        Parameter = 0x2,
    };

    enum class DampingSpeedFunction : std::uint32_t {
        NoDamping = 0x0,
        Constant = 0x1,
        Spring = 0x2,
        AsymmetricSpring = 0x3,
    };

    enum class PulseApiFeature_t : std::uint32_t {
        AF_NONE = 0x0,
        AF_ENTITIES = 0x1,
        AF_PANORAMA = 0x2,
        AF_PARTICLES = 0x8,
        AF_FAKE_ENTITIES = 0x10,
        AF_SELECTORS_WITHOUT_REQUIREMENTS = 0x20,
    };

    enum class AnimationProcessingType_t : std::uint32_t {
        ANIMATION_PROCESSING_SERVER_SIMULATION = 0x0,
        ANIMATION_PROCESSING_CLIENT_SIMULATION = 0x1,
        ANIMATION_PROCESSING_CLIENT_PREDICTION = 0x2,
        ANIMATION_PROCESSING_CLIENT_INTERPOLATION = 0x3,
        ANIMATION_PROCESSING_CLIENT_RENDER = 0x4,
        ANIMATION_PROCESSING_MAX = 0x5,
    };

    enum class JiggleBoneSimSpace : std::uint32_t {
        SimSpace_Local = 0x0,
        SimSpace_Model = 0x1,
        SimSpace_World = 0x2,
    };

    enum class StanceOverrideMode : std::uint32_t {
        Sequence = 0x0,
        Node = 0x1,
    };

    enum class IkEndEffectorType : std::uint32_t {
        IkEndEffector_Attachment = 0x0,
        IkEndEffector_Bone = 0x1,
    };

    enum class AnimScriptType : std::int16_t {
        ANIMSCRIPT_TYPE_INVALID = -1,
        ANIMSCRIPT_FUSE_GENERAL = 0x0,
        ANIMSCRIPT_FUSE_STATEMACHINE = 0x1,
    };

    enum class CNmTimeConditionNode_2 : std::uint8_t {
        PercentageThroughState = 0x0,
        PercentageThroughSyncEvent = 0x1,
        ElapsedTime = 0x2,
    };

    enum class SeqPoseSetting_t : std::uint32_t {
        SEQ_POSE_SETTING_CONSTANT = 0x0,
        SEQ_POSE_SETTING_ROTATION = 0x1,
        SEQ_POSE_SETTING_POSITION = 0x2,
        SEQ_POSE_SETTING_VELOCITY = 0x3,
    };

    enum class AnimParamButton_t : std::uint32_t {
        ANIMPARAM_BUTTON_NONE = 0x0,
        ANIMPARAM_BUTTON_DPAD_UP = 0x1,
        ANIMPARAM_BUTTON_DPAD_RIGHT = 0x2,
        ANIMPARAM_BUTTON_DPAD_DOWN = 0x3,
        ANIMPARAM_BUTTON_DPAD_LEFT = 0x4,
        ANIMPARAM_BUTTON_A = 0x5,
        ANIMPARAM_BUTTON_B = 0x6,
        ANIMPARAM_BUTTON_X = 0x7,
        ANIMPARAM_BUTTON_Y = 0x8,
        ANIMPARAM_BUTTON_LEFT_SHOULDER = 0x9,
        ANIMPARAM_BUTTON_RIGHT_SHOULDER = 0xA,
        ANIMPARAM_BUTTON_LTRIGGER = 0xB,
        ANIMPARAM_BUTTON_RTRIGGER = 0xC,
    };

    enum class SelectorTagBehavior_t : std::uint32_t {
        SelectorTagBehavior_OnWhileCurrent = 0x0,
        SelectorTagBehavior_OffWhenFinished = 0x1,
        SelectorTagBehavior_OffBeforeFinished = 0x2,
    };

    enum class HandshakeTagType_t : std::int32_t {
        eInvalid = -1,
        eTask = 0x0,
        eMovement = 0x1,
        eCount = 0x2,
    };

    enum class OrientationWarpTargetOffsetMode_t : std::uint32_t {
        eLiteralValue = 0x0,
        eParameter = 0x1,
        eAnimationMovementHeading = 0x2,
        eAnimationMovementHeadingAtEnd = 0x3,
    };

    enum class OrientationWarpMode_t : std::uint32_t {
        eInvalid = 0x0,
        eAngle = 0x1,
        eWorldPosition = 0x2,
    };

    enum class PulseInstructionCode_t : std::uint16_t {
        INVALID = 0x0,
        IMMEDIATE_HALT = 0x1,
        RETURN_VOID = 0x2,
        RETURN_VALUE = 0x3,
        NOP = 0x4,
        JUMP = 0x5,
        JUMP_COND = 0x6,
        CHUNK_LEAP = 0x7,
        CHUNK_LEAP_COND = 0x8,
        PULSE_CALL_SYNC = 0x9,
        PULSE_CALL_ASYNC_FIRE = 0xA,
        CELL_INVOKE = 0xB,
        LIBRARY_INVOKE = 0xC,
        SET_VAR = 0xD,
        GET_VAR = 0xE,
        GET_VAR_DETACH = 0xF,
        DETACH_REGISTER = 0x10,
        SET_VAR_ARRAY_ELEMENT_1D = 0x11,
        SET_VAR_OBSERVABLE = 0x12,
        GET_CONST = 0x13,
        GET_ARRAY_ELEMENT = 0x14,
        GET_DOMAIN_VALUE = 0x15,
        COPY = 0x16,
        NOT = 0x17,
        NEGATE = 0x18,
        ADD = 0x19,
        SUB = 0x1A,
        MUL = 0x1B,
        DIV = 0x1C,
        MOD = 0x1D,
        LT = 0x1E,
        LTE = 0x1F,
        EQ = 0x20,
        NE = 0x21,
        AND = 0x22,
        OR = 0x23,
        SCALE = 0x24,
        SCALE_INV = 0x25,
        ELEMENT_ACCESS = 0x26,
        CONVERT_VALUE = 0x27,
        REINTERPRET_INSTANCE = 0x28,
        GET_BLACKBOARD_REFERENCE = 0x29,
        SET_BLACKBOARD_REFERENCE = 0x2A,
        LAST_SERIALIZED_CODE = 0x2B,
        NEGATE_INT = 0x2C,
        NEGATE_FLOAT = 0x2D,
        NEGATE_VEC2 = 0x2E,
        NEGATE_VEC3 = 0x2F,
        NEGATE_VEC4 = 0x30,
        ADD_INT = 0x31,
        ADD_FLOAT = 0x32,
        ADD_STRING = 0x33,
        ADD_VEC2 = 0x34,
        ADD_VEC3 = 0x35,
        ADD_VEC3WS_VEC3 = 0x36,
        ADD_VEC3_VEC3WS = 0x37,
        ADD_VEC4 = 0x38,
        ADD_GAMETIME_FLOAT = 0x39,
        ADD_FLOAT_GAMETIME = 0x3A,
        SUB_INT = 0x3B,
        SUB_FLOAT = 0x3C,
        SUB_VEC2 = 0x3D,
        SUB_VEC3 = 0x3E,
        SUB_VEC3WS_VEC3 = 0x3F,
        SUB_VEC3WS_VEC3WS = 0x40,
        SUB_VEC4 = 0x41,
        SUB_GAMETIME_FLOAT = 0x42,
        SUB_GAMETIME = 0x43,
        MUL_INT = 0x44,
        MUL_FLOAT = 0x45,
        DIV_FLOAT = 0x46,
        MOD_INT = 0x47,
        MOD_FLOAT = 0x48,
        LT_INT = 0x49,
        LT_FLOAT = 0x4A,
        LT_GAMETIME = 0x4B,
        LTE_INT = 0x4C,
        LTE_FLOAT = 0x4D,
        LTE_GAMETIME = 0x4E,
        EQ_BOOL = 0x4F,
        EQ_INT = 0x50,
        EQ_FLOAT = 0x51,
        EQ_VEC2 = 0x52,
        EQ_VEC3 = 0x53,
        EQ_VEC3WS = 0x54,
        EQ_VEC4 = 0x55,
        EQ_STRING = 0x56,
        EQ_ENTITY_NAME = 0x57,
        EQ_SCHEMA_ENUM = 0x58,
        EQ_EHANDLE = 0x59,
        EQ_PANEL_HANDLE = 0x5A,
        EQ_OPAQUE_HANDLE = 0x5B,
        EQ_TEST_HANDLE = 0x5C,
        EQ_COLOR_RGB = 0x5D,
        EQ_ARRAY = 0x5E,
        EQ_GAMETIME = 0x5F,
        NE_BOOL = 0x60,
        NE_INT = 0x61,
        NE_FLOAT = 0x62,
        NE_VEC2 = 0x63,
        NE_VEC3 = 0x64,
        NE_VEC3WS = 0x65,
        NE_VEC4 = 0x66,
        NE_STRING = 0x67,
        NE_ENTITY_NAME = 0x68,
        NE_SCHEMA_ENUM = 0x69,
        NE_EHANDLE = 0x6A,
        NE_PANEL_HANDLE = 0x6B,
        NE_OPAQUE_HANDLE = 0x6C,
        NE_TEST_HANDLE = 0x6D,
        NE_COLOR_RGB = 0x6E,
        NE_ARRAY = 0x6F,
        NE_GAMETIME = 0x70,
        SCALE_VEC3 = 0x71,
        SCALE_VEC2 = 0x72,
        SCALE_VEC4 = 0x73,
        SCALE_INV_VEC3 = 0x74,
        SCALE_INV_VEC2 = 0x75,
        SCALE_INV_VEC4 = 0x76,
        ELEMENT_ACCESS_VEC2 = 0x77,
        ELEMENT_ACCESS_VEC3 = 0x78,
        ELEMENT_ACCESS_VEC3WS = 0x79,
        ELEMENT_ACCESS_VEC4 = 0x7A,
        ELEMENT_ACCESS_COLOR_RGB = 0x7B,
        GET_CONST_INLINE_STORAGE = 0x7C,
    };

    enum class ParticleTransformType_t : std::uint32_t {
        PT_TYPE_INVALID = 0x0,
        PT_TYPE_NAMED_VALUE = 0x1,
        PT_TYPE_CONTROL_POINT = 0x2,
        PT_TYPE_CONTROL_POINT_RANGE = 0x3,
        PT_TYPE_COUNT = 0x4,
    };

    enum class ParticleAttachment_t : std::int32_t {
        PATTACH_INVALID = -1,
        PATTACH_ABSORIGIN = 0x0,
        PATTACH_ABSORIGIN_FOLLOW = 0x1,
        PATTACH_CUSTOMORIGIN = 0x2,
        PATTACH_CUSTOMORIGIN_FOLLOW = 0x3,
        PATTACH_POINT = 0x4,
        PATTACH_POINT_FOLLOW = 0x5,
        PATTACH_EYES_FOLLOW = 0x6,
        PATTACH_OVERHEAD_FOLLOW = 0x7,
        PATTACH_WORLDORIGIN = 0x8,
        PATTACH_ROOTBONE_FOLLOW = 0x9,
        PATTACH_RENDERORIGIN_FOLLOW = 0xA,
        PATTACH_MAIN_VIEW = 0xB,
        PATTACH_WATERWAKE = 0xC,
        PATTACH_CENTER_FOLLOW = 0xD,
        PATTACH_CUSTOM_GAME_STATE_1 = 0xE,
        PATTACH_HEALTHBAR = 0xF,
        MAX_PATTACH_TYPES = 0x10,
    };

    enum class CNmEventTargetEntity_t : std::uint32_t {
        Self = 0x0,
        Weapon = 0x1,
        HeldItem = 0x2,
        Custom = 0x3,
    };

    enum class FieldNetworkOption : std::uint32_t {
        Auto = 0x0,
        ForceEnable = 0x1,
        ForceDisable = 0x2,
    };

    enum class NmGraphEventTypeCondition_t : std::uint8_t {
        Entry = 0x0,
        FullyInState = 0x1,
        Exit = 0x2,
        Timed = 0x3,
        Generic = 0x4,
        Any = 0x5,
    };

    enum class CNmTransitionNode : std::uint8_t {
        None = 0x0,
        ClampDuration = 0x1,
        Synchronized = 0x2,
        MatchSourceTime = 0x3,
        MatchSyncEventIndex = 0x4,
        MatchSyncEventID = 0x5,
        MatchSyncEventPercentage = 0x6,
        PreferClosestSyncEventID = 0x7,
        MatchTimeInSeconds = 0x8,
        OffsetTimeInSeconds = 0x9,
    };

    enum class CNmFloatComparisonNode : std::uint8_t {
        GreaterThanEqual = 0x0,
        LessThanEqual = 0x1,
        NearEqual = 0x2,
        GreaterThan = 0x3,
        LessThan = 0x4,
    };

    enum class VPhysXJoint_t_e : std::uint32_t {
        JOINT_FLAGS_NONE = 0x0,
        JOINT_FLAGS_BODY1_FIXED = 0x1,
        JOINT_FLAGS_USE_BLOCK_SOLVER = 0x2,
    };

    enum class ScriptedHeldWeaponBehavior_t : std::int32_t {
        eInvalid = -1,
        eHolster = 0x0,
        eDeploy = 0x1,
        eDrop = 0x2,
    };

    enum class VelocityMetricMode : std::uint8_t {
        DirectionOnly = 0x0,
        MagnitudeOnly = 0x1,
        DirectionAndMagnitude = 0x2,
    };

    enum class FacingMode : std::uint8_t {
        FacingMode_Invalid = 0x0,
        FacingMode_Manual = 0x1,
        FacingMode_Path = 0x2,
        FacingMode_LookTarget = 0x3,
        FacingMode_ManualPosition = 0x4,
    };

    enum class VertexAlbedoFormat_t : std::uint8_t {
        VERTEX_ALBEDO_NONE = 0x0,
        VERTEX_ALBEDO_8888 = 0x1,
        VERTEX_ALBEDO_565 = 0x2,
    };

    enum class AimMatrixBlendMode : std::uint32_t {
        AimMatrixBlendMode_None = 0x0,
        AimMatrixBlendMode_Additive = 0x1,
        AimMatrixBlendMode_ModelSpaceAdditive = 0x2,
        AimMatrixBlendMode_BoneMask = 0x3,
    };

    enum class AnimationSnapshotType_t : std::uint32_t {
        ANIMATION_SNAPSHOT_SERVER_SIMULATION = 0x0,
        ANIMATION_SNAPSHOT_CLIENT_SIMULATION = 0x1,
        ANIMATION_SNAPSHOT_CLIENT_PREDICTION = 0x2,
        ANIMATION_SNAPSHOT_CLIENT_INTERPOLATION = 0x3,
        ANIMATION_SNAPSHOT_CLIENT_RENDER = 0x4,
        ANIMATION_SNAPSHOT_FINAL_COMPOSITE = 0x5,
        ANIMATION_SNAPSHOT_MAX = 0x6,
    };

    enum class NmTargetWarpRule_t : std::uint8_t {
        WarpXY = 0x0,
        WarpZ = 0x1,
        WarpXYZ = 0x2,
        RotationOnly = 0x3,
        FixedSection = 0x4,
    };

    enum class FootFallTagFoot_t : std::uint32_t {
        FOOT1 = 0x0,
        FOOT2 = 0x1,
        FOOT3 = 0x2,
        FOOT4 = 0x3,
        FOOT5 = 0x4,
        FOOT6 = 0x5,
        FOOT7 = 0x6,
        FOOT8 = 0x7,
    };

    enum class ChoiceMethod : std::uint32_t {
        WeightedRandom = 0x0,
        WeightedRandomNoRepeat = 0x1,
        Iterate = 0x2,
        IterateRandom = 0x3,
    };

    enum class AnimVectorSource : std::uint32_t {
        MoveDirection = 0x0,
        FacingPosition = 0x1,
        LookDirection = 0x2,
        VectorParameter = 0x3,
        WayPointDirection = 0x4,
        Acceleration = 0x5,
        SlopeNormal = 0x6,
        SlopeNormal_WorldSpace = 0x7,
        LookTarget = 0x8,
        LookTarget_WorldSpace = 0x9,
        WayPointPosition = 0xA,
        GoalPosition = 0xB,
        RootMotionVelocity = 0xC,
        ManualTarget_WorldSpace = 0xD,
    };

    enum class IkTargetType : std::uint32_t {
        IkTarget_Attachment = 0x0,
        IkTarget_Bone = 0x1,
        IkTarget_Parameter_ModelSpace = 0x2,
        IkTarget_Parameter_WorldSpace = 0x3,
    };

    enum class RenderMeshSlotType_t : std::int8_t {
        RENDERMESH_SLOT_INVALID = -1,
        RENDERMESH_SLOT_PER_VERTEX = 0x0,
        RENDERMESH_SLOT_PER_INSTANCE = 0x1,
    };

    enum class BoneMaskBlendSpace : std::uint32_t {
        BlendSpace_Parent = 0x0,
        BlendSpace_Model = 0x1,
        BlendSpace_Model_RotationOnly = 0x2,
        BlendSpace_Model_TranslationOnly = 0x3,
    };

    enum class MovementCapability_t : std::uint32_t {
        eStrafe = 0x0,
        eIdleTurn = 0x1,
        eStart = 0x2,
        eStop = 0x3,
        eInstantStop = 0x4,
        eShuffle = 0x5,
        ePlantedTurn = 0x6,
        eUseStartAsPlantedTurn = 0x7,
        eLean = 0x8,
        eCount = 0x9,
    };

    enum class ModelConfigAttachmentType_t : std::int32_t {
        MODEL_CONFIG_ATTACHMENT_INVALID = -1,
        MODEL_CONFIG_ATTACHMENT_BONE_OR_ATTACHMENT = 0x0,
        MODEL_CONFIG_ATTACHMENT_ROOT_RELATIVE = 0x1,
        MODEL_CONFIG_ATTACHMENT_BONEMERGE = 0x2,
        MODEL_CONFIG_ATTACHMENT_COUNT = 0x3,
    };

    enum class BinaryNodeChildOption : std::uint32_t {
        Child1 = 0x0,
        Child2 = 0x1,
    };

    enum class NPCPhysicsHullType_t : std::uint32_t {
        eInvalid = 0x0,
        eGroundCapsule = 0x1,
        eCenteredCapsule = 0x2,
        eGenericCapsule = 0x3,
        eGroundBox = 0x4,
    };

    enum class PulseDomainValueType_t : std::int32_t {
        INVALID = -1,
        ENTITY_NAME = 0x0,
        PANEL_ID = 0x1,
        COUNT = 0x2,
    };

    enum class JumpCorrectionMethod : std::uint32_t {
        ScaleMotion = 0x0,
        AddCorrectionDelta = 0x1,
    };

    enum class MoodType_t : std::uint32_t {
        eMoodType_Head = 0x0,
        eMoodType_Body = 0x1,
    };

    class CPulse_RegisterInfo {
    public:
        SCHEMA_FIELD(PulseRuntimeRegisterIndex_t     , m_nReg                                          , 0x0)
        SCHEMA_FIELD(CPulseValueFullType             , m_Type                                          , 0x8)
        SCHEMA_FIELD(CKV3MemberNameWithStorage       , m_OriginName                                    , 0x20)
        SCHEMA_FIELD(std::int32_t                    , m_nWrittenByInstruction                         , 0x58)
        SCHEMA_FIELD(std::int32_t                    , m_nLastReadByInstruction                        , 0x5C)
    };

    class CNmClip {
    public:
        using _Type0 = CUtlVectorFixedGrowable<CNmClip*,1>;
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeCNmSkeleton>, m_skeleton                                      , 0x0)
        SCHEMA_FIELD(std::uint32_t                   , m_nNumFrames                                    , 0x8)
        SCHEMA_FIELD(float                           , m_flDuration                                    , 0xC)
        SCHEMA_FIELD(::CUtlBinaryBlock               , m_compressedPoseData                            , 0x10)
        SCHEMA_FIELD(CUtlVector<NmCompressionSettings_t>, m_trackCompressionSettings                      , 0x20)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_compressedPoseOffsets                         , 0x38)
        SCHEMA_FIELD(CUtlVector<CGlobalSymbol>       , m_floatCurveIDs                                 , 0x50)
        SCHEMA_FIELD(CUtlVector<NmFloatCurveCompressionSettings_t>, m_floatCurveDefs                                , 0x68)
        SCHEMA_FIELD(CUtlVector<uint16>              , m_compressedFloatCurveData                      , 0x80)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_compressedFloatCurveOffsets                   , 0x98)
        SCHEMA_FIELD(_Type0                          , m_secondaryAnimations                           , 0xD8)
        SCHEMA_FIELD(CNmSyncTrack                    , m_syncTrack                                     , 0xF8)
        SCHEMA_FIELD(CNmRootMotionData               , m_rootMotion                                    , 0x1B0)
        SCHEMA_FIELD(bool                            , m_bIsAdditive                                   , 0x200)
        SCHEMA_FIELD(CUtlVector<CNmClip_ModelSpaceSamplingChainLink_t>, m_modelSpaceSamplingChain                       , 0x208)
        SCHEMA_FIELD(CUtlVector<int32>               , m_modelSpaceBoneSamplingIndices                 , 0x220)
    };

    class CSolveIKChainUpdateNode {
    public:
        SCHEMA_FIELD(CUtlVector<CSolveIKTargetHandle_t>, m_targetHandles                                 , 0x70)
        SCHEMA_FIELD(SolveIKChainPoseOpFixedSettings_t, m_opFixedData                                   , 0x88)
    };

    class CPulseCell_BaseFlow {
    public:
    };

    class CNmConstFloatNode_CDefinition {
    public:
        SCHEMA_FIELD(float                           , m_flValue                                       , 0x10)
    };

    class SkeletonAnimCapture_t_Bone_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_Name                                          , 0x0)
        SCHEMA_FIELD(CTransform                      , m_BindPose                                      , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nParent                                       , 0x30)
    };

    class CPulse_OutputConnection {
    public:
        SCHEMA_FIELD(::PulseSymbol_t                 , m_SourceOutput                                  , 0x0)
        SCHEMA_FIELD(::PulseSymbol_t                 , m_TargetEntity                                  , 0x10)
        SCHEMA_FIELD(::PulseSymbol_t                 , m_TargetInput                                   , 0x20)
        SCHEMA_FIELD(::PulseSymbol_t                 , m_Param                                         , 0x30)
    };

    class CNmIDEvent {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_ID                                            , 0x18)
        SCHEMA_FIELD(CGlobalSymbol                   , m_secondaryID                                   , 0x20)
    };

    class CNmCachedPoseWriteTask {
    public:
    };

    class CPulseCell_Inflow_ObservableVariableListener {
    public:
        SCHEMA_FIELD(PulseRuntimeBlackboardReferenceIndex_t, m_nBlackboardReference                          , 0x80)
        SCHEMA_FIELD(bool                            , m_bSelfReference                                , 0x82)
    };

    class CBoolAnimParameter {
    public:
        SCHEMA_FIELD(bool                            , m_bDefaultValue                                 , 0x80)
    };

    class CNmModelSpaceBlendTask {
    public:
    };

    class TraceSettings_t {
    public:
        SCHEMA_FIELD(float                           , m_flTraceHeight                                 , 0x0)
        SCHEMA_FIELD(float                           , m_flTraceRadius                                 , 0x4)
    };

    class CBodyGroupAnimTag {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nPriority                                     , 0x58)
        SCHEMA_FIELD(CUtlVector<CBodyGroupSetting>   , m_bodyGroupSettings                             , 0x60)
    };

    class CPulseCell_IsRequirementValid_Criteria_t {
    public:
        SCHEMA_FIELD(bool                            , m_bIsValid                                      , 0x0)
    };

    class CPhysSurfacePropertiesPhysics {
    public:
        SCHEMA_FIELD(float                           , m_friction                                      , 0x0)
        SCHEMA_FIELD(float                           , m_elasticity                                    , 0x4)
        SCHEMA_FIELD(float                           , m_density                                       , 0x8)
        SCHEMA_FIELD(float                           , m_thickness                                     , 0xC)
        SCHEMA_FIELD(float                           , m_softContactFrequency                          , 0x10)
        SCHEMA_FIELD(float                           , m_softContactDampingRatio                       , 0x14)
    };

    class CFutureVelocityMetricEvaluator {
    public:
        SCHEMA_FIELD(float                           , m_flDistance                                    , 0x50)
        SCHEMA_FIELD(float                           , m_flStoppingDistance                            , 0x54)
        SCHEMA_FIELD(float                           , m_flTargetSpeed                                 , 0x58)
        SCHEMA_FIELD(VelocityMetricMode              , m_eMode                                         , 0x5C)
    };

    class CAnimDesc_Flag {
    public:
        SCHEMA_FIELD(bool                            , m_bLooping                                      , 0x0)
        SCHEMA_FIELD(bool                            , m_bAllZeros                                     , 0x1)
        SCHEMA_FIELD(bool                            , m_bHidden                                       , 0x2)
        SCHEMA_FIELD(bool                            , m_bDelta                                        , 0x3)
        SCHEMA_FIELD(bool                            , m_bLegacyWorldspace                             , 0x4)
        SCHEMA_FIELD(bool                            , m_bModelDoc                                     , 0x5)
        SCHEMA_FIELD(bool                            , m_bImplicitSeqIgnoreDelta                       , 0x6)
        SCHEMA_FIELD(bool                            , m_bAnimGraphAdditive                            , 0x7)
    };

    class CSequenceTagSpans {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_sSequenceName                                 , 0x0)
        SCHEMA_FIELD(CUtlVector<TagSpan_t>           , m_tags                                          , 0x8)
    };

    class PulseRegisterMap_t {
    public:
        SCHEMA_FIELD(KeyValues3                      , m_Inparams                                      , 0x0)
        SCHEMA_FIELD(CKV3MemberNameSet               , m_InparamsWhichCanBeMoved                       , 0x10)
        SCHEMA_FIELD(KeyValues3                      , m_Outparams                                     , 0x20)
    };

    class CMorphBundleData {
    public:
        SCHEMA_FIELD(float                           , m_flULeftSrc                                    , 0x0)
        SCHEMA_FIELD(float                           , m_flVTopSrc                                     , 0x4)
        SCHEMA_FIELD(CUtlVector<float32>             , m_offsets                                       , 0x8)
        SCHEMA_FIELD(CUtlVector<float32>             , m_ranges                                        , 0x20)
    };

    class CRemapValueUpdateItem {
    public:
        SCHEMA_FIELD(CAnimParamHandle                , m_hParamIn                                      , 0x0)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParamOut                                     , 0x2)
        SCHEMA_FIELD(float                           , m_flMinInputValue                               , 0x4)
        SCHEMA_FIELD(float                           , m_flMaxInputValue                               , 0x8)
        SCHEMA_FIELD(float                           , m_flMinOutputValue                              , 0xC)
        SCHEMA_FIELD(float                           , m_flMaxOutputValue                              , 0x10)
    };

    class CModelConfigElement_RandomPick {
    public:
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_Choices                                       , 0x48)
        SCHEMA_FIELD(CUtlVector<float32>             , m_ChoiceWeights                                 , 0x60)
    };

    class DynamicMeshDeformParams_t {
    public:
        SCHEMA_FIELD(float                           , m_flTensionCompressScale                        , 0x0)
        SCHEMA_FIELD(float                           , m_flTensionStretchScale                         , 0x4)
        SCHEMA_FIELD(bool                            , m_bRecomputeSmoothNormalsAfterAnimation         , 0x8)
        SCHEMA_FIELD(bool                            , m_bComputeDynamicMeshTensionAfterAnimation      , 0x9)
        SCHEMA_FIELD(bool                            , m_bSmoothNormalsAcrossUvSeams                   , 0xA)
        SCHEMA_FIELD(bool                            , m_bEnableEyeBulgeDeformation                    , 0xB)
    };

    class StanceInfo_t {
    public:
        SCHEMA_FIELD(::Vector                        , m_vPosition                                     , 0x0)
        SCHEMA_FIELD(float                           , m_flDirection                                   , 0xC)
    };

    class CBlendNodeInstanceData {
    public:
        SCHEMA_FIELD(float                           , m_dampedValue                                   , 0x0)
        SCHEMA_FIELD(float                           , m_flCycle                                       , 0x4)
        SCHEMA_FIELD(float                           , m_flCycleZeroTime                               , 0x8)
        SCHEMA_FIELD(float                           , m_flPlaybackRate                                , 0xC)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flBlendValue                                  , 0x10)
        SCHEMA_FIELD(float                           , m_flDuration                                    , 0x1C)
        SCHEMA_FIELD(CAnimNetVar<uint8>              , m_resetCount                                    , 0x20)
    };

    class OutflowWithRequirements_t {
    public:
        SCHEMA_FIELD(CPulse_OutflowConnection        , m_Connection                                    , 0x0)
        SCHEMA_FIELD(::PulseDocNodeID_t              , m_DestinationFlowNodeID                         , 0x48)
        SCHEMA_FIELD(CUtlVector<PulseDocNodeID_t>    , m_RequirementNodeIDs                            , 0x50)
        SCHEMA_FIELD(CUtlVector<int32>               , m_nCursorStateBlockIndex                        , 0x68)
    };

    class CBasePulseGraphInstance {
    public:
    };

    class CInputStreamUpdateNode {
    public:
    };

    class CBlend2DInstanceData {
    public:
        SCHEMA_FIELD(::Vector2D                      , m_dampedValue                                   , 0x8)
        SCHEMA_FIELD(float                           , m_flCycle                                       , 0x44)
        SCHEMA_FIELD(float                           , m_flPrevCycle                                   , 0x48)
    };

    class CNmIsExternalPoseSetNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nExternalPoseNodeIdx                          , 0x10)
    };

    class CSeqAutoLayer {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nLocalReference                               , 0x0)
        SCHEMA_FIELD(std::int16_t                    , m_nLocalPose                                    , 0x2)
        SCHEMA_FIELD(CSeqAutoLayerFlag               , m_flags                                         , 0x4)
        SCHEMA_FIELD(float                           , m_start                                         , 0xC)
        SCHEMA_FIELD(float                           , m_peak                                          , 0x10)
        SCHEMA_FIELD(float                           , m_tail                                          , 0x14)
        SCHEMA_FIELD(float                           , m_end                                           , 0x18)
    };

    class CNmOrNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,4>;
        SCHEMA_FIELD(_Type0                          , m_conditionNodeIndices                          , 0x10)
    };

    class LookAtBone_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_index                                         , 0x0)
        SCHEMA_FIELD(float                           , m_weight                                        , 0x4)
    };

    class CFootAdjustmentInstanceData {
    public:
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flStartTime                                   , 0xC)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flDuration                                    , 0x18)
        SCHEMA_FIELD(float                           , m_flStartHeadingWS                              , 0x3C)
    };

    class PulseGraphExecutionHistoryCursorDesc_t {
    public:
        SCHEMA_FIELD(CUtlVector<PulseCursorID_t>     , vecAncestorCursorIDs                            , 0x0)
        SCHEMA_FIELD(::PulseDocNodeID_t              , nSpawnNodeID                                    , 0x18)
        SCHEMA_FIELD(::PulseDocNodeID_t              , nRetiredAtNodeID                                , 0x1C)
        SCHEMA_FIELD(float                           , flLastReferenced                                , 0x20)
        SCHEMA_FIELD(std::int32_t                    , nLastValidEntryIdx                              , 0x24)
        SCHEMA_FIELD(bool                            , bWasAnObservableComputation                     , 0x28)
    };

    class CMotionGraphConfig {
    public:
        SCHEMA_FIELD(float                           , m_paramValues                                   , 0x0)
        SCHEMA_FIELD(float                           , m_flDuration                                    , 0x10)
        SCHEMA_FIELD(MotionIndex                     , m_nMotionIndex                                  , 0x14)
        SCHEMA_FIELD(std::int32_t                    , m_nSampleStart                                  , 0x18)
        SCHEMA_FIELD(std::int32_t                    , m_nSampleCount                                  , 0x1C)
    };

    class CMotionGraphUpdateNode {
    public:
        SCHEMA_FIELD(CSmartPtr<CMotionGraph>         , m_pMotionGraph                                  , 0x58)
    };

    class VPhysXRange_t {
    public:
        SCHEMA_FIELD(float                           , m_flMin                                         , 0x0)
        SCHEMA_FIELD(float                           , m_flMax                                         , 0x4)
    };

    class CEditableMotionGraph {
    public:
    };

    class CDampedValueComponentUpdater {
    public:
        SCHEMA_FIELD(CUtlVector<CDampedValueUpdateItem>, m_items                                         , 0x30)
    };

    class CNmTwoBoneIKTask {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nEffectorBoneIdx                              , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_nEffectorTargetBoneIdx                        , 0x4C)
        SCHEMA_FIELD(CTransform                      , m_targetTransform                               , 0x50)
        SCHEMA_FIELD(CNmTarget                       , m_effectorTarget                                , 0x70)
        SCHEMA_FIELD(NmIKBlendMode_t                 , m_blendMode                                     , 0xA0)
        SCHEMA_FIELD(float                           , m_flBlendWeight                                 , 0xA4)
        SCHEMA_FIELD(bool                            , m_bIsTargetInWorldSpace                         , 0xA8)
        SCHEMA_FIELD(bool                            , m_bIsRunningFromDeserializedData                , 0xA9)
        SCHEMA_FIELD(float                           , m_flChainRotationWeight                         , 0xAC)
        SCHEMA_FIELD(CGlobalSymbol                   , m_debugEffectorBoneID                           , 0xB0)
    };

    class CNmBoneMaskBlendNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nSourceMaskNodeIdx                            , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nTargetMaskNodeIdx                            , 0x12)
        SCHEMA_FIELD(std::int16_t                    , m_nBlendWeightValueNodeIdx                      , 0x14)
    };

    class CMorphData {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(CUtlVector<CMorphRectData>      , m_morphRectDatas                                , 0x8)
    };

    class CPulseCell_BaseRequirement {
    public:
    };

    class CNmFloatAngleMathNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(CNmFloatAngleMathNode_Operation_t, m_operation                                     , 0x12)
    };

    class CTaskHandshakeAnimTag {
    public:
    };

    class CNmVelocityBasedSpeedScaleNode_CDefinition {
    public:
    };

    class CPlayerInputAnimMotorUpdater {
    public:
        SCHEMA_FIELD(CUtlVector<float32>             , m_sampleTimes                                   , 0x20)
        SCHEMA_FIELD(float                           , m_flSpringConstant                              , 0x3C)
        SCHEMA_FIELD(float                           , m_flAnticipationDistance                        , 0x40)
        SCHEMA_FIELD(CAnimParamHandle                , m_hAnticipationPosParam                         , 0x44)
        SCHEMA_FIELD(CAnimParamHandle                , m_hAnticipationHeadingParam                     , 0x46)
        SCHEMA_FIELD(bool                            , m_bUseAcceleration                              , 0x48)
    };

    class CPulseCell_Inflow_Method {
    public:
        SCHEMA_FIELD(::PulseSymbol_t                 , m_MethodName                                    , 0x80)
        SCHEMA_FIELD(::CUtlString                    , m_Description                                   , 0x90)
        SCHEMA_FIELD(bool                            , m_bIsPublic                                     , 0x98)
        SCHEMA_FIELD(CPulseValueFullType             , m_ReturnType                                    , 0xA0)
        SCHEMA_FIELD(CUtlLeanVector<CPulseRuntimeMethodArg>, m_Args                                          , 0xB8)
    };

    class CNmReferencePoseNode_CDefinition {
    public:
    };

    class CBinaryUpdateNode {
    public:
        SCHEMA_FIELD(CAnimUpdateNodeRef              , m_pChild1                                       , 0x60)
        SCHEMA_FIELD(CAnimUpdateNodeRef              , m_pChild2                                       , 0x70)
        SCHEMA_FIELD(BinaryNodeTiming                , m_timingBehavior                                , 0x80)
        SCHEMA_FIELD(float                           , m_flTimingBlend                                 , 0x84)
        SCHEMA_FIELD(bool                            , m_bResetChild1                                  , 0x88)
        SCHEMA_FIELD(bool                            , m_bResetChild2                                  , 0x89)
    };

    class PulseSelectorOutflowList_t {
    public:
        SCHEMA_FIELD(CUtlVector<OutflowWithRequirements_t>, m_Outflows                                      , 0x0)
    };

    class CNmParticleEvent {
    public:
        SCHEMA_FIELD(CNmEventRelevance_t             , m_relevance                                     , 0x18)
        SCHEMA_FIELD(CNmParticleEvent_Type_t         , m_type                                          , 0x1C)
        SCHEMA_FIELD(CNmEventTargetEntity_t          , m_target                                        , 0x20)
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeIParticleSystemDefinition>, m_hParticleSystem                               , 0x28)
        SCHEMA_FIELD(::CUtlString                    , m_tags                                          , 0x30)
        SCHEMA_FIELD(bool                            , m_bStopImmediately                              , 0x38)
        SCHEMA_FIELD(bool                            , m_bDetachFromOwner                              , 0x39)
        SCHEMA_FIELD(bool                            , m_bPlayEndCap                                   , 0x3A)
        SCHEMA_FIELD(::CUtlString                    , m_attachmentPoint0                              , 0x40)
        SCHEMA_FIELD(ParticleAttachment_t            , m_attachmentType0                               , 0x48)
        SCHEMA_FIELD(::CUtlString                    , m_attachmentPoint1                              , 0x50)
        SCHEMA_FIELD(ParticleAttachment_t            , m_attachmentType1                               , 0x58)
        SCHEMA_FIELD(::CUtlString                    , m_config                                        , 0x60)
        SCHEMA_FIELD(::CUtlString                    , m_effectForConfig                               , 0x68)
    };

    class IKDemoCaptureSettings_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_parentBoneName                                , 0x0)
        SCHEMA_FIELD(IKChannelMode                   , m_eMode                                         , 0x8)
        SCHEMA_FIELD(::CUtlString                    , m_ikChainName                                   , 0x10)
        SCHEMA_FIELD(::CUtlString                    , m_oneBoneStart                                  , 0x18)
        SCHEMA_FIELD(::CUtlString                    , m_oneBoneEnd                                    , 0x20)
    };

    class CNmSyncTrack {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<CNmSyncTrack_Event_t,10>;
        SCHEMA_FIELD(_Type0                          , m_syncEvents                                    , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nStartEventOffset                             , 0xA8)
    };

    class CMotionGraphGroup {
    public:
        SCHEMA_FIELD(CMotionSearchDB                 , m_searchDB                                      , 0x0)
        SCHEMA_FIELD(CUtlVector<CSmartPtr<CMotionGraph>>, m_motionGraphs                                  , 0xB8)
        SCHEMA_FIELD(CUtlVector<CMotionGraphConfig>  , m_motionGraphConfigs                            , 0xD0)
        SCHEMA_FIELD(CUtlVector<int32>               , m_sampleToConfig                                , 0xE8)
        SCHEMA_FIELD(AnimScriptHandle                , m_hIsActiveScript                               , 0x100)
    };

    class CNmTransitionEventConditionNode_CDefinition {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_requireRuleID                                 , 0x10)
        SCHEMA_FIELD(CNmBitFlags                     , m_eventConditionRules                           , 0x18)
        SCHEMA_FIELD(std::int16_t                    , m_nSourceStateNodeIdx                           , 0x1C)
        SCHEMA_FIELD(NmTransitionRuleCondition_t     , m_ruleCondition                                 , 0x1E)
    };

    class CWarpSectionAnimTagBase {
    public:
    };

    class CPulseCell_WaitForObservable {
    public:
        SCHEMA_FIELD(PulseObservableBoolExpression_t , m_Condition                                     , 0x48)
        SCHEMA_FIELD(CPulse_ResumePoint              , m_OnTrue                                        , 0xC0)
    };

    class CParticleVecInput {
    public:
        SCHEMA_FIELD(ParticleVecType_t               , m_nType                                         , 0x10)
        SCHEMA_FIELD(::Vector                        , m_vLiteralValue                                 , 0x14)
        SCHEMA_FIELD(::Color                         , m_LiteralColor                                  , 0x20)
        SCHEMA_FIELD(CParticleNamedValueRef          , m_NamedValue                                    , 0x28)
        SCHEMA_FIELD(bool                            , m_bFollowNamedValue                             , 0x68)
        SCHEMA_FIELD(ParticleAttributeIndex_t        , m_nVectorAttribute                              , 0x6C)
        SCHEMA_FIELD(::Vector                        , m_vVectorAttributeScale                         , 0x70)
        SCHEMA_FIELD(std::int32_t                    , m_nControlPoint                                 , 0x7C)
        SCHEMA_FIELD(std::int32_t                    , m_nDeltaControlPoint                            , 0x80)
        SCHEMA_FIELD(::Vector                        , m_vCPValueScale                                 , 0x84)
        SCHEMA_FIELD(::Vector                        , m_vCPRelativePosition                           , 0x90)
        SCHEMA_FIELD(::Vector                        , m_vCPRelativeDir                                , 0x9C)
        SCHEMA_FIELD(CParticleFloatInput             , m_FloatComponentX                               , 0xA8)
        SCHEMA_FIELD(CParticleFloatInput             , m_FloatComponentY                               , 0x218)
        SCHEMA_FIELD(CParticleFloatInput             , m_FloatComponentZ                               , 0x388)
        SCHEMA_FIELD(CParticleFloatInput             , m_FloatInterp                                   , 0x4F8)
        SCHEMA_FIELD(float                           , m_flInterpInput0                                , 0x668)
        SCHEMA_FIELD(float                           , m_flInterpInput1                                , 0x66C)
        SCHEMA_FIELD(::Vector                        , m_vInterpOutput0                                , 0x670)
        SCHEMA_FIELD(::Vector                        , m_vInterpOutput1                                , 0x67C)
        SCHEMA_FIELD(CColorGradient                  , m_Gradient                                      , 0x688)
        SCHEMA_FIELD(::Vector                        , m_vRandomMin                                    , 0x6A0)
        SCHEMA_FIELD(::Vector                        , m_vRandomMax                                    , 0x6AC)
    };

    class CChoiceUpdateNode {
    public:
        SCHEMA_FIELD(CUtlVector<CAnimUpdateNodeRef>  , m_children                                      , 0x60)
        SCHEMA_FIELD(CUtlVector<float32>             , m_weights                                       , 0x78)
        SCHEMA_FIELD(CUtlVector<float32>             , m_blendTimes                                    , 0x90)
        SCHEMA_FIELD(ChoiceMethod                    , m_choiceMethod                                  , 0xA8)
        SCHEMA_FIELD(ChoiceChangeMethod              , m_choiceChangeMethod                            , 0xAC)
        SCHEMA_FIELD(ChoiceBlendMethod               , m_blendMethod                                   , 0xB0)
        SCHEMA_FIELD(float                           , m_blendTime                                     , 0xB4)
        SCHEMA_FIELD(bool                            , m_bCrossFade                                    , 0xB8)
        SCHEMA_FIELD(bool                            , m_bResetChosen                                  , 0xB9)
        SCHEMA_FIELD(bool                            , m_bDontResetSameSelection                       , 0xBA)
    };

    class CNmBoneMaskValueNode_CDefinition {
    public:
    };

    class CMovementHandshakeAnimTag {
    public:
    };

    class VPhysXBodyPart_t {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_nFlags                                        , 0x0)
        SCHEMA_FIELD(float                           , m_flMass                                        , 0x4)
        SCHEMA_FIELD(VPhysics2ShapeDef_t             , m_rnShape                                       , 0x8)
        SCHEMA_FIELD(std::uint16_t                   , m_nCollisionAttributeIndex                      , 0x80)
        SCHEMA_FIELD(std::uint16_t                   , m_nReserved                                     , 0x82)
        SCHEMA_FIELD(float                           , m_flInertiaScale                                , 0x84)
        SCHEMA_FIELD(float                           , m_flLinearDamping                               , 0x88)
        SCHEMA_FIELD(float                           , m_flAngularDamping                              , 0x8C)
        SCHEMA_FIELD(float                           , m_flLinearDrag                                  , 0x90)
        SCHEMA_FIELD(float                           , m_flAngularDrag                                 , 0x94)
        SCHEMA_FIELD(bool                            , m_bOverrideMassCenter                           , 0x98)
        SCHEMA_FIELD(::Vector                        , m_vMassCenterOverride                           , 0x9C)
    };

    class NetVarConfigIndex {
    public:
        SCHEMA_FIELD(CAnimNetVar<uint32>             , m_index                                         , 0x0)
    };

    class CBodyGroupSetting {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_BodyGroupName                                 , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nBodyGroupOption                              , 0x8)
    };

    class PulseGraphExecutionHistoryEntry_t {
    public:
        SCHEMA_FIELD(PulseCursorID_t                 , nCursorID                                       , 0x0)
        SCHEMA_FIELD(::PulseDocNodeID_t              , nEditorID                                       , 0x4)
        SCHEMA_FIELD(float                           , flExecTime                                      , 0x8)
        SCHEMA_FIELD(std::uint32_t                   , unFlags                                         , 0xC)
        SCHEMA_FIELD(::PulseSymbol_t                 , tagName                                         , 0x10)
    };

    class CParticleCollectionBindingInstance {
    public:
    };

    class CNmGraphVariationUserData {
    public:
    };

    class SignatureOutflow_Resume {
    public:
    };

    class CPulseMathlib {
    public:
    };

    class CFootCycleMetricEvaluator {
    public:
        SCHEMA_FIELD(CUtlVector<int32>               , m_footIndices                                   , 0x50)
    };

    class CEnumAnimParameter {
    public:
        SCHEMA_FIELD(std::uint8_t                    , m_defaultValue                                  , 0x88)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_enumOptions                                   , 0x90)
        SCHEMA_FIELD(CUtlVector<uint64>              , m_vecEnumReferenced                             , 0xA8)
    };

    class CNmVectorValueNode_CDefinition {
    public:
    };

    class CAimMatrixUpdateNode {
    public:
        SCHEMA_FIELD(AimMatrixOpFixedSettings_t      , m_opFixedSettings                               , 0x70)
        SCHEMA_FIELD(AnimVectorSource                , m_target                                        , 0x168)
        SCHEMA_FIELD(CAnimParamHandle                , m_paramIndex                                    , 0x16C)
        SCHEMA_FIELD(HSequence                       , m_hSequence                                     , 0x170)
        SCHEMA_FIELD(bool                            , m_bResetChild                                   , 0x174)
        SCHEMA_FIELD(bool                            , m_bLockWhenWaning                               , 0x175)
    };

    class PulseRuntimeCallInfoIndex_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_Value                                         , 0x0)
    };

    class NmSyncTrackTimeRange_t {
    public:
        SCHEMA_FIELD(NmSyncTrackTime_t               , m_startTime                                     , 0x0)
        SCHEMA_FIELD(NmSyncTrackTime_t               , m_endTime                                       , 0x8)
    };

    class CTargetWarpUpdateNode {
    public:
        SCHEMA_FIELD(TargetWarpAngleMode_t           , m_eAngleMode                                    , 0x74)
        SCHEMA_FIELD(CAnimParamHandle                , m_hTargetPositionParameter                      , 0x78)
        SCHEMA_FIELD(CAnimParamHandle                , m_hTargetUpVectorParameter                      , 0x7A)
        SCHEMA_FIELD(CAnimParamHandle                , m_hTargetFacePositionParameter                  , 0x7C)
        SCHEMA_FIELD(CAnimParamHandle                , m_hMoveHeadingParameter                         , 0x7E)
        SCHEMA_FIELD(CAnimParamHandle                , m_hDesiredMoveHeadingParameter                  , 0x80)
        SCHEMA_FIELD(TargetWarpCorrectionMethod      , m_eCorrectionMethod                             , 0x84)
        SCHEMA_FIELD(TargetWarpTimingMethod          , m_eTargetWarpTimingMethod                       , 0x88)
        SCHEMA_FIELD(bool                            , m_bTargetFacePositionIsWorldSpace               , 0x8C)
        SCHEMA_FIELD(bool                            , m_bTargetPositionIsWorldSpace                   , 0x8D)
        SCHEMA_FIELD(bool                            , m_bOnlyWarpWhenTagIsFound                       , 0x8E)
        SCHEMA_FIELD(bool                            , m_bWarpOrientationDuringTranslation             , 0x8F)
        SCHEMA_FIELD(bool                            , m_bWarpAroundCenter                             , 0x90)
        SCHEMA_FIELD(float                           , m_flMaxAngle                                    , 0x94)
    };

    class CPulseCell_WaitForCursorsWithTagBase_CursorState_t {
    public:
        SCHEMA_FIELD(::PulseSymbol_t                 , m_TagName                                       , 0x0)
    };

    class CBindPoseUpdateNode {
    public:
    };

    class CActionComponentUpdater {
    public:
        SCHEMA_FIELD(CUtlVector<CSmartPtr<CAnimActionUpdater>>, m_actions                                       , 0x30)
    };

    class CSetParameterActionUpdater {
    public:
        SCHEMA_FIELD(CAnimParamHandle                , m_hParam                                        , 0x18)
        SCHEMA_FIELD(CAnimVariant                    , m_value                                         , 0x1A)
    };

    class CNmVectorInfoNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(CNmVectorInfoNode_Info_t        , m_desiredInfo                                   , 0x12)
    };

    class CPulseCell_Outflow_CycleShuffled {
    public:
        SCHEMA_FIELD(CUtlVector<CPulse_OutflowConnection>, m_Outputs                                       , 0x48)
    };

    class CUnaryUpdateNode {
    public:
        SCHEMA_FIELD(CAnimUpdateNodeRef              , m_pChildNode                                    , 0x60)
    };

    class CNmValueNode_CDefinition {
    public:
    };

    class CNmParameterizedBlendNode_BlendRange_t {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputIdx0                                    , 0x0)
        SCHEMA_FIELD(std::int16_t                    , m_nInputIdx1                                    , 0x2)
        SCHEMA_FIELD(Range_t                         , m_parameterValueRange                           , 0x4)
    };

    class CSequenceUpdateNodeBase {
    public:
        SCHEMA_FIELD(float                           , m_playbackSpeed                                 , 0x6C)
        SCHEMA_FIELD(bool                            , m_bLoop                                         , 0x70)
    };

    class CPulseCell_LimitCount_InstanceState_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nCurrentCount                                 , 0x0)
    };

    class ConfigIndex {
    public:
        SCHEMA_FIELD(std::uint16_t                   , m_nGroup                                        , 0x0)
        SCHEMA_FIELD(std::uint16_t                   , m_nConfig                                       , 0x2)
    };

    class SelectorInstanceData_t {
    public:
        SCHEMA_FIELD(CRelativeArray<float32>         , m_weights                                       , 0x0)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_currentIndexStartTime                         , 0x8)
        SCHEMA_FIELD(std::int32_t                    , m_currentIndex                                  , 0x14)
        SCHEMA_FIELD(std::int32_t                    , m_previousIndex                                 , 0x18)
    };

    class CAnimationGroup {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_nFlags                                        , 0x10)
        SCHEMA_FIELD(CBufferString                   , m_name                                          , 0x18)
        SCHEMA_FIELD(CUtlVector<CStrongHandle<InfoForResourceTypeCAnimData>>, m_localHAnimArray_Handle                        , 0x60)
        SCHEMA_FIELD(CUtlVector<CStrongHandle<InfoForResourceTypeCAnimationGroup>>, m_includedGroupArray_Handle                     , 0x78)
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeCSequenceGroupData>, m_directHSeqGroup_Handle                        , 0x90)
        SCHEMA_FIELD(CAnimKeyData                    , m_decodeKey                                     , 0x98)
        SCHEMA_FIELD(CUtlVector<CBufferString>       , m_szScripts                                     , 0x110)
        SCHEMA_FIELD(CUtlVector<CStrongHandleVoid>   , m_AdditionalExtRefs                             , 0x128)
    };

    class CNmStateMachineNode_TransitionDefinition_t {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nTargetStateIdx                               , 0x0)
        SCHEMA_FIELD(std::int16_t                    , m_nConditionNodeIdx                             , 0x2)
        SCHEMA_FIELD(std::int16_t                    , m_nTransitionNodeIdx                            , 0x4)
        SCHEMA_FIELD(bool                            , m_bCanBeForced                                  , 0x6)
    };

    class CLODComponentUpdater {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nServerLOD                                    , 0x30)
    };

    class CMaterialDrawDescriptor {
    public:
        SCHEMA_FIELD(float                           , m_flUvDensity                                   , 0x0)
        SCHEMA_FIELD(::Vector                        , m_vTintColor                                    , 0x4)
        SCHEMA_FIELD(float                           , m_flAlpha                                       , 0x10)
        SCHEMA_FIELD(std::uint16_t                   , m_nNumMeshlets                                  , 0x16)
        SCHEMA_FIELD(std::uint32_t                   , m_nFirstMeshlet                                 , 0x1C)
        SCHEMA_FIELD(std::uint32_t                   , m_nAppliedIndexOffset                           , 0x20)
        SCHEMA_FIELD(std::uint8_t                    , m_nDepthVertexBufferIndex                       , 0x24)
        SCHEMA_FIELD(std::uint8_t                    , m_nMeshletPackedIVBIndex                        , 0x25)
        SCHEMA_FIELD(CUtlLeanVector<CMaterialDrawDescriptor_RigidMeshPart_t>, m_rigidMeshParts                                , 0x28)
        SCHEMA_FIELD(RenderPrimitiveType_t           , m_nPrimitiveType                                , 0x38)
        SCHEMA_FIELD(std::int32_t                    , m_nBaseVertex                                   , 0x3C)
        SCHEMA_FIELD(std::int32_t                    , m_nVertexCount                                  , 0x40)
        SCHEMA_FIELD(std::int32_t                    , m_nStartIndex                                   , 0x44)
        SCHEMA_FIELD(std::int32_t                    , m_nIndexCount                                   , 0x48)
        SCHEMA_FIELD(::CRenderBufferBinding          , m_indexBuffer                                   , 0xB0)
        SCHEMA_FIELD(::CRenderBufferBinding          , m_meshletPackedIVB                              , 0xD0)
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeIMaterial2>, m_material                                      , 0x100)
    };

    class CWayPointHelperInstanceData {
    public:
        SCHEMA_FIELD(::Vector                        , m_vMovement                                     , 0x0)
        SCHEMA_FIELD(::QAngle                        , m_vRotation                                     , 0xC)
        SCHEMA_FIELD(::Vector                        , m_vWaypointPosWS                                , 0x18)
        SCHEMA_FIELD(bool                            , m_bStopUpdatingWaypointPos                      , 0x24)
    };

    class CNmRootMotionOverrideNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_desiredMovingVelocityNodeIdx                  , 0x18)
        SCHEMA_FIELD(std::int16_t                    , m_desiredFacingDirectionNodeIdx                 , 0x1A)
        SCHEMA_FIELD(std::int16_t                    , m_linearVelocityLimitNodeIdx                    , 0x1C)
        SCHEMA_FIELD(std::int16_t                    , m_angularVelocityLimitNodeIdx                   , 0x1E)
        SCHEMA_FIELD(float                           , m_maxLinearVelocity                             , 0x20)
        SCHEMA_FIELD(float                           , m_maxAngularVelocityRadians                     , 0x24)
        SCHEMA_FIELD(CNmBitFlags                     , m_overrideFlags                                 , 0x28)
    };

    class CSeqTransition {
    public:
        SCHEMA_FIELD(float                           , m_flFadeInTime                                  , 0x0)
        SCHEMA_FIELD(float                           , m_flFadeOutTime                                 , 0x4)
    };

    class CNmIDValueNode_CDefinition {
    public:
    };

    class CModelConfigElement_SetRenderColor {
    public:
        SCHEMA_FIELD(::Color                         , m_Color                                         , 0x48)
    };

    class MotionBlendItem {
    public:
        SCHEMA_FIELD(CSmartPtr<CMotionNode>          , m_pChild                                        , 0x0)
        SCHEMA_FIELD(float                           , m_flKeyValue                                    , 0x8)
    };

    class SkeletonDemoDb_t {
    public:
        SCHEMA_FIELD(CUtlVector<SkeletonAnimCapture_t*>, m_AnimCaptures                                  , 0x0)
        SCHEMA_FIELD(CUtlVector<SkeletonAnimCapture_t_Camera_t>, m_CameraTrack                                   , 0x18)
        SCHEMA_FIELD(float                           , m_flRecordingTime                               , 0x30)
    };

    class CNmGraphNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nNodeIdx                                      , 0x8)
    };

    class CBlendUpdateNode {
    public:
        SCHEMA_FIELD(CUtlVector<CAnimUpdateNodeRef>  , m_children                                      , 0x60)
        SCHEMA_FIELD(CUtlVector<uint8>               , m_sortedOrder                                   , 0x78)
        SCHEMA_FIELD(CUtlVector<float32>             , m_targetValues                                  , 0x90)
        SCHEMA_FIELD(AnimValueSource                 , m_blendValueSource                              , 0xAC)
        SCHEMA_FIELD(LinearRootMotionBlendMode_t     , m_eLinearRootMotionBlendMode                    , 0xB0)
        SCHEMA_FIELD(CAnimParamHandle                , m_paramIndex                                    , 0xB4)
        SCHEMA_FIELD(CAnimInputDamping               , m_damping                                       , 0xB8)
        SCHEMA_FIELD(BlendKeyType                    , m_blendKeyType                                  , 0xD0)
        SCHEMA_FIELD(bool                            , m_bLockBlendOnReset                             , 0xD4)
        SCHEMA_FIELD(bool                            , m_bSyncCycles                                   , 0xD5)
        SCHEMA_FIELD(bool                            , m_bLoop                                         , 0xD6)
        SCHEMA_FIELD(bool                            , m_bLockWhenWaning                               , 0xD7)
        SCHEMA_FIELD(bool                            , m_bIsAngle                                      , 0xD8)
    };

    class CAnimationGraphInstance {
    public:
        SCHEMA_FIELD(bool                            , m_bTagDispatchDirty                             , 0x329)
    };

    class CNmTargetInfoNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(CNmTargetInfoNode_Info_t        , m_infoType                                      , 0x14)
        SCHEMA_FIELD(bool                            , m_bIsWorldSpaceTarget                           , 0x18)
    };

    class TagSpan_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_tagIndex                                      , 0x0)
        SCHEMA_FIELD(float                           , m_startCycle                                    , 0x4)
        SCHEMA_FIELD(float                           , m_endCycle                                      , 0x8)
    };

    class CPulse_InvokeBinding {
    public:
        SCHEMA_FIELD(::PulseRegisterMap_t            , m_RegisterMap                                   , 0x0)
        SCHEMA_FIELD(::PulseSymbol_t                 , m_FuncName                                      , 0x30)
        SCHEMA_FIELD(PulseRuntimeCellIndex_t         , m_nCellIndex                                    , 0x40)
        SCHEMA_FIELD(::PulseRuntimeChunkIndex_t      , m_nSrcChunk                                     , 0x44)
        SCHEMA_FIELD(std::int32_t                    , m_nSrcInstruction                               , 0x48)
    };

    class PulseRuntimeBlackboardReferenceIndex_t {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_Value                                         , 0x0)
    };

    class CNmVirtualParameterVectorNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nChildNodeIdx                                 , 0x10)
    };

    class CNetworkedCycle {
    public:
        SCHEMA_FIELD(float                           , m_flCycleUnclamped                              , 0x0)
        SCHEMA_FIELD(float                           , m_flPrevCycleUnclamped                          , 0x4)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flCyclesPerSecond                             , 0x10)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flCycleZeroTime                               , 0x1C)
        SCHEMA_FIELD(CAnimNetVar<uint8>              , m_resetCount                                    , 0x28)
    };

    class CNmControlParameterFloatNode_CDefinition {
    public:
    };

    class CModelConfigElement_SetMaterialGroup {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_MaterialGroupName                             , 0x48)
    };

    class AimCameraOpFixedSettings_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nChainIndex                                   , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nCameraJointIndex                             , 0x4)
        SCHEMA_FIELD(std::int32_t                    , m_nPelvisJointIndex                             , 0x8)
        SCHEMA_FIELD(std::int32_t                    , m_nClavicleLeftJointIndex                       , 0xC)
        SCHEMA_FIELD(std::int32_t                    , m_nClavicleRightJointIndex                      , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nDepenetrationJointIndex                      , 0x14)
        SCHEMA_FIELD(CUtlVector<int32>               , m_propJoints                                    , 0x18)
    };

    class CDirectionalBlendUpdateNode {
    public:
        SCHEMA_FIELD(HSequence                       , m_hSequences                                    , 0x5C)
        SCHEMA_FIELD(CAnimInputDamping               , m_damping                                       , 0x80)
        SCHEMA_FIELD(AnimValueSource                 , m_blendValueSource                              , 0x98)
        SCHEMA_FIELD(CAnimParamHandle                , m_paramIndex                                    , 0x9C)
        SCHEMA_FIELD(float                           , m_playbackSpeed                                 , 0xA0)
        SCHEMA_FIELD(float                           , m_duration                                      , 0xA4)
        SCHEMA_FIELD(bool                            , m_bLoop                                         , 0xA8)
        SCHEMA_FIELD(bool                            , m_bLockBlendOnReset                             , 0xA9)
    };

    class PARTICLE_EHANDLE__ {
    public:
        SCHEMA_FIELD(std::int32_t                    , unused                                          , 0x0)
    };

    class CNmBoneWeightList {
    public:
        SCHEMA_FIELD(CResourceName                   , m_skeletonName                                  , 0x0)
        SCHEMA_FIELD(CUtlVector<CGlobalSymbol>       , m_boneIDs                                       , 0xE0)
        SCHEMA_FIELD(CUtlVector<float32>             , m_weights                                       , 0xF8)
    };

    class CCurrentVelocityMetricEvaluator {
    public:
    };

    class CSlowDownOnSlopesUpdateNode {
    public:
        SCHEMA_FIELD(float                           , m_flSlowDownStrength                            , 0x70)
    };

    class CNmIDEventNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nSourceStateNodeIdx                           , 0x10)
        SCHEMA_FIELD(CNmBitFlags                     , m_eventConditionRules                           , 0x14)
        SCHEMA_FIELD(CGlobalSymbol                   , m_defaultValue                                  , 0x18)
    };

    class VPhysXAggregateData_t {
    public:
        SCHEMA_FIELD(std::uint16_t                   , m_nFlags                                        , 0x0)
        SCHEMA_FIELD(std::uint16_t                   , m_nRefCounter                                   , 0x2)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_bonesHash                                     , 0x8)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_boneNames                                     , 0x20)
        SCHEMA_FIELD(CUtlVector<uint16>              , m_indexNames                                    , 0x38)
        SCHEMA_FIELD(CUtlVector<uint16>              , m_indexHash                                     , 0x50)
        SCHEMA_FIELD(CUtlVector<matrix3x4a_t>        , m_bindPose                                      , 0x68)
        SCHEMA_FIELD(CUtlVector<VPhysXBodyPart_t>    , m_parts                                         , 0x80)
        SCHEMA_FIELD(CUtlVector<PhysShapeMarkup_t>   , m_shapeMarkups                                  , 0x98)
        SCHEMA_FIELD(CUtlVector<VPhysXConstraint2_t> , m_constraints2                                  , 0xB0)
        SCHEMA_FIELD(CUtlVector<VPhysXJoint_t>       , m_joints                                        , 0xC8)
        SCHEMA_FIELD(PhysFeModelDesc_t*              , m_pFeModel                                      , 0xE0)
        SCHEMA_FIELD(CUtlVector<uint16>              , m_boneParents                                   , 0xE8)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_surfacePropertyHashes                         , 0x100)
        SCHEMA_FIELD(CUtlVector<VPhysXCollisionAttributes_t>, m_collisionAttributes                           , 0x118)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_debugPartNames                                , 0x130)
        SCHEMA_FIELD(::CUtlString                    , m_embeddedKeyvalues                             , 0x148)
    };

    class CFutureFacingMetricEvaluator {
    public:
        SCHEMA_FIELD(float                           , m_flDistance                                    , 0x50)
        SCHEMA_FIELD(float                           , m_flTime                                        , 0x54)
    };

    class CNmBlendTaskBase {
    public:
    };

    class CNmSpeedScaleNode_CDefinition {
    public:
    };

    class CToggleComponentActionUpdater {
    public:
        SCHEMA_FIELD(AnimComponentID                 , m_componentID                                   , 0x18)
        SCHEMA_FIELD(bool                            , m_bSetEnabled                                   , 0x1C)
    };

    class CPathAnimMotorUpdaterBase {
    public:
        SCHEMA_FIELD(bool                            , m_bLockToPath                                   , 0x20)
    };

    class CParticleVariableRef {
    public:
        SCHEMA_FIELD(CKV3MemberNameWithStorage       , m_variableName                                  , 0x0)
        SCHEMA_FIELD(CPulseValueFullType             , m_variableType                                  , 0x38)
    };

    class CRootMotion {
    public:
        SCHEMA_FIELD(CMotionTransform                , m_deltaTransform                                , 0x0)
        SCHEMA_FIELD(::Vector                        , m_vVelocityMS                                   , 0x10)
        SCHEMA_FIELD(::Vector                        , m_vUpOverride                                   , 0x1C)
    };

    class COrientationWarpUpdateNode {
    public:
        SCHEMA_FIELD(OrientationWarpMode_t           , m_eMode                                         , 0x74)
        SCHEMA_FIELD(CAnimParamHandle                , m_hTargetParam                                  , 0x78)
        SCHEMA_FIELD(CAnimParamHandle                , m_hTargetPositionParam                          , 0x7A)
        SCHEMA_FIELD(CAnimParamHandle                , m_hFallbackTargetPositionParam                  , 0x7C)
        SCHEMA_FIELD(OrientationWarpTargetOffsetMode_t, m_eTargetOffsetMode                             , 0x80)
        SCHEMA_FIELD(float                           , m_flTargetOffset                                , 0x84)
        SCHEMA_FIELD(CAnimParamHandle                , m_hTargetOffsetParam                            , 0x88)
        SCHEMA_FIELD(CAnimInputDamping               , m_damping                                       , 0x90)
        SCHEMA_FIELD(OrientationWarpRootMotionSource_t, m_eRootMotionSource                             , 0xA8)
        SCHEMA_FIELD(float                           , m_flMaxRootMotionScale                          , 0xAC)
        SCHEMA_FIELD(bool                            , m_bEnablePreferredRotationDirection             , 0xB0)
        SCHEMA_FIELD(AnimValueSource                 , m_ePreferredRotationDirection                   , 0xB4)
        SCHEMA_FIELD(float                           , m_flPreferredRotationThreshold                  , 0xB8)
    };

    class CAnimParameterBase {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_name                                          , 0x18)
        SCHEMA_FIELD(::CUtlString                    , m_sComment                                      , 0x20)
        SCHEMA_FIELD(::CUtlString                    , m_group                                         , 0x28)
        SCHEMA_FIELD(AnimParamID                     , m_id                                            , 0x30)
        SCHEMA_FIELD(::CUtlString                    , m_componentName                                 , 0x48)
        SCHEMA_FIELD(bool                            , m_bNetworkingRequested                          , 0x68)
        SCHEMA_FIELD(bool                            , m_bIsReferenced                                 , 0x69)
    };

    class IKBoneNameAndIndex_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_Name                                          , 0x0)
    };

    class PulseCursorYieldToken_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_Value                                         , 0x0)
    };

    class LookData {
    public:
        SCHEMA_FIELD(CAnimNetVar<Vector>             , m_vLookTarget                                   , 0x0)
    };

    class CRagdollComponentUpdater {
    public:
        SCHEMA_FIELD(CUtlVector<CAnimNodePath>       , m_ragdollNodePaths                              , 0x30)
        SCHEMA_FIELD(CUtlVector<CAnimNodePath>       , m_followAttachmentNodePaths                     , 0x48)
        SCHEMA_FIELD(CUtlVector<int32>               , m_boneIndices                                   , 0x60)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_boneNames                                     , 0x78)
        SCHEMA_FIELD(CUtlVector<WeightList>          , m_weightLists                                   , 0x90)
        SCHEMA_FIELD(CUtlVector<int32>               , m_boneToWeightIndices                           , 0xA8)
        SCHEMA_FIELD(float                           , m_flSpringFrequencyMin                          , 0xC0)
        SCHEMA_FIELD(float                           , m_flSpringFrequencyMax                          , 0xC4)
        SCHEMA_FIELD(float                           , m_flMaxStretch                                  , 0xC8)
        SCHEMA_FIELD(bool                            , m_bSolidCollisionAtZeroWeight                   , 0xCC)
    };

    class CNmCurrentSyncEventNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nSourceStateNodeIdx                           , 0x10)
        SCHEMA_FIELD(CNmCurrentSyncEventNode_InfoType_t, m_infoType                                      , 0x12)
    };

    class CNmVectorNegateNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
    };

    class CConcreteAnimParameter {
    public:
        SCHEMA_FIELD(AnimParamButton_t               , m_previewButton                                 , 0x70)
        SCHEMA_FIELD(AnimParamNetworkSetting         , m_eNetworkSetting                               , 0x74)
        SCHEMA_FIELD(bool                            , m_bUseMostRecentValue                           , 0x78)
        SCHEMA_FIELD(bool                            , m_bAutoReset                                    , 0x79)
        SCHEMA_FIELD(bool                            , m_bGameWritable                                 , 0x7A)
        SCHEMA_FIELD(bool                            , m_bGraphWritable                                , 0x7B)
    };

    class CPulseCell_BaseState {
    public:
    };

    class MotionMatchingInstanceData {
    public:
        SCHEMA_FIELD(MotionSelection                 , m_currentSelection                              , 0x2C)
        SCHEMA_FIELD(MotionSelection                 , m_previousSelection                             , 0x84)
    };

    class CBonePositionMetricEvaluator {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nBoneIndex                                    , 0x50)
    };

    class CNmOverlayBlendTask {
    public:
    };

    class CNmStateMachineNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<CNmStateMachineNode_StateDefinition_t,5>;
        SCHEMA_FIELD(_Type0                          , m_stateDefinitions                              , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nDefaultStateIndex                            , 0x130)
    };

    class CNmBoneMaskNode_CDefinition {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_boneMaskID                                    , 0x10)
    };

    class ModelEmbeddedMesh_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_Name                                          , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nMeshIndex                                    , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nDataBlock                                    , 0x14)
        SCHEMA_FIELD(std::int32_t                    , m_nMorphBlock                                   , 0x18)
        SCHEMA_FIELD(CUtlVector<ModelMeshBufferData_t>, m_vertexBuffers                                 , 0x20)
        SCHEMA_FIELD(CUtlVector<ModelMeshBufferData_t>, m_indexBuffers                                  , 0x38)
        SCHEMA_FIELD(CUtlVector<ModelMeshBufferData_t>, m_toolsBuffers                                  , 0x50)
        SCHEMA_FIELD(std::int32_t                    , m_nVBIBBlock                                    , 0x68)
        SCHEMA_FIELD(std::int32_t                    , m_nToolsVBBlock                                 , 0x6C)
    };

    class CAnimDemoCaptureSettings {
    public:
        SCHEMA_FIELD(::Vector2D                      , m_vecErrorRangeSplineRotation                   , 0x0)
        SCHEMA_FIELD(::Vector2D                      , m_vecErrorRangeSplineTranslation                , 0x8)
        SCHEMA_FIELD(::Vector2D                      , m_vecErrorRangeSplineScale                      , 0x10)
        SCHEMA_FIELD(float                           , m_flIkRotation_MaxSplineError                   , 0x18)
        SCHEMA_FIELD(float                           , m_flIkTranslation_MaxSplineError                , 0x1C)
        SCHEMA_FIELD(::Vector2D                      , m_vecErrorRangeQuantizationRotation             , 0x20)
        SCHEMA_FIELD(::Vector2D                      , m_vecErrorRangeQuantizationTranslation          , 0x28)
        SCHEMA_FIELD(::Vector2D                      , m_vecErrorRangeQuantizationScale                , 0x30)
        SCHEMA_FIELD(float                           , m_flIkRotation_MaxQuantizationError             , 0x38)
        SCHEMA_FIELD(float                           , m_flIkTranslation_MaxQuantizationError          , 0x3C)
        SCHEMA_FIELD(::CUtlString                    , m_baseSequence                                  , 0x40)
        SCHEMA_FIELD(std::int32_t                    , m_nBaseSequenceFrame                            , 0x48)
        SCHEMA_FIELD(EDemoBoneSelectionMode          , m_boneSelectionMode                             , 0x4C)
        SCHEMA_FIELD(CUtlVector<BoneDemoCaptureSettings_t>, m_bones                                         , 0x50)
        SCHEMA_FIELD(CUtlVector<IKDemoCaptureSettings_t>, m_ikChains                                      , 0x68)
    };

    class AimMatrixOpFixedSettings_t {
    public:
        SCHEMA_FIELD(CAnimAttachment                 , m_attachment                                    , 0x0)
        SCHEMA_FIELD(CAnimInputDamping               , m_damping                                       , 0x80)
        SCHEMA_FIELD(CPoseHandle                     , m_poseCacheHandles                              , 0x98)
        SCHEMA_FIELD(AimMatrixBlendMode              , m_eBlendMode                                    , 0xC0)
        SCHEMA_FIELD(float                           , m_flMaxYawAngle                                 , 0xC4)
        SCHEMA_FIELD(float                           , m_flMaxPitchAngle                               , 0xC8)
        SCHEMA_FIELD(std::int32_t                    , m_nSequenceMaxFrame                             , 0xCC)
        SCHEMA_FIELD(std::int32_t                    , m_nBoneMaskIndex                                , 0xD0)
        SCHEMA_FIELD(bool                            , m_bTargetIsPosition                             , 0xD4)
        SCHEMA_FIELD(bool                            , m_bUseBiasAndClamp                              , 0xD5)
        SCHEMA_FIELD(float                           , m_flBiasAndClampYawOffset                       , 0xD8)
        SCHEMA_FIELD(float                           , m_flBiasAndClampPitchOffset                     , 0xDC)
        SCHEMA_FIELD(CBlendCurve                     , m_biasAndClampBlendCurve                        , 0xE0)
    };

    class CCycleClipInstanceData {
    public:
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flCycle                                       , 0x0)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flPrevCycle                                   , 0xC)
    };

    class AnimParamID {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_id                                            , 0x0)
    };

    class MotionDBIndex {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_nIndex                                        , 0x0)
    };

    class CBaseConstraint {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x20)
        SCHEMA_FIELD(::Vector                        , m_vUpVector                                     , 0x28)
        SCHEMA_FIELD(CUtlLeanVector<CConstraintSlave>, m_slaves                                        , 0x38)
        SCHEMA_FIELD(CUtlVector<CConstraintTarget>   , m_targets                                       , 0x48)
    };

    class CMotionSearchDB {
    public:
        SCHEMA_FIELD(CMotionSearchNode               , m_rootNode                                      , 0x0)
        SCHEMA_FIELD(CProductQuantizer               , m_residualQuantizer                             , 0x80)
        SCHEMA_FIELD(CUtlVector<MotionDBIndex>       , m_codeIndices                                   , 0xA0)
    };

    class CAnimGraphNetworkSettings {
    public:
        SCHEMA_FIELD(bool                            , m_bNetworkingEnabled                            , 0x20)
    };

    class CNmGraphEventConditionNode_CDefinition {
    public:
        using _Type0 = CUtlVectorFixedGrowable<CNmGraphEventConditionNode_Condition_t,5>;
        SCHEMA_FIELD(std::int16_t                    , m_nSourceStateNodeIdx                           , 0x10)
        SCHEMA_FIELD(CNmBitFlags                     , m_eventConditionRules                           , 0x14)
        SCHEMA_FIELD(_Type0                          , m_conditions                                    , 0x18)
    };

    class CParticleCollectionRendererFloatInput {
    public:
    };

    class CMotionNode {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x18)
        SCHEMA_FIELD(AnimNodeID                      , m_id                                            , 0x20)
    };

    class CAnimGraphSettingsGroup {
    public:
    };

    class CNmClipNode_CDefinition {
    public:
        using _Type0 = CUtlVectorFixedGrowable<CGlobalSymbol,2>;
        SCHEMA_FIELD(std::int16_t                    , m_nPlayInReverseValueNodeIdx                    , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nResetTimeValueNodeIdx                        , 0x12)
        SCHEMA_FIELD(bool                            , m_bSampleRootMotion                             , 0x14)
        SCHEMA_FIELD(bool                            , m_bAllowLooping                                 , 0x15)
        SCHEMA_FIELD(std::int16_t                    , m_nDataSlotIdx                                  , 0x16)
        SCHEMA_FIELD(_Type0                          , m_graphEvents                                   , 0x18)
        SCHEMA_FIELD(float                           , m_flSpeedMultiplier                             , 0x40)
        SCHEMA_FIELD(std::int32_t                    , m_nStartSyncEventOffset                         , 0x44)
    };

    class CPulse_DomainValue {
    public:
        SCHEMA_FIELD(PulseDomainValueType_t          , m_nType                                         , 0x0)
        SCHEMA_FIELD(CGlobalSymbolCaseSensitive      , m_Value                                         , 0x8)
        SCHEMA_FIELD(CPulseValueFullType             , m_RequiredRuntimeType                           , 0x10)
    };

    class CVectorAnimParameter {
    public:
        SCHEMA_FIELD(::Vector                        , m_defaultValue                                  , 0x80)
        SCHEMA_FIELD(bool                            , m_bInterpolate                                  , 0x8C)
        SCHEMA_FIELD(AnimParamVectorType_t           , m_vectorType                                    , 0x90)
    };

    class CNmGraphDefinition_ExternalPoseSlot_t {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nNodeIdx                                      , 0x0)
        SCHEMA_FIELD(CGlobalSymbol                   , m_slotID                                        , 0x8)
    };

    class CRemapValueComponentUpdater {
    public:
        SCHEMA_FIELD(CUtlVector<CRemapValueUpdateItem>, m_items                                         , 0x30)
    };

    class CStateMachineComponentUpdater {
    public:
        SCHEMA_FIELD(CAnimStateMachineUpdater        , m_stateMachine                                  , 0x30)
    };

    class CSeqPoseParamDesc {
    public:
        SCHEMA_FIELD(CBufferString                   , m_sName                                         , 0x0)
        SCHEMA_FIELD(float                           , m_flStart                                       , 0x10)
        SCHEMA_FIELD(float                           , m_flEnd                                         , 0x14)
        SCHEMA_FIELD(float                           , m_flLoop                                        , 0x18)
        SCHEMA_FIELD(bool                            , m_bLooping                                      , 0x1C)
    };

    class FootStepTrigger {
    public:
        SCHEMA_FIELD(CUtlVector<int32>               , m_tags                                          , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nFootIndex                                    , 0x18)
        SCHEMA_FIELD(StepPhase                       , m_triggerPhase                                  , 0x1C)
    };

    class CAnimDecoder {
    public:
        SCHEMA_FIELD(CBufferString                   , m_szName                                        , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nVersion                                      , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nType                                         , 0x14)
    };

    class CFlexDesc {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_szFacs                                        , 0x0)
    };

    class CNmIsInactiveBranchConditionNode_CDefinition {
    public:
    };

    class CMotionMatchingUpdateNode {
    public:
        SCHEMA_FIELD(CMotionDataSet                  , m_dataSet                                       , 0x58)
        SCHEMA_FIELD(CUtlVector<CSmartPtr<CMotionMetricEvaluator>>, m_metrics                                       , 0x78)
        SCHEMA_FIELD(CUtlVector<float32>             , m_weights                                       , 0x90)
        SCHEMA_FIELD(bool                            , m_bSearchEveryTick                              , 0xE0)
        SCHEMA_FIELD(float                           , m_flSearchInterval                              , 0xE4)
        SCHEMA_FIELD(bool                            , m_bSearchWhenClipEnds                           , 0xE8)
        SCHEMA_FIELD(bool                            , m_bSearchWhenGoalChanges                        , 0xE9)
        SCHEMA_FIELD(CBlendCurve                     , m_blendCurve                                    , 0xEC)
        SCHEMA_FIELD(float                           , m_flSampleRate                                  , 0xF4)
        SCHEMA_FIELD(float                           , m_flBlendTime                                   , 0xF8)
        SCHEMA_FIELD(bool                            , m_bLockClipWhenWaning                           , 0xFC)
        SCHEMA_FIELD(float                           , m_flSelectionThreshold                          , 0x100)
        SCHEMA_FIELD(float                           , m_flReselectionTimeWindow                       , 0x104)
        SCHEMA_FIELD(bool                            , m_bEnableRotationCorrection                     , 0x108)
        SCHEMA_FIELD(bool                            , m_bGoalAssist                                   , 0x109)
        SCHEMA_FIELD(float                           , m_flGoalAssistDistance                          , 0x10C)
        SCHEMA_FIELD(float                           , m_flGoalAssistTolerance                         , 0x110)
        SCHEMA_FIELD(CAnimInputDamping               , m_distanceScale_Damping                         , 0x118)
        SCHEMA_FIELD(float                           , m_flDistanceScale_OuterRadius                   , 0x130)
        SCHEMA_FIELD(float                           , m_flDistanceScale_InnerRadius                   , 0x134)
        SCHEMA_FIELD(float                           , m_flDistanceScale_MaxScale                      , 0x138)
        SCHEMA_FIELD(float                           , m_flDistanceScale_MinScale                      , 0x13C)
        SCHEMA_FIELD(bool                            , m_bEnableDistanceScaling                        , 0x140)
    };

    class CBoneMaskUpdateNode {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nWeightListIndex                              , 0x94)
        SCHEMA_FIELD(float                           , m_flRootMotionBlend                             , 0x98)
        SCHEMA_FIELD(BoneMaskBlendSpace              , m_blendSpace                                    , 0x9C)
        SCHEMA_FIELD(BinaryNodeChildOption           , m_footMotionTiming                              , 0xA0)
        SCHEMA_FIELD(bool                            , m_bUseBlendScale                                , 0xA4)
        SCHEMA_FIELD(AnimValueSource                 , m_blendValueSource                              , 0xA8)
        SCHEMA_FIELD(CAnimParamHandle                , m_hBlendParameter                               , 0xAC)
    };

    class CAimConstraint {
    public:
        SCHEMA_FIELD(::Quaternion                    , m_qAimOffset                                    , 0x60)
        SCHEMA_FIELD(std::uint32_t                   , m_nUpType                                       , 0x70)
    };

    class CPulse_PublicOutput {
    public:
        SCHEMA_FIELD(::PulseSymbol_t                 , m_Name                                          , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_Description                                   , 0x10)
        SCHEMA_FIELD(CUtlLeanVector<CPulseRuntimeMethodArg>, m_Args                                          , 0x18)
    };

    class CPulseCell_Unknown {
    public:
        SCHEMA_FIELD(KeyValues3                      , m_UnknownKeys                                   , 0x48)
    };

    class CPulseCell_Step_DebugLog {
    public:
    };

    class CSpeedScaleUpdateNode {
    public:
        SCHEMA_FIELD(CAnimParamHandle                , m_paramIndex                                    , 0x70)
    };

    class CChoiceInstanceData {
    public:
        SCHEMA_FIELD(CAnimNetVar<int32>              , m_currentChoice                                 , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_previousChoice                                , 0x1C)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flClipStartTime                               , 0x20)
        SCHEMA_FIELD(float                           , m_choicePreviousCycle                           , 0x2C)
    };

    class CPulseCell_Value_Gradient {
    public:
        SCHEMA_FIELD(CColorGradient                  , m_Gradient                                      , 0x48)
    };

    class CPerParticleFloatInput {
    public:
    };

    class CAnimUserDifference {
    public:
        SCHEMA_FIELD(CBufferString                   , m_name                                          , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nType                                         , 0x10)
    };

    class VPhysics2ShapeDef_t {
    public:
        SCHEMA_FIELD(CUtlVector<RnSphereDesc_t>      , m_spheres                                       , 0x0)
        SCHEMA_FIELD(CUtlVector<RnCapsuleDesc_t>     , m_capsules                                      , 0x18)
        SCHEMA_FIELD(CUtlVector<RnHullDesc_t>        , m_hulls                                         , 0x30)
        SCHEMA_FIELD(CUtlVector<RnMeshDesc_t>        , m_meshes                                        , 0x48)
        SCHEMA_FIELD(CUtlVector<uint16>              , m_CollisionAttributeIndices                     , 0x60)
    };

    class CMotionSearchNode {
    public:
        SCHEMA_FIELD(CUtlVector<CMotionSearchNode*>  , m_children                                      , 0x0)
        SCHEMA_FIELD(CVectorQuantizer                , m_quantizer                                     , 0x18)
        SCHEMA_FIELD(CUtlVector<CUtlVector<SampleCode>>, m_sampleCodes                                   , 0x38)
        SCHEMA_FIELD(CUtlVector<CUtlVector<int32>>   , m_sampleIndices                                 , 0x50)
        SCHEMA_FIELD(CUtlVector<int32>               , m_selectableSamples                             , 0x68)
    };

    class CNmCachedFloatNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(NmCachedValueMode_t             , m_mode                                          , 0x14)
    };

    class CFootPositionMetricEvaluator {
    public:
        SCHEMA_FIELD(CUtlVector<int32>               , m_footIndices                                   , 0x50)
        SCHEMA_FIELD(bool                            , m_bIgnoreSlope                                  , 0x68)
    };

    class IKSolverSettings_t {
    public:
        SCHEMA_FIELD(IKSolverType                    , m_SolverType                                    , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nNumIterations                                , 0x4)
        SCHEMA_FIELD(EIKEndEffectorRotationFixUpMode , m_EndEffectorRotationFixUpMode                  , 0x8)
    };

    class CDrawCullingData {
    public:
        SCHEMA_FIELD(std::int8_t                     , m_ConeAxis                                      , 0x0)
        SCHEMA_FIELD(std::int8_t                     , m_ConeCutoff                                    , 0x3)
    };

    class CPulseCell_WaitForCursorsWithTagBase {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nCursorsAllowedToWait                         , 0x48)
        SCHEMA_FIELD(CPulse_ResumePoint              , m_WaitComplete                                  , 0x50)
    };

    class CNmParameterizedSelectorNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,8>;
        using _Type1 = CUtlLeanVectorFixedGrowable<uint8,8>;
        SCHEMA_FIELD(_Type0                          , m_optionNodeIndices                             , 0x10)
        SCHEMA_FIELD(_Type1                          , m_optionWeights                                 , 0x28)
        SCHEMA_FIELD(std::int16_t                    , m_parameterNodeIdx                              , 0x38)
        SCHEMA_FIELD(bool                            , m_bIgnoreInvalidOptions                         , 0x3A)
        SCHEMA_FIELD(bool                            , m_bHasWeightsSet                                , 0x3B)
    };

    class CPulseArraylib {
    public:
    };

    class CAnimCycle {
    public:
    };

    class PulseCursorID_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_Value                                         , 0x0)
    };

    class PermModelExtPart_t {
    public:
        SCHEMA_FIELD(CTransform                      , m_Transform                                     , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_Name                                          , 0x20)
        SCHEMA_FIELD(std::int32_t                    , m_nParent                                       , 0x28)
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeCModel>, m_refModel                                      , 0x30)
    };

    class CAnimData {
    public:
        SCHEMA_FIELD(CBufferString                   , m_name                                          , 0x10)
        SCHEMA_FIELD(CUtlVector<CAnimDesc>           , m_animArray                                     , 0x20)
        SCHEMA_FIELD(CUtlVector<CAnimDecoder>        , m_decoderArray                                  , 0x38)
        SCHEMA_FIELD(std::int32_t                    , m_nMaxUniqueFrameIndex                          , 0x50)
        SCHEMA_FIELD(CUtlVector<CAnimFrameSegment>   , m_segmentArray                                  , 0x58)
    };

    class CPulseCell_InlineNodeSkipSelector {
    public:
        SCHEMA_FIELD(::PulseDocNodeID_t              , m_nFlowNodeID                                   , 0x48)
        SCHEMA_FIELD(bool                            , m_bAnd                                          , 0x4C)
        SCHEMA_FIELD(PulseSelectorOutflowList_t      , m_PassOutflow                                   , 0x50)
        SCHEMA_FIELD(CPulse_OutflowConnection        , m_FailOutflow                                   , 0x68)
    };

    class SlopeData {
    public:
        SCHEMA_FIELD(::Vector                        , m_vSlopeNormal                                  , 0x0)
    };

    class CAnimStateMachineUpdater {
    public:
        SCHEMA_FIELD(CUtlVector<CStateUpdateData>    , m_states                                        , 0x8)
        SCHEMA_FIELD(CUtlVector<CTransitionUpdateData>, m_transitions                                   , 0x20)
        SCHEMA_FIELD(std::int32_t                    , m_startStateIndex                               , 0x50)
    };

    class CModelConfigElement_RandomColor {
    public:
        SCHEMA_FIELD(CColorGradient                  , m_Gradient                                      , 0x48)
    };

    class CNmFootstepEventPercentageThroughNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nSourceStateNodeIdx                           , 0x10)
        SCHEMA_FIELD(NmFootPhaseCondition_t          , m_phaseCondition                                , 0x12)
        SCHEMA_FIELD(CNmBitFlags                     , m_eventConditionRules                           , 0x14)
    };

    class CCycleControlUpdateNode {
    public:
        SCHEMA_FIELD(AnimValueSource                 , m_valueSource                                   , 0x70)
        SCHEMA_FIELD(CAnimParamHandle                , m_paramIndex                                    , 0x74)
        SCHEMA_FIELD(bool                            , m_bLockWhenWaning                               , 0x76)
    };

    class ScriptInfo_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_code                                          , 0x0)
        SCHEMA_FIELD(CUtlVector<CAnimParamHandle>    , m_paramsModified                                , 0x8)
        SCHEMA_FIELD(CUtlVector<int32>               , m_proxyReadParams                               , 0x20)
        SCHEMA_FIELD(CUtlVector<int32>               , m_proxyWriteParams                              , 0x38)
        SCHEMA_FIELD(AnimScriptType                  , m_eScriptType                                   , 0x50)
    };

    class CAnimKeyData {
    public:
        SCHEMA_FIELD(CBufferString                   , m_name                                          , 0x0)
        SCHEMA_FIELD(CUtlVector<CAnimBone>           , m_boneArray                                     , 0x10)
        SCHEMA_FIELD(CUtlVector<CAnimUser>           , m_userArray                                     , 0x28)
        SCHEMA_FIELD(CUtlVector<CBufferString>       , m_morphArray                                    , 0x40)
        SCHEMA_FIELD(std::int32_t                    , m_nChannelElements                              , 0x58)
        SCHEMA_FIELD(CUtlVector<CAnimDataChannelDesc>, m_dataChannelArray                              , 0x60)
    };

    class CNmTwoBoneIKNode_CDefinition {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_effectorBoneID                                , 0x18)
        SCHEMA_FIELD(std::int16_t                    , m_nEffectorTargetNodeIdx                        , 0x20)
        SCHEMA_FIELD(std::int16_t                    , m_nEnabledNodeIdx                               , 0x22)
        SCHEMA_FIELD(float                           , m_flBlendTimeSeconds                            , 0x24)
        SCHEMA_FIELD(NmIKBlendMode_t                 , m_blendMode                                     , 0x28)
        SCHEMA_FIELD(bool                            , m_bIsTargetInWorldSpace                         , 0x29)
        SCHEMA_FIELD(float                           , m_flChainRotationWeight                         , 0x2C)
    };

    class CPulse_InstructionDebug {
    public:
        SCHEMA_FIELD(::PulseDocNodeID_t              , m_nFlowNodeID                                   , 0x0)
        SCHEMA_FIELD(::PulseDocNodeID_t              , m_nValueNodeID                                  , 0x4)
        SCHEMA_FIELD(CGlobalSymbol                   , m_SequencePointName                             , 0x8)
    };

    class CNmClipReferenceNode_CDefinition {
    public:
    };

    class CPulseCell_BaseLerp_CursorState_t {
    public:
        SCHEMA_FIELD(::GameTime_t                    , m_StartTime                                     , 0x0)
        SCHEMA_FIELD(::GameTime_t                    , m_EndTime                                       , 0x4)
    };

    class CAnimComponentUpdater {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x18)
        SCHEMA_FIELD(AnimComponentID                 , m_id                                            , 0x20)
        SCHEMA_FIELD(AnimNodeNetworkMode             , m_networkMode                                   , 0x24)
        SCHEMA_FIELD(bool                            , m_bStartEnabled                                 , 0x28)
    };

    class AnimScriptHandle {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_id                                            , 0x0)
    };

    class RenderSkeletonBone_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_boneName                                      , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_parentName                                    , 0x8)
        SCHEMA_FIELD(::matrix3x4_t                   , m_invBindPose                                   , 0x10)
        SCHEMA_FIELD(SkeletonBoneBounds_t            , m_bbox                                          , 0x40)
        SCHEMA_FIELD(float                           , m_flSphereRadius                                , 0x58)
    };

    class CParticleCollectionVecInput {
    public:
    };

    class CLeanMatrixUpdateNode {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_frameCorners                                  , 0x5C)
        SCHEMA_FIELD(CPoseHandle                     , m_poses                                         , 0x80)
        SCHEMA_FIELD(CAnimInputDamping               , m_damping                                       , 0xA8)
        SCHEMA_FIELD(AnimVectorSource                , m_blendSource                                   , 0xC0)
        SCHEMA_FIELD(CAnimParamHandle                , m_paramIndex                                    , 0xC4)
        SCHEMA_FIELD(::Vector                        , m_verticalAxis                                  , 0xC8)
        SCHEMA_FIELD(::Vector                        , m_horizontalAxis                                , 0xD4)
        SCHEMA_FIELD(HSequence                       , m_hSequence                                     , 0xE0)
        SCHEMA_FIELD(float                           , m_flMaxValue                                    , 0xE4)
        SCHEMA_FIELD(std::int32_t                    , m_nSequenceMaxFrame                             , 0xE8)
    };

    class PulseRuntimeEntrypointIndex_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_Value                                         , 0x0)
    };

    class CStateMachineInstanceData {
    public:
        SCHEMA_FIELD(float                           , m_flTimeInState                                 , 0x0)
        SCHEMA_FIELD(CAnimNetVar<int32>              , m_currentTransitionIndex                        , 0x4)
        SCHEMA_FIELD(std::int32_t                    , m_prevStateIndex                                , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_scheduledTransitionIndex                      , 0x14)
    };

    class CNmMaterialAttributeEvent {
    public:
        SCHEMA_FIELD(CNmEventTargetEntity_t          , m_target                                        , 0x18)
        SCHEMA_FIELD(::CUtlString                    , m_attributeName                                 , 0x20)
        SCHEMA_FIELD(CUtlStringToken                 , m_attributeNameToken                            , 0x28)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_x                                             , 0x30)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_y                                             , 0x70)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_z                                             , 0xB0)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_w                                             , 0xF0)
    };

    class CNmSyncEventIndexConditionNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nSourceStateNodeIdx                           , 0x10)
        SCHEMA_FIELD(CNmSyncEventIndexConditionNode_TriggerMode_t, m_triggerMode                                   , 0x12)
        SCHEMA_FIELD(std::int32_t                    , m_syncEventIdx                                  , 0x14)
    };

    class JiggleBoneSettings_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nBoneIndex                                    , 0x0)
        SCHEMA_FIELD(float                           , m_flSpringStrength                              , 0x4)
        SCHEMA_FIELD(float                           , m_flMaxTimeStep                                 , 0x8)
        SCHEMA_FIELD(float                           , m_flDamping                                     , 0xC)
        SCHEMA_FIELD(::Vector                        , m_vBoundsMaxLS                                  , 0x10)
        SCHEMA_FIELD(::Vector                        , m_vBoundsMinLS                                  , 0x1C)
        SCHEMA_FIELD(JiggleBoneSimSpace              , m_eSimSpace                                     , 0x28)
    };

    class CVectorQuantizer {
    public:
        SCHEMA_FIELD(CUtlVector<float32>             , m_centroidVectors                               , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nCentroids                                    , 0x18)
        SCHEMA_FIELD(std::int32_t                    , m_nDimensions                                   , 0x1C)
    };

    class CPathMetricEvaluator {
    public:
        SCHEMA_FIELD(CUtlVector<float32>             , m_pathTimeSamples                               , 0x50)
        SCHEMA_FIELD(float                           , m_flDistance                                    , 0x68)
        SCHEMA_FIELD(bool                            , m_bExtrapolateMovement                          , 0x6C)
        SCHEMA_FIELD(float                           , m_flMinExtrapolationSpeed                       , 0x70)
    };

    class CHandshakeAnimTagBase {
    public:
        SCHEMA_FIELD(bool                            , m_bIsDisableTag                                 , 0x50)
    };

    class CMorphConstraint {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_sTargetMorph                                  , 0x60)
        SCHEMA_FIELD(std::int32_t                    , m_nSlaveChannel                                 , 0x68)
        SCHEMA_FIELD(float                           , m_flMin                                         , 0x6C)
        SCHEMA_FIELD(float                           , m_flMax                                         , 0x70)
    };

    class CNmControlParameterIDNode_CDefinition {
    public:
    };

    class CPhysSurfacePropertiesSoundNames {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_impactSoft                                    , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_impactHard                                    , 0x8)
        SCHEMA_FIELD(::CUtlString                    , m_scrapeSmooth                                  , 0x10)
        SCHEMA_FIELD(::CUtlString                    , m_scrapeRough                                   , 0x18)
        SCHEMA_FIELD(::CUtlString                    , m_bulletImpact                                  , 0x20)
        SCHEMA_FIELD(::CUtlString                    , m_rolling                                       , 0x28)
        SCHEMA_FIELD(::CUtlString                    , m_break                                         , 0x30)
        SCHEMA_FIELD(::CUtlString                    , m_strain                                        , 0x38)
        SCHEMA_FIELD(::CUtlString                    , m_meleeImpact                                   , 0x40)
        SCHEMA_FIELD(::CUtlString                    , m_pushOff                                       , 0x48)
        SCHEMA_FIELD(::CUtlString                    , m_skidStop                                      , 0x50)
        SCHEMA_FIELD(::CUtlString                    , m_resonant                                      , 0x58)
    };

    class ParticleNamedValueConfiguration_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_ConfigName                                    , 0x0)
        SCHEMA_FIELD(KeyValues3                      , m_ConfigValue                                   , 0x8)
        SCHEMA_FIELD(::CUtlString                    , m_BoundValuePath                                , 0x18)
        SCHEMA_FIELD(ParticleAttachment_t            , m_iAttachType                                   , 0x20)
        SCHEMA_FIELD(::CUtlString                    , m_strEntityScope                                , 0x28)
        SCHEMA_FIELD(::CUtlString                    , m_strAttachmentName                             , 0x30)
    };

    class CAnimUpdateNodeBase {
    public:
        SCHEMA_FIELD(CAnimNodePath                   , m_nodePath                                      , 0x18)
        SCHEMA_FIELD(AnimNodeNetworkMode             , m_networkMode                                   , 0x48)
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x50)
    };

    class CAnimEnum {
    public:
        SCHEMA_FIELD(std::uint8_t                    , m_value                                         , 0x0)
    };

    class CNmFootEvent {
    public:
        SCHEMA_FIELD(NmFootPhase_t                   , m_phase                                         , 0x18)
    };

    class CNmSyncTrack_EventMarker_t {
    public:
        SCHEMA_FIELD(NmPercent_t                     , m_startTime                                     , 0x0)
        SCHEMA_FIELD(CGlobalSymbol                   , m_ID                                            , 0x8)
    };

    class FootPinningPoseOpFixedData_t {
    public:
        SCHEMA_FIELD(CUtlVector<FootFixedData_t>     , m_footInfo                                      , 0x0)
        SCHEMA_FIELD(float                           , m_flBlendTime                                   , 0x18)
        SCHEMA_FIELD(float                           , m_flLockBreakDistance                           , 0x1C)
        SCHEMA_FIELD(float                           , m_flMaxLegTwist                                 , 0x20)
        SCHEMA_FIELD(std::int32_t                    , m_nHipBoneIndex                                 , 0x24)
        SCHEMA_FIELD(bool                            , m_bApplyLegTwistLimits                          , 0x28)
        SCHEMA_FIELD(bool                            , m_bApplyFootRotationLimits                      , 0x29)
    };

    class CFootStepTriggerUpdateNode {
    public:
        SCHEMA_FIELD(CUtlVector<FootStepTrigger>     , m_triggers                                      , 0x70)
        SCHEMA_FIELD(float                           , m_flTolerance                                   , 0x8C)
    };

    class CPulseCell_Outflow_CycleShuffled_InstanceState_t {
    public:
        using _Type0 = CUtlVectorFixedGrowable<uint8,8>;
        SCHEMA_FIELD(_Type0                          , m_Shuffle                                       , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nNextShuffle                                  , 0x20)
    };

    class CModelConfigElement_SetMaterialGroupOnAttachedModels {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_MaterialGroupName                             , 0x48)
    };

    class CAnimBoneDifference {
    public:
        SCHEMA_FIELD(CBufferString                   , m_name                                          , 0x0)
        SCHEMA_FIELD(CBufferString                   , m_parent                                        , 0x10)
        SCHEMA_FIELD(::Vector                        , m_posError                                      , 0x20)
        SCHEMA_FIELD(bool                            , m_bHasRotation                                  , 0x2C)
        SCHEMA_FIELD(bool                            , m_bHasMovement                                  , 0x2D)
    };

    class CAnimUser {
    public:
        SCHEMA_FIELD(CBufferString                   , m_name                                          , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nType                                         , 0x10)
    };

    class FollowTargetOpFixedSettings_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_boneIndex                                     , 0x0)
        SCHEMA_FIELD(bool                            , m_bBoneTarget                                   , 0x4)
        SCHEMA_FIELD(std::int32_t                    , m_boneTargetIndex                               , 0x8)
        SCHEMA_FIELD(bool                            , m_bWorldCoodinateTarget                         , 0xC)
        SCHEMA_FIELD(bool                            , m_bMatchTargetOrientation                       , 0xD)
    };

    class CJumpHelperUpdateNode {
    public:
        SCHEMA_FIELD(CAnimParamHandle                , m_hTargetParam                                  , 0xB0)
        SCHEMA_FIELD(::Vector                        , m_flOriginalJumpMovement                        , 0xB4)
        SCHEMA_FIELD(float                           , m_flOriginalJumpDuration                        , 0xC0)
        SCHEMA_FIELD(float                           , m_flJumpStartCycle                              , 0xC4)
        SCHEMA_FIELD(float                           , m_flJumpEndCycle                                , 0xC8)
        SCHEMA_FIELD(JumpCorrectionMethod            , m_eCorrectionMethod                             , 0xCC)
        SCHEMA_FIELD(bool                            , m_bTranslationAxis                              , 0xD0)
        SCHEMA_FIELD(bool                            , m_bScaleSpeed                                   , 0xD3)
    };

    class CNmVirtualParameterBoneMaskNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nChildNodeIdx                                 , 0x10)
    };

    class VPhysXConstraintParams_t {
    public:
        SCHEMA_FIELD(std::int8_t                     , m_nType                                         , 0x0)
        SCHEMA_FIELD(std::int8_t                     , m_nTranslateMotion                              , 0x1)
        SCHEMA_FIELD(std::int8_t                     , m_nRotateMotion                                 , 0x2)
        SCHEMA_FIELD(std::int8_t                     , m_nFlags                                        , 0x3)
        SCHEMA_FIELD(::Vector                        , m_anchor                                        , 0x4)
        SCHEMA_FIELD(QuaternionStorage               , m_axes                                          , 0x1C)
        SCHEMA_FIELD(float                           , m_maxForce                                      , 0x3C)
        SCHEMA_FIELD(float                           , m_maxTorque                                     , 0x40)
        SCHEMA_FIELD(float                           , m_linearLimitValue                              , 0x44)
        SCHEMA_FIELD(float                           , m_linearLimitRestitution                        , 0x48)
        SCHEMA_FIELD(float                           , m_linearLimitSpring                             , 0x4C)
        SCHEMA_FIELD(float                           , m_linearLimitDamping                            , 0x50)
        SCHEMA_FIELD(float                           , m_twistLowLimitValue                            , 0x54)
        SCHEMA_FIELD(float                           , m_twistLowLimitRestitution                      , 0x58)
        SCHEMA_FIELD(float                           , m_twistLowLimitSpring                           , 0x5C)
        SCHEMA_FIELD(float                           , m_twistLowLimitDamping                          , 0x60)
        SCHEMA_FIELD(float                           , m_twistHighLimitValue                           , 0x64)
        SCHEMA_FIELD(float                           , m_twistHighLimitRestitution                     , 0x68)
        SCHEMA_FIELD(float                           , m_twistHighLimitSpring                          , 0x6C)
        SCHEMA_FIELD(float                           , m_twistHighLimitDamping                         , 0x70)
        SCHEMA_FIELD(float                           , m_swing1LimitValue                              , 0x74)
        SCHEMA_FIELD(float                           , m_swing1LimitRestitution                        , 0x78)
        SCHEMA_FIELD(float                           , m_swing1LimitSpring                             , 0x7C)
        SCHEMA_FIELD(float                           , m_swing1LimitDamping                            , 0x80)
        SCHEMA_FIELD(float                           , m_swing2LimitValue                              , 0x84)
        SCHEMA_FIELD(float                           , m_swing2LimitRestitution                        , 0x88)
        SCHEMA_FIELD(float                           , m_swing2LimitSpring                             , 0x8C)
        SCHEMA_FIELD(float                           , m_swing2LimitDamping                            , 0x90)
        SCHEMA_FIELD(::Vector                        , m_goalPosition                                  , 0x94)
        SCHEMA_FIELD(QuaternionStorage               , m_goalOrientation                               , 0xA0)
        SCHEMA_FIELD(::Vector                        , m_goalAngularVelocity                           , 0xB0)
        SCHEMA_FIELD(float                           , m_driveSpringX                                  , 0xBC)
        SCHEMA_FIELD(float                           , m_driveSpringY                                  , 0xC0)
        SCHEMA_FIELD(float                           , m_driveSpringZ                                  , 0xC4)
        SCHEMA_FIELD(float                           , m_driveDampingX                                 , 0xC8)
        SCHEMA_FIELD(float                           , m_driveDampingY                                 , 0xCC)
        SCHEMA_FIELD(float                           , m_driveDampingZ                                 , 0xD0)
        SCHEMA_FIELD(float                           , m_driveSpringTwist                              , 0xD4)
        SCHEMA_FIELD(float                           , m_driveSpringSwing                              , 0xD8)
        SCHEMA_FIELD(float                           , m_driveSpringSlerp                              , 0xDC)
        SCHEMA_FIELD(float                           , m_driveDampingTwist                             , 0xE0)
        SCHEMA_FIELD(float                           , m_driveDampingSwing                             , 0xE4)
        SCHEMA_FIELD(float                           , m_driveDampingSlerp                             , 0xE8)
        SCHEMA_FIELD(std::int32_t                    , m_solverIterationCount                          , 0xEC)
        SCHEMA_FIELD(float                           , m_projectionLinearTolerance                     , 0xF0)
        SCHEMA_FIELD(float                           , m_projectionAngularTolerance                    , 0xF4)
    };

    class CBoneConstraintPoseSpaceBone_Input_t {
    public:
        SCHEMA_FIELD(::Vector                        , m_inputValue                                    , 0x0)
        SCHEMA_FIELD(CUtlVector<CTransform>          , m_outputTransformList                           , 0x10)
    };

    class CTwistConstraint {
    public:
        SCHEMA_FIELD(bool                            , m_bInverse                                      , 0x60)
        SCHEMA_FIELD(::Quaternion                    , m_qParentBindRotation                           , 0x70)
        SCHEMA_FIELD(::Quaternion                    , m_qChildBindRotation                            , 0x80)
    };

    class CNmTargetWarpEvent {
    public:
        SCHEMA_FIELD(NmTargetWarpRule_t              , m_rule                                          , 0x18)
        SCHEMA_FIELD(NmTargetWarpAlgorithm_t         , m_algorithm                                     , 0x19)
    };

    class CChoreoInstanceData {
    public:
        SCHEMA_FIELD(CAnimationLayer                 , m_AnimOverlay                                   , 0x0)
    };

    class PulseRuntimeConstantIndex_t {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_Value                                         , 0x0)
    };

    class JiggleBoneSettingsList_t {
    public:
        SCHEMA_FIELD(CUtlVector<JiggleBoneSettings_t>, m_boneSettings                                  , 0x0)
    };

    class BlendItem_t {
    public:
        SCHEMA_FIELD(CUtlVector<TagSpan_t>           , m_tags                                          , 0x0)
        SCHEMA_FIELD(CAnimUpdateNodeRef              , m_pChild                                        , 0x18)
        SCHEMA_FIELD(HSequence                       , m_hSequence                                     , 0x28)
        SCHEMA_FIELD(::Vector2D                      , m_vPos                                          , 0x2C)
        SCHEMA_FIELD(float                           , m_flDuration                                    , 0x34)
        SCHEMA_FIELD(bool                            , m_bUseCustomDuration                            , 0x38)
    };

    class CNmTargetSelectorNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,8>;
        SCHEMA_FIELD(_Type0                          , m_optionNodeIndices                             , 0x10)
        SCHEMA_FIELD(float                           , m_flOrientationScoreWeight                      , 0x28)
        SCHEMA_FIELD(float                           , m_flPositionScoreWeight                         , 0x2C)
        SCHEMA_FIELD(std::int16_t                    , m_parameterNodeIdx                              , 0x30)
        SCHEMA_FIELD(bool                            , m_bIgnoreInvalidOptions                         , 0x32)
        SCHEMA_FIELD(bool                            , m_bIsWorldSpaceTarget                           , 0x33)
    };

    class CNmClipSelectorNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,8>;
        using _Type1 = CUtlLeanVectorFixedGrowable<int16,8>;
        SCHEMA_FIELD(_Type0                          , m_optionNodeIndices                             , 0x10)
        SCHEMA_FIELD(_Type1                          , m_conditionNodeIndices                          , 0x28)
    };

    class CPulseCell_Inflow_Wait {
    public:
        SCHEMA_FIELD(CPulse_ResumePoint              , m_WakeResume                                    , 0x48)
    };

    class CModelConfigList {
    public:
        SCHEMA_FIELD(bool                            , m_bHideMaterialGroupInTools                     , 0x0)
        SCHEMA_FIELD(bool                            , m_bHideRenderColorInTools                       , 0x1)
        SCHEMA_FIELD(CUtlVector<CModelConfig*>       , m_Configs                                       , 0x8)
    };

    class CNmStateNode_TimedEvent_t {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_ID                                            , 0x0)
        SCHEMA_FIELD(float                           , m_flTimeValueSeconds                            , 0x8)
        SCHEMA_FIELD(CNmStateNode_TimedEvent_t_Comparison_t, m_comparisionOperator                           , 0xC)
    };

    class CMoverInstanceData {
    public:
        SCHEMA_FIELD(float                           , m_flDampedValue                                 , 0x0)
        SCHEMA_FIELD(::Vector                        , m_vMovement                                     , 0x4)
        SCHEMA_FIELD(CRotation                       , m_Rotation                                      , 0x1C)
        SCHEMA_FIELD(CRotation                       , m_TargetOrientation                             , 0x20)
    };

    class CNmOrientationWarpNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nClipReferenceNodeIdx                         , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nTargetValueNodeIdx                           , 0x12)
        SCHEMA_FIELD(bool                            , m_bIsOffsetNode                                 , 0x14)
        SCHEMA_FIELD(bool                            , m_bIsOffsetRelativeToCharacter                  , 0x15)
        SCHEMA_FIELD(bool                            , m_bWarpTranslation                              , 0x16)
        SCHEMA_FIELD(CNmRootMotionData_SamplingMode_t, m_samplingMode                                  , 0x17)
    };

    class CFootAdjustmentUpdateNode {
    public:
        SCHEMA_FIELD(CUtlVector<HSequence>           , m_clips                                         , 0x78)
        SCHEMA_FIELD(CPoseHandle                     , m_hBasePoseCacheHandle                          , 0x90)
        SCHEMA_FIELD(CAnimParamHandle                , m_facingTarget                                  , 0x94)
        SCHEMA_FIELD(float                           , m_flTurnTimeMin                                 , 0x98)
        SCHEMA_FIELD(float                           , m_flTurnTimeMax                                 , 0x9C)
        SCHEMA_FIELD(float                           , m_flStepHeightMax                               , 0xA0)
        SCHEMA_FIELD(float                           , m_flStepHeightMaxAngle                          , 0xA4)
        SCHEMA_FIELD(bool                            , m_bResetChild                                   , 0xA8)
        SCHEMA_FIELD(bool                            , m_bAnimationDriven                              , 0xA9)
    };

    class CIntAnimParameter {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_defaultValue                                  , 0x80)
        SCHEMA_FIELD(std::int32_t                    , m_minValue                                      , 0x84)
        SCHEMA_FIELD(std::int32_t                    , m_maxValue                                      , 0x88)
    };

    class CNmTargetValueNode_CDefinition {
    public:
    };

    class CSeqCmdLayer {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_cmd                                           , 0x0)
        SCHEMA_FIELD(std::int16_t                    , m_nLocalReference                               , 0x2)
        SCHEMA_FIELD(std::int16_t                    , m_nLocalBonemask                                , 0x4)
        SCHEMA_FIELD(std::int16_t                    , m_nDstResult                                    , 0x6)
        SCHEMA_FIELD(std::int16_t                    , m_nSrcResult                                    , 0x8)
        SCHEMA_FIELD(bool                            , m_bSpline                                       , 0xA)
        SCHEMA_FIELD(float                           , m_flVar1                                        , 0xC)
        SCHEMA_FIELD(float                           , m_flVar2                                        , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nLineNumber                                   , 0x14)
    };

    class CDirectPlaybackUpdateNode {
    public:
        SCHEMA_FIELD(bool                            , m_bFinishEarly                                  , 0x74)
        SCHEMA_FIELD(bool                            , m_bResetOnFinish                                , 0x75)
        SCHEMA_FIELD(CUtlVector<CDirectPlaybackTagData>, m_allTags                                       , 0x78)
    };

    class CPathHelperUpdateNode {
    public:
        SCHEMA_FIELD(float                           , m_flStoppingRadius                              , 0x70)
        SCHEMA_FIELD(float                           , m_flStoppingSpeedScale                          , 0x74)
    };

    class CNmTarget {
    public:
        SCHEMA_FIELD(CTransform                      , m_transform                                     , 0x0)
        SCHEMA_FIELD(CGlobalSymbol                   , m_boneID                                        , 0x20)
        SCHEMA_FIELD(bool                            , m_bIsBoneTarget                                 , 0x28)
        SCHEMA_FIELD(bool                            , m_bIsUsingBoneSpaceOffsets                      , 0x29)
        SCHEMA_FIELD(bool                            , m_bHasOffsets                                   , 0x2A)
        SCHEMA_FIELD(bool                            , m_bIsSet                                        , 0x2B)
    };

    class CCycleBase {
    public:
        SCHEMA_FIELD(float                           , m_flCycle                                       , 0x0)
    };

    class CParticleProperty {
    public:
    };

    class CAnimActivity {
    public:
        SCHEMA_FIELD(CBufferString                   , m_name                                          , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nActivity                                     , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nFlags                                        , 0x14)
        SCHEMA_FIELD(std::int32_t                    , m_nWeight                                       , 0x18)
    };

    class CPhysSurfacePropertiesAudio {
    public:
        SCHEMA_FIELD(float                           , m_reflectivity                                  , 0x0)
        SCHEMA_FIELD(float                           , m_hardnessFactor                                , 0x4)
        SCHEMA_FIELD(float                           , m_roughnessFactor                               , 0x8)
        SCHEMA_FIELD(float                           , m_roughThreshold                                , 0xC)
        SCHEMA_FIELD(float                           , m_hardThreshold                                 , 0x10)
        SCHEMA_FIELD(float                           , m_hardVelocityThreshold                         , 0x14)
        SCHEMA_FIELD(float                           , m_flStaticImpactVolume                          , 0x18)
        SCHEMA_FIELD(float                           , m_flOcclusionFactor                             , 0x1C)
    };

    class CAnimMotorUpdaterBase {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x10)
        SCHEMA_FIELD(bool                            , m_bDefault                                      , 0x18)
    };

    class CAnimTagManagerUpdater {
    public:
        SCHEMA_FIELD(CUtlVector<CSmartPtr<CAnimTagBase>>, m_tags                                          , 0x38)
    };

    class CRootUpdateNode {
    public:
    };

    class VPhysXCollisionAttributes_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nIncludeDetailLayerCount                      , 0x0)
        SCHEMA_FIELD(std::uint32_t                   , m_CollisionGroup                                , 0x4)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_InteractAs                                    , 0x8)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_InteractWith                                  , 0x20)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_InteractExclude                               , 0x38)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_DetailLayers                                  , 0x50)
        SCHEMA_FIELD(::CUtlString                    , m_CollisionGroupString                          , 0x68)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_InteractAsStrings                             , 0x70)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_InteractWithStrings                           , 0x88)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_InteractExcludeStrings                        , 0xA0)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_DetailLayerStrings                            , 0xB8)
    };

    class CChoreoUpdateNode {
    public:
    };

    class VPhysXConstraint2_t {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_nFlags                                        , 0x0)
        SCHEMA_FIELD(std::uint16_t                   , m_nParent                                       , 0x4)
        SCHEMA_FIELD(std::uint16_t                   , m_nChild                                        , 0x6)
        SCHEMA_FIELD(VPhysXConstraintParams_t        , m_params                                        , 0x8)
    };

    class FootFixedSettings {
    public:
        SCHEMA_FIELD(TraceSettings_t                 , m_traceSettings                                 , 0x0)
        SCHEMA_FIELD(VectorAligned                   , m_vFootBaseBindPosePositionMS                   , 0x10)
        SCHEMA_FIELD(float                           , m_flFootBaseLength                              , 0x20)
        SCHEMA_FIELD(float                           , m_flMaxRotationLeft                             , 0x24)
        SCHEMA_FIELD(float                           , m_flMaxRotationRight                            , 0x28)
        SCHEMA_FIELD(std::int32_t                    , m_footstepLandedTagIndex                        , 0x2C)
        SCHEMA_FIELD(bool                            , m_bEnableTracing                                , 0x30)
        SCHEMA_FIELD(float                           , m_flTraceAngleBlend                             , 0x34)
        SCHEMA_FIELD(std::int32_t                    , m_nDisableTagIndex                              , 0x38)
        SCHEMA_FIELD(std::int32_t                    , m_nFootIndex                                    , 0x3C)
    };

    class CNmClip_ModelSpaceSamplingChainLink_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nBoneIdx                                      , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nParentBoneIdx                                , 0x4)
        SCHEMA_FIELD(std::int32_t                    , m_nParentChainLinkIdx                           , 0x8)
    };

    class CNmTargetPointNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(bool                            , m_bIsWorldSpaceTarget                           , 0x12)
    };

    class CPulse_Chunk {
    public:
        SCHEMA_FIELD(CUtlLeanVector<PGDInstruction_t>, m_Instructions                                  , 0x0)
        SCHEMA_FIELD(CUtlLeanVector<CPulse_RegisterInfo>, m_Registers                                     , 0x10)
        SCHEMA_FIELD(CUtlLeanVector<CPulse_InstructionDebug>, m_InstructionDebugInfos                         , 0x20)
    };

    class CNmEvent {
    public:
        SCHEMA_FIELD(NmPercent_t                     , m_flStartTime                                   , 0x8)
        SCHEMA_FIELD(NmPercent_t                     , m_flDuration                                    , 0xC)
        SCHEMA_FIELD(CGlobalSymbol                   , m_syncID                                        , 0x10)
    };

    class AnimNodeOutputID {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_id                                            , 0x0)
    };

    class CAnimDesc {
    public:
        SCHEMA_FIELD(CBufferString                   , m_name                                          , 0x0)
        SCHEMA_FIELD(CAnimDesc_Flag                  , m_flags                                         , 0x10)
        SCHEMA_FIELD(float                           , fps                                             , 0x18)
        SCHEMA_FIELD(CAnimEncodedFrames              , m_Data                                          , 0x20)
        SCHEMA_FIELD(CUtlVector<CAnimMovement>       , m_movementArray                                 , 0xF8)
        SCHEMA_FIELD(CTransform                      , m_xInitialOffset                                , 0x110)
        SCHEMA_FIELD(CUtlVector<CAnimEventDefinition>, m_eventArray                                    , 0x130)
        SCHEMA_FIELD(CUtlVector<CAnimActivity>       , m_activityArray                                 , 0x148)
        SCHEMA_FIELD(CUtlVector<CAnimLocalHierarchy> , m_hierarchyArray                                , 0x160)
        SCHEMA_FIELD(float                           , framestalltime                                  , 0x178)
        SCHEMA_FIELD(::Vector                        , m_vecRootMin                                    , 0x17C)
        SCHEMA_FIELD(::Vector                        , m_vecRootMax                                    , 0x188)
        SCHEMA_FIELD(CUtlVector<Vector>              , m_vecBoneWorldMin                               , 0x198)
        SCHEMA_FIELD(CUtlVector<Vector>              , m_vecBoneWorldMax                               , 0x1B0)
        SCHEMA_FIELD(CAnimSequenceParams             , m_sequenceParams                                , 0x1C8)
    };

    class PulseGraphInstanceID_t {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_Value                                         , 0x0)
    };

    class PulseNodeDynamicOutflows_t_DynamicOutflow_t {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_OutflowID                                     , 0x0)
        SCHEMA_FIELD(CPulse_OutflowConnection        , m_Connection                                    , 0x8)
    };

    class VPhysXJoint_t {
    public:
        SCHEMA_FIELD(std::uint16_t                   , m_nType                                         , 0x0)
        SCHEMA_FIELD(std::uint16_t                   , m_nBody1                                        , 0x2)
        SCHEMA_FIELD(std::uint16_t                   , m_nBody2                                        , 0x4)
        SCHEMA_FIELD(std::uint16_t                   , m_nFlags                                        , 0x6)
        SCHEMA_FIELD(CTransform                      , m_Frame1                                        , 0x10)
        SCHEMA_FIELD(CTransform                      , m_Frame2                                        , 0x30)
        SCHEMA_FIELD(bool                            , m_bEnableCollision                              , 0x50)
        SCHEMA_FIELD(bool                            , m_bIsLinearConstraintDisabled                   , 0x51)
        SCHEMA_FIELD(bool                            , m_bIsAngularConstraintDisabled                  , 0x52)
        SCHEMA_FIELD(bool                            , m_bEnableLinearLimit                            , 0x53)
        SCHEMA_FIELD(VPhysXRange_t                   , m_LinearLimit                                   , 0x54)
        SCHEMA_FIELD(bool                            , m_bEnableLinearMotor                            , 0x5C)
        SCHEMA_FIELD(::Vector                        , m_vLinearTargetVelocity                         , 0x60)
        SCHEMA_FIELD(float                           , m_flMaxForce                                    , 0x6C)
        SCHEMA_FIELD(bool                            , m_bEnableSwingLimit                             , 0x70)
        SCHEMA_FIELD(VPhysXRange_t                   , m_SwingLimit                                    , 0x74)
        SCHEMA_FIELD(bool                            , m_bEnableTwistLimit                             , 0x7C)
        SCHEMA_FIELD(VPhysXRange_t                   , m_TwistLimit                                    , 0x80)
        SCHEMA_FIELD(bool                            , m_bEnableAngularMotor                           , 0x88)
        SCHEMA_FIELD(::Vector                        , m_vAngularTargetVelocity                        , 0x8C)
        SCHEMA_FIELD(float                           , m_flMaxTorque                                   , 0x98)
        SCHEMA_FIELD(float                           , m_flLinearFrequency                             , 0x9C)
        SCHEMA_FIELD(float                           , m_flLinearDampingRatio                          , 0xA0)
        SCHEMA_FIELD(float                           , m_flAngularFrequency                            , 0xA4)
        SCHEMA_FIELD(float                           , m_flAngularDampingRatio                         , 0xA8)
        SCHEMA_FIELD(float                           , m_flFriction                                    , 0xAC)
        SCHEMA_FIELD(float                           , m_flElasticity                                  , 0xB0)
        SCHEMA_FIELD(float                           , m_flElasticDamping                              , 0xB4)
        SCHEMA_FIELD(float                           , m_flPlasticity                                  , 0xB8)
        SCHEMA_FIELD(::CUtlString                    , m_Tag                                           , 0xC0)
    };

    class CSeqAutoLayerFlag {
    public:
        SCHEMA_FIELD(bool                            , m_bPost                                         , 0x0)
        SCHEMA_FIELD(bool                            , m_bSpline                                       , 0x1)
        SCHEMA_FIELD(bool                            , m_bXFade                                        , 0x2)
        SCHEMA_FIELD(bool                            , m_bNoBlend                                      , 0x3)
        SCHEMA_FIELD(bool                            , m_bLocal                                        , 0x4)
        SCHEMA_FIELD(bool                            , m_bPose                                         , 0x5)
        SCHEMA_FIELD(bool                            , m_bFetchFrame                                   , 0x6)
        SCHEMA_FIELD(bool                            , m_bSubtract                                     , 0x7)
    };

    class CPulseCell_Step_PublicOutput {
    public:
        SCHEMA_FIELD(PulseRuntimeOutputIndex_t       , m_OutputIndex                                   , 0x48)
    };

    class CDirectionalBlendInstanceData {
    public:
        SCHEMA_FIELD(float                           , m_dampedValue                                   , 0x0)
        SCHEMA_FIELD(float                           , m_flCycle                                       , 0x14)
        SCHEMA_FIELD(float                           , m_flPrevCycle                                   , 0x18)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flPlaybackRate                                , 0x1C)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flCycleZeroTime                               , 0x28)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_resetCycleValue                               , 0x34)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_resetCount                                    , 0x40)
    };

    class CConstraintTarget {
    public:
        SCHEMA_FIELD(::Quaternion                    , m_qOffset                                       , 0x20)
        SCHEMA_FIELD(::Vector                        , m_vOffset                                       , 0x30)
        SCHEMA_FIELD(std::uint32_t                   , m_nBoneHash                                     , 0x3C)
        SCHEMA_FIELD(::CUtlString                    , m_sName                                         , 0x40)
        SCHEMA_FIELD(float                           , m_flWeight                                      , 0x48)
        SCHEMA_FIELD(bool                            , m_bIsAttachment                                 , 0x59)
    };

    class HSequence {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_Value                                         , 0x0)
    };

    class CMotionDataSet {
    public:
        SCHEMA_FIELD(CUtlVector<CMotionGraphGroup>   , m_groups                                        , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nDimensionCount                               , 0x18)
    };

    class ModelMeshBufferData_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nBlockIndex                                   , 0x0)
        SCHEMA_FIELD(std::uint32_t                   , m_nElementCount                                 , 0x4)
        SCHEMA_FIELD(std::uint32_t                   , m_nElementSizeInBytes                           , 0x8)
        SCHEMA_FIELD(bool                            , m_bMeshoptCompressed                            , 0xC)
        SCHEMA_FIELD(bool                            , m_bMeshoptIndexSequence                         , 0xD)
        SCHEMA_FIELD(std::int8_t                     , m_nMeshoptMeshletEncodeVersion                  , 0xE)
        SCHEMA_FIELD(bool                            , m_bCompressedZSTD                               , 0xF)
        SCHEMA_FIELD(bool                            , m_bCreateBufferSRV                              , 0x10)
        SCHEMA_FIELD(bool                            , m_bCreateBufferUAV                              , 0x11)
        SCHEMA_FIELD(bool                            , m_bCreateRawBuffer                              , 0x12)
        SCHEMA_FIELD(bool                            , m_bCreatePooledBuffer                           , 0x13)
        SCHEMA_FIELD(std::uint8_t                    , m_nBufferUsage                                  , 0x14)
        SCHEMA_FIELD(CUtlVector<RenderInputLayoutField_t>, m_inputLayoutFields                             , 0x18)
    };

    class CPulse_CallInfo {
    public:
        SCHEMA_FIELD(::PulseSymbol_t                 , m_PortName                                      , 0x0)
        SCHEMA_FIELD(::PulseDocNodeID_t              , m_nEditorNodeID                                 , 0x10)
        SCHEMA_FIELD(::PulseRegisterMap_t            , m_RegisterMap                                   , 0x18)
        SCHEMA_FIELD(::PulseDocNodeID_t              , m_CallMethodID                                  , 0x48)
        SCHEMA_FIELD(::PulseRuntimeChunkIndex_t      , m_nSrcChunk                                     , 0x4C)
        SCHEMA_FIELD(std::int32_t                    , m_nSrcInstruction                               , 0x50)
    };

    class CHitBox {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_sSurfaceProperty                              , 0x8)
        SCHEMA_FIELD(::CUtlString                    , m_sBoneName                                     , 0x10)
        SCHEMA_FIELD(::Vector                        , m_vMinBounds                                    , 0x18)
        SCHEMA_FIELD(::Vector                        , m_vMaxBounds                                    , 0x24)
        SCHEMA_FIELD(float                           , m_flShapeRadius                                 , 0x30)
        SCHEMA_FIELD(std::uint32_t                   , m_nBoneNameHash                                 , 0x34)
        SCHEMA_FIELD(std::int32_t                    , m_nGroupId                                      , 0x38)
        SCHEMA_FIELD(std::uint8_t                    , m_nShapeType                                    , 0x3C)
        SCHEMA_FIELD(bool                            , m_bTranslationOnly                              , 0x3D)
        SCHEMA_FIELD(std::uint32_t                   , m_CRC                                           , 0x40)
        SCHEMA_FIELD(::Color                         , m_cRenderColor                                  , 0x44)
        SCHEMA_FIELD(std::uint16_t                   , m_nHitBoxIndex                                  , 0x48)
    };

    class CAnimBone {
    public:
        SCHEMA_FIELD(CBufferString                   , m_name                                          , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_parent                                        , 0x10)
        SCHEMA_FIELD(::Vector                        , m_pos                                           , 0x14)
        SCHEMA_FIELD(QuaternionStorage               , m_quat                                          , 0x20)
        SCHEMA_FIELD(float                           , m_scale                                         , 0x30)
        SCHEMA_FIELD(QuaternionStorage               , m_qAlignment                                    , 0x34)
        SCHEMA_FIELD(std::int32_t                    , m_flags                                         , 0x44)
    };

    class CNmEntityAttributeIntEvent {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nIntValue                                     , 0x38)
    };

    class CTransitionUpdateData {
    public:
        SCHEMA_FIELD(std::uint8_t                    , m_srcStateIndex                                 , 0x0)
        SCHEMA_FIELD(std::uint8_t                    , m_destStateIndex                                , 0x1)

    };

    class CAnimMovement {
    public:
        SCHEMA_FIELD(std::int32_t                    , endframe                                        , 0x0)
        SCHEMA_FIELD(std::int32_t                    , motionflags                                     , 0x4)
        SCHEMA_FIELD(float                           , v0                                              , 0x8)
        SCHEMA_FIELD(float                           , v1                                              , 0xC)
        SCHEMA_FIELD(float                           , angle                                           , 0x10)
        SCHEMA_FIELD(::Vector                        , vector                                          , 0x14)
        SCHEMA_FIELD(::Vector                        , position                                        , 0x20)
    };

    class CPulseCell_IsRequirementValid {
    public:
    };

    class CPulseCell_Outflow_CycleOrdered_InstanceState_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nNextIndex                                    , 0x0)
    };

    class ParamSpan_t {
    public:
        SCHEMA_FIELD(CUtlVector<ParamSpanSample_t>   , m_samples                                       , 0x0)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParam                                        , 0x18)
        SCHEMA_FIELD(AnimParamType_t                 , m_eParamType                                    , 0x1A)
        SCHEMA_FIELD(float                           , m_flStartCycle                                  , 0x1C)
        SCHEMA_FIELD(float                           , m_flEndCycle                                    , 0x20)
    };

    class CSequenceGroupData {
    public:
        SCHEMA_FIELD(CBufferString                   , m_sName                                         , 0x10)
        SCHEMA_FIELD(std::uint32_t                   , m_nFlags                                        , 0x20)
        SCHEMA_FIELD(CUtlVector<CBufferString>       , m_localSequenceNameArray                        , 0x28)
        SCHEMA_FIELD(CUtlVector<CSeqS1SeqDesc>       , m_localS1SeqDescArray                           , 0x40)
        SCHEMA_FIELD(CUtlVector<CSeqS1SeqDesc>       , m_localMultiSeqDescArray                        , 0x58)
        SCHEMA_FIELD(CUtlVector<CSeqSynthAnimDesc>   , m_localSynthAnimDescArray                       , 0x70)
        SCHEMA_FIELD(CUtlVector<CSeqCmdSeqDesc>      , m_localCmdSeqDescArray                          , 0x88)
        SCHEMA_FIELD(CUtlVector<CSeqBoneMaskList>    , m_localBoneMaskArray                            , 0xA0)
        SCHEMA_FIELD(CUtlVector<CSeqScaleSet>        , m_localScaleSetArray                            , 0xB8)
        SCHEMA_FIELD(CUtlVector<CBufferString>       , m_localBoneNameArray                            , 0xD0)
        SCHEMA_FIELD(CBufferString                   , m_localNodeName                                 , 0xE8)
        SCHEMA_FIELD(CUtlVector<CSeqPoseParamDesc>   , m_localPoseParamArray                           , 0xF8)
        SCHEMA_FIELD(KeyValues3                      , m_keyValues                                     , 0x110)
        SCHEMA_FIELD(CUtlVector<CSeqIKLock>          , m_localIKAutoplayLockArray                      , 0x120)
    };

    class TargetSelectorInstanceData_t {
    public:
        SCHEMA_FIELD(CAnimNetVar<int32>              , m_currentIndex                                  , 0x0)
        SCHEMA_FIELD(CAnimNetVar<Vector>             , m_vMSRootMotionAnlyzerTarget                    , 0x1C)
    };

    class CNmFixedWeightBoneMaskNode_CDefinition {
    public:
        SCHEMA_FIELD(float                           , m_flBoneWeight                                  , 0x10)
    };

    class PermModelData_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(PermModelInfo_t                 , m_modelInfo                                     , 0x8)
        SCHEMA_FIELD(CUtlVector<PermModelExtPart_t>  , m_ExtParts                                      , 0x60)
        SCHEMA_FIELD(CUtlVector<CStrongHandle<InfoForResourceTypeCRenderMesh>>, m_refMeshes                                     , 0x78)
        SCHEMA_FIELD(CUtlVector<uint64>              , m_refMeshGroupMasks                             , 0x90)
        SCHEMA_FIELD(CUtlVector<uint64>              , m_refPhysGroupMasks                             , 0xA8)
        SCHEMA_FIELD(CUtlVector<uint8>               , m_refLODGroupMasks                              , 0xC0)
        SCHEMA_FIELD(CUtlVector<float32>             , m_lodGroupSwitchDistances                       , 0xD8)
        SCHEMA_FIELD(CUtlVector<CStrongHandle<InfoForResourceTypeCPhysAggregateData>>, m_refPhysicsData                                , 0xF0)
        SCHEMA_FIELD(CUtlVector<CStrongHandle<InfoForResourceTypeCPhysAggregateData>>, m_refPhysicsHitboxData                          , 0x108)
        SCHEMA_FIELD(CUtlVector<CStrongHandle<InfoForResourceTypeCAnimationGroup>>, m_refAnimGroups                                 , 0x120)
        SCHEMA_FIELD(CUtlVector<CStrongHandle<InfoForResourceTypeCSequenceGroupData>>, m_refSequenceGroups                             , 0x138)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_meshGroups                                    , 0x150)
        SCHEMA_FIELD(CUtlVector<MaterialGroup_t>     , m_materialGroups                                , 0x168)
        SCHEMA_FIELD(std::uint64_t                   , m_nDefaultMeshGroupMask                         , 0x180)
        SCHEMA_FIELD(ModelSkeletonData_t             , m_modelSkeleton                                 , 0x188)
        SCHEMA_FIELD(CUtlVector<int16>               , m_remappingTable                                , 0x230)
        SCHEMA_FIELD(CUtlVector<uint16>              , m_remappingTableStarts                          , 0x248)
        SCHEMA_FIELD(CUtlVector<ModelBoneFlexDriver_t>, m_boneFlexDrivers                               , 0x260)
        SCHEMA_FIELD(CModelConfigList*               , m_pModelConfigList                              , 0x278)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_BodyGroupsHiddenInTools                       , 0x280)
        SCHEMA_FIELD(CUtlVector<CStrongHandle<InfoForResourceTypeCModel>>, m_refAnimIncludeModels                          , 0x298)
        SCHEMA_FIELD(CUtlVector<PermModelDataAnimatedMaterialAttribute_t>, m_AnimatedMaterialAttributes                    , 0x2B0)
        SCHEMA_FIELD(CUtlVector<ModelAnimGraph2Ref_t>, m_animGraph2Refs                                , 0x2C8)
        SCHEMA_FIELD(CUtlVector<CStrongHandle<InfoForResourceTypeCNmSkeleton>>, m_vecNmSkeletonRefs                             , 0x2E0)
    };

    class CParticleFloatInput {
    public:
        SCHEMA_FIELD(ParticleFloatType_t             , m_nType                                         , 0x10)
        SCHEMA_FIELD(ParticleFloatMapType_t          , m_nMapType                                      , 0x14)
        SCHEMA_FIELD(float                           , m_flLiteralValue                                , 0x18)
        SCHEMA_FIELD(CParticleNamedValueRef          , m_NamedValue                                    , 0x20)
        SCHEMA_FIELD(std::int32_t                    , m_nControlPoint                                 , 0x60)
        SCHEMA_FIELD(ParticleAttributeIndex_t        , m_nScalarAttribute                              , 0x64)
        SCHEMA_FIELD(ParticleAttributeIndex_t        , m_nVectorAttribute                              , 0x68)
        SCHEMA_FIELD(std::int32_t                    , m_nVectorComponent                              , 0x6C)
        SCHEMA_FIELD(bool                            , m_bReverseOrder                                 , 0x70)
        SCHEMA_FIELD(float                           , m_flRandomMin                                   , 0x74)
        SCHEMA_FIELD(float                           , m_flRandomMax                                   , 0x78)
        SCHEMA_FIELD(bool                            , m_bHasRandomSignFlip                            , 0x7C)
        SCHEMA_FIELD(std::int32_t                    , m_nRandomSeed                                   , 0x80)
        SCHEMA_FIELD(ParticleFloatRandomMode_t       , m_nRandomMode                                   , 0x84)
        SCHEMA_FIELD(::CUtlString                    , m_strSnapshotSubset                             , 0x90)
        SCHEMA_FIELD(float                           , m_flLOD0                                        , 0x98)
        SCHEMA_FIELD(float                           , m_flLOD1                                        , 0x9C)
        SCHEMA_FIELD(float                           , m_flLOD2                                        , 0xA0)
        SCHEMA_FIELD(float                           , m_flLOD3                                        , 0xA4)
        SCHEMA_FIELD(ParticleAttributeIndex_t        , m_nNoiseInputVectorAttribute                    , 0xA8)
        SCHEMA_FIELD(float                           , m_flNoiseOutputMin                              , 0xAC)
        SCHEMA_FIELD(float                           , m_flNoiseOutputMax                              , 0xB0)
        SCHEMA_FIELD(float                           , m_flNoiseScale                                  , 0xB4)
        SCHEMA_FIELD(::Vector                        , m_vecNoiseOffsetRate                            , 0xB8)
        SCHEMA_FIELD(float                           , m_flNoiseOffset                                 , 0xC4)
        SCHEMA_FIELD(std::int32_t                    , m_nNoiseOctaves                                 , 0xC8)
        SCHEMA_FIELD(PFNoiseTurbulence_t             , m_nNoiseTurbulence                              , 0xCC)
        SCHEMA_FIELD(PFNoiseType_t                   , m_nNoiseType                                    , 0xD0)
        SCHEMA_FIELD(PFNoiseModifier_t               , m_nNoiseModifier                                , 0xD4)
        SCHEMA_FIELD(float                           , m_flNoiseTurbulenceScale                        , 0xD8)
        SCHEMA_FIELD(float                           , m_flNoiseTurbulenceMix                          , 0xDC)
        SCHEMA_FIELD(float                           , m_flNoiseImgPreviewScale                        , 0xE0)
        SCHEMA_FIELD(bool                            , m_bNoiseImgPreviewLive                          , 0xE4)
        SCHEMA_FIELD(float                           , m_flNoCameraFallback                            , 0xF0)
        SCHEMA_FIELD(bool                            , m_bUseBoundsCenter                              , 0xF4)
        SCHEMA_FIELD(ParticleFloatInputMode_t        , m_nInputMode                                    , 0xF8)
        SCHEMA_FIELD(float                           , m_flMultFactor                                  , 0xFC)
        SCHEMA_FIELD(float                           , m_flInput0                                      , 0x100)
        SCHEMA_FIELD(float                           , m_flInput1                                      , 0x104)
        SCHEMA_FIELD(float                           , m_flOutput0                                     , 0x108)
        SCHEMA_FIELD(float                           , m_flOutput1                                     , 0x10C)
        SCHEMA_FIELD(float                           , m_flNotchedRangeMin                             , 0x110)
        SCHEMA_FIELD(float                           , m_flNotchedRangeMax                             , 0x114)
        SCHEMA_FIELD(float                           , m_flNotchedOutputOutside                        , 0x118)
        SCHEMA_FIELD(float                           , m_flNotchedOutputInside                         , 0x11C)
        SCHEMA_FIELD(ParticleFloatRoundType_t        , m_nRoundType                                    , 0x120)
        SCHEMA_FIELD(ParticleFloatBiasType_t         , m_nBiasType                                     , 0x124)
        SCHEMA_FIELD(float                           , m_flBiasParameter                               , 0x128)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_Curve                                         , 0x130)
    };

    class CNmFootIKTask {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nLeftEffectorBoneIdx                          , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_nRightEffectorBoneIdx                         , 0x4C)
        SCHEMA_FIELD(CTransform                      , m_leftTargetTransform                           , 0x50)
        SCHEMA_FIELD(CTransform                      , m_rightTargetTransform                          , 0x70)
        SCHEMA_FIELD(std::int32_t                    , m_nLeftTargetBoneIdx                            , 0x90)
        SCHEMA_FIELD(std::int32_t                    , m_nRightTargetBoneIdx                           , 0x94)
        SCHEMA_FIELD(CNmTarget                       , m_leftTarget                                    , 0xA0)
        SCHEMA_FIELD(CNmTarget                       , m_rightTarget                                   , 0xD0)
        SCHEMA_FIELD(NmIKBlendMode_t                 , m_blendMode                                     , 0x100)
        SCHEMA_FIELD(float                           , m_flBlendWeight                                 , 0x104)
        SCHEMA_FIELD(bool                            , m_bIsTargetInWorldSpace                         , 0x108)
        SCHEMA_FIELD(bool                            , m_bIsRunningFromDeserializedData                , 0x109)
    };

    class FootFixedData_t {
    public:
        SCHEMA_FIELD(VectorAligned                   , m_vToeOffset                                    , 0x0)
        SCHEMA_FIELD(VectorAligned                   , m_vHeelOffset                                   , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nTargetBoneIndex                              , 0x20)
        SCHEMA_FIELD(std::int32_t                    , m_nAnkleBoneIndex                               , 0x24)
        SCHEMA_FIELD(std::int32_t                    , m_nIKAnchorBoneIndex                            , 0x28)
        SCHEMA_FIELD(std::int32_t                    , m_ikChainIndex                                  , 0x2C)
        SCHEMA_FIELD(float                           , m_flMaxIKLength                                 , 0x30)
        SCHEMA_FIELD(std::int32_t                    , m_nFootIndex                                    , 0x34)
        SCHEMA_FIELD(std::int32_t                    , m_nTagIndex                                     , 0x38)
        SCHEMA_FIELD(float                           , m_flMaxRotationLeft                             , 0x3C)
        SCHEMA_FIELD(float                           , m_flMaxRotationRight                            , 0x40)
    };

    class AnimationSnapshotBase_t {
    public:
        SCHEMA_FIELD(float                           , m_flRealTime                                    , 0x0)
        SCHEMA_FIELD(matrix3x4a_t                    , m_rootToWorld                                   , 0x10)
        SCHEMA_FIELD(bool                            , m_bBonesInWorldSpace                            , 0x40)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_boneSetupMask                                 , 0x48)
        SCHEMA_FIELD(CUtlVector<matrix3x4a_t>        , m_boneTransforms                                , 0x60)
        SCHEMA_FIELD(CUtlVector<float32>             , m_flexControllers                               , 0x78)
        SCHEMA_FIELD(AnimationSnapshotType_t         , m_SnapshotType                                  , 0x90)
        SCHEMA_FIELD(bool                            , m_bHasDecodeDump                                , 0x94)
        SCHEMA_FIELD(AnimationDecodeDebugDumpElement_t, m_DecodeDump                                    , 0x98)
    };

    class CSelectorUpdateNode {
    public:
        SCHEMA_FIELD(CUtlVector<CAnimUpdateNodeRef>  , m_children                                      , 0x60)
        SCHEMA_FIELD(CUtlVector<int8>                , m_tags                                          , 0x78)
        SCHEMA_FIELD(CBlendCurve                     , m_blendCurve                                    , 0x94)
        SCHEMA_FIELD(CAnimValue<float32>             , m_flBlendTime                                   , 0x9C)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParameter                                    , 0xA4)
        SCHEMA_FIELD(std::int32_t                    , m_nTagIndex                                     , 0xA8)
        SCHEMA_FIELD(SelectorTagBehavior_t           , m_eTagBehavior                                  , 0xAC)
        SCHEMA_FIELD(bool                            , m_bResetOnChange                                , 0xB0)
        SCHEMA_FIELD(bool                            , m_bLockWhenWaning                               , 0xB1)
        SCHEMA_FIELD(bool                            , m_bSyncCyclesOnChange                           , 0xB2)
    };

    class CNmIDSwitchNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nSwitchValueNodeIdx                           , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nTrueValueNodeIdx                             , 0x12)
        SCHEMA_FIELD(std::int16_t                    , m_nFalseValueNodeIdx                            , 0x14)
        SCHEMA_FIELD(CGlobalSymbol                   , m_falseValue                                    , 0x18)
        SCHEMA_FIELD(CGlobalSymbol                   , m_trueValue                                     , 0x20)
    };

    class CNmTimeConditionNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_sourceStateNodeIdx                            , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x12)
        SCHEMA_FIELD(float                           , m_flComparand                                   , 0x14)
        SCHEMA_FIELD(CNmTimeConditionNode_ComparisonType_t, m_type                                          , 0x18)
        SCHEMA_FIELD(CNmTimeConditionNode_Operator_t , m_operator                                      , 0x19)
    };

    class CModelConfigElement_SetBodygroupOnAttachedModels {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_GroupName                                     , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_nChoice                                       , 0x50)
    };

    class CNmReferencedGraphNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nReferencedGraphIdx                           , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nFallbackNodeIdx                              , 0x12)
    };

    class CPulseExecCursor {
    public:
    };

    class CNmSkeleton {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_ID                                            , 0x0)
        SCHEMA_FIELD(CUtlLeanVector<CGlobalSymbol>   , m_boneIDs                                       , 0x8)
        SCHEMA_FIELD(CUtlVector<int32>               , m_parentIndices                                 , 0x18)
        SCHEMA_FIELD(CUtlVector<CTransform>          , m_parentSpaceReferencePose                      , 0x30)
        SCHEMA_FIELD(CUtlVector<CTransform>          , m_modelSpaceReferencePose                       , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_numBonesToSampleAtLowLOD                      , 0x60)
        SCHEMA_FIELD(CUtlLeanVector<NmBoneMaskSetDefinition_t>, m_maskDefinitions                               , 0x88)
        SCHEMA_FIELD(CUtlLeanVector<CNmSkeleton_SecondarySkeleton_t>, m_secondarySkeletons                            , 0xA8)
        SCHEMA_FIELD(bool                            , m_bIsPropSkeleton                               , 0xB8)
    };

    class CParticleTransformInput {
    public:
        SCHEMA_FIELD(ParticleTransformType_t         , m_nType                                         , 0x10)
        SCHEMA_FIELD(CParticleNamedValueRef          , m_NamedValue                                    , 0x18)
        SCHEMA_FIELD(bool                            , m_bFollowNamedValue                             , 0x58)
        SCHEMA_FIELD(bool                            , m_bSupportsDisabled                             , 0x59)
        SCHEMA_FIELD(bool                            , m_bUseOrientation                               , 0x5A)
        SCHEMA_FIELD(std::int32_t                    , m_nControlPoint                                 , 0x5C)
        SCHEMA_FIELD(std::int32_t                    , m_nControlPointRangeMax                         , 0x60)
        SCHEMA_FIELD(float                           , m_flEndCPGrowthTime                             , 0x64)
    };

    class CCPPScriptComponentUpdater {
    public:
        SCHEMA_FIELD(CUtlVector<CGlobalSymbol>       , m_scriptsToRun                                  , 0x30)
    };

    class CNmFloatMathNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdxA                           , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdxB                           , 0x12)
        SCHEMA_FIELD(bool                            , m_bReturnAbsoluteResult                         , 0x14)
        SCHEMA_FIELD(bool                            , m_bReturnNegatedResult                          , 0x15)
        SCHEMA_FIELD(CNmFloatMathNode_Operator_t     , m_operator                                      , 0x16)
        SCHEMA_FIELD(float                           , m_flValueB                                      , 0x18)
    };

    class CPulseCell_Inflow_Yield {
    public:
        SCHEMA_FIELD(CPulse_ResumePoint              , m_UnyieldResume                                 , 0x48)
    };

    class CParamSpanUpdater {
    public:
        SCHEMA_FIELD(CUtlVector<ParamSpan_t>         , m_spans                                         , 0x0)
    };

    class PulseRuntimeChunkIndex_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_Value                                         , 0x0)
    };

    class CPulse_Variable {
    public:
        SCHEMA_FIELD(::PulseSymbol_t                 , m_Name                                          , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_Description                                   , 0x10)
        SCHEMA_FIELD(CPulseValueFullType             , m_Type                                          , 0x18)
        SCHEMA_FIELD(KeyValues3                      , m_DefaultValue                                  , 0x30)
        SCHEMA_FIELD(PulseVariableKeysSource_t       , m_nKeysSource                                   , 0x44)
        SCHEMA_FIELD(bool                            , m_bIsPublicBlackboardVariable                   , 0x48)
        SCHEMA_FIELD(bool                            , m_bIsObservable                                 , 0x49)
        SCHEMA_FIELD(::PulseDocNodeID_t              , m_nEditorNodeID                                 , 0x4C)
    };

    class CParticleBindingRealPulse {
    public:
    };

    class PlayerInputMotorInstanceData_t {
    public:
        SCHEMA_FIELD(::Vector                        , m_vInputVectorWS                                , 0x0)
        SCHEMA_FIELD(::Vector                        , m_vVelocityWS                                   , 0xC)
        SCHEMA_FIELD(::Vector                        , m_vAccelerationWS                               , 0x18)
    };

    class CZeroPoseUpdateNode {
    public:
    };

    class CExpressionActionUpdater {
    public:
        SCHEMA_FIELD(CAnimParamHandle                , m_hParam                                        , 0x18)
        SCHEMA_FIELD(AnimParamType_t                 , m_eParamType                                    , 0x1A)
        SCHEMA_FIELD(AnimScriptHandle                , m_hScript                                       , 0x1C)
    };

    class CNmCachedIDNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(NmCachedValueMode_t             , m_mode                                          , 0x14)
    };

    class CFloatAnimParameter {
    public:
        SCHEMA_FIELD(float                           , m_fDefaultValue                                 , 0x80)
        SCHEMA_FIELD(float                           , m_fMinValue                                     , 0x84)
        SCHEMA_FIELD(float                           , m_fMaxValue                                     , 0x88)
        SCHEMA_FIELD(bool                            , m_bInterpolate                                  , 0x8C)
    };

    class CNmCachedTargetNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(NmCachedValueMode_t             , m_mode                                          , 0x14)
    };

    class CNmFloatCurveEventNode_CDefinition {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_eventID                                       , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nDefaultNodeIdx                               , 0x18)
        SCHEMA_FIELD(float                           , m_flDefaultValue                                , 0x1C)
        SCHEMA_FIELD(CNmBitFlags                     , m_eventConditionRules                           , 0x20)
    };

    class CModelConfig {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_ConfigName                                    , 0x0)
        SCHEMA_FIELD(CUtlVector<CModelConfigElement*>, m_Elements                                      , 0x8)
        SCHEMA_FIELD(bool                            , m_bTopLevel                                     , 0x20)
        SCHEMA_FIELD(bool                            , m_bActiveInEditorByDefault                      , 0x21)
    };

    class PulseGraphExecutionHistoryNodeDesc_t {
    public:
        SCHEMA_FIELD(CBufferString                   , strCellDesc                                     , 0x0)
        SCHEMA_FIELD(::PulseSymbol_t                 , strBindingName                                  , 0x10)
    };

    class CNmCachedVectorNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(NmCachedValueMode_t             , m_mode                                          , 0x14)
    };

    class CPulseCell_BaseYieldingInflow {
    public:
    };

    class CSingleFrameUpdateNode {
    public:
        SCHEMA_FIELD(CUtlVector<CSmartPtr<CAnimActionUpdater>>, m_actions                                       , 0x58)
        SCHEMA_FIELD(CPoseHandle                     , m_hPoseCacheHandle                              , 0x70)
        SCHEMA_FIELD(HSequence                       , m_hSequence                                     , 0x74)
        SCHEMA_FIELD(float                           , m_flCycle                                       , 0x78)
    };

    class CSequenceUpdateNode {
    public:
        SCHEMA_FIELD(HSequence                       , m_hSequence                                     , 0x78)
        SCHEMA_FIELD(float                           , m_duration                                      , 0x7C)
        SCHEMA_FIELD(CParamSpanUpdater               , m_paramSpans                                    , 0x80)
        SCHEMA_FIELD(CUtlVector<TagSpan_t>           , m_tags                                          , 0x98)
    };

    class CNmFloatRemapNode_RemapRange_t {
    public:
        SCHEMA_FIELD(float                           , m_flBegin                                       , 0x0)
        SCHEMA_FIELD(float                           , m_flEnd                                         , 0x4)
    };

    class CAttachment {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_influenceNames                                , 0x8)
        SCHEMA_FIELD(::Quaternion                    , m_vInfluenceRotations                           , 0x20)
        SCHEMA_FIELD(::Vector                        , m_vInfluenceOffsets                             , 0x50)
        SCHEMA_FIELD(float                           , m_influenceWeights                              , 0x74)
        SCHEMA_FIELD(bool                            , m_bInfluenceRootTransform                       , 0x80)
        SCHEMA_FIELD(std::uint8_t                    , m_nInfluences                                   , 0x83)
        SCHEMA_FIELD(bool                            , m_bIgnoreRotation                               , 0x84)
    };

    class PulseRuntimeDomainValueIndex_t {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_Value                                         , 0x0)
    };

    class CAddUpdateNode {
    public:
        SCHEMA_FIELD(BinaryNodeChildOption           , m_footMotionTiming                              , 0x94)
        SCHEMA_FIELD(bool                            , m_bApplyToFootMotion                            , 0x98)
        SCHEMA_FIELD(bool                            , m_bApplyChannelsSeparately                      , 0x99)
        SCHEMA_FIELD(bool                            , m_bUseModelSpace                                , 0x9A)
        SCHEMA_FIELD(bool                            , m_bApplyScale                                   , 0x9B)
    };

    class CNmBoneMaskSwitchNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nSwitchValueNodeIdx                           , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nTrueValueNodeIdx                             , 0x12)
        SCHEMA_FIELD(std::int16_t                    , m_nFalseValueNodeIdx                            , 0x14)
        SCHEMA_FIELD(float                           , m_flBlendTimeSeconds                            , 0x18)
        SCHEMA_FIELD(bool                            , m_bSwitchDynamically                            , 0x1C)
    };

    class CCachedPose {
    public:
        SCHEMA_FIELD(CUtlVector<CTransform>          , m_transforms                                    , 0x8)
        SCHEMA_FIELD(CUtlVector<float32>             , m_morphWeights                                  , 0x20)
        SCHEMA_FIELD(HSequence                       , m_hSequence                                     , 0x38)
        SCHEMA_FIELD(float                           , m_flCycle                                       , 0x3C)
    };

    class CMeshletDescriptor {
    public:
        SCHEMA_FIELD(PackedAABB_t                    , m_PackedAABB                                    , 0x0)
        SCHEMA_FIELD(CDrawCullingData                , m_CullingData                                   , 0x8)
        SCHEMA_FIELD(std::uint32_t                   , m_nVertexOffset                                 , 0xC)
        SCHEMA_FIELD(std::uint32_t                   , m_nTriangleOffset                               , 0x10)
        SCHEMA_FIELD(std::uint8_t                    , m_nVertexCount                                  , 0x14)
        SCHEMA_FIELD(std::uint8_t                    , m_nTriangleCount                                , 0x15)
    };

    class ModelBoneFlexDriverControl_t {
    public:
        SCHEMA_FIELD(ModelBoneFlexComponent_t        , m_nBoneComponent                                , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_flexController                                , 0x8)
        SCHEMA_FIELD(std::uint32_t                   , m_flexControllerToken                           , 0x10)
        SCHEMA_FIELD(float                           , m_flMin                                         , 0x14)
        SCHEMA_FIELD(float                           , m_flMax                                         , 0x18)
    };

    class CLeafUpdateNode {
    public:
    };

    class CAnimUpdateSharedData {
    public:
        using _Type0 = CUtlHashtable<CAnimNodePath,int32>;
        SCHEMA_FIELD(CUtlVector<CSmartPtr<CAnimUpdateNodeBase>>, m_nodes                                         , 0x10)
        SCHEMA_FIELD(_Type0                          , m_nodeIndexMap                                  , 0x28)
        SCHEMA_FIELD(CUtlVector<CSmartPtr<CAnimComponentUpdater>>, m_components                                    , 0x48)
        SCHEMA_FIELD(CSmartPtr<CAnimParameterManagerUpdater>, m_pParamListUpdater                             , 0x60)
        SCHEMA_FIELD(CSmartPtr<CAnimTagManagerUpdater>, m_pTagManagerUpdater                            , 0x68)
        SCHEMA_FIELD(CSmartPtr<CAnimScriptManager>   , m_scriptManager                                 , 0x70)
        SCHEMA_FIELD(CAnimGraphSettingsManager       , m_settings                                      , 0x78)
        SCHEMA_FIELD(CSmartPtr<CStaticPoseCacheBuilder>, m_pStaticPoseCache                              , 0xA8)
        SCHEMA_FIELD(CSmartPtr<CAnimSkeleton>        , m_pSkeleton                                     , 0xB0)
        SCHEMA_FIELD(CAnimNodePath                   , m_rootNodePath                                  , 0xB8)
    };

    class CNmVelocityBlendNode_CDefinition {
    public:
    };

    class CNmBlend1DNode_CDefinition {
    public:
        SCHEMA_FIELD(CNmParameterizedBlendNode_Parameterization_t, m_parameterization                              , 0x30)
    };

    class CNmFloatEaseNode_CDefinition {
    public:
        SCHEMA_FIELD(float                           , m_flEaseTime                                    , 0x10)
        SCHEMA_FIELD(float                           , m_flStartValue                                  , 0x14)
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x18)
        SCHEMA_FIELD(NmEasingOperation_t             , m_easingOp                                      , 0x1A)
        SCHEMA_FIELD(bool                            , m_bUseStartValue                                , 0x1B)
    };

    class FollowAttachmentSettings_t {
    public:
        SCHEMA_FIELD(CAnimAttachment                 , m_attachment                                    , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_boneIndex                                     , 0x80)
        SCHEMA_FIELD(AttachmentHandle_t              , m_attachmentHandle                              , 0x84)
        SCHEMA_FIELD(bool                            , m_bMatchTranslation                             , 0x85)
        SCHEMA_FIELD(bool                            , m_bMatchRotation                                , 0x86)
    };

    class CNmFootstepEventIDNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nSourceStateNodeIdx                           , 0x10)
        SCHEMA_FIELD(CNmBitFlags                     , m_eventConditionRules                           , 0x14)
    };

    class MotionSelection {
    public:
        SCHEMA_FIELD(NetVarConfigIndex               , m_nConfigIndex                                  , 0x24)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flCycleZeroTime                               , 0x30)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flPlaybackSpeed                               , 0x3C)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flStartTime                                   , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_nSample                                       , 0x54)
    };

    class CHitBoxSetList {
    public:
        SCHEMA_FIELD(CUtlVector<CHitBoxSet>          , m_HitBoxSets                                    , 0x0)
    };

    class CAnimNodePath {
    public:
        SCHEMA_FIELD(AnimNodeID                      , m_path                                          , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nCount                                        , 0x2C)
    };

    class CModelConfigElement_Command {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_Command                                       , 0x48)
        SCHEMA_FIELD(KeyValues3                      , m_Args                                          , 0x50)
    };

    class CNmLegacyEvent {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_animEventClassName                            , 0x18)
        SCHEMA_FIELD(KeyValues3                      , m_KV                                            , 0x20)
    };

    class CPulseCell_Value_Curve {
    public:
        SCHEMA_FIELD(CPiecewiseCurve                 , m_Curve                                         , 0x48)
    };

    class CPulse_BlackboardReference {
    public:
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeIPulseGraphDef>, m_hBlackboardResource                           , 0x0)
        SCHEMA_FIELD(::PulseSymbol_t                 , m_BlackboardResource                            , 0x8)
        SCHEMA_FIELD(::PulseDocNodeID_t              , m_nNodeID                                       , 0x18)
        SCHEMA_FIELD(CGlobalSymbol                   , m_NodeName                                      , 0x20)
    };

    class CNmSpeedScaleBaseNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x18)
        SCHEMA_FIELD(float                           , m_flDefaultInputValue                           , 0x1C)
    };

    class CPulseCursorFuncs {
    public:
    };

    class CSeqCmdSeqDesc {
    public:
        SCHEMA_FIELD(CBufferString                   , m_sName                                         , 0x0)
        SCHEMA_FIELD(CSeqSeqDescFlag                 , m_flags                                         , 0x10)
        SCHEMA_FIELD(CSeqTransition                  , m_transition                                    , 0x1C)
        SCHEMA_FIELD(std::int16_t                    , m_nFrameRangeSequence                           , 0x24)
        SCHEMA_FIELD(std::int16_t                    , m_nFrameCount                                   , 0x26)
        SCHEMA_FIELD(float                           , m_flFPS                                         , 0x28)
        SCHEMA_FIELD(std::int16_t                    , m_nSubCycles                                    , 0x2C)
        SCHEMA_FIELD(std::int16_t                    , m_numLocalResults                               , 0x2E)
        SCHEMA_FIELD(CUtlVector<CSeqCmdLayer>        , m_cmdLayerArray                                 , 0x30)
        SCHEMA_FIELD(CUtlVector<CAnimEventDefinition>, m_eventArray                                    , 0x48)
        SCHEMA_FIELD(CUtlVector<CAnimActivity>       , m_activityArray                                 , 0x60)
        SCHEMA_FIELD(CUtlVector<CSeqPoseSetting>     , m_poseSettingArray                              , 0x78)
    };

    class CSeqScaleSet {
    public:
        SCHEMA_FIELD(CBufferString                   , m_sName                                         , 0x0)
        SCHEMA_FIELD(bool                            , m_bRootOffset                                   , 0x10)
        SCHEMA_FIELD(::Vector                        , m_vRootOffset                                   , 0x14)
        SCHEMA_FIELD(CUtlVector<int16>               , m_nLocalBoneArray                               , 0x20)
        SCHEMA_FIELD(CUtlVector<float32>             , m_flBoneScaleArray                              , 0x38)
    };

    class TwoBoneIKSettings_t {
    public:
        SCHEMA_FIELD(IkEndEffectorType               , m_endEffectorType                               , 0x0)
        SCHEMA_FIELD(CAnimAttachment                 , m_endEffectorAttachment                         , 0x10)
        SCHEMA_FIELD(IkTargetType                    , m_targetType                                    , 0x90)
        SCHEMA_FIELD(CAnimAttachment                 , m_targetAttachment                              , 0xA0)
        SCHEMA_FIELD(std::int32_t                    , m_targetBoneIndex                               , 0x120)
        SCHEMA_FIELD(CAnimParamHandle                , m_hPositionParam                                , 0x124)
        SCHEMA_FIELD(CAnimParamHandle                , m_hRotationParam                                , 0x126)
        SCHEMA_FIELD(bool                            , m_bAlwaysUseFallbackHinge                       , 0x128)
        SCHEMA_FIELD(VectorAligned                   , m_vLsFallbackHingeAxis                          , 0x130)
        SCHEMA_FIELD(std::int32_t                    , m_nFixedBoneIndex                               , 0x140)
        SCHEMA_FIELD(std::int32_t                    , m_nMiddleBoneIndex                              , 0x144)
        SCHEMA_FIELD(std::int32_t                    , m_nEndBoneIndex                                 , 0x148)
        SCHEMA_FIELD(bool                            , m_bMatchTargetOrientation                       , 0x14C)
        SCHEMA_FIELD(bool                            , m_bConstrainTwist                               , 0x14D)
        SCHEMA_FIELD(float                           , m_flMaxTwist                                    , 0x150)
    };

    class CAnimEncodedFrames {
    public:
        SCHEMA_FIELD(CBufferString                   , m_fileName                                      , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nFrames                                       , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nFramesPerBlock                               , 0x14)
        SCHEMA_FIELD(CUtlVector<CAnimFrameBlockAnim> , m_frameblockArray                               , 0x18)
        SCHEMA_FIELD(CAnimEncodeDifference           , m_usageDifferences                              , 0x30)
    };

    class CSeqSeqDescFlag {
    public:
        SCHEMA_FIELD(bool                            , m_bLooping                                      , 0x0)
        SCHEMA_FIELD(bool                            , m_bSnap                                         , 0x1)
        SCHEMA_FIELD(bool                            , m_bAutoplay                                     , 0x2)
        SCHEMA_FIELD(bool                            , m_bPost                                         , 0x3)
        SCHEMA_FIELD(bool                            , m_bHidden                                       , 0x4)
        SCHEMA_FIELD(bool                            , m_bMulti                                        , 0x5)
        SCHEMA_FIELD(bool                            , m_bLegacyDelta                                  , 0x6)
        SCHEMA_FIELD(bool                            , m_bLegacyWorldspace                             , 0x7)
        SCHEMA_FIELD(bool                            , m_bLegacyCyclepose                              , 0x8)
        SCHEMA_FIELD(bool                            , m_bLegacyRealtime                               , 0x9)
        SCHEMA_FIELD(bool                            , m_bModelDoc                                     , 0xA)
    };

    class CAnimGraphDebugReplay {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_animGraphFileName                             , 0x40)
        SCHEMA_FIELD(CUtlVector<CSmartPtr<CAnimReplayFrame>>, m_frameList                                     , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_startIndex                                    , 0x60)
        SCHEMA_FIELD(std::int32_t                    , m_writeIndex                                    , 0x64)
        SCHEMA_FIELD(std::int32_t                    , m_frameCount                                    , 0x68)
    };

    class CAnimationGraphVisualizerLine {
    public:
        SCHEMA_FIELD(VectorAligned                   , m_vWsPositionStart                              , 0x40)
        SCHEMA_FIELD(VectorAligned                   , m_vWsPositionEnd                                , 0x50)
        SCHEMA_FIELD(::Color                         , m_Color                                         , 0x60)
    };

    class CFootStride {
    public:
        SCHEMA_FIELD(CFootCycleDefinition            , m_definition                                    , 0x0)
        SCHEMA_FIELD(CFootTrajectories               , m_trajectories                                  , 0x40)
    };

    class CNmRootMotionEvent {
    public:
        SCHEMA_FIELD(float                           , m_flBlendTimeSeconds                            , 0x18)
    };

    class CNmPassthroughNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nChildNodeIdx                                 , 0x10)
    };

    class CStanceScaleUpdateNode {
    public:
        SCHEMA_FIELD(CAnimParamHandle                , m_hParam                                        , 0x70)
    };

    class CSeqSynthAnimDesc {
    public:
        SCHEMA_FIELD(CBufferString                   , m_sName                                         , 0x0)
        SCHEMA_FIELD(CSeqSeqDescFlag                 , m_flags                                         , 0x10)
        SCHEMA_FIELD(CSeqTransition                  , m_transition                                    , 0x1C)
        SCHEMA_FIELD(std::int16_t                    , m_nLocalBaseReference                           , 0x24)
        SCHEMA_FIELD(std::int16_t                    , m_nLocalBoneMask                                , 0x26)
        SCHEMA_FIELD(CUtlVector<CAnimActivity>       , m_activityArray                                 , 0x28)
    };

    class CDirectPlaybackTagData {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_sequenceName                                  , 0x0)
        SCHEMA_FIELD(CUtlVector<TagSpan_t>           , m_tags                                          , 0x8)
    };

    class CAnimReplayFrame {
    public:
        SCHEMA_FIELD(CUtlVector<CUtlBinaryBlock>     , m_inputDataBlocks                               , 0x10)
        SCHEMA_FIELD(::CUtlBinaryBlock               , m_instanceData                                  , 0x28)
        SCHEMA_FIELD(CTransform                      , m_startingLocalToWorldTransform                 , 0x40)
        SCHEMA_FIELD(CTransform                      , m_localToWorldTransform                         , 0x60)
        SCHEMA_FIELD(float                           , m_timeStamp                                     , 0x80)
    };

    class CTurnHelperUpdateNode {
    public:
        SCHEMA_FIELD(AnimValueSource                 , m_facingTarget                                  , 0x74)
        SCHEMA_FIELD(float                           , m_turnStartTimeOffset                           , 0x78)
        SCHEMA_FIELD(float                           , m_turnDuration                                  , 0x7C)
        SCHEMA_FIELD(bool                            , m_bMatchChildDuration                           , 0x80)
        SCHEMA_FIELD(float                           , m_manualTurnOffset                              , 0x84)
        SCHEMA_FIELD(bool                            , m_bUseManualTurnOffset                          , 0x88)
    };

    class CStateActionUpdater {
    public:
        SCHEMA_FIELD(CSmartPtr<CAnimActionUpdater>   , m_pAction                                       , 0x0)
        SCHEMA_FIELD(StateActionBehavior             , m_eBehavior                                     , 0x8)
    };

    class CFootFallAnimTag {
    public:
        SCHEMA_FIELD(FootFallTagFoot_t               , m_foot                                          , 0x58)
    };

    class CAnimParamHandle {
    public:
        SCHEMA_FIELD(AnimParamType_t                 , m_type                                          , 0x0)
        SCHEMA_FIELD(std::uint8_t                    , m_index                                         , 0x1)
    };

    class SkeletonBoneBounds_t {
    public:
        SCHEMA_FIELD(::Vector                        , m_vecCenter                                     , 0x0)
        SCHEMA_FIELD(::Vector                        , m_vecSize                                       , 0xC)
    };

    class SkeletonAnimCapture_t_Frame_t {
    public:
        SCHEMA_FIELD(float                           , m_flTime                                        , 0x0)
        SCHEMA_FIELD(SkeletonAnimCapture_t_FrameStamp_t, m_Stamp                                         , 0x4)
        SCHEMA_FIELD(CTransform                      , m_Transform                                     , 0x20)
        SCHEMA_FIELD(bool                            , m_bTeleport                                     , 0x40)
        SCHEMA_FIELD(CUtlVector<CTransform>          , m_CompositeBones                                , 0x48)
        SCHEMA_FIELD(CUtlVector<CTransform>          , m_SimStateBones                                 , 0x60)
        SCHEMA_FIELD(CUtlVector<CTransform>          , m_FeModelAnims                                  , 0x78)
        SCHEMA_FIELD(CUtlVector<VectorAligned>       , m_FeModelPos                                    , 0x90)
        SCHEMA_FIELD(CUtlVector<float32>             , m_FlexControllerWeights                         , 0xA8)
    };

    class CMotionNodeSequence {
    public:
        SCHEMA_FIELD(CUtlVector<TagSpan_t>           , m_tags                                          , 0x28)
        SCHEMA_FIELD(HSequence                       , m_hSequence                                     , 0x40)
        SCHEMA_FIELD(float                           , m_flPlaybackSpeed                               , 0x44)
    };

    class CNmFollowBoneTask {
    public:
    };

    class CPulseCell_LimitCount {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nLimitCount                                   , 0x48)
    };

    class MoodAnimationLayer_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_sName                                         , 0x0)
        SCHEMA_FIELD(bool                            , m_bActiveListening                              , 0x8)
        SCHEMA_FIELD(bool                            , m_bActiveTalking                                , 0x9)
        SCHEMA_FIELD(CUtlVector<MoodAnimation_t>     , m_layerAnimations                               , 0x10)
        SCHEMA_FIELD(CRangeFloat                     , m_flIntensity                                   , 0x28)
        SCHEMA_FIELD(CRangeFloat                     , m_flDurationScale                               , 0x30)
        SCHEMA_FIELD(bool                            , m_bScaleWithInts                                , 0x38)
        SCHEMA_FIELD(CRangeFloat                     , m_flNextStart                                   , 0x3C)
        SCHEMA_FIELD(CRangeFloat                     , m_flStartOffset                                 , 0x44)
        SCHEMA_FIELD(CRangeFloat                     , m_flEndOffset                                   , 0x4C)
        SCHEMA_FIELD(float                           , m_flFadeIn                                      , 0x54)
        SCHEMA_FIELD(float                           , m_flFadeOut                                     , 0x58)
    };

    class CParticleInput {
    public:
    };

    class CProductQuantizer {
    public:
        SCHEMA_FIELD(CUtlVector<CVectorQuantizer>    , m_subQuantizers                                 , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nDimensions                                   , 0x18)
    };

    class CNmConstVectorNode_CDefinition {
    public:
        SCHEMA_FIELD(::Vector                        , m_value                                         , 0x10)
    };

    class CWarpSectionAnimTag {
    public:
        SCHEMA_FIELD(bool                            , m_bWarpPosition                                 , 0x50)
        SCHEMA_FIELD(bool                            , m_bWarpOrientation                              , 0x51)
    };

    class CNmCachedPoseReadTask {
    public:
    };

    class CNmTransitionEvent {
    public:
        SCHEMA_FIELD(NmTransitionRule_t              , m_rule                                          , 0x18)
        SCHEMA_FIELD(CGlobalSymbol                   , m_ID                                            , 0x20)
    };

    class CAnimationGraphVisualizerSphere {
    public:
        SCHEMA_FIELD(VectorAligned                   , m_vWsPosition                                   , 0x40)
        SCHEMA_FIELD(float                           , m_flRadius                                      , 0x50)
        SCHEMA_FIELD(::Color                         , m_Color                                         , 0x54)
    };

    class CNmGraphDefinition_ExternalGraphSlot_t {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nNodeIdx                                      , 0x0)
        SCHEMA_FIELD(CGlobalSymbol                   , m_slotID                                        , 0x8)
    };

    class CNmConstTargetNode_CDefinition {
    public:
        SCHEMA_FIELD(CNmTarget                       , m_value                                         , 0x10)
    };

    class CNmExternalPoseNode_CDefinition {
    public:
        SCHEMA_FIELD(bool                            , m_bShouldSampleRootMotion                       , 0x10)
    };

    class CPulseCell_IntervalTimer {
    public:
        SCHEMA_FIELD(CPulse_ResumePoint              , m_Completed                                     , 0x48)
        SCHEMA_FIELD(SignatureOutflow_Continue       , m_OnInterval                                    , 0x90)
    };

    class CNmFloatRangeComparisonNode_CDefinition {
    public:
        SCHEMA_FIELD(Range_t                         , m_range                                         , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x18)
        SCHEMA_FIELD(bool                            , m_bIsInclusiveCheck                             , 0x1A)
    };

    class CStateNodeStateData {
    public:
        SCHEMA_FIELD(CAnimUpdateNodeRef              , m_pChild                                        , 0x0)

    };

    class CFollowAttachmentUpdateNode {
    public:
        SCHEMA_FIELD(FollowAttachmentSettings_t      , m_opFixedData                                   , 0x70)
    };

    class CTwoBoneIKUpdateNode {
    public:
        SCHEMA_FIELD(TwoBoneIKSettings_t             , m_opFixedData                                   , 0x70)
    };

    class CAnimMorphDifference {
    public:
        SCHEMA_FIELD(CBufferString                   , m_name                                          , 0x0)
    };

    class CPulseCell_Value_RandomInt {
    public:
    };

    class PulseRuntimeInvokeIndex_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_Value                                         , 0x0)
    };

    class CPulseCell_BooleanSwitchState {
    public:
        SCHEMA_FIELD(PulseObservableBoolExpression_t , m_Condition                                     , 0x48)
        SCHEMA_FIELD(CPulse_OutflowConnection        , m_Always                                        , 0xC0)
        SCHEMA_FIELD(CPulse_OutflowConnection        , m_WhenTrue                                      , 0x108)
        SCHEMA_FIELD(CPulse_OutflowConnection        , m_WhenFalse                                     , 0x150)
    };

    class MaterialGroup_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(CUtlVector<CStrongHandle<InfoForResourceTypeIMaterial2>>, m_materials                                     , 0x8)
    };

    class PulseRuntimeRegisterIndex_t {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_Value                                         , 0x0)
    };

    class CFollowPathInstanceData {
    public:
        SCHEMA_FIELD(CRelativeArray<CMotionTransform>, m_xLastPredictedTransformsDeltas                , 0x0)
        SCHEMA_FIELD(float                           , m_dampedTurnValue                               , 0x8)
        SCHEMA_FIELD(float                           , m_flTurnAmount                                  , 0xC)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flPredictionScale                             , 0x10)
        SCHEMA_FIELD(float                           , m_flLastPathTime                                , 0x1C)
    };

    class SkeletonAnimCapture_t_Camera_t {
    public:
        SCHEMA_FIELD(CTransform                      , m_tmCamera                                      , 0x0)
        SCHEMA_FIELD(float                           , m_flTime                                        , 0x20)
    };

    class CParticleCollectionRendererVecInput {
    public:
    };

    class NmCompressionSettings_t_QuantizationRange_t {
    public:
        SCHEMA_FIELD(float                           , m_flRangeStart                                  , 0x0)
        SCHEMA_FIELD(float                           , m_flRangeLength                                 , 0x4)
    };

    class CNmSelectorNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,8>;
        using _Type1 = CUtlLeanVectorFixedGrowable<int16,8>;
        SCHEMA_FIELD(_Type0                          , m_optionNodeIndices                             , 0x10)
        SCHEMA_FIELD(_Type1                          , m_conditionNodeIndices                          , 0x28)
    };

    class SignatureOutflow_Continue {
    public:
    };

    class CJiggleBoneUpdateNode {
    public:
        SCHEMA_FIELD(JiggleBoneSettingsList_t        , m_opFixedData                                   , 0x70)
    };

    class CNmControlParameterBoolNode_CDefinition {
    public:
    };

    class IAnimationGraphInstance {
    public:
    };

    class CSymbolAnimParameter {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_defaultValue                                  , 0x80)
    };

    class CTaskStatusAnimTag {
    public:
    };

    class CAnimFrameSegment {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nUniqueFrameIndex                             , 0x0)
        SCHEMA_FIELD(std::uint32_t                   , m_nLocalElementMasks                            , 0x4)
        SCHEMA_FIELD(std::int32_t                    , m_nLocalChannel                                 , 0x8)
        SCHEMA_FIELD(::CUtlBinaryBlock               , m_container                                     , 0x10)
    };

    class CFootCycleDefinition {
    public:
        SCHEMA_FIELD(::Vector                        , m_vStancePositionMS                             , 0x0)
        SCHEMA_FIELD(::Vector                        , m_vMidpointPositionMS                           , 0xC)
        SCHEMA_FIELD(float                           , m_flStanceDirectionMS                           , 0x18)
        SCHEMA_FIELD(::Vector                        , m_vToStrideStartPos                             , 0x1C)
        SCHEMA_FIELD(CAnimCycle                      , m_stanceCycle                                   , 0x28)
        SCHEMA_FIELD(CFootCycle                      , m_footLiftCycle                                 , 0x2C)
        SCHEMA_FIELD(CFootCycle                      , m_footOffCycle                                  , 0x30)
        SCHEMA_FIELD(CFootCycle                      , m_footStrikeCycle                               , 0x34)
        SCHEMA_FIELD(CFootCycle                      , m_footLandCycle                                 , 0x38)
    };

    class CVirtualAnimParameter {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_expressionString                              , 0x70)
        SCHEMA_FIELD(AnimParamType_t                 , m_eParamType                                    , 0x78)
    };

    class CNmFloatClampNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(Range_t                         , m_clampRange                                    , 0x14)
    };

    class CModelConfigElement_AttachedModel {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_InstanceName                                  , 0x48)
        SCHEMA_FIELD(::CUtlString                    , m_EntityClass                                   , 0x50)
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeCModel>, m_hModel                                        , 0x58)
        SCHEMA_FIELD(::Vector                        , m_vOffset                                       , 0x60)
        SCHEMA_FIELD(::QAngle                        , m_aAngOffset                                    , 0x6C)
        SCHEMA_FIELD(::CUtlString                    , m_AttachmentName                                , 0x78)
        SCHEMA_FIELD(::CUtlString                    , m_LocalAttachmentOffsetName                     , 0x80)
        SCHEMA_FIELD(ModelConfigAttachmentType_t     , m_AttachmentType                                , 0x88)
        SCHEMA_FIELD(bool                            , m_bBoneMergeFlex                                , 0x8C)
        SCHEMA_FIELD(bool                            , m_bUserSpecifiedColor                           , 0x8D)
        SCHEMA_FIELD(bool                            , m_bUserSpecifiedMaterialGroup                   , 0x8E)
        SCHEMA_FIELD(::CUtlString                    , m_BodygroupOnOtherModels                        , 0x90)
        SCHEMA_FIELD(::CUtlString                    , m_MaterialGroupOnOtherModels                    , 0x98)
    };

    class CBoneConstraintPoseSpaceMorph {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_sBoneName                                     , 0x20)
        SCHEMA_FIELD(::CUtlString                    , m_sAttachmentName                               , 0x28)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_outputMorph                                   , 0x30)
        SCHEMA_FIELD(CUtlVector<CBoneConstraintPoseSpaceMorph_Input_t>, m_inputList                                     , 0x48)
        SCHEMA_FIELD(bool                            , m_bClamp                                        , 0x60)
    };

    class PhysShapeMarkup_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nBodyInAggregate                              , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nShapeInBody                                  , 0x4)
        SCHEMA_FIELD(CGlobalSymbol                   , m_sHitGroup                                     , 0x8)
    };

    class CNmGraphDefinition_ReferencedGraphSlot_t {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nNodeIdx                                      , 0x0)
        SCHEMA_FIELD(std::int16_t                    , m_dataSlotIdx                                   , 0x2)
    };

    class CSequenceFinishedAnimTag {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_sequenceName                                  , 0x58)
    };

    class CNmPoseTask {
    public:
    };

    class PulseObservableBoolExpression_t {
    public:
        SCHEMA_FIELD(CPulse_OutflowConnection        , m_EvaluateConnection                            , 0x0)
        SCHEMA_FIELD(CUtlVector<PulseRuntimeVarIndex_t>, m_DependentObservableVars                       , 0x48)
        SCHEMA_FIELD(CUtlVector<PulseRuntimeBlackboardReferenceIndex_t>, m_DependentObservableBlackboardReferences       , 0x60)
    };

    class CAnimationGraphVisualizerPie {
    public:
        SCHEMA_FIELD(VectorAligned                   , m_vWsCenter                                     , 0x40)
        SCHEMA_FIELD(VectorAligned                   , m_vWsStart                                      , 0x50)
        SCHEMA_FIELD(VectorAligned                   , m_vWsEnd                                        , 0x60)
        SCHEMA_FIELD(::Color                         , m_Color                                         , 0x70)
    };

    class CNmVirtualParameterBoolNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nChildNodeIdx                                 , 0x10)
    };

    class ParticleNamedValueSource_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_Name                                          , 0x0)
        SCHEMA_FIELD(bool                            , m_IsPublic                                      , 0x8)
        SCHEMA_FIELD(CPulseValueFullType             , m_ValueType                                     , 0x10)
        SCHEMA_FIELD(ParticleNamedValueConfiguration_t, m_DefaultConfig                                 , 0x28)
    };

    class CEmitTagActionUpdater {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nTagIndex                                     , 0x18)
        SCHEMA_FIELD(bool                            , m_bIsZeroDuration                               , 0x1C)
    };

    class FollowAttachmentData {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_boneIndex                                     , 0x0)
        SCHEMA_FIELD(AttachmentHandle_t              , m_attachmentHandle                              , 0x4)
    };

    class CAnimDataChannelDesc {
    public:
        SCHEMA_FIELD(CBufferString                   , m_szChannelClass                                , 0x0)
        SCHEMA_FIELD(CBufferString                   , m_szVariableName                                , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nFlags                                        , 0x20)
        SCHEMA_FIELD(std::int32_t                    , m_nType                                         , 0x24)
        SCHEMA_FIELD(CBufferString                   , m_szGrouping                                    , 0x28)
        SCHEMA_FIELD(CBufferString                   , m_szDescription                                 , 0x38)
        SCHEMA_FIELD(CUtlVector<CBufferString>       , m_szElementNameArray                            , 0x48)
        SCHEMA_FIELD(CUtlVector<int32>               , m_nElementIndexArray                            , 0x60)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_nElementMaskArray                             , 0x78)
    };

    class SolveIKChainPoseOpFixedSettings_t {
    public:
        SCHEMA_FIELD(CUtlVector<ChainToSolveData_t>  , m_ChainsToSolveData                             , 0x0)
    };

    class CSeqBoneMaskList {
    public:
        using _Type0 = CUtlVector<std::pair<CBufferString,float32>>;
        SCHEMA_FIELD(CBufferString                   , m_sName                                         , 0x0)
        SCHEMA_FIELD(CUtlVector<int16>               , m_nLocalBoneArray                               , 0x10)
        SCHEMA_FIELD(CUtlVector<float32>             , m_flBoneWeightArray                             , 0x28)
        SCHEMA_FIELD(float                           , m_flDefaultMorphCtrlWeight                      , 0x40)
        SCHEMA_FIELD(_Type0                          , m_morphCtrlWeightArray                          , 0x48)
    };

    class CNmScaleTask {
    public:
    };

    class CNmVirtualParameterIDNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nChildNodeIdx                                 , 0x10)
    };

    class CNmSyncTrack_Event_t {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_ID                                            , 0x0)
        SCHEMA_FIELD(NmPercent_t                     , m_startTime                                     , 0x8)
        SCHEMA_FIELD(NmPercent_t                     , m_duration                                      , 0xC)
    };

    class CPulseCell_Inflow_EventHandler {
    public:
        SCHEMA_FIELD(::PulseSymbol_t                 , m_EventName                                     , 0x80)
    };

    class CFootLockUpdateNode {
    public:
        SCHEMA_FIELD(FootLockPoseOpFixedSettings     , m_opFixedSettings                               , 0x70)
        SCHEMA_FIELD(CUtlVector<FootFixedSettings>   , m_footSettings                                  , 0xE0)
        SCHEMA_FIELD(CAnimInputDamping               , m_hipShiftDamping                               , 0xF8)
        SCHEMA_FIELD(CAnimInputDamping               , m_rootHeightDamping                             , 0x110)
        SCHEMA_FIELD(float                           , m_flStrideCurveScale                            , 0x128)
        SCHEMA_FIELD(float                           , m_flStrideCurveLimitScale                       , 0x12C)
        SCHEMA_FIELD(float                           , m_flStepHeightIncreaseScale                     , 0x130)
        SCHEMA_FIELD(float                           , m_flStepHeightDecreaseScale                     , 0x134)
        SCHEMA_FIELD(float                           , m_flHipShiftScale                               , 0x138)
        SCHEMA_FIELD(float                           , m_flBlendTime                                   , 0x13C)
        SCHEMA_FIELD(float                           , m_flMaxRootHeightOffset                         , 0x140)
        SCHEMA_FIELD(float                           , m_flMinRootHeightOffset                         , 0x144)
        SCHEMA_FIELD(float                           , m_flTiltPlanePitchSpringStrength                , 0x148)
        SCHEMA_FIELD(float                           , m_flTiltPlaneRollSpringStrength                 , 0x14C)
        SCHEMA_FIELD(bool                            , m_bApplyFootRotationLimits                      , 0x150)
        SCHEMA_FIELD(bool                            , m_bApplyHipShift                                , 0x151)
        SCHEMA_FIELD(bool                            , m_bModulateStepHeight                           , 0x152)
        SCHEMA_FIELD(bool                            , m_bResetChild                                   , 0x153)
        SCHEMA_FIELD(bool                            , m_bEnableVerticalCurvedPaths                    , 0x154)
        SCHEMA_FIELD(bool                            , m_bEnableRootHeightDamping                      , 0x155)
    };

    class CSeqS1SeqDesc {
    public:
        SCHEMA_FIELD(CBufferString                   , m_sName                                         , 0x0)
        SCHEMA_FIELD(CSeqSeqDescFlag                 , m_flags                                         , 0x10)
        SCHEMA_FIELD(CSeqMultiFetch                  , m_fetch                                         , 0x20)
        SCHEMA_FIELD(std::int32_t                    , m_nLocalWeightlist                              , 0x90)
        SCHEMA_FIELD(CUtlVector<CSeqAutoLayer>       , m_autoLayerArray                                , 0x98)
        SCHEMA_FIELD(CUtlVector<CSeqIKLock>          , m_IKLockArray                                   , 0xB0)
        SCHEMA_FIELD(CSeqTransition                  , m_transition                                    , 0xC8)
        SCHEMA_FIELD(KeyValues3                      , m_SequenceKeys                                  , 0xD0)
        SCHEMA_FIELD(CBufferString                   , m_LegacyKeyValueText                            , 0xE0)
        SCHEMA_FIELD(CUtlVector<CAnimActivity>       , m_activityArray                                 , 0xF0)
        SCHEMA_FIELD(CUtlVector<CFootMotion>         , m_footMotion                                    , 0x108)
    };

    class LookAtOpFixedSettings_t {
    public:
        SCHEMA_FIELD(CAnimAttachment                 , m_attachment                                    , 0x0)
        SCHEMA_FIELD(CAnimInputDamping               , m_damping                                       , 0x80)
        SCHEMA_FIELD(CUtlVector<LookAtBone_t>        , m_bones                                         , 0x98)
        SCHEMA_FIELD(float                           , m_flYawLimit                                    , 0xB0)
        SCHEMA_FIELD(float                           , m_flPitchLimit                                  , 0xB4)
        SCHEMA_FIELD(float                           , m_flHysteresisInnerAngle                        , 0xB8)
        SCHEMA_FIELD(float                           , m_flHysteresisOuterAngle                        , 0xBC)
        SCHEMA_FIELD(bool                            , m_bRotateYawForward                             , 0xC0)
        SCHEMA_FIELD(bool                            , m_bMaintainUpDirection                          , 0xC1)
        SCHEMA_FIELD(bool                            , m_bTargetIsPosition                             , 0xC2)
        SCHEMA_FIELD(bool                            , m_bUseHysteresis                                , 0xC3)
    };

    class CNmAnimationPoseNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nPoseTimeValueNodeIdx                         , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nDataSlotIdx                                  , 0x12)
        SCHEMA_FIELD(Range_t                         , m_inputTimeRemapRange                           , 0x14)
        SCHEMA_FIELD(float                           , m_flUserSpecifiedTime                           , 0x1C)
        SCHEMA_FIELD(bool                            , m_bUseFramesAsInput                             , 0x20)
    };

    class CNmTargetWarpNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nClipReferenceNodeIdx                         , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nTargetValueNodeIdx                           , 0x12)
        SCHEMA_FIELD(CNmRootMotionData_SamplingMode_t, m_samplingMode                                  , 0x14)
        SCHEMA_FIELD(CNmTargetWarpNode_TargetUpdateRule_t, m_targetUpdateRule                              , 0x15)
        SCHEMA_FIELD(bool                            , m_bAlignWithTargetAtLastWarpEvent               , 0x16)
        SCHEMA_FIELD(float                           , m_flSamplingPositionErrorThresholdSq            , 0x18)
        SCHEMA_FIELD(float                           , m_flMaxTangentLength                            , 0x1C)
        SCHEMA_FIELD(float                           , m_flLerpFallbackDistanceThreshold               , 0x20)
        SCHEMA_FIELD(float                           , m_flTargetUpdateDistanceThreshold               , 0x24)
        SCHEMA_FIELD(float                           , m_flTargetUpdateAngleThresholdRadians           , 0x28)
        SCHEMA_FIELD(CGlobalSymbol                   , m_alignmentBoneID                               , 0x30)
    };

    class CNmControlParameterTargetNode_CDefinition {
    public:
    };

    class CNmTargetOffsetNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(bool                            , m_bIsBoneSpaceOffset                            , 0x12)
        SCHEMA_FIELD(::Quaternion                    , m_rotationOffset                                , 0x20)
        SCHEMA_FIELD(::Vector                        , m_translationOffset                             , 0x30)
    };

    class CNmLayerBlendNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<CNmLayerBlendNode_LayerDefinition_t,3>;
        SCHEMA_FIELD(std::int16_t                    , m_nBaseNodeIdx                                  , 0x10)
        SCHEMA_FIELD(bool                            , m_bOnlySampleBaseRootMotion                     , 0x12)
        SCHEMA_FIELD(_Type0                          , m_layerDefinition                               , 0x18)
    };

    class CFootCycle {
    public:
    };

    class SkeletonAnimCapture_t_FrameStamp_t {
    public:
        SCHEMA_FIELD(float                           , m_flTime                                        , 0x0)
        SCHEMA_FIELD(float                           , m_flEntitySimTime                               , 0x4)
        SCHEMA_FIELD(bool                            , m_bTeleportTick                                 , 0x8)
        SCHEMA_FIELD(bool                            , m_bPredicted                                    , 0x9)
        SCHEMA_FIELD(float                           , m_flCurTime                                     , 0xC)
        SCHEMA_FIELD(float                           , m_flRealTime                                    , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nFrameCount                                   , 0x14)
        SCHEMA_FIELD(std::int32_t                    , m_nTickCount                                    , 0x18)
    };

    class CNmChainLookatNode_CDefinition {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_chainEndBoneID                                , 0x18)
        SCHEMA_FIELD(std::int16_t                    , m_nLookatTargetNodeIdx                          , 0x20)
        SCHEMA_FIELD(std::int16_t                    , m_nEnabledNodeIdx                               , 0x22)
        SCHEMA_FIELD(float                           , m_flBlendTimeSeconds                            , 0x24)
        SCHEMA_FIELD(std::uint8_t                    , m_nChainLength                                  , 0x28)
        SCHEMA_FIELD(bool                            , m_bIsTargetInWorldSpace                         , 0x29)
        SCHEMA_FIELD(::Vector                        , m_chainForwardDir                               , 0x2C)
    };

    class CTimeRemainingMetricEvaluator {
    public:
        SCHEMA_FIELD(bool                            , m_bMatchByTimeRemaining                         , 0x50)
        SCHEMA_FIELD(float                           , m_flMaxTimeRemaining                            , 0x54)
        SCHEMA_FIELD(bool                            , m_bFilterByTimeRemaining                        , 0x58)
        SCHEMA_FIELD(float                           , m_flMinTimeRemaining                            , 0x5C)
    };

    class CMoverUpdateNode {
    public:
        SCHEMA_FIELD(CAnimInputDamping               , m_damping                                       , 0x78)
        SCHEMA_FIELD(AnimValueSource                 , m_facingTarget                                  , 0x90)
        SCHEMA_FIELD(CAnimParamHandle                , m_hMoveVecParam                                 , 0x94)
        SCHEMA_FIELD(CAnimParamHandle                , m_hMoveHeadingParam                             , 0x96)
        SCHEMA_FIELD(CAnimParamHandle                , m_hTurnToFaceParam                              , 0x98)
        SCHEMA_FIELD(float                           , m_flTurnToFaceOffset                            , 0x9C)
        SCHEMA_FIELD(float                           , m_flTurnToFaceLimit                             , 0xA0)
        SCHEMA_FIELD(bool                            , m_bAdditive                                     , 0xA4)
        SCHEMA_FIELD(bool                            , m_bApplyMovement                                , 0xA5)
        SCHEMA_FIELD(bool                            , m_bOrientMovement                               , 0xA6)
        SCHEMA_FIELD(bool                            , m_bApplyRotation                                , 0xA7)
        SCHEMA_FIELD(bool                            , m_bLimitOnly                                    , 0xA8)
    };

    class CNmSkeleton_SecondarySkeleton_t {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_attachToBoneID                                , 0x0)
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeCNmSkeleton>, m_skeleton                                      , 0x8)
    };

    class CSeqMultiFetch {
    public:
        SCHEMA_FIELD(CSeqMultiFetchFlag              , m_flags                                         , 0x0)
        SCHEMA_FIELD(CUtlVector<int16>               , m_localReferenceArray                           , 0x8)
        SCHEMA_FIELD(std::int32_t                    , m_nGroupSize                                    , 0x20)
        SCHEMA_FIELD(std::int32_t                    , m_nLocalPose                                    , 0x28)
        SCHEMA_FIELD(CUtlVector<float32>             , m_poseKeyArray0                                 , 0x30)
        SCHEMA_FIELD(CUtlVector<float32>             , m_poseKeyArray1                                 , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_nLocalCyclePoseParameter                      , 0x60)
        SCHEMA_FIELD(bool                            , m_bCalculatePoseParameters                      , 0x64)
        SCHEMA_FIELD(bool                            , m_bFixedBlendWeight                             , 0x65)
        SCHEMA_FIELD(float                           , m_flFixedBlendWeightVals                        , 0x68)
    };

    class CNmFloatComparisonNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nComparandValueNodeIdx                        , 0x12)
        SCHEMA_FIELD(CNmFloatComparisonNode_Comparison_t, m_comparison                                    , 0x14)
        SCHEMA_FIELD(float                           , m_flEpsilon                                     , 0x18)
        SCHEMA_FIELD(float                           , m_flComparisonValue                             , 0x1C)
    };

    class CCycleControlClipUpdateNode {
    public:
        SCHEMA_FIELD(CUtlVector<TagSpan_t>           , m_tags                                          , 0x60)
        SCHEMA_FIELD(HSequence                       , m_hSequence                                     , 0x7C)
        SCHEMA_FIELD(float                           , m_duration                                      , 0x80)
        SCHEMA_FIELD(AnimValueSource                 , m_valueSource                                   , 0x84)
        SCHEMA_FIELD(CAnimParamHandle                , m_paramIndex                                    , 0x88)
        SCHEMA_FIELD(bool                            , m_bLockWhenWaning                               , 0x8A)
    };

    class CRagdollAnimTag {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_profileName                                   , 0x58)
    };

    class ModelAnimGraph2Ref_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_sIdentifier                                   , 0x0)
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeCNmGraphDefinition>, m_hGraph                                        , 0x8)
    };

    class CMaterialAttributeAnimTag {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_AttributeName                                 , 0x58)
        SCHEMA_FIELD(MatterialAttributeTagType_t     , m_AttributeType                                 , 0x60)
        SCHEMA_FIELD(float                           , m_flValue                                       , 0x64)
        SCHEMA_FIELD(::Color                         , m_Color                                         , 0x68)
    };

    class CNmIDEventConditionNode_CDefinition {
    public:
        using _Type0 = CUtlVectorFixedGrowable<CGlobalSymbol,5>;
        SCHEMA_FIELD(std::int16_t                    , m_nSourceStateNodeIdx                           , 0x10)
        SCHEMA_FIELD(CNmBitFlags                     , m_eventConditionRules                           , 0x14)
        SCHEMA_FIELD(_Type0                          , m_eventIDs                                      , 0x18)
    };

    class CNmAdditiveBlendTask {
    public:
    };

    class CModelConfigElement {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_ElementName                                   , 0x8)
        SCHEMA_FIELD(CUtlVector<CModelConfigElement*>, m_NestedElements                                , 0x10)
    };

    class WeightList {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(CUtlVector<float32>             , m_weights                                       , 0x8)
    };

    class CNmIDComparisonNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<CGlobalSymbol,4>;
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(CNmIDComparisonNode_Comparison_t, m_comparison                                    , 0x12)
        SCHEMA_FIELD(_Type0                          , m_comparisionIDs                                , 0x18)
    };

    class AttachmentHandle_t {
    public:
        SCHEMA_FIELD(std::uint8_t                    , m_Value                                         , 0x0)
    };

    class CAnimEncodeDifference {
    public:
        SCHEMA_FIELD(CUtlVector<CAnimBoneDifference> , m_boneArray                                     , 0x0)
        SCHEMA_FIELD(CUtlVector<CAnimMorphDifference>, m_morphArray                                    , 0x18)
        SCHEMA_FIELD(CUtlVector<CAnimUserDifference> , m_userArray                                     , 0x30)
        SCHEMA_FIELD(CUtlVector<uint8>               , m_bHasRotationBitArray                          , 0x48)
        SCHEMA_FIELD(CUtlVector<uint8>               , m_bHasMovementBitArray                          , 0x60)
        SCHEMA_FIELD(CUtlVector<uint8>               , m_bHasMorphBitArray                             , 0x78)
        SCHEMA_FIELD(CUtlVector<uint8>               , m_bHasUserBitArray                              , 0x90)
    };

    class CNPCPhysicsHull {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_sName                                         , 0x0)
        SCHEMA_FIELD(NPCPhysicsHullType_t            , m_eType                                         , 0x8)
        SCHEMA_FIELD(float                           , m_flCapsuleHeight                               , 0xC)
        SCHEMA_FIELD(float                           , m_flCapsuleRadius                               , 0x10)
        SCHEMA_FIELD(::Vector                        , m_vCapsuleCenter1                               , 0x14)
        SCHEMA_FIELD(::Vector                        , m_vCapsuleCenter2                               , 0x20)
        SCHEMA_FIELD(float                           , m_flGroundBoxHeight                             , 0x2C)
        SCHEMA_FIELD(float                           , m_flGroundBoxWidth                              , 0x30)
    };

    class CStateMachineUpdateNode {
    public:
        SCHEMA_FIELD(CAnimStateMachineUpdater        , m_stateMachine                                  , 0x70)
        SCHEMA_FIELD(CUtlVector<CStateNodeStateData> , m_stateData                                     , 0xC8)
        SCHEMA_FIELD(CUtlVector<CStateNodeTransitionData>, m_transitionData                                , 0xE0)
        SCHEMA_FIELD(bool                            , m_bBlockWaningTags                              , 0xFC)
        SCHEMA_FIELD(bool                            , m_bLockStateWhenWaning                          , 0xFD)
        SCHEMA_FIELD(bool                            , m_bResetWhenActivated                           , 0xFE)
    };

    class CFollowPathUpdateNode {
    public:
        SCHEMA_FIELD(float                           , m_flBlendOutTime                                , 0x74)
        SCHEMA_FIELD(bool                            , m_bBlockNonPathMovement                         , 0x78)
        SCHEMA_FIELD(bool                            , m_bStopFeetAtGoal                               , 0x79)
        SCHEMA_FIELD(bool                            , m_bScaleSpeed                                   , 0x7A)
        SCHEMA_FIELD(float                           , m_flScale                                       , 0x7C)
        SCHEMA_FIELD(float                           , m_flMinAngle                                    , 0x80)
        SCHEMA_FIELD(float                           , m_flMaxAngle                                    , 0x84)
        SCHEMA_FIELD(float                           , m_flSpeedScaleBlending                          , 0x88)
        SCHEMA_FIELD(CAnimInputDamping               , m_turnDamping                                   , 0x90)
        SCHEMA_FIELD(AnimValueSource                 , m_facingTarget                                  , 0xA8)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParam                                        , 0xAC)
        SCHEMA_FIELD(float                           , m_flTurnToFaceOffset                            , 0xB0)
        SCHEMA_FIELD(bool                            , m_bTurnToFace                                   , 0xB4)
    };

    class CNmBoneMaskSelectorNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,8>;
        using _Type1 = CUtlLeanVectorFixedGrowable<CGlobalSymbol,7>;
        SCHEMA_FIELD(std::int16_t                    , m_defaultMaskNodeIdx                            , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_parameterValueNodeIdx                         , 0x12)
        SCHEMA_FIELD(bool                            , m_bSwitchDynamically                            , 0x14)
        SCHEMA_FIELD(_Type0                          , m_maskNodeIndices                               , 0x18)
        SCHEMA_FIELD(_Type1                          , m_parameterValues                               , 0x30)
        SCHEMA_FIELD(float                           , m_flBlendTimeSeconds                            , 0x70)
    };

    class CParticleModelInput {
    public:
        SCHEMA_FIELD(ParticleModelType_t             , m_nType                                         , 0x10)
        SCHEMA_FIELD(CParticleNamedValueRef          , m_NamedValue                                    , 0x18)
        SCHEMA_FIELD(std::int32_t                    , m_nControlPoint                                 , 0x58)
    };

    class CModelConfigElement_SetBodygroup {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_GroupName                                     , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_nChoice                                       , 0x50)
    };

    class CFlexController {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_szName                                        , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_szType                                        , 0x8)
        SCHEMA_FIELD(float                           , min                                             , 0x10)
        SCHEMA_FIELD(float                           , max                                             , 0x14)
    };

    class NmFloatCurveCompressionSettings_t {
    public:
        SCHEMA_FIELD(NmCompressionSettings_t_QuantizationRange_t, m_range                                         , 0x0)
        SCHEMA_FIELD(bool                            , m_bIsStatic                                     , 0x8)
    };

    class CNmRootMotionData {
    public:
        SCHEMA_FIELD(CUtlVector<CTransform>          , m_transforms                                    , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nNumFrames                                    , 0x18)
        SCHEMA_FIELD(float                           , m_flAverageLinearVelocity                       , 0x1C)
        SCHEMA_FIELD(float                           , m_flAverageAngularVelocityRadians               , 0x20)
        SCHEMA_FIELD(CTransform                      , m_totalDelta                                    , 0x30)
    };

    class CMorphSetData {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nWidth                                        , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nHeight                                       , 0x14)
        SCHEMA_FIELD(CUtlVector<MorphBundleType_t>   , m_bundleTypes                                   , 0x18)
        SCHEMA_FIELD(CUtlVector<CMorphData>          , m_morphDatas                                    , 0x30)
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeCTextureBase>, m_pTextureAtlas                                 , 0x48)
        SCHEMA_FIELD(CUtlVector<CFlexDesc>           , m_FlexDesc                                      , 0x50)
        SCHEMA_FIELD(CUtlVector<CFlexController>     , m_FlexControllers                               , 0x68)
        SCHEMA_FIELD(CUtlVector<CFlexRule>           , m_FlexRules                                     , 0x80)
    };

    class CStaticPoseCacheBuilder {
    public:
    };

    class CPulseCell_Outflow_CycleOrdered {
    public:
        SCHEMA_FIELD(CUtlVector<CPulse_OutflowConnection>, m_Outputs                                       , 0x48)
    };

    class CNmFloatCurveNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_curve                                         , 0x18)
    };

    class CPulseCell_Value_RandomFloat {
    public:
    };

    class CNmControlParameterVectorNode_CDefinition {
    public:
    };

    class CBlendCurve {
    public:
        SCHEMA_FIELD(float                           , m_flControlPoint1                               , 0x0)
        SCHEMA_FIELD(float                           , m_flControlPoint2                               , 0x4)
    };

    class CParticleRemapFloatInput {
    public:
    };

    class CNmFloatSpringNode_CDefinition {
    public:
        SCHEMA_FIELD(float                           , m_flStartValue                                  , 0x10)
        SCHEMA_FIELD(float                           , m_flHertz                                       , 0x14)
        SCHEMA_FIELD(float                           , m_flDampingRatio                                , 0x18)
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x1C)
        SCHEMA_FIELD(bool                            , m_bUseStartValue                                , 0x1E)
    };

    class CNmFloatValueNode_CDefinition {
    public:
    };

    class IKTargetSettings_t {
    public:
        SCHEMA_FIELD(IKTargetSource                  , m_TargetSource                                  , 0x0)
        SCHEMA_FIELD(IKBoneNameAndIndex_t            , m_Bone                                          , 0x8)
        SCHEMA_FIELD(AnimParamID                     , m_AnimgraphParameterNamePosition                , 0x18)
        SCHEMA_FIELD(AnimParamID                     , m_AnimgraphParameterNameOrientation             , 0x1C)
        SCHEMA_FIELD(IKTargetCoordinateSystem        , m_TargetCoordSystem                             , 0x20)
    };

    class CPulse_ResumePoint {
    public:
    };

    class CPulseCell_PickBestOutflowSelector {
    public:
        SCHEMA_FIELD(PulseBestOutflowRules_t         , m_nCheckType                                    , 0x48)
        SCHEMA_FIELD(PulseSelectorOutflowList_t      , m_OutflowList                                   , 0x50)
    };

    class SampleCode {
    public:
        SCHEMA_FIELD(std::uint8_t                    , m_subCode                                       , 0x0)
    };

    class CNmStateMachineNode_StateDefinition_t {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<CNmStateMachineNode_TransitionDefinition_t,5>;
        SCHEMA_FIELD(std::int16_t                    , m_nStateNodeIdx                                 , 0x0)
        SCHEMA_FIELD(std::int16_t                    , m_nEntryConditionNodeIdx                        , 0x2)
        SCHEMA_FIELD(_Type0                          , m_transitionDefinitions                         , 0x8)
    };

    class CFlexOp {
    public:
        SCHEMA_FIELD(FlexOpCode_t                    , m_OpCode                                        , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_Data                                          , 0x4)
    };

    class CSceneObjectData_RTProxyDrawDescriptor_t {
    public:
        SCHEMA_FIELD(CMaterialDrawDescriptor         , m_drawDesc                                      , 0x0)
        SCHEMA_FIELD(::matrix3x4_t                   , m_mWorldFromLocal                               , 0x108)
        SCHEMA_FIELD(VertexAlbedoFormat_t            , m_nVertexAlbedoFormat                           , 0x138)
        SCHEMA_FIELD(std::int8_t                     , m_nVertexAlbedoVB                               , 0x139)
        SCHEMA_FIELD(std::uint16_t                   , m_nVertexAlbedoOffset                           , 0x13A)
        SCHEMA_FIELD(std::uint16_t                   , m_nVertexAlbedoStride                           , 0x13C)
    };

    class CRenderSkeleton {
    public:
        SCHEMA_FIELD(CUtlVector<RenderSkeletonBone_t>, m_bones                                         , 0x0)
        SCHEMA_FIELD(CUtlVector<int32>               , m_boneParents                                   , 0x30)
        SCHEMA_FIELD(std::int32_t                    , m_nBoneWeightCount                              , 0x48)
    };

    class CNmFloatSwitchNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nSwitchValueNodeIdx                           , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nTrueValueNodeIdx                             , 0x12)
        SCHEMA_FIELD(std::int16_t                    , m_nFalseValueNodeIdx                            , 0x14)
        SCHEMA_FIELD(float                           , m_flFalseValue                                  , 0x18)
        SCHEMA_FIELD(float                           , m_flTrueValue                                   , 0x1C)
    };

    class CMoodVData {
    public:
        SCHEMA_FIELD(CResourceNameTyped<CWeakHandle<InfoForResourceTypeCModel>>, m_sModelName                                    , 0x0)
        SCHEMA_FIELD(MoodType_t                      , m_nMoodType                                     , 0xE0)
        SCHEMA_FIELD(CUtlVector<MoodAnimationLayer_t>, m_animationLayers                               , 0xE8)
    };

    class CNmReferencePoseTask {
    public:
    };

    class CNmBlend2DNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,5>;
        using _Type1 = CUtlLeanVectorFixedGrowable<Vector2D,10>;
        using _Type2 = CUtlLeanVectorFixedGrowable<uint8,30>;
        using _Type3 = CUtlLeanVectorFixedGrowable<uint8,10>;
        SCHEMA_FIELD(_Type0                          , m_sourceNodeIndices                             , 0x10)
        SCHEMA_FIELD(_Type1                          , m_values                                        , 0x28)
        SCHEMA_FIELD(_Type2                          , m_indices                                       , 0x80)
        SCHEMA_FIELD(_Type3                          , m_hullIndices                                   , 0xA8)
        SCHEMA_FIELD(std::int16_t                    , m_nInputParameterNodeIdx0                       , 0xC0)
        SCHEMA_FIELD(std::int16_t                    , m_nInputParameterNodeIdx1                       , 0xC2)
        SCHEMA_FIELD(bool                            , m_bAllowLooping                                 , 0xC4)
    };

    class CAnimSkeleton {
    public:
        SCHEMA_FIELD(CUtlVector<CTransform>          , m_localSpaceTransforms                          , 0x10)
        SCHEMA_FIELD(CUtlVector<CTransform>          , m_modelSpaceTransforms                          , 0x28)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_boneNames                                     , 0x40)
        SCHEMA_FIELD(CUtlVector<CUtlVector<int32>>   , m_children                                      , 0x58)
        SCHEMA_FIELD(CUtlVector<int32>               , m_parents                                       , 0x70)
        SCHEMA_FIELD(CUtlVector<CAnimFoot>           , m_feet                                          , 0x88)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_morphNames                                    , 0xA0)
        SCHEMA_FIELD(CUtlVector<int32>               , m_lodBoneCounts                                 , 0xB8)
    };

    class CPulse_Constant {
    public:
        SCHEMA_FIELD(CPulseValueFullType             , m_Type                                          , 0x0)
        SCHEMA_FIELD(KeyValues3                      , m_Value                                         , 0x18)
    };

    class CFootMotion {
    public:
        SCHEMA_FIELD(CUtlVector<CFootStride>         , m_strides                                       , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x18)
        SCHEMA_FIELD(bool                            , m_bAdditive                                     , 0x20)
    };

    class CDistanceRemainingMetricEvaluator {
    public:
        SCHEMA_FIELD(float                           , m_flMaxDistance                                 , 0x50)
        SCHEMA_FIELD(float                           , m_flMinDistance                                 , 0x54)
        SCHEMA_FIELD(float                           , m_flStartGoalFilterDistance                     , 0x58)
        SCHEMA_FIELD(float                           , m_flMaxGoalOvershootScale                       , 0x5C)
        SCHEMA_FIELD(bool                            , m_bFilterFixedMinDistance                       , 0x60)
        SCHEMA_FIELD(bool                            , m_bFilterGoalDistance                           , 0x61)
        SCHEMA_FIELD(bool                            , m_bFilterGoalOvershoot                          , 0x62)
    };

    class CStateNodeTransitionData {
    public:
        SCHEMA_FIELD(CBlendCurve                     , m_curve                                         , 0x0)
        SCHEMA_FIELD(CAnimValue<float32>             , m_blendDuration                                 , 0x8)
        SCHEMA_FIELD(CAnimValue<float32>             , m_resetCycleValue                               , 0x10)

    };

    class CNmAndNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,4>;
        SCHEMA_FIELD(_Type0                          , m_conditionNodeIndices                          , 0x10)
    };

    class CBoneConstraintDotToMorph {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_sBoneName                                     , 0x20)
        SCHEMA_FIELD(::CUtlString                    , m_sTargetBoneName                               , 0x28)
        SCHEMA_FIELD(::CUtlString                    , m_sMorphChannelName                             , 0x30)
        SCHEMA_FIELD(float                           , m_flRemap                                       , 0x38)
    };

    class CPerParticleVecInput {
    public:
    };

    class CPulseCell_Step_CallExternalMethod {
    public:
        SCHEMA_FIELD(::PulseSymbol_t                 , m_MethodName                                    , 0x48)
        SCHEMA_FIELD(PulseRuntimeBlackboardReferenceIndex_t, m_nBlackboardIndex                              , 0x58)
        SCHEMA_FIELD(CUtlLeanVector<CPulseRuntimeMethodArg>, m_ExpectedArgs                                  , 0x60)
        SCHEMA_FIELD(PulseMethodCallMode_t           , m_nAsyncCallMode                                , 0x70)
        SCHEMA_FIELD(CPulse_ResumePoint              , m_OnFinished                                    , 0x78)
    };

    class COrientConstraint {
    public:
    };

    class PairedSequenceData {
    public:
        SCHEMA_FIELD(PairedSequence_t                , m_vecPairedSequences                            , 0x0)
    };

    class CDampedPathAnimMotorUpdater {
    public:
        SCHEMA_FIELD(float                           , m_flAnticipationTime                            , 0x2C)
        SCHEMA_FIELD(float                           , m_flMinSpeedScale                               , 0x30)
        SCHEMA_FIELD(CAnimParamHandle                , m_hAnticipationPosParam                         , 0x34)
        SCHEMA_FIELD(CAnimParamHandle                , m_hAnticipationHeadingParam                     , 0x36)
        SCHEMA_FIELD(float                           , m_flSpringConstant                              , 0x38)
        SCHEMA_FIELD(float                           , m_flMinSpringTension                            , 0x3C)
        SCHEMA_FIELD(float                           , m_flMaxSpringTension                            , 0x40)
    };

    class HitReactFixedSettings_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nWeightListIndex                              , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nEffectedBoneCount                            , 0x4)
        SCHEMA_FIELD(float                           , m_flMaxImpactForce                              , 0x8)
        SCHEMA_FIELD(float                           , m_flMinImpactForce                              , 0xC)
        SCHEMA_FIELD(float                           , m_flWhipImpactScale                             , 0x10)
        SCHEMA_FIELD(float                           , m_flCounterRotationScale                        , 0x14)
        SCHEMA_FIELD(float                           , m_flDistanceFadeScale                           , 0x18)
        SCHEMA_FIELD(float                           , m_flPropagationScale                            , 0x1C)
        SCHEMA_FIELD(float                           , m_flWhipDelay                                   , 0x20)
        SCHEMA_FIELD(float                           , m_flSpringStrength                              , 0x24)
        SCHEMA_FIELD(float                           , m_flWhipSpringStrength                          , 0x28)
        SCHEMA_FIELD(float                           , m_flMaxAngleRadians                             , 0x2C)
        SCHEMA_FIELD(std::int32_t                    , m_nHipBoneIndex                                 , 0x30)
        SCHEMA_FIELD(float                           , m_flHipBoneTranslationScale                     , 0x34)
        SCHEMA_FIELD(float                           , m_flHipDipSpringStrength                        , 0x38)
        SCHEMA_FIELD(float                           , m_flHipDipImpactScale                           , 0x3C)
        SCHEMA_FIELD(float                           , m_flHipDipDelay                                 , 0x40)
    };

    class CLookAtUpdateNode {
    public:
        SCHEMA_FIELD(LookAtOpFixedSettings_t         , m_opFixedSettings                               , 0x70)
        SCHEMA_FIELD(AnimVectorSource                , m_target                                        , 0x148)
        SCHEMA_FIELD(CAnimParamHandle                , m_paramIndex                                    , 0x14C)
        SCHEMA_FIELD(CAnimParamHandle                , m_weightParamIndex                              , 0x14E)
        SCHEMA_FIELD(bool                            , m_bResetChild                                   , 0x150)
        SCHEMA_FIELD(bool                            , m_bLockWhenWaning                               , 0x151)
    };

    class CAnimParamHandleMap {
    public:
        using _Type0 = CUtlHashtable<uint16,int16>;
        SCHEMA_FIELD(_Type0                          , m_list                                          , 0x0)
    };

    class CNmGraphEventConditionNode_Condition_t {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_eventID                                       , 0x0)
        SCHEMA_FIELD(NmGraphEventTypeCondition_t     , m_eventTypeCondition                            , 0x8)
    };

    class CAnimGraphModelBinding {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_modelName                                     , 0x8)
        SCHEMA_FIELD(CSmartPtr<CAnimUpdateSharedData>, m_pSharedData                                   , 0x10)
    };

    class PulseRuntimeCellIndex_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_Value                                         , 0x0)
    };

    class AnimationDecodeDebugDumpElement_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nEntityIndex                                  , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_modelName                                     , 0x8)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_poseParams                                    , 0x10)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_decodeOps                                     , 0x28)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_internalOps                                   , 0x40)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_decodedAnims                                  , 0x58)
    };

    class CPathAnimMotorUpdater {
    public:
    };

    class MovementData {
    public:
        SCHEMA_FIELD(::Vector                        , m_goalWayPointPos                               , 0x0)
        SCHEMA_FIELD(CAnimNetVar<Vector>             , m_vMoveDir                                      , 0xC)
        SCHEMA_FIELD(CAnimNetVar<Vector>             , m_vAcceleration                                 , 0x20)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flCurrentMoveSpeed                            , 0x34)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flTargetMoveSpeed                             , 0x40)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flGoalDistance                                , 0x4C)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flBoundaryRadius                              , 0x58)
        SCHEMA_FIELD(bool                            , m_bGoalChanged                                  , 0x64)
        SCHEMA_FIELD(CAnimNetVar<bool>               , m_bHasPath                                      , 0x68)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flFacingHeading                               , 0x74)
        SCHEMA_FIELD(::Vector                        , m_vManualFacingDirection                        , 0x80)
        SCHEMA_FIELD(VectorWS                        , m_vManualFacingTarget                           , 0x8C)
        SCHEMA_FIELD(CAnimNetVar<uint8>              , m_nFacingMode                                   , 0x98)
        SCHEMA_FIELD(CAnimNetVar<bool>               , m_bForceFacing                                  , 0xA4)
        SCHEMA_FIELD(CAnimNetVar<int32>              , m_nActiveMotorIndex                             , 0xB0)
        SCHEMA_FIELD(CAnimNetVar<bool>               , m_bOnGround                                     , 0xBC)
        SCHEMA_FIELD(CAnimNetVar<Vector>             , m_vFacingPosition                               , 0xC8)
        SCHEMA_FIELD(::Vector                        , m_vPrevFacingPosition                           , 0xDC)
    };

    class CPulseTestScriptLib {
    public:
    };

    class ModelBoneFlexDriver_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_boneName                                      , 0x0)
        SCHEMA_FIELD(std::uint32_t                   , m_boneNameToken                                 , 0x8)
        SCHEMA_FIELD(CUtlVector<ModelBoneFlexDriverControl_t>, m_controls                                      , 0x10)
    };

    class CMaterialDrawDescriptor_RigidMeshPart_t {
    public:
        SCHEMA_FIELD(std::uint16_t                   , m_nRigidBLASIndex                               , 0x0)
        SCHEMA_FIELD(std::int16_t                    , m_nBoneIndex                                    , 0x2)
        SCHEMA_FIELD(std::uint32_t                   , m_nStartIndexOffset                             , 0x4)
        SCHEMA_FIELD(std::uint32_t                   , m_nPrimitiveCount                               , 0x8)
    };

    class PulseRuntimeVarIndex_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_Value                                         , 0x0)
    };

    class PerTickSettings_t {
    public:
        SCHEMA_FIELD(CTransform                      , m_startingLocalToWorld                          , 0x0)
        SCHEMA_FIELD(CTransform                      , m_prevLocalToWorld                              , 0x20)
        SCHEMA_FIELD(CTransform                      , m_finalLocalToWorld                             , 0x40)
        SCHEMA_FIELD(CRootMotion                     , m_rootMotion                                    , 0x60)
        SCHEMA_FIELD(std::int32_t                    , m_updateID                                      , 0x69C)
        SCHEMA_FIELD(float                           , m_flLastTimeStep                                , 0x6A4)
        SCHEMA_FIELD(float                           , m_flPrevAnimTime                                , 0x6A8)
        SCHEMA_FIELD(float                           , m_flNextAnimTime                                , 0x6AC)
        SCHEMA_FIELD(bool                            , m_bAwaken                                       , 0x6B4)
        SCHEMA_FIELD(bool                            , m_bTeleported                                   , 0x6B5)
        SCHEMA_FIELD(bool                            , m_bIsClient                                     , 0x6B6)
        SCHEMA_FIELD(bool                            , m_bIsPredicted                                  , 0x6B7)
    };

    class CQuaternionAnimParameter {
    public:
        SCHEMA_FIELD(::Quaternion                    , m_defaultValue                                  , 0x80)
        SCHEMA_FIELD(bool                            , m_bInterpolate                                  , 0x90)
    };

    class CAnimGraphSettingsManager {
    public:
        SCHEMA_FIELD(CUtlVector<CSmartPtr<CAnimGraphSettingsGroup>>, m_settingsGroups                                , 0x18)
    };

    class CPoseHandle {
    public:
        SCHEMA_FIELD(std::uint16_t                   , m_nIndex                                        , 0x0)
        SCHEMA_FIELD(PoseType_t                      , m_eType                                         , 0x2)
    };

    class CAnimTagBase {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_name                                          , 0x18)
        SCHEMA_FIELD(::CUtlString                    , m_sComment                                      , 0x20)
        SCHEMA_FIELD(CGlobalSymbol                   , m_group                                         , 0x28)
        SCHEMA_FIELD(AnimTagID                       , m_tagID                                         , 0x30)
        SCHEMA_FIELD(bool                            , m_bIsReferenced                                 , 0x48)
    };

    class CPhysSurfacePropertiesVehicle {
    public:
        SCHEMA_FIELD(float                           , m_wheelDrag                                     , 0x0)
        SCHEMA_FIELD(float                           , m_wheelFrictionScale                            , 0x4)
    };

    class CClothSettingsAnimTag {
    public:
        SCHEMA_FIELD(float                           , m_flStiffness                                   , 0x58)
        SCHEMA_FIELD(float                           , m_flEaseIn                                      , 0x5C)
        SCHEMA_FIELD(float                           , m_flEaseOut                                     , 0x60)
        SCHEMA_FIELD(::CUtlString                    , m_nVertexSet                                    , 0x68)
    };

    class CPulseGraphExecutionHistory {
    public:
        using _Type0 = CUtlOrderedMap<PulseDocNodeID_t,PulseGraphExecutionHistoryNodeDesc_t*>;
        using _Type1 = CUtlOrderedMap<PulseCursorID_t,PulseGraphExecutionHistoryCursorDesc_t*>;
        SCHEMA_FIELD(PulseGraphInstanceID_t          , m_nInstanceID                                   , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_strFileName                                   , 0x8)
        SCHEMA_FIELD(CUtlVector<PulseGraphExecutionHistoryEntry_t*>, m_vecHistory                                    , 0x10)
        SCHEMA_FIELD(_Type0                          , m_mapCellDesc                                   , 0x28)
        SCHEMA_FIELD(_Type1                          , m_mapCursorDesc                                 , 0x50)
    };

    class CDirectPlaybackInstanceData {
    public:
        SCHEMA_FIELD(::Vector                        , m_vTargetPosition                               , 0x0)
        SCHEMA_FIELD(float                           , m_flTargetFacing                                , 0xC)
        SCHEMA_FIELD(float                           , m_flInterpEndTime                               , 0x10)
        SCHEMA_FIELD(float                           , m_weights                                       , 0x14)
        SCHEMA_FIELD(SequenceData                    , m_sequences                                     , 0x24)
        SCHEMA_FIELD(std::uint32_t                   , m_currentSequenceIndex                          , 0x104)
        SCHEMA_FIELD(CAnimNetVar<uint64>             , m_currentSequenceData                           , 0x108)
        SCHEMA_FIELD(float                           , m_flFadeInTime                                  , 0x118)
        SCHEMA_FIELD(float                           , m_flFadeOutTime                                 , 0x11C)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flForcedCycle                                 , 0x120)
        SCHEMA_FIELD(bool                            , m_bResetPending                                 , 0x130)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_SequenceCycleZeroTime                         , 0x138)
    };

    class CNmFootIKNode_CDefinition {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_leftEffectorBoneID                            , 0x18)
        SCHEMA_FIELD(CGlobalSymbol                   , m_rightEffectorBoneID                           , 0x20)
        SCHEMA_FIELD(std::int16_t                    , m_nLeftTargetNodeIdx                            , 0x28)
        SCHEMA_FIELD(std::int16_t                    , m_nRightTargetNodeIdx                           , 0x2A)
        SCHEMA_FIELD(std::int16_t                    , m_nEnabledNodeIdx                               , 0x2C)
        SCHEMA_FIELD(float                           , m_flBlendTimeSeconds                            , 0x30)
        SCHEMA_FIELD(NmIKBlendMode_t                 , m_blendMode                                     , 0x34)
        SCHEMA_FIELD(bool                            , m_bIsTargetInWorldSpace                         , 0x35)
    };

    class CFollowTargetUpdateNode {
    public:
        SCHEMA_FIELD(FollowTargetOpFixedSettings_t   , m_opFixedData                                   , 0x70)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParameterPosition                            , 0x88)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParameterOrientation                         , 0x8A)
    };

    class CPulseCell_WaitForCursorsWithTag {
    public:
        SCHEMA_FIELD(bool                            , m_bTagSelfWhenComplete                          , 0x98)
        SCHEMA_FIELD(PulseCursorCancelPriority_t     , m_nDesiredKillPriority                          , 0x9C)
    };

    class CAimCameraUpdateNode {
    public:
        SCHEMA_FIELD(CAnimParamHandle                , m_hParameterPosition                            , 0x70)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParameterOrientation                         , 0x72)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParameterPelvisOffset                        , 0x74)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParameterCameraOnly                          , 0x76)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParameterWeaponDepenetrationDistance         , 0x78)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParameterWeaponDepenetrationDelta            , 0x7A)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParameterCameraClearanceDistance             , 0x7C)
        SCHEMA_FIELD(AimCameraOpFixedSettings_t      , m_opFixedSettings                               , 0x80)
    };

    class CAnimScriptComponentUpdater {
    public:
        SCHEMA_FIELD(AnimScriptHandle                , m_hScript                                       , 0x30)
    };

    class CNmStateNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<CGlobalSymbol,3>;
        using _Type1 = CUtlLeanVectorFixedGrowable<CGlobalSymbol,3>;
        using _Type2 = CUtlLeanVectorFixedGrowable<CGlobalSymbol,3>;
        using _Type3 = CUtlLeanVectorFixedGrowable<CNmStateNode_TimedEvent_t,1>;
        using _Type4 = CUtlLeanVectorFixedGrowable<CNmStateNode_TimedEvent_t,1>;
        SCHEMA_FIELD(std::int16_t                    , m_nChildNodeIdx                                 , 0x10)
        SCHEMA_FIELD(_Type0                          , m_entryEvents                                   , 0x18)
        SCHEMA_FIELD(_Type1                          , m_executeEvents                                 , 0x38)
        SCHEMA_FIELD(_Type2                          , m_exitEvents                                    , 0x58)
        SCHEMA_FIELD(_Type3                          , m_timedRemainingEvents                          , 0x78)
        SCHEMA_FIELD(_Type4                          , m_timedElapsedEvents                            , 0x90)
        SCHEMA_FIELD(std::int16_t                    , m_nLayerWeightNodeIdx                           , 0xA8)
        SCHEMA_FIELD(std::int16_t                    , m_nLayerRootMotionWeightNodeIdx                 , 0xAA)
        SCHEMA_FIELD(std::int16_t                    , m_nLayerBoneMaskNodeIdx                         , 0xAC)
        SCHEMA_FIELD(bool                            , m_bIsOffState                                   , 0xAE)
        SCHEMA_FIELD(bool                            , m_bUseActualElapsedTimeInStateForTimedEvents    , 0xAF)
    };

    class CNmPoseNode_CDefinition {
    public:
    };

    class ModelSkeletonData_t {
    public:
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_boneName                                      , 0x0)
        SCHEMA_FIELD(CUtlVector<int16>               , m_nParent                                       , 0x18)
        SCHEMA_FIELD(CUtlVector<float32>             , m_boneSphere                                    , 0x30)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_nFlag                                         , 0x48)
        SCHEMA_FIELD(CUtlVector<Vector>              , m_bonePosParent                                 , 0x60)
        SCHEMA_FIELD(CUtlVector<QuaternionStorage>   , m_boneRotParent                                 , 0x78)
        SCHEMA_FIELD(CUtlVector<float32>             , m_boneScaleParent                               , 0x90)
    };

    class CRenderBufferBinding {
    public:
        SCHEMA_FIELD(std::uint64_t                   , m_hBuffer                                       , 0x0)
        SCHEMA_FIELD(std::uint32_t                   , m_nBindOffsetBytes                              , 0x10)
    };

    class CStateNodeInstanceData {
    public:
        SCHEMA_FIELD(CRelativeArray<float32>         , m_stateWeights                                  , 0x0)
        SCHEMA_FIELD(::Vector                        , m_vTransitionVelocityDeltaWS                    , 0x8)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_currentStateStartTime                         , 0x20)
        SCHEMA_FIELD(CAnimNetVar<uint8>              , m_resetCount                                    , 0x3C)
    };

    class CStanceOverrideUpdateNode {
    public:
        SCHEMA_FIELD(CUtlVector<StanceInfo_t>        , m_footStanceInfo                                , 0x70)
        SCHEMA_FIELD(CAnimUpdateNodeRef              , m_pStanceSourceNode                             , 0x88)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParameter                                    , 0x98)
        SCHEMA_FIELD(StanceOverrideMode              , m_eMode                                         , 0x9C)
    };

    class CFootDefinition {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_ankleBoneName                                 , 0x8)
        SCHEMA_FIELD(::CUtlString                    , m_toeBoneName                                   , 0x10)
        SCHEMA_FIELD(::Vector                        , m_vBallOffset                                   , 0x18)
        SCHEMA_FIELD(::Vector                        , m_vHeelOffset                                   , 0x24)
        SCHEMA_FIELD(float                           , m_flFootLength                                  , 0x30)
        SCHEMA_FIELD(float                           , m_flBindPoseDirectionMS                         , 0x34)
        SCHEMA_FIELD(float                           , m_flTraceHeight                                 , 0x38)
        SCHEMA_FIELD(float                           , m_flTraceRadius                                 , 0x3C)
    };

    class CNmBitFlags {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_flags                                         , 0x0)
    };

    class ChainToSolveData_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nChainIndex                                   , 0x0)
        SCHEMA_FIELD(IKSolverSettings_t              , m_SolverSettings                                , 0x4)
        SCHEMA_FIELD(IKTargetSettings_t              , m_TargetSettings                                , 0x10)
        SCHEMA_FIELD(SolveIKChainAnimNodeDebugSetting, m_DebugSetting                                  , 0x38)
        SCHEMA_FIELD(float                           , m_flDebugNormalizedValue                        , 0x3C)
        SCHEMA_FIELD(VectorAligned                   , m_vDebugOffset                                  , 0x40)
    };

    class CNmDurationScaleNode_CDefinition {
    public:
    };

    class CPulseCell_Timeline_TimelineEvent_t {
    public:
        SCHEMA_FIELD(float                           , m_flTimeFromPrevious                            , 0x0)
        SCHEMA_FIELD(CPulse_OutflowConnection        , m_EventOutflow                                  , 0x8)
    };

    class CMorphRectData {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nXLeftDst                                     , 0x0)
        SCHEMA_FIELD(std::int16_t                    , m_nYTopDst                                      , 0x2)
        SCHEMA_FIELD(float                           , m_flUWidthSrc                                   , 0x4)
        SCHEMA_FIELD(float                           , m_flVHeightSrc                                  , 0x8)
        SCHEMA_FIELD(CUtlVector<CMorphBundleData>    , m_bundleDatas                                   , 0x10)
    };

    class PulseRuntimeStateOffset_t {
    public:
        SCHEMA_FIELD(std::uint16_t                   , m_Value                                         , 0x0)
    };

    class CFootPinningUpdateNode {
    public:
        SCHEMA_FIELD(FootPinningPoseOpFixedData_t    , m_poseOpFixedData                               , 0x78)
        SCHEMA_FIELD(FootPinningTimingSource         , m_eTimingSource                                 , 0xA8)
        SCHEMA_FIELD(CUtlVector<CAnimParamHandle>    , m_params                                        , 0xB0)
        SCHEMA_FIELD(bool                            , m_bResetChild                                   , 0xC8)
    };

    class BoneDemoCaptureSettings_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_boneName                                      , 0x0)
        SCHEMA_FIELD(float                           , m_flErrorSplineRotationMax                      , 0x8)
        SCHEMA_FIELD(float                           , m_flErrorSplineTranslationMax                   , 0xC)
        SCHEMA_FIELD(float                           , m_flErrorSplineScaleMax                         , 0x10)
        SCHEMA_FIELD(float                           , m_flErrorQuantizationRotationMax                , 0x14)
        SCHEMA_FIELD(float                           , m_flErrorQuantizationTranslationMax             , 0x18)
        SCHEMA_FIELD(float                           , m_flErrorQuantizationScaleMax                   , 0x1C)
    };

    class CPulseCell_LimitCount_Criteria_t {
    public:
        SCHEMA_FIELD(bool                            , m_bLimitCountPasses                             , 0x0)
    };

    class PulseNodeDynamicOutflows_t {
    public:
        SCHEMA_FIELD(CUtlVector<PulseNodeDynamicOutflows_t_DynamicOutflow_t>, m_Outflows                                      , 0x0)
    };

    class CNmLayerBlendNode_LayerDefinition_t {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputNodeIdx                                 , 0x0)
        SCHEMA_FIELD(std::int16_t                    , m_nWeightValueNodeIdx                           , 0x2)
        SCHEMA_FIELD(std::int16_t                    , m_nBoneMaskValueNodeIdx                         , 0x4)
        SCHEMA_FIELD(std::int16_t                    , m_nRootMotionWeightValueNodeIdx                 , 0x6)
        SCHEMA_FIELD(bool                            , m_bIsSynchronized                               , 0x8)
        SCHEMA_FIELD(bool                            , m_bIgnoreEvents                                 , 0x9)
        SCHEMA_FIELD(bool                            , m_bIsStateMachineLayer                          , 0xA)
        SCHEMA_FIELD(NmPoseBlendMode_t               , m_blendMode                                     , 0xB)
    };

    class CNmVirtualParameterTargetNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nChildNodeIdx                                 , 0x10)
    };

    class SkeletonAnimCapture_t {
    public:
        SCHEMA_FIELD(CEntityIndex                    , m_nEntIndex                                     , 0x0)
        SCHEMA_FIELD(CEntityIndex                    , m_nEntParent                                    , 0x4)
        SCHEMA_FIELD(CUtlVector<CEntityIndex>        , m_ImportedCollision                             , 0x8)
        SCHEMA_FIELD(::CUtlString                    , m_ModelName                                     , 0x20)
        SCHEMA_FIELD(::CUtlString                    , m_CaptureName                                   , 0x28)
        SCHEMA_FIELD(CUtlVector<SkeletonAnimCapture_t_Bone_t>, m_ModelBindPose                                 , 0x30)
        SCHEMA_FIELD(CUtlVector<SkeletonAnimCapture_t_Bone_t>, m_FeModelInitPose                               , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_nFlexControllers                              , 0x60)
        SCHEMA_FIELD(bool                            , m_bPredicted                                    , 0x64)
        SCHEMA_FIELD(CUtlVector<SkeletonAnimCapture_t_Frame_t>, m_Frames                                        , 0xA8)
    };

    class CFootstepLandedAnimTag {
    public:
        SCHEMA_FIELD(FootstepLandedFootSoundType_t   , m_FootstepType                                  , 0x58)
        SCHEMA_FIELD(::CUtlString                    , m_OverrideSoundName                             , 0x60)
        SCHEMA_FIELD(::CUtlString                    , m_DebugAnimSourceString                         , 0x68)
        SCHEMA_FIELD(::CUtlString                    , m_BoneName                                      , 0x70)
        SCHEMA_FIELD(FootstepJumpPhase_t             , m_footstepJumpPhase                             , 0x78)
    };

    class CPulse_OutflowConnection {
    public:
        SCHEMA_FIELD(::PulseSymbol_t                 , m_SourceOutflowName                             , 0x0)
        SCHEMA_FIELD(::PulseRuntimeChunkIndex_t      , m_nDestChunk                                    , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nInstruction                                  , 0x14)
        SCHEMA_FIELD(::PulseRegisterMap_t            , m_OutflowRegisterMap                            , 0x18)
    };

    class PulseRuntimeOutputIndex_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_Value                                         , 0x0)
    };

    class CSceneObjectData {
    public:
        SCHEMA_FIELD(::Vector                        , m_vMinBounds                                    , 0x0)
        SCHEMA_FIELD(::Vector                        , m_vMaxBounds                                    , 0xC)
        SCHEMA_FIELD(CUtlLeanVector<CMaterialDrawDescriptor>, m_drawCalls                                     , 0x18)
        SCHEMA_FIELD(CUtlLeanVector<AABB_t>          , m_drawBounds                                    , 0x28)
        SCHEMA_FIELD(CUtlLeanVector<CMeshletDescriptor>, m_meshlets                                      , 0x38)
        SCHEMA_FIELD(CUtlLeanVector<CSceneObjectData_RTProxyDrawDescriptor_t>, m_rtProxyDrawCalls                              , 0x48)
        SCHEMA_FIELD(::Vector4D                      , m_vTintColor                                    , 0x58)
    };

    class CNmFrameSnapEvent {
    public:
        SCHEMA_FIELD(NmFrameSnapEventMode_t          , m_frameSnapMode                                 , 0x18)
    };

    class CNmIDBasedSelectorNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,5>;
        using _Type1 = CUtlLeanVectorFixedGrowable<CGlobalSymbol,5>;
        SCHEMA_FIELD(_Type0                          , m_optionNodeIndices                             , 0x10)
        SCHEMA_FIELD(_Type1                          , m_optionIDs                                     , 0x28)
        SCHEMA_FIELD(std::int16_t                    , m_nParameterNodeIdx                             , 0x58)
        SCHEMA_FIELD(std::int16_t                    , m_nFallbackNodeIdx                              , 0x5A)
        SCHEMA_FIELD(bool                            , m_bIgnoreInvalidOptions                         , 0x5C)
    };

    class NmSyncTrackTime_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nEventIdx                                     , 0x0)
        SCHEMA_FIELD(NmPercent_t                     , m_percentageThrough                             , 0x4)
    };

    class CAnimFrameBlockAnim {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nStartFrame                                   , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nEndFrame                                     , 0x4)
        SCHEMA_FIELD(CUtlVector<int32>               , m_segmentIndexArray                             , 0x8)
    };

    class RenderHairStrandInfo_t {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_nGuideHairIndices_nSurfaceTriIndex            , 0x0)
        SCHEMA_FIELD(std::uint16_t                   , m_vGuideBary_vBaseBary                          , 0x8)
        SCHEMA_FIELD(std::uint16_t                   , m_vRootOffset_flLengthScale                     , 0x10)
        SCHEMA_FIELD(std::uint16_t                   , m_nPackedBaseUv                                 , 0x18)
        SCHEMA_FIELD(std::uint32_t                   , m_nPackedSurfaceNormalOs                        , 0x1C)
        SCHEMA_FIELD(std::uint32_t                   , m_nPackedSurfaceTangentOs                       , 0x20)
        SCHEMA_FIELD(std::uint32_t                   , m_nDataOffset_Segments                          , 0x24)
    };

    class CNmParameterizedBlendNode_Parameterization_t {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<CNmParameterizedBlendNode_BlendRange_t,5>;
        SCHEMA_FIELD(_Type0                          , m_blendRanges                                   , 0x0)
        SCHEMA_FIELD(Range_t                         , m_parameterRange                                , 0x48)
    };

    class CAnimFoot {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(::Vector                        , m_vBallOffset                                   , 0x8)
        SCHEMA_FIELD(::Vector                        , m_vHeelOffset                                   , 0x14)
        SCHEMA_FIELD(std::int32_t                    , m_ankleBoneIndex                                , 0x20)
        SCHEMA_FIELD(std::int32_t                    , m_toeBoneIndex                                  , 0x24)
    };

    class CNmBoolValueNode_CDefinition {
    public:
    };

    class CModelConfigElement_UserPick {
    public:
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_Choices                                       , 0x48)
    };

    class CNmEntityAttributeEventBase {
    public:
        SCHEMA_FIELD(CNmEventTargetEntity_t          , m_target                                        , 0x18)
        SCHEMA_FIELD(::CUtlString                    , m_attributeName                                 , 0x20)
    };

    class CPulseCell_Inflow_EntOutputHandler {
    public:
        SCHEMA_FIELD(::PulseSymbol_t                 , m_SourceEntity                                  , 0x80)
        SCHEMA_FIELD(::PulseSymbol_t                 , m_SourceOutput                                  , 0x90)
        SCHEMA_FIELD(CPulseValueFullType             , m_ExpectedParamType                             , 0xA0)
    };

    class ParamSpanSample_t {
    public:
        SCHEMA_FIELD(CAnimVariant                    , m_value                                         , 0x0)
        SCHEMA_FIELD(float                           , m_flCycle                                       , 0x14)
    };

    class CFootTrajectories {
    public:
        SCHEMA_FIELD(CUtlVector<CFootTrajectory>     , m_trajectories                                  , 0x0)
    };

    class CPulseCell_IntervalTimer_CursorState_t {
    public:
        SCHEMA_FIELD(::GameTime_t                    , m_StartTime                                     , 0x0)
        SCHEMA_FIELD(::GameTime_t                    , m_EndTime                                       , 0x4)
        SCHEMA_FIELD(float                           , m_flWaitInterval                                , 0x8)
        SCHEMA_FIELD(float                           , m_flWaitIntervalHigh                            , 0xC)
        SCHEMA_FIELD(bool                            , m_bCompleteOnNextWake                           , 0x10)
    };

    class CNmIsTargetSetNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
    };

    class CRagdollUpdateNode {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nWeightListIndex                              , 0x70)
        SCHEMA_FIELD(RagdollPoseControl              , m_poseControlMethod                             , 0x74)
    };

    class AnimStateID {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_id                                            , 0x0)
    };

    class CNmIDToFloatNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<CGlobalSymbol,5>;
        using _Type1 = CUtlLeanVectorFixedGrowable<float32,5>;
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(float                           , m_defaultValue                                  , 0x14)
        SCHEMA_FIELD(_Type0                          , m_IDs                                           , 0x18)
        SCHEMA_FIELD(_Type1                          , m_values                                        , 0x48)
    };

    class CBoneConstraintRbf {
    public:
        using _Type0 = CUtlVector<std::pair<CUtlString,uint32>>;
        using _Type1 = CUtlVector<std::pair<CUtlString,uint32>>;
        SCHEMA_FIELD(_Type0                          , m_inputBones                                    , 0x20)
        SCHEMA_FIELD(_Type1                          , m_outputBones                                   , 0x38)
    };

    class CAnimationLayer {
    public:
        SCHEMA_FIELD(CAnimNetVar<int32>              , m_hSequence                                     , 0x0)
        SCHEMA_FIELD(float                           , m_flPrevCycle                                   , 0xC)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flCycle                                       , 0x10)
        SCHEMA_FIELD(CAnimNetVar<float32>            , m_flWeight                                      , 0x1C)
        SCHEMA_FIELD(CAnimNetVar<int32>              , m_nOrder                                        , 0x28)
        SCHEMA_FIELD(bool                            , m_bLooping                                      , 0x34)
        SCHEMA_FIELD(std::int32_t                    , m_nFlags                                        , 0x38)
        SCHEMA_FIELD(bool                            , m_bSequenceFinished                             , 0x3C)
        SCHEMA_FIELD(float                           , m_flKillRate                                    , 0x40)
        SCHEMA_FIELD(float                           , m_flKillDelay                                   , 0x44)
        SCHEMA_FIELD(std::int32_t                    , m_nPriority                                     , 0x48)
    };

    class CNmChainLookatTask {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nChainEndBoneIdx                              , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_nNumBonesInChain                              , 0x4C)
        SCHEMA_FIELD(::Vector                        , m_chainForwardDir                               , 0x50)
        SCHEMA_FIELD(float                           , m_flBlendWeight                                 , 0x5C)
        SCHEMA_FIELD(float                           , m_flHorizontalAngleLimitDegrees                 , 0x60)
        SCHEMA_FIELD(float                           , m_flVerticalAngleLimitDegrees                   , 0x64)
        SCHEMA_FIELD(::Vector                        , m_lookatTarget                                  , 0x68)
        SCHEMA_FIELD(bool                            , m_bIsTargetInWorldSpace                         , 0x74)
        SCHEMA_FIELD(bool                            , m_bIsRunningFromDeserializedData                , 0x75)
        SCHEMA_FIELD(float                           , m_flHorizontalAngleDegrees                      , 0x78)
        SCHEMA_FIELD(float                           , m_flVerticalAngleDegrees                        , 0x7C)
    };

    class CNmNotNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
    };

    class CPulseCell_BaseLerp {
    public:
        SCHEMA_FIELD(CPulse_ResumePoint              , m_WakeResume                                    , 0x48)
    };

    class CPulseCell_Outflow_CycleRandom {
    public:
        SCHEMA_FIELD(CUtlVector<CPulse_OutflowConnection>, m_Outputs                                       , 0x48)
    };

    class CPulseCell_Inflow_BaseEntrypoint {
    public:
        SCHEMA_FIELD(::PulseRuntimeChunkIndex_t      , m_EntryChunk                                    , 0x48)
        SCHEMA_FIELD(::PulseRegisterMap_t            , m_RegisterMap                                   , 0x50)
    };

    class CAnimEventDefinition {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nFrame                                        , 0x8)
        SCHEMA_FIELD(std::int32_t                    , m_nEndFrame                                     , 0xC)
        SCHEMA_FIELD(float                           , m_flCycle                                       , 0x10)
        SCHEMA_FIELD(float                           , m_flDuration                                    , 0x14)
        SCHEMA_FIELD(KeyValues3                      , m_EventData                                     , 0x18)
        SCHEMA_FIELD(CBufferString                   , m_sLegacyOptions                                , 0x28)
        SCHEMA_FIELD(CGlobalSymbol                   , m_sEventName                                    , 0x38)
    };

    class AnimNodeID {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_id                                            , 0x0)
    };

    class CParticleCollectionFloatInput {
    public:
    };

    class AnimComponentID {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_id                                            , 0x0)
    };

    class CNmZeroPoseNode_CDefinition {
    public:
    };

    class CParentConstraint {
    public:
    };

    class CAnimationGraphVisualizerText {
    public:
        SCHEMA_FIELD(VectorAligned                   , m_vWsPosition                                   , 0x40)
        SCHEMA_FIELD(::Color                         , m_Color                                         , 0x50)
        SCHEMA_FIELD(::CUtlString                    , m_Text                                          , 0x58)
    };

    class CTurnHelperInstanceData {
    public:
        SCHEMA_FIELD(float                           , m_turnAmount                                    , 0x0)
        SCHEMA_FIELD(float                           , m_turnStartTime                                 , 0x4)
        SCHEMA_FIELD(float                           , m_duration                                      , 0x8)
    };

    class CNmFloatCurveEvent {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_ID                                            , 0x18)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_curve                                         , 0x20)
    };

    class CStringAnimTag {
    public:
    };

    class CNmZeroPoseTask {
    public:
    };

    class PermModelDataAnimatedMaterialAttribute_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_AttributeName                                 , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nNumChannels                                  , 0x8)
    };

    class CNmCachedBoolNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(NmCachedValueMode_t             , m_mode                                          , 0x14)
    };

    class CAnimActionUpdater {
    public:
    };

    class CTargetSelectorUpdateNode {
    public:
        SCHEMA_FIELD(TargetSelectorAngleMode_t       , m_eAngleMode                                    , 0x60)
        SCHEMA_FIELD(CUtlVector<CAnimUpdateNodeRef>  , m_children                                      , 0x68)
        SCHEMA_FIELD(CAnimParamHandle                , m_hTargetPosition                               , 0x84)
        SCHEMA_FIELD(CAnimParamHandle                , m_hTargetFacePositionParameter                  , 0x86)
        SCHEMA_FIELD(CAnimParamHandle                , m_hMoveHeadingParameter                         , 0x88)
        SCHEMA_FIELD(CAnimParamHandle                , m_hDesiredMoveHeadingParameter                  , 0x8A)
        SCHEMA_FIELD(bool                            , m_bTargetPositionIsWorldSpace                   , 0x8C)
        SCHEMA_FIELD(bool                            , m_bTargetFacePositionIsWorldSpace               , 0x8D)
        SCHEMA_FIELD(bool                            , m_bEnablePhaseMatching                          , 0x8E)
        SCHEMA_FIELD(float                           , m_flPhaseMatchingMaxRootMotionSkip              , 0x90)
    };

    class CNmVirtualParameterFloatNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nChildNodeIdx                                 , 0x10)
    };

    class CCompressorGroup {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nTotalElementCount                            , 0x0)
        SCHEMA_FIELD(CUtlVector<char*>               , m_szChannelClass                                , 0x8)
        SCHEMA_FIELD(CUtlVector<char*>               , m_szVariableName                                , 0x20)
        SCHEMA_FIELD(CUtlVector<fieldtype_t>         , m_nType                                         , 0x38)
        SCHEMA_FIELD(CUtlVector<int32>               , m_nFlags                                        , 0x50)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_szGrouping                                    , 0x68)
        SCHEMA_FIELD(CUtlVector<int32>               , m_nCompressorIndex                              , 0x80)
        SCHEMA_FIELD(CUtlVector<CUtlVector<char*>>   , m_szElementNames                                , 0x98)
        SCHEMA_FIELD(CUtlVector<CUtlVector<int32>>   , m_nElementUniqueID                              , 0xB0)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_nElementMask                                  , 0xC8)
        SCHEMA_FIELD(CUtlVector<CCompressor<Vector>*>, m_vectorCompressor                              , 0xF8)
        SCHEMA_FIELD(CUtlVector<CCompressor<QuaternionStorage>*>, m_quaternionCompressor                          , 0x110)
        SCHEMA_FIELD(CUtlVector<CCompressor<int32>*> , m_intCompressor                                 , 0x128)
        SCHEMA_FIELD(CUtlVector<CCompressor<bool>*>  , m_boolCompressor                                , 0x140)
        SCHEMA_FIELD(CUtlVector<CCompressor<Color>*> , m_colorCompressor                               , 0x158)
        SCHEMA_FIELD(CUtlVector<CCompressor<Vector2D>*>, m_vector2DCompressor                            , 0x170)
        SCHEMA_FIELD(CUtlVector<CCompressor<Vector4D>*>, m_vector4DCompressor                            , 0x188)
    };

    class CNmScaleNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nMaskNodeIdx                                  , 0x18)
        SCHEMA_FIELD(std::int16_t                    , m_nEnableNodeIdx                                , 0x1A)
    };

    class CNmCurrentSyncEventIDNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nSourceStateNodeIdx                           , 0x10)
    };

    class CNmConstIDNode_CDefinition {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_value                                         , 0x10)
    };

    class AnimTagID {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_id                                            , 0x0)
    };

    class NmBoneMaskSetDefinition_t {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_ID                                            , 0x0)
        SCHEMA_FIELD(CNmBoneWeightList               , m_primaryWeightList                             , 0x8)
        SCHEMA_FIELD(CUtlLeanVector<CNmBoneWeightList>, m_secondaryWeightLists                          , 0x118)
    };

    class CRenderMesh {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<CSceneObjectData,1>;
        SCHEMA_FIELD(_Type0                          , m_sceneObjects                                  , 0x10)
        SCHEMA_FIELD(CUtlLeanVector<CBaseConstraint*>, m_constraints                                   , 0xB8)
        SCHEMA_FIELD(CRenderSkeleton                 , m_skeleton                                      , 0xC8)
        SCHEMA_FIELD(bool                            , m_bUseUV2ForCharting                            , 0x1D4)
        SCHEMA_FIELD(bool                            , m_bEmbeddedMapMesh                              , 0x1D5)
        SCHEMA_FIELD(DynamicMeshDeformParams_t       , m_meshDeformParams                              , 0x1F8)
        SCHEMA_FIELD(CRenderGroom*                   , m_pGroomData                                    , 0x208)
    };

    class CMotionGraph {
    public:
        SCHEMA_FIELD(CParamSpanUpdater               , m_paramSpans                                    , 0x10)
        SCHEMA_FIELD(CUtlVector<TagSpan_t>           , m_tags                                          , 0x28)
        SCHEMA_FIELD(CSmartPtr<CMotionNode>          , m_pRootNode                                     , 0x40)
        SCHEMA_FIELD(std::int32_t                    , m_nParameterCount                               , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_nConfigStartIndex                             , 0x4C)
        SCHEMA_FIELD(std::int32_t                    , m_nConfigCount                                  , 0x50)
        SCHEMA_FIELD(bool                            , m_bLoop                                         , 0x54)
    };

    class CMovementComponentUpdater {
    public:
        SCHEMA_FIELD(CUtlVector<CSmartPtr<CAnimMotorUpdaterBase>>, m_motors                                        , 0x30)
        SCHEMA_FIELD(CAnimInputDamping               , m_facingDamping                                 , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_nDefaultMotorIndex                            , 0x68)
        SCHEMA_FIELD(float                           , m_flDefaultRunSpeed                             , 0x6C)
        SCHEMA_FIELD(bool                            , m_bMoveVarsDisabled                             , 0x70)
        SCHEMA_FIELD(bool                            , m_bNetworkPath                                  , 0x71)
        SCHEMA_FIELD(bool                            , m_bNetworkFacing                                , 0x72)
        SCHEMA_FIELD(CAnimParamHandle                , m_paramHandles                                  , 0x73)
    };

    class CFlexRule {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nFlex                                         , 0x0)
        SCHEMA_FIELD(CUtlVector<CFlexOp>             , m_FlexOps                                       , 0x8)
    };

    class CBlockSelectionMetricEvaluator {
    public:
    };

    class PulseDocNodeID_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_Value                                         , 0x0)
    };

    class CSeqMultiFetchFlag {
    public:
        SCHEMA_FIELD(bool                            , m_bRealtime                                     , 0x0)
        SCHEMA_FIELD(bool                            , m_bCylepose                                     , 0x1)
        SCHEMA_FIELD(bool                            , m_b0D                                           , 0x2)
        SCHEMA_FIELD(bool                            , m_b1D                                           , 0x3)
        SCHEMA_FIELD(bool                            , m_b2D                                           , 0x4)
        SCHEMA_FIELD(bool                            , m_b2D_TRI                                       , 0x5)
    };

    class PairedSequence_t {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_sRole                                         , 0x0)
        SCHEMA_FIELD(CGlobalSymbol                   , m_sSequenceName                                 , 0x8)
        SCHEMA_FIELD(CAnimNetVar<uint32>             , m_hSequence                                     , 0x10)
    };

    class CPulseCell_Timeline {
    public:
        SCHEMA_FIELD(CUtlVector<CPulseCell_Timeline_TimelineEvent_t>, m_TimelineEvents                                , 0x48)
        SCHEMA_FIELD(bool                            , m_bWaitForChildOutflows                         , 0x60)
        SCHEMA_FIELD(CPulse_ResumePoint              , m_OnFinished                                    , 0x68)
        SCHEMA_FIELD(CPulse_ResumePoint              , m_OnCanceled                                    , 0xB0)
    };

    class CNmFootEventConditionNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nSourceStateNodeIdx                           , 0x10)
        SCHEMA_FIELD(NmFootPhaseCondition_t          , m_phaseCondition                                , 0x12)
        SCHEMA_FIELD(CNmBitFlags                     , m_eventConditionRules                           , 0x14)
    };

    class CNmVectorCreateNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_inputVectorValueNodeIdx                       , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_inputValueXNodeIdx                            , 0x12)
        SCHEMA_FIELD(std::int16_t                    , m_inputValueYNodeIdx                            , 0x14)
        SCHEMA_FIELD(std::int16_t                    , m_inputValueZNodeIdx                            , 0x16)
    };

    class CNmFloatRemapNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nInputValueNodeIdx                            , 0x10)
        SCHEMA_FIELD(CNmFloatRemapNode_RemapRange_t  , m_inputRange                                    , 0x14)
        SCHEMA_FIELD(CNmFloatRemapNode_RemapRange_t  , m_outputRange                                   , 0x1C)
    };

    class CPulseCell_CursorQueue {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nCursorsAllowedToRunParallel                  , 0x98)
    };

    class CRenderGroom {
    public:
        SCHEMA_FIELD(CUtlVector<RenderHairStrandInfo_t>, m_hairs                                         , 0x0)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_hairPositionOffsets                           , 0x18)
        SCHEMA_FIELD(CStrongHandleCopyable<InfoForResourceTypeIMaterial2>, m_hSimParamsMat                                 , 0x40)
        SCHEMA_FIELD(CUtlVector<int32>               , m_strandSegmentCountHist                        , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_nMaxSegmentsPerHairStrand                     , 0x78)
        SCHEMA_FIELD(std::int32_t                    , m_nGuideHairCount                               , 0x7C)
        SCHEMA_FIELD(std::int32_t                    , m_nHairCount                                    , 0x80)
        SCHEMA_FIELD(std::int32_t                    , m_nTotalVertexCount                             , 0x84)
        SCHEMA_FIELD(std::int32_t                    , m_nTotalSegmentCount                            , 0x88)
        SCHEMA_FIELD(std::int32_t                    , m_nGroomGroupID                                 , 0x8C)
        SCHEMA_FIELD(std::int32_t                    , m_nAttachBoneIdx                                , 0x90)
        SCHEMA_FIELD(std::int32_t                    , m_nAttachMeshIdx                                , 0x94)
        SCHEMA_FIELD(std::int32_t                    , m_nAttachMeshDrawCallIdx                        , 0x98)
        SCHEMA_FIELD(bool                            , m_bEnableSimulation                             , 0xAC)
    };

    class CWayPointHelperUpdateNode {
    public:
        SCHEMA_FIELD(float                           , m_flStartCycle                                  , 0x74)
        SCHEMA_FIELD(float                           , m_flEndCycle                                    , 0x78)
        SCHEMA_FIELD(bool                            , m_bOnlyGoals                                    , 0x7C)
        SCHEMA_FIELD(bool                            , m_bPreventOvershoot                             , 0x7D)
        SCHEMA_FIELD(bool                            , m_bPreventUndershoot                            , 0x7E)
    };

    class NmCompressionSettings_t {
    public:
        SCHEMA_FIELD(NmCompressionSettings_t_QuantizationRange_t, m_translationRangeX                             , 0x0)
        SCHEMA_FIELD(NmCompressionSettings_t_QuantizationRange_t, m_translationRangeY                             , 0x8)
        SCHEMA_FIELD(NmCompressionSettings_t_QuantizationRange_t, m_translationRangeZ                             , 0x10)
        SCHEMA_FIELD(NmCompressionSettings_t_QuantizationRange_t, m_scaleRange                                    , 0x18)
        SCHEMA_FIELD(std::int32_t                    , m_nTrackReadOffset                              , 0x20)
        SCHEMA_FIELD(::Quaternion                    , m_constantRotation                              , 0x30)
        SCHEMA_FIELD(bool                            , m_bIsRotationStatic                             , 0x40)
        SCHEMA_FIELD(bool                            , m_bIsTranslationStatic                          , 0x41)
        SCHEMA_FIELD(bool                            , m_bIsScaleStatic                                , 0x42)
    };

    class CPulseCell_Inflow_GraphHook {
    public:
        SCHEMA_FIELD(::PulseSymbol_t                 , m_HookName                                      , 0x80)
    };

    class CAnimLocalHierarchy {
    public:
        SCHEMA_FIELD(CBufferString                   , m_sBone                                         , 0x0)
        SCHEMA_FIELD(CBufferString                   , m_sNewParent                                    , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nStartFrame                                   , 0x20)
        SCHEMA_FIELD(std::int32_t                    , m_nPeakFrame                                    , 0x24)
        SCHEMA_FIELD(std::int32_t                    , m_nTailFrame                                    , 0x28)
        SCHEMA_FIELD(std::int32_t                    , m_nEndFrame                                     , 0x2C)
    };

    class CBoneConstraintPoseSpaceMorph_Input_t {
    public:
        SCHEMA_FIELD(::Vector                        , m_inputValue                                    , 0x0)
        SCHEMA_FIELD(CUtlVector<float32>             , m_outputWeightList                              , 0x10)
    };

    class CStopAtGoalUpdateNode {
    public:
        SCHEMA_FIELD(float                           , m_flOuterRadius                                 , 0x74)
        SCHEMA_FIELD(float                           , m_flInnerRadius                                 , 0x78)
        SCHEMA_FIELD(float                           , m_flMaxScale                                    , 0x7C)
        SCHEMA_FIELD(float                           , m_flMinScale                                    , 0x80)
        SCHEMA_FIELD(CAnimInputDamping               , m_damping                                       , 0x88)
    };

    class CPulseGraphDef {
    public:
        SCHEMA_FIELD(::PulseSymbol_t                 , m_DomainIdentifier                              , 0x8)
        SCHEMA_FIELD(CPulseValueFullType             , m_DomainSubType                                 , 0x18)
        SCHEMA_FIELD(::PulseSymbol_t                 , m_ParentMapName                                 , 0x30)
        SCHEMA_FIELD(::PulseSymbol_t                 , m_ParentXmlName                                 , 0x40)
        SCHEMA_FIELD(CUtlVector<CPulse_Chunk*>       , m_Chunks                                        , 0x50)
        SCHEMA_FIELD(CUtlVector<CPulseCell_Base*>    , m_Cells                                         , 0x68)
        SCHEMA_FIELD(CUtlVector<CPulse_Variable>     , m_Vars                                          , 0x80)
        SCHEMA_FIELD(CUtlVector<CPulse_PublicOutput> , m_PublicOutputs                                 , 0x98)
        SCHEMA_FIELD(CUtlVector<CPulse_InvokeBinding*>, m_InvokeBindings                                , 0xB0)
        SCHEMA_FIELD(CUtlVector<CPulse_CallInfo*>    , m_CallInfos                                     , 0xC8)
        SCHEMA_FIELD(CUtlVector<CPulse_Constant>     , m_Constants                                     , 0xE0)
        SCHEMA_FIELD(CUtlVector<CPulse_DomainValue>  , m_DomainValues                                  , 0xF8)
        SCHEMA_FIELD(CUtlVector<CPulse_BlackboardReference>, m_BlackboardReferences                          , 0x110)
        SCHEMA_FIELD(CUtlVector<CPulse_OutputConnection*>, m_OutputConnections                             , 0x128)
    };

    class CSeqPoseSetting {
    public:
        SCHEMA_FIELD(CBufferString                   , m_sPoseParameter                                , 0x0)
        SCHEMA_FIELD(CBufferString                   , m_sAttachment                                   , 0x10)
        SCHEMA_FIELD(CBufferString                   , m_sReferenceSequence                            , 0x20)
        SCHEMA_FIELD(float                           , m_flValue                                       , 0x30)
        SCHEMA_FIELD(bool                            , m_bX                                            , 0x34)
        SCHEMA_FIELD(bool                            , m_bY                                            , 0x35)
        SCHEMA_FIELD(bool                            , m_bZ                                            , 0x36)
        SCHEMA_FIELD(std::int32_t                    , m_eType                                         , 0x38)
    };

    class CDemoSettingsComponentUpdater {
    public:
        SCHEMA_FIELD(CAnimDemoCaptureSettings        , m_settings                                      , 0x30)
    };

    class CPhysSurfaceProperties {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(std::uint32_t                   , m_nameHash                                      , 0x8)
        SCHEMA_FIELD(std::uint32_t                   , m_baseNameHash                                  , 0xC)
        SCHEMA_FIELD(bool                            , m_bHidden                                       , 0x18)
        SCHEMA_FIELD(::CUtlString                    , m_description                                   , 0x20)
        SCHEMA_FIELD(CPhysSurfacePropertiesPhysics   , m_physics                                       , 0x28)
        SCHEMA_FIELD(CPhysSurfacePropertiesVehicle   , m_vehicleParams                                 , 0x40)
        SCHEMA_FIELD(CPhysSurfacePropertiesSoundNames, m_audioSounds                                   , 0x48)
        SCHEMA_FIELD(CPhysSurfacePropertiesAudio     , m_audioParams                                   , 0xA8)
    };

    class CPairedSequenceComponentUpdater {
    public:
    };

    class CPointConstraint {
    public:
    };

    class CNmBodyGroupEvent {
    public:
        SCHEMA_FIELD(CNmEventTargetEntity_t          , m_target                                        , 0x18)
        SCHEMA_FIELD(::CUtlString                    , m_groupName                                     , 0x20)
        SCHEMA_FIELD(std::int32_t                    , m_nGroupValue                                   , 0x28)
    };

    class CParticleAnimTag {
    public:
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeIParticleSystemDefinition>, m_hParticleSystem                               , 0x58)
        SCHEMA_FIELD(::CUtlString                    , m_particleSystemName                            , 0x60)
        SCHEMA_FIELD(::CUtlString                    , m_configName                                    , 0x68)
        SCHEMA_FIELD(bool                            , m_bDetachFromOwner                              , 0x70)
        SCHEMA_FIELD(bool                            , m_bAggregate                                    , 0x71)
        SCHEMA_FIELD(bool                            , m_bStopWhenTagEnds                              , 0x72)
        SCHEMA_FIELD(bool                            , m_bTagEndStopIsInstant                          , 0x73)
        SCHEMA_FIELD(::CUtlString                    , m_attachmentName                                , 0x78)
        SCHEMA_FIELD(ParticleAttachment_t            , m_attachmentType                                , 0x80)
        SCHEMA_FIELD(::CUtlString                    , m_attachmentCP1Name                             , 0x88)
        SCHEMA_FIELD(ParticleAttachment_t            , m_attachmentCP1Type                             , 0x90)
    };

    class CNmFloatSelectorNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,5>;
        using _Type1 = CUtlLeanVectorFixedGrowable<float32,5>;
        SCHEMA_FIELD(_Type0                          , m_conditionNodeIndices                          , 0x10)
        SCHEMA_FIELD(_Type1                          , m_values                                        , 0x28)
        SCHEMA_FIELD(float                           , m_flDefaultValue                                , 0x48)
        SCHEMA_FIELD(float                           , m_flEaseTime                                    , 0x4C)
        SCHEMA_FIELD(NmEasingOperation_t             , m_easingOp                                      , 0x50)
    };

    class NmPercent_t {
    public:
        SCHEMA_FIELD(float                           , m_flValue                                       , 0x0)
    };

    class CNmFollowBoneNode_CDefinition {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_bone                                          , 0x18)
        SCHEMA_FIELD(CGlobalSymbol                   , m_followTargetBone                              , 0x20)
        SCHEMA_FIELD(std::int16_t                    , m_nEnabledNodeIdx                               , 0x28)
        SCHEMA_FIELD(NmFollowBoneMode_t              , m_mode                                          , 0x2A)
    };

    class CBlend2DUpdateNode {
    public:
        SCHEMA_FIELD(CUtlVector<BlendItem_t>         , m_items                                         , 0x60)
        SCHEMA_FIELD(CUtlVector<TagSpan_t>           , m_tags                                          , 0x78)
        SCHEMA_FIELD(CParamSpanUpdater               , m_paramSpans                                    , 0x90)
        SCHEMA_FIELD(CUtlVector<int32>               , m_nodeItemIndices                               , 0xA8)
        SCHEMA_FIELD(CAnimInputDamping               , m_damping                                       , 0xC0)
        SCHEMA_FIELD(AnimValueSource                 , m_blendSourceX                                  , 0xD8)
        SCHEMA_FIELD(CAnimParamHandle                , m_paramX                                        , 0xDC)
        SCHEMA_FIELD(AnimValueSource                 , m_blendSourceY                                  , 0xE0)
        SCHEMA_FIELD(CAnimParamHandle                , m_paramY                                        , 0xE4)
        SCHEMA_FIELD(Blend2DMode                     , m_eBlendMode                                    , 0xE8)
        SCHEMA_FIELD(float                           , m_playbackSpeed                                 , 0xEC)
        SCHEMA_FIELD(bool                            , m_bLoop                                         , 0xF0)
        SCHEMA_FIELD(bool                            , m_bLockBlendOnReset                             , 0xF1)
        SCHEMA_FIELD(bool                            , m_bLockWhenWaning                               , 0xF2)
        SCHEMA_FIELD(bool                            , m_bAnimEventsAndTagsOnMostWeightedOnly          , 0xF3)
    };

    class CAnimInputDamping {
    public:
        SCHEMA_FIELD(DampingSpeedFunction            , m_speedFunction                                 , 0x8)
        SCHEMA_FIELD(float                           , m_fSpeedScale                                   , 0xC)
        SCHEMA_FIELD(float                           , m_fFallingSpeedScale                            , 0x10)
    };

    class CNmTransitionNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nTargetStateNodeIdx                           , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nDurationOverrideNodeIdx                      , 0x12)
        SCHEMA_FIELD(std::int16_t                    , m_timeOffsetOverrideNodeIdx                     , 0x14)
        SCHEMA_FIELD(std::int16_t                    , m_startBoneMaskNodeIdx                          , 0x16)
        SCHEMA_FIELD(float                           , m_flDuration                                    , 0x18)
        SCHEMA_FIELD(NmPercent_t                     , m_boneMaskBlendInTimePercentage                 , 0x1C)
        SCHEMA_FIELD(float                           , m_flTimeOffset                                  , 0x20)
        SCHEMA_FIELD(CNmBitFlags                     , m_transitionOptions                             , 0x24)
        SCHEMA_FIELD(std::int16_t                    , m_targetSyncIDNodeIdx                           , 0x28)
        SCHEMA_FIELD(NmEasingOperation_t             , m_blendWeightEasing                             , 0x2A)
        SCHEMA_FIELD(NmRootMotionBlendMode_t         , m_rootMotionBlend                               , 0x2B)
    };

    class CDampedValueUpdateItem {
    public:
        SCHEMA_FIELD(CAnimInputDamping               , m_damping                                       , 0x0)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParamIn                                      , 0x20)
        SCHEMA_FIELD(CAnimParamHandle                , m_hParamOut                                     , 0x22)
    };

    class CNmParameterizedBlendNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,5>;
        SCHEMA_FIELD(_Type0                          , m_sourceNodeIndices                             , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nInputParameterValueNodeIdx                   , 0x28)
        SCHEMA_FIELD(bool                            , m_bAllowLooping                                 , 0x2A)
    };

    class CConstraintSlave {
    public:
        SCHEMA_FIELD(::Quaternion                    , m_qBaseOrientation                              , 0x0)
        SCHEMA_FIELD(::Vector                        , m_vBasePosition                                 , 0x10)
        SCHEMA_FIELD(std::uint32_t                   , m_nBoneHash                                     , 0x1C)
        SCHEMA_FIELD(float                           , m_flWeight                                      , 0x20)
        SCHEMA_FIELD(::CUtlString                    , m_sName                                         , 0x28)
    };

    class CNmGraphInstance {
    public:
    };

    class CTiltTwistConstraint {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nTargetAxis                                   , 0x60)
        SCHEMA_FIELD(std::int32_t                    , m_nSlaveAxis                                    , 0x64)
    };

    class CCurrentRotationVelocityMetricEvaluator {
    public:
    };

    class CPairedSequenceUpdateNode {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_sPairedSequenceRole                           , 0x78)
    };

    class SequenceData {
    public:
        SCHEMA_FIELD(HSequence                       , m_hSequence                                     , 0x0)
        SCHEMA_FIELD(CNetworkedCycle                 , m_cycle                                         , 0x4)
    };

    class CNmSampleTask {
    public:
    };

    class CAnimationGraphVisualizerAxis {
    public:
        SCHEMA_FIELD(CTransform                      , m_xWsTransform                                  , 0x40)
        SCHEMA_FIELD(float                           , m_flAxisSize                                    , 0x60)
    };

    class CSubtractUpdateNode {
    public:
        SCHEMA_FIELD(BinaryNodeChildOption           , m_footMotionTiming                              , 0x94)
        SCHEMA_FIELD(bool                            , m_bApplyToFootMotion                            , 0x98)
        SCHEMA_FIELD(bool                            , m_bApplyChannelsSeparately                      , 0x99)
        SCHEMA_FIELD(bool                            , m_bUseModelSpace                                , 0x9A)
    };

    class CNmIDSelectorNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,5>;
        using _Type1 = CUtlLeanVectorFixedGrowable<CGlobalSymbol,5>;
        SCHEMA_FIELD(_Type0                          , m_conditionNodeIndices                          , 0x10)
        SCHEMA_FIELD(_Type1                          , m_values                                        , 0x28)
        SCHEMA_FIELD(CGlobalSymbol                   , m_defaultValue                                  , 0x58)
    };

    class CSlopeComponentUpdater {
    public:
        SCHEMA_FIELD(float                           , m_flTraceDistance                               , 0x34)
        SCHEMA_FIELD(CAnimParamHandle                , m_hSlopeAngle                                   , 0x38)
        SCHEMA_FIELD(CAnimParamHandle                , m_hSlopeAngleFront                              , 0x3A)
        SCHEMA_FIELD(CAnimParamHandle                , m_hSlopeAngleSide                               , 0x3C)
        SCHEMA_FIELD(CAnimParamHandle                , m_hSlopeHeading                                 , 0x3E)
        SCHEMA_FIELD(CAnimParamHandle                , m_hSlopeNormal                                  , 0x40)
        SCHEMA_FIELD(CAnimParamHandle                , m_hSlopeNormal_WorldSpace                       , 0x42)
    };

    class CBoneConstraintPoseSpaceBone {
    public:
        SCHEMA_FIELD(CUtlVector<CBoneConstraintPoseSpaceBone_Input_t>, m_inputList                                     , 0x60)
    };

    class PhysSoftbodyDesc_t {
    public:
        SCHEMA_FIELD(CUtlVector<uint32>              , m_ParticleBoneHash                              , 0x0)
        SCHEMA_FIELD(CUtlVector<RnSoftbodyParticle_t>, m_Particles                                     , 0x18)
        SCHEMA_FIELD(CUtlVector<RnSoftbodySpring_t>  , m_Springs                                       , 0x30)
        SCHEMA_FIELD(CUtlVector<RnSoftbodyCapsule_t> , m_Capsules                                      , 0x48)
        SCHEMA_FIELD(CUtlVector<CTransform>          , m_InitPose                                      , 0x60)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_ParticleBoneName                              , 0x78)
    };

    class CPulseRuntimeMethodArg {
    public:
        SCHEMA_FIELD(CKV3MemberNameWithStorage       , m_Name                                          , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_Description                                   , 0x38)
        SCHEMA_FIELD(CPulseValueFullType             , m_Type                                          , 0x40)
    };

    class CNmBlendTask {
    public:
    };

    class IParticleEffect {
    public:
    };

    class CNmIDBasedClipSelectorNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,5>;
        using _Type1 = CUtlLeanVectorFixedGrowable<CGlobalSymbol,5>;
        SCHEMA_FIELD(_Type0                          , m_optionNodeIndices                             , 0x10)
        SCHEMA_FIELD(_Type1                          , m_optionIDs                                     , 0x28)
        SCHEMA_FIELD(std::int16_t                    , m_nParameterNodeIdx                             , 0x58)
        SCHEMA_FIELD(std::int16_t                    , m_nFallbackNodeIdx                              , 0x5A)
        SCHEMA_FIELD(bool                            , m_bIgnoreInvalidOptions                         , 0x5C)
    };

    class AnimationDecodeDebugDump_t {
    public:
        SCHEMA_FIELD(AnimationProcessingType_t       , m_processingType                                , 0x0)
        SCHEMA_FIELD(CUtlVector<AnimationDecodeDebugDumpElement_t>, m_elems                                         , 0x8)
    };

    class MotionIndex {
    public:
        SCHEMA_FIELD(std::uint16_t                   , m_nGroup                                        , 0x0)
        SCHEMA_FIELD(std::uint16_t                   , m_nMotion                                       , 0x2)
    };

    class CAnimParameterManagerUpdater {
    public:
        using _Type0 = CUtlHashtable<AnimParamID,int32>;
        using _Type1 = CUtlHashtable<CUtlString,int32>;
        using _Type2 = CUtlVector<std::pair<CAnimParamHandle,CAnimVariant>>;
        using _Type3 = CUtlHashtable<CAnimParamHandle,int16>;
        SCHEMA_FIELD(CUtlVector<CSmartPtr<CAnimParameterBase>>, m_parameters                                    , 0x18)
        SCHEMA_FIELD(_Type0                          , m_idToIndexMap                                  , 0x30)
        SCHEMA_FIELD(_Type1                          , m_nameToIndexMap                                , 0x50)
        SCHEMA_FIELD(CUtlVector<CAnimParamHandle>    , m_indexToHandle                                 , 0x70)
        SCHEMA_FIELD(_Type2                          , m_autoResetParams                               , 0x88)
        SCHEMA_FIELD(_Type3                          , m_autoResetMap                                  , 0xA0)
    };

    class CMotionMetricEvaluator {
    public:
        SCHEMA_FIELD(CUtlVector<float32>             , m_means                                         , 0x18)
        SCHEMA_FIELD(CUtlVector<float32>             , m_standardDeviations                            , 0x30)
        SCHEMA_FIELD(float                           , m_flWeight                                      , 0x48)
        SCHEMA_FIELD(std::int32_t                    , m_nDimensionStartIndex                          , 0x4C)
    };

    class MoodAnimation_t {
    public:
        SCHEMA_FIELD(CModelAnimNameWithDeltas        , m_sName                                         , 0x0)
        SCHEMA_FIELD(float                           , m_flWeight                                      , 0x8)
    };

    class CAnimationGraphVisualizerPrimitiveBase {
    public:
        SCHEMA_FIELD(CAnimationGraphVisualizerPrimitiveType, m_Type                                          , 0x8)
        SCHEMA_FIELD(AnimNodeID                      , m_OwningAnimNodePaths                           , 0xC)
        SCHEMA_FIELD(std::int32_t                    , m_nOwningAnimNodePathCount                      , 0x38)
    };

    class CAnimAttachment {
    public:
        SCHEMA_FIELD(::Quaternion                    , m_influenceRotations                            , 0x0)
        SCHEMA_FIELD(VectorAligned                   , m_influenceOffsets                              , 0x30)
        SCHEMA_FIELD(std::int32_t                    , m_influenceIndices                              , 0x60)
        SCHEMA_FIELD(float                           , m_influenceWeights                              , 0x6C)
        SCHEMA_FIELD(std::uint8_t                    , m_numInfluences                                 , 0x78)
    };

    class CNmSoundEvent {
    public:
        SCHEMA_FIELD(CNmEventRelevance_t             , m_relevance                                     , 0x18)
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x20)
        SCHEMA_FIELD(CNmSoundEvent_Position_t        , m_position                                      , 0x28)
        SCHEMA_FIELD(::CUtlString                    , m_attachmentName                                , 0x30)
        SCHEMA_FIELD(::CUtlString                    , m_tags                                          , 0x38)
        SCHEMA_FIELD(bool                            , m_bContinuePlayingSoundAtDurationEnd            , 0x40)
        SCHEMA_FIELD(float                           , m_flDurationInterruptionThreshold               , 0x44)
    };

    class CNmIsExternalGraphSlotFilledNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nExternalGraphNodeIdx                         , 0x10)
    };

    class CStepsRemainingMetricEvaluator {
    public:
        SCHEMA_FIELD(CUtlVector<int32>               , m_footIndices                                   , 0x50)
        SCHEMA_FIELD(float                           , m_flMinStepsRemaining                           , 0x68)
    };

    class CNewParticleEffect {
    public:
        SCHEMA_FIELD(CNewParticleEffect*             , m_pNext                                         , 0x10)
        SCHEMA_FIELD(CNewParticleEffect*             , m_pPrev                                         , 0x18)
        SCHEMA_FIELD(IParticleCollection*            , m_pParticles                                    , 0x20)
        SCHEMA_FIELD(char*                           , m_pDebugName                                    , 0x28)

        SCHEMA_FIELD(::Vector                        , m_vSortOrigin                                   , 0x40)
        SCHEMA_FIELD(float                           , m_flScale                                       , 0x4C)
        SCHEMA_FIELD(PARTICLE_EHANDLE__*             , m_hOwner                                        , 0x50)
        SCHEMA_FIELD(CParticleProperty*              , m_pOwningParticleProperty                       , 0x58)
        SCHEMA_FIELD(float                           , m_flFreezeTransitionStart                       , 0x70)
        SCHEMA_FIELD(float                           , m_flFreezeTransitionDuration                    , 0x74)
        SCHEMA_FIELD(float                           , m_flFreezeTransitionOverride                    , 0x78)
        SCHEMA_FIELD(::Vector                        , m_LastMin                                       , 0x7C)
        SCHEMA_FIELD(::Vector                        , m_LastMax                                       , 0x88)
        SCHEMA_FIELD(CSplitScreenSlot                , m_nSplitScreenUser                              , 0x94)
        SCHEMA_FIELD(::Vector                        , m_vecAggregationCenter                          , 0x98)
        SCHEMA_FIELD(std::int32_t                    , m_RefCount                                      , 0xD0)
    };

    class CLookComponentUpdater {
    public:
        SCHEMA_FIELD(CAnimParamHandle                , m_hLookHeading                                  , 0x34)
        SCHEMA_FIELD(CAnimParamHandle                , m_hLookHeadingNormalized                        , 0x36)
        SCHEMA_FIELD(CAnimParamHandle                , m_hLookHeadingVelocity                          , 0x38)
        SCHEMA_FIELD(CAnimParamHandle                , m_hLookPitch                                    , 0x3A)
        SCHEMA_FIELD(CAnimParamHandle                , m_hLookDistance                                 , 0x3C)
        SCHEMA_FIELD(CAnimParamHandle                , m_hLookDirection                                , 0x3E)
        SCHEMA_FIELD(CAnimParamHandle                , m_hLookTarget                                   , 0x40)
        SCHEMA_FIELD(CAnimParamHandle                , m_hLookTargetWorldSpace                         , 0x42)
        SCHEMA_FIELD(bool                            , m_bNetworkLookTarget                            , 0x44)
    };

    class CAnimScriptManager {
    public:
        SCHEMA_FIELD(CUtlVector<ScriptInfo_t>        , m_scriptInfo                                    , 0x10)
    };

    class AnimationSnapshot_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nEntIndex                                     , 0x110)
        SCHEMA_FIELD(::CUtlString                    , m_modelName                                     , 0x118)
    };

    class CBoneVelocityMetricEvaluator {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nBoneIndex                                    , 0x50)
    };

    class CVPhysXSurfacePropertiesList {
    public:
        SCHEMA_FIELD(CUtlVector<CPhysSurfaceProperties*>, m_surfacePropertiesList                         , 0x0)
    };

    class CBoneConstraintBase {
    public:
    };

    class CAnimSequenceParams {
    public:
        SCHEMA_FIELD(float                           , m_flFadeInTime                                  , 0x0)
        SCHEMA_FIELD(float                           , m_flFadeOutTime                                 , 0x4)
    };

    class CStateUpdateData {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(AnimScriptHandle                , m_hScript                                       , 0x8)
        SCHEMA_FIELD(CUtlVector<int32>               , m_transitionIndices                             , 0x10)
        SCHEMA_FIELD(CUtlVector<CStateActionUpdater> , m_actions                                       , 0x28)
        SCHEMA_FIELD(AnimStateID                     , m_stateID                                       , 0x40)

    };

    class PGDInstruction_t {
    public:
        SCHEMA_FIELD(PulseInstructionCode_t          , m_nCode                                         , 0x0)
        SCHEMA_FIELD(PulseRuntimeVarIndex_t          , m_nVar                                          , 0x4)
        SCHEMA_FIELD(PulseRuntimeRegisterIndex_t     , m_nReg0                                         , 0x8)
        SCHEMA_FIELD(PulseRuntimeRegisterIndex_t     , m_nReg1                                         , 0xA)
        SCHEMA_FIELD(PulseRuntimeRegisterIndex_t     , m_nReg2                                         , 0xC)
        SCHEMA_FIELD(PulseRuntimeInvokeIndex_t       , m_nInvokeBindingIndex                           , 0x10)
        SCHEMA_FIELD(::PulseRuntimeChunkIndex_t      , m_nChunk                                        , 0x14)
        SCHEMA_FIELD(std::int32_t                    , m_nDestInstruction                              , 0x18)
        SCHEMA_FIELD(PulseRuntimeCallInfoIndex_t     , m_nCallInfoIndex                                , 0x1C)
        SCHEMA_FIELD(PulseRuntimeConstantIndex_t     , m_nConstIdx                                     , 0x20)
        SCHEMA_FIELD(PulseRuntimeDomainValueIndex_t  , m_nDomainValueIdx                               , 0x22)
        SCHEMA_FIELD(PulseRuntimeBlackboardReferenceIndex_t, m_nBlackboardReferenceIdx                       , 0x24)
    };

    class FootLockPoseOpFixedSettings {
    public:
        SCHEMA_FIELD(CUtlVector<FootFixedData_t>     , m_footInfo                                      , 0x0)
        SCHEMA_FIELD(CAnimInputDamping               , m_hipDampingSettings                            , 0x18)
        SCHEMA_FIELD(std::int32_t                    , m_nHipBoneIndex                                 , 0x30)
        SCHEMA_FIELD(IKSolverType                    , m_ikSolverType                                  , 0x34)
        SCHEMA_FIELD(bool                            , m_bApplyTilt                                    , 0x38)
        SCHEMA_FIELD(bool                            , m_bApplyHipDrop                                 , 0x39)
        SCHEMA_FIELD(bool                            , m_bAlwaysUseFallbackHinge                       , 0x3A)
        SCHEMA_FIELD(bool                            , m_bApplyFootRotationLimits                      , 0x3B)
        SCHEMA_FIELD(bool                            , m_bApplyLegTwistLimits                          , 0x3C)
        SCHEMA_FIELD(float                           , m_flMaxFootHeight                               , 0x40)
        SCHEMA_FIELD(float                           , m_flExtensionScale                              , 0x44)
        SCHEMA_FIELD(float                           , m_flMaxLegTwist                                 , 0x48)
        SCHEMA_FIELD(bool                            , m_bEnableLockBreaking                           , 0x4C)
        SCHEMA_FIELD(float                           , m_flLockBreakTolerance                          , 0x50)
        SCHEMA_FIELD(float                           , m_flLockBlendTime                               , 0x54)
        SCHEMA_FIELD(bool                            , m_bEnableStretching                             , 0x58)
        SCHEMA_FIELD(float                           , m_flMaxStretchAmount                            , 0x5C)
        SCHEMA_FIELD(float                           , m_flStretchExtensionScale                       , 0x60)
    };

    class CNmStateCompletedConditionNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nSourceStateNodeIdx                           , 0x10)
        SCHEMA_FIELD(std::int16_t                    , m_nTransitionDurationOverrideNodeIdx            , 0x12)
        SCHEMA_FIELD(float                           , m_flTransitionDurationSeconds                   , 0x14)
    };

    class CNmIDEventPercentageThroughNode_CDefinition {
    public:
        SCHEMA_FIELD(std::int16_t                    , m_nSourceStateNodeIdx                           , 0x10)
        SCHEMA_FIELD(CNmBitFlags                     , m_eventConditionRules                           , 0x14)
        SCHEMA_FIELD(CGlobalSymbol                   , m_eventID                                       , 0x18)
    };

    class CAudioAnimTag {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_clipName                                      , 0x58)
        SCHEMA_FIELD(::CUtlString                    , m_attachmentName                                , 0x60)
        SCHEMA_FIELD(float                           , m_flVolume                                      , 0x68)
        SCHEMA_FIELD(bool                            , m_bStopWhenTagEnds                              , 0x6C)
        SCHEMA_FIELD(bool                            , m_bStopWhenGraphEnds                            , 0x6D)
        SCHEMA_FIELD(bool                            , m_bPlayOnServer                                 , 0x6E)
        SCHEMA_FIELD(bool                            , m_bPlayOnClient                                 , 0x6F)
    };

    class CHitReactUpdateNode {
    public:
        SCHEMA_FIELD(HitReactFixedSettings_t         , m_opFixedSettings                               , 0x70)
        SCHEMA_FIELD(CAnimParamHandle                , m_triggerParam                                  , 0xBC)
        SCHEMA_FIELD(CAnimParamHandle                , m_hitBoneParam                                  , 0xBE)
        SCHEMA_FIELD(CAnimParamHandle                , m_hitOffsetParam                                , 0xC0)
        SCHEMA_FIELD(CAnimParamHandle                , m_hitDirectionParam                             , 0xC2)
        SCHEMA_FIELD(CAnimParamHandle                , m_hitStrengthParam                              , 0xC4)
        SCHEMA_FIELD(float                           , m_flMinDelayBetweenHits                         , 0xC8)
        SCHEMA_FIELD(bool                            , m_bResetChild                                   , 0xCC)
    };

    class CNmParameterizedClipSelectorNode_CDefinition {
    public:
        using _Type0 = CUtlLeanVectorFixedGrowable<int16,8>;
        using _Type1 = CUtlLeanVectorFixedGrowable<uint8,8>;
        SCHEMA_FIELD(_Type0                          , m_optionNodeIndices                             , 0x10)
        SCHEMA_FIELD(_Type1                          , m_optionWeights                                 , 0x28)
        SCHEMA_FIELD(std::int16_t                    , m_parameterNodeIdx                              , 0x38)
        SCHEMA_FIELD(bool                            , m_bIgnoreInvalidOptions                         , 0x3A)
        SCHEMA_FIELD(bool                            , m_bHasWeightsSet                                , 0x3B)
    };

    class CHitBoxSet {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(std::uint32_t                   , m_nNameHash                                     , 0x8)
        SCHEMA_FIELD(CUtlVector<CHitBox>             , m_HitBoxes                                      , 0x10)
        SCHEMA_FIELD(::CUtlString                    , m_SourceFilename                                , 0x28)
    };

    class CNmGraphDefinition {
    public:
        SCHEMA_FIELD(CGlobalSymbol                   , m_variationID                                   , 0x0)
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeCNmSkeleton>, m_skeleton                                      , 0x8)
        SCHEMA_FIELD(CUtlVector<CStrongHandle<InfoForResourceTypeCNmSkeleton>>, m_supportedSecondarySkeletons                   , 0x10)
        SCHEMA_FIELD(CNmGraphVariationUserData*      , m_pUserData                                     , 0x28)
        SCHEMA_FIELD(CUtlVector<int16>               , m_persistentNodeIndices                         , 0x30)
        SCHEMA_FIELD(std::int16_t                    , m_nRootNodeIdx                                  , 0x48)
        SCHEMA_FIELD(CUtlVector<CGlobalSymbol>       , m_controlParameterIDs                           , 0x50)
        SCHEMA_FIELD(CUtlVector<CGlobalSymbol>       , m_virtualParameterIDs                           , 0x68)
        SCHEMA_FIELD(CUtlVector<int16>               , m_virtualParameterNodeIndices                   , 0x80)
        SCHEMA_FIELD(CUtlVector<CNmGraphDefinition_ReferencedGraphSlot_t>, m_referencedGraphSlots                          , 0x98)
        SCHEMA_FIELD(CUtlVector<CNmGraphDefinition_ExternalGraphSlot_t>, m_externalGraphSlots                            , 0xB0)
        SCHEMA_FIELD(CUtlVector<CNmGraphDefinition_ExternalPoseSlot_t>, m_externalPoseSlots                             , 0xC8)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_nodePaths                                     , 0x150)
        SCHEMA_FIELD(CUtlVector<CStrongHandleVoid>   , m_resources                                     , 0x168)
    };

    class CPulseCell_BaseValue {
    public:
    };

    class CLeanMatrixInstanceData {
    public:
        SCHEMA_FIELD(float                           , m_flValueY                                      , 0x0)
        SCHEMA_FIELD(float                           , m_flValueX                                      , 0x4)
    };

    class CSeqIKLock {
    public:
        SCHEMA_FIELD(float                           , m_flPosWeight                                   , 0x0)
        SCHEMA_FIELD(float                           , m_flAngleWeight                                 , 0x4)
        SCHEMA_FIELD(std::int16_t                    , m_nLocalBone                                    , 0x8)
        SCHEMA_FIELD(bool                            , m_bBonesOrientedAlongPositiveX                  , 0xA)
    };

    class DampedPathMotorInstanceData_t {
    public:
        SCHEMA_FIELD(::Vector                        , m_vVelocity                                     , 0x0)
        SCHEMA_FIELD(::Vector                        , m_vAcceleration                                 , 0xC)
        SCHEMA_FIELD(bool                            , m_bStopping                                     , 0x24)
    };

    class CPulseCell_Base {
    public:
        SCHEMA_FIELD(::PulseDocNodeID_t              , m_nEditorNodeID                                 , 0x8)
    };

    class CMotionNodeBlend1D {
    public:
        SCHEMA_FIELD(CUtlVector<MotionBlendItem>     , m_blendItems                                    , 0x28)
        SCHEMA_FIELD(std::int32_t                    , m_nParamIndex                                   , 0x40)
    };

    class CFootTrajectory {
    public:
        SCHEMA_FIELD(::Vector                        , m_vOffset                                       , 0x8)
        SCHEMA_FIELD(float                           , m_flRotationOffset                              , 0x14)
        SCHEMA_FIELD(float                           , m_flProgression                                 , 0x18)
    };

    class CPulseCell_FireCursors {
    public:
        SCHEMA_FIELD(CUtlVector<CPulse_OutflowConnection>, m_Outflows                                      , 0x48)
        SCHEMA_FIELD(bool                            , m_bWaitForChildOutflows                         , 0x60)
        SCHEMA_FIELD(CPulse_ResumePoint              , m_OnFinished                                    , 0x68)
        SCHEMA_FIELD(CPulse_ResumePoint              , m_OnCanceled                                    , 0xB0)
    };

    class CNmConstBoolNode_CDefinition {
    public:
        SCHEMA_FIELD(bool                            , m_bValue                                        , 0x10)
    };

    class PermModelInfo_t {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_nFlags                                        , 0x0)
        SCHEMA_FIELD(::Vector                        , m_vHullMin                                      , 0x4)
        SCHEMA_FIELD(::Vector                        , m_vHullMax                                      , 0x10)
        SCHEMA_FIELD(::Vector                        , m_vViewMin                                      , 0x1C)
        SCHEMA_FIELD(::Vector                        , m_vViewMax                                      , 0x28)
        SCHEMA_FIELD(float                           , m_flMass                                        , 0x34)
        SCHEMA_FIELD(::Vector                        , m_vEyePosition                                  , 0x38)
        SCHEMA_FIELD(float                           , m_flMaxEyeDeflection                            , 0x44)
        SCHEMA_FIELD(::CUtlString                    , m_sSurfaceProperty                              , 0x48)
        SCHEMA_FIELD(::CUtlString                    , m_keyValueText                                  , 0x50)
    };

    class CSolveIKTargetHandle_t {
    public:
        SCHEMA_FIELD(CAnimParamHandle                , m_positionHandle                                , 0x0)
        SCHEMA_FIELD(CAnimParamHandle                , m_orientationHandle                             , 0x2)
    };

    class CAnimUpdateNodeRef {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nodeIndex                                     , 0x8)
    };

    class CStaticPoseCache {
    public:
        SCHEMA_FIELD(CUtlVector<CCachedPose>         , m_poses                                         , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nBoneCount                                    , 0x28)
        SCHEMA_FIELD(std::int32_t                    , m_nMorphCount                                   , 0x2C)
    };

    class CNmEntityAttributeFloatEvent {
    public:
        SCHEMA_FIELD(CPiecewiseCurve                 , m_FloatValue                                    , 0x38)
    };

    class CNmOrientationWarpEvent {
    public:
    };

}
