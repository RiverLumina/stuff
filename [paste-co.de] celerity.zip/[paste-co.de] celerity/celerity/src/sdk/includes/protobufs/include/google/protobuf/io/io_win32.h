﻿
#ifndef GOOGLE_PROTOBUF_IO_IO_WIN32_H__
#define GOOGLE_PROTOBUF_IO_IO_WIN32_H__

#if defined(_WIN32)

#include <functional>
#include <string>

#include <google/protobuf/port.h>

#include <google/protobuf/port_def.inc>

namespace google {
namespace protobuf {
namespace io {
namespace win32 {

PROTOBUF_EXPORT FILE* fopen(const char* path, const char* mode);
PROTOBUF_EXPORT int access(const char* path, int mode);
PROTOBUF_EXPORT int chdir(const char* path);
PROTOBUF_EXPORT int close(int fd);
PROTOBUF_EXPORT int dup(int fd);
PROTOBUF_EXPORT int dup2(int fd1, int fd2);
PROTOBUF_EXPORT int mkdir(const char* path, int _mode);
PROTOBUF_EXPORT int open(const char* path, int flags, int mode = 0);
PROTOBUF_EXPORT int read(int fd, void* buffer, size_t size);
PROTOBUF_EXPORT int setmode(int fd, int mode);
PROTOBUF_EXPORT int stat(const char* path, struct _stat* buffer);
PROTOBUF_EXPORT int write(int fd, const void* buffer, size_t size);
PROTOBUF_EXPORT std::wstring testonly_utf8_to_winpath(const char* path);

enum class ExpandWildcardsResult {
  kSuccess = 0,
  kErrorNoMatchingFile = 1,
  kErrorInputPathConversion = 2,
  kErrorOutputPathConversion = 3,
};

PROTOBUF_EXPORT ExpandWildcardsResult ExpandWildcards(
    const std::string& path, std::function<void(const std::string&)> consume);

namespace strings {

PROTOBUF_EXPORT bool wcs_to_mbs(const wchar_t* s, std::string* out,
                                bool outUtf8);

PROTOBUF_EXPORT bool mbs_to_wcs(const char* s, std::wstring* out, bool inUtf8);

PROTOBUF_EXPORT bool utf8_to_wcs(const char* input, std::wstring* out);

PROTOBUF_EXPORT bool wcs_to_utf8(const wchar_t* input, std::string* out);

}

}
}
}
}

#ifndef W_OK
#define W_OK 02
#endif

#ifndef F_OK
#define F_OK 00
#endif

#ifndef STDIN_FILENO
#define STDIN_FILENO 0
#endif

#ifndef STDOUT_FILENO
#define STDOUT_FILENO 1
#endif

#include <google/protobuf/port_undef.inc>

#endif

#endif
