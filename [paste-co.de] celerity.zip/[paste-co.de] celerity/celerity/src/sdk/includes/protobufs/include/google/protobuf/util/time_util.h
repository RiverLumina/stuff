﻿
#ifndef GOOGLE_PROTOBUF_UTIL_TIME_UTIL_H__
#define GOOGLE_PROTOBUF_UTIL_TIME_UTIL_H__

#include <cstdint>
#include <ctime>
#include <ostream>
#include <string>
#ifdef _MSC_VER
#ifdef _XBOX_ONE
struct timeval {
  int64_t tv_sec;
  int64_t tv_usec;
};
#else
#include <winsock2.h>
#endif
#else
#include <sys/time.h>
#endif

#include <google/protobuf/duration.pb.h>
#include <google/protobuf/timestamp.pb.h>

#include <google/protobuf/port_def.inc>

namespace google {
namespace protobuf {
namespace util {

class PROTOBUF_EXPORT TimeUtil {
  typedef google::protobuf::Timestamp Timestamp;
  typedef google::protobuf::Duration Duration;

 public:

  static const int64_t kTimestampMinSeconds = -62135596800LL;

  static const int64_t kTimestampMaxSeconds = 253402300799LL;
  static const int64_t kDurationMinSeconds = -315576000000LL;
  static const int64_t kDurationMaxSeconds = 315576000000LL;

  static std::string ToString(const Timestamp& timestamp);
  static bool FromString(const std::string& value, Timestamp* timestamp);

  static std::string ToString(const Duration& duration);
  static bool FromString(const std::string& value, Duration* timestamp);

#ifdef GetCurrentTime
#undef GetCurrentTime
#endif

  static Timestamp GetCurrentTime();

  static Timestamp GetEpoch();

  static Duration NanosecondsToDuration(int64_t nanos);
  static Duration MicrosecondsToDuration(int64_t micros);
  static Duration MillisecondsToDuration(int64_t millis);
  static Duration SecondsToDuration(int64_t seconds);
  static Duration MinutesToDuration(int64_t minutes);
  static Duration HoursToDuration(int64_t hours);

  static int64_t DurationToNanoseconds(const Duration& duration);
  static int64_t DurationToMicroseconds(const Duration& duration);
  static int64_t DurationToMilliseconds(const Duration& duration);
  static int64_t DurationToSeconds(const Duration& duration);
  static int64_t DurationToMinutes(const Duration& duration);
  static int64_t DurationToHours(const Duration& duration);

  static Timestamp NanosecondsToTimestamp(int64_t nanos);
  static Timestamp MicrosecondsToTimestamp(int64_t micros);
  static Timestamp MillisecondsToTimestamp(int64_t millis);
  static Timestamp SecondsToTimestamp(int64_t seconds);

  static int64_t TimestampToNanoseconds(const Timestamp& timestamp);
  static int64_t TimestampToMicroseconds(const Timestamp& timestamp);
  static int64_t TimestampToMilliseconds(const Timestamp& timestamp);
  static int64_t TimestampToSeconds(const Timestamp& timestamp);

  static Timestamp TimeTToTimestamp(time_t value);
  static time_t TimestampToTimeT(const Timestamp& value);

  static Timestamp TimevalToTimestamp(const timeval& value);
  static timeval TimestampToTimeval(const Timestamp& value);
  static Duration TimevalToDuration(const timeval& value);
  static timeval DurationToTimeval(const Duration& value);
};

}
}
}

namespace google {
namespace protobuf {

PROTOBUF_EXPORT Duration& operator+=(Duration& d1,
                                     const Duration& d2);
PROTOBUF_EXPORT Duration& operator-=(Duration& d1,
                                     const Duration& d2);
PROTOBUF_EXPORT Duration& operator*=(Duration& d, int64_t r);
PROTOBUF_EXPORT Duration& operator*=(Duration& d, double r);
PROTOBUF_EXPORT Duration& operator/=(Duration& d, int64_t r);
PROTOBUF_EXPORT Duration& operator/=(Duration& d, double r);

template <typename T>
Duration& operator*=(Duration& d, T r) {
  int64_t x = r;
  return d *= x;
}
template <typename T>
Duration& operator/=(Duration& d, T r) {
  int64_t x = r;
  return d /= x;
}
PROTOBUF_EXPORT Duration& operator%=(Duration& d1,
                                     const Duration& d2);

inline bool operator<(const Duration& d1, const Duration& d2) {
  if (d1.seconds() == d2.seconds()) {
    return d1.nanos() < d2.nanos();
  }
  return d1.seconds() < d2.seconds();
}
inline bool operator>(const Duration& d1, const Duration& d2) {
  return d2 < d1;
}
inline bool operator>=(const Duration& d1, const Duration& d2) {
  return !(d1 < d2);
}
inline bool operator<=(const Duration& d1, const Duration& d2) {
  return !(d2 < d1);
}
inline bool operator==(const Duration& d1, const Duration& d2) {
  return d1.seconds() == d2.seconds() && d1.nanos() == d2.nanos();
}
inline bool operator!=(const Duration& d1, const Duration& d2) {
  return !(d1 == d2);
}

inline Duration operator-(const Duration& d) {
  Duration result;
  result.set_seconds(-d.seconds());
  result.set_nanos(-d.nanos());
  return result;
}
inline Duration operator+(const Duration& d1, const Duration& d2) {
  Duration result = d1;
  return result += d2;
}
inline Duration operator-(const Duration& d1, const Duration& d2) {
  Duration result = d1;
  return result -= d2;
}

template <typename T>
inline Duration operator*(Duration d, T r) {
  return d *= r;
}
template <typename T>
inline Duration operator*(T r, Duration d) {
  return d *= r;
}
template <typename T>
inline Duration operator/(Duration d, T r) {
  return d /= r;
}
PROTOBUF_EXPORT int64_t operator/(const Duration& d1, const Duration& d2);

inline Duration operator%(const Duration& d1, const Duration& d2) {
  Duration result = d1;
  return result %= d2;
}

inline std::ostream& operator<<(std::ostream& out, const Duration& d) {
  out << ::PROTOBUF_NAMESPACE_ID::util::TimeUtil::ToString(d);
  return out;
}

PROTOBUF_EXPORT Timestamp& operator+=(Timestamp& t,
                                      const Duration& d);
PROTOBUF_EXPORT Timestamp& operator-=(Timestamp& t,
                                      const Duration& d);

inline bool operator<(const Timestamp& t1, const Timestamp& t2) {
  if (t1.seconds() == t2.seconds()) {
    return t1.nanos() < t2.nanos();
  }
  return t1.seconds() < t2.seconds();
}
inline bool operator>(const Timestamp& t1, const Timestamp& t2) {
  return t2 < t1;
}
inline bool operator>=(const Timestamp& t1, const Timestamp& t2) {
  return !(t1 < t2);
}
inline bool operator<=(const Timestamp& t1, const Timestamp& t2) {
  return !(t2 < t1);
}
inline bool operator==(const Timestamp& t1, const Timestamp& t2) {
  return t1.seconds() == t2.seconds() && t1.nanos() == t2.nanos();
}
inline bool operator!=(const Timestamp& t1, const Timestamp& t2) {
  return !(t1 == t2);
}

inline Timestamp operator+(const Timestamp& t, const Duration& d) {
  Timestamp result = t;
  return result += d;
}
inline Timestamp operator+(const Duration& d, const Timestamp& t) {
  Timestamp result = t;
  return result += d;
}
inline Timestamp operator-(const Timestamp& t, const Duration& d) {
  Timestamp result = t;
  return result -= d;
}
PROTOBUF_EXPORT Duration operator-(const Timestamp& t1, const Timestamp& t2);

inline std::ostream& operator<<(std::ostream& out, const Timestamp& t) {
  out << ::PROTOBUF_NAMESPACE_ID::util::TimeUtil::ToString(t);
  return out;
}

}
}

#include <google/protobuf/port_undef.inc>

#endif
