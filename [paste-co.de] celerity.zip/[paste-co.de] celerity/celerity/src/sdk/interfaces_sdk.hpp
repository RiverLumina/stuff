﻿
#pragma once

#include <cstdint>

namespace cs2::ifaces { inline constexpr std::uint32_t CS2_BUILD = 14160; }

namespace cs2::ifaces {

    namespace animationsystem_dll {
        inline void* AnimationSystemUtils_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x812190); }
        inline void* AnimationSystem_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x80A0B0); }
    }

    namespace client_dll {
        inline void* ClientToolsInfo_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x204F1C0); }
        inline void* EmptyWorldService001_Client(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x2012AA0); }
        inline void* GameClientExports001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x204BE60); }
        inline void* LegacyGameUI001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x20675C0); }
        inline void* Source2Client002(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x2325F10); }
        inline void* Source2ClientConfig001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x2297F10); }
        inline void* Source2ClientPrediction001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x2056610); }
        inline void* Source2ClientUI001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x2065B20); }
    }

    namespace engine2_dll {
        inline void* BenchmarkService001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x611950); }
        inline void* BugService001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x8C9900); }
        inline void* ClientServerEngineLoopService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x90B000); }
        inline void* ClientServerSharedHandleSystem001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x90A5B0); }
        inline void* EngineGameUI001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x60F2A0); }
        inline void* EngineServiceMgr001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x90A8E0); }
        inline void* GameEventSystemClientV001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x90ABC0); }
        inline void* GameEventSystemServerV001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x90ACF0); }
        inline void* GameResourceServiceClientV001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x611A50); }
        inline void* GameResourceServiceServerV001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x611AB0); }
        inline void* GameUIService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x8C9D30); }
        inline void* HostStateMgr001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x612290); }
        inline void* INETSUPPORT_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x60B040); }
        inline void* InputService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x8CA020); }
        inline void* KeyValueCache001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x612340); }
        inline void* MapListService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x908E90); }
        inline void* NetworkClientService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x909020); }
        inline void* NetworkP2PService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x909360); }
        inline void* NetworkServerService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x909510); }
        inline void* NetworkService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x611C20); }
        inline void* RenderService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x909780); }
        inline void* ScreenshotService001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x909A40); }
        inline void* SimpleEngineLoopService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x6123A0); }
        inline void* SoundService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x611C60); }
        inline void* Source2EngineToClient001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x60EBA0); }
        inline void* Source2EngineToClientStringTable001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x60EC00); }
        inline void* Source2EngineToServer001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x60EC78); }
        inline void* Source2EngineToServerStringTable001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x60ECA0); }
        inline void* SplitScreenService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x611F40); }
        inline void* StatsService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x909E00); }
        inline void* ToolService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x612100); }
        inline void* VENGINE_GAMEUIFUNCS_VERSION005(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x60F330); }
        inline void* VProfService_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x612140); }
    }

    namespace filesystem_stdio_dll {
        inline void* VAsyncFileSystem2_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x2159E0); }
        inline void* VFileSystem017(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x2157A0); }
    }

    namespace host_dll {
        inline void* DebugDrawQueueManager001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x139060); }
        inline void* GameModelInfo001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1390A0); }
        inline void* GameSystem2HostHook(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1390E0); }
        inline void* HostUtils001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x148AB0); }
        inline void* PredictionDiffManager001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1391F0); }
        inline void* SaveRestoreDataVersion001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x139320); }
        inline void* SinglePlayerSharedMemory001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x139350); }
        inline void* Source2Host001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1393C0); }
    }

    namespace imemanager_dll {
        inline void* IMEManager001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x36B20); }
    }

    namespace inputsystem_dll {
        inline void* InputStackSystemVersion001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x40E30); }
        inline void* InputSystemVersion001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x42B50); }
    }

    namespace localize_dll {
        inline void* Localize_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x62180); }
    }

    namespace matchmaking_dll {
        inline void* GameTypes001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1B0F80); }
        inline void* MATCHFRAMEWORK_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1B9060); }
    }

    namespace materialsystem2_dll {
        inline void* FontManager_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x15DE60); }
        inline void* MaterialUtils_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x145D40); }
        inline void* PostProcessingSystem_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x145C50); }
        inline void* TextLayout_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x145CD0); }
        inline void* VMaterialSystem2_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x15D750); }
    }

    namespace meshsystem_dll {
        inline void* MeshSystem001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x150C20); }
    }

    namespace navsystem_dll {
        inline void* NavSystem001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x122930); }
    }

    namespace networksystem_dll {
        inline void* FlattenedSerializersVersion001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x26D700); }
        inline void* NetworkMessagesVersion001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x2959D0); }
        inline void* NetworkSystemVersion001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x286E50); }
        inline void* SerializedEntitiesVersion001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x286F40); }
    }

    namespace panorama_dll {
        inline void* PanoramaUIEngine001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x506D30); }
    }

    namespace panorama_text_pango_dll {
        inline void* PanoramaTextServices001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x2B8A40); }
    }

    namespace panoramauiclient_dll {
        inline void* PanoramaUIClient001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x296420); }
    }

    namespace particles_dll {
        inline void* ParticleSystemMgr003(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x54A3C0); }
    }

    namespace pulse_system_dll {
        inline void* IPulseSystem_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1F36A0); }
    }

    namespace rendersystemdx11_dll {
        inline void* RenderDeviceMgr001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x42B530); }
        inline void* RenderUtils_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x42BE28); }
        inline void* VRenderDeviceMgrBackdoor001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x42B5D0); }
    }

    namespace resourcesystem_dll {
        inline void* ResourceSystem013(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x831E0); }
    }

    namespace scenefilecache_dll {
        inline void* ResponseRulesCache001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0xF58F0); }
        inline void* SceneFileCache002(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0xF5A78); }
    }

    namespace scenesystem_dll {
        inline void* RenderingPipelines_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x663BA0); }
        inline void* SceneSystem_002(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x8DB490); }
        inline void* SceneUtils_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x664AB0); }
    }

    namespace schemasystem_dll {
        inline void* SchemaSystem_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x76800); }
    }

    namespace server_dll {
        inline void* EmptyWorldService001_Server(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1BEFD30); }
        inline void* EntitySubclassUtilsV001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1B9B3B0); }
        inline void* NavGameTest001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1C9C240); }
        inline void* ServerToolsInfo_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1C49228); }
        inline void* Source2GameClients001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1C47C80); }
        inline void* Source2GameDirector001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1DE17F0); }
        inline void* Source2GameEntities001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1C48930); }
        inline void* Source2Server001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1C48780); }
        inline void* Source2ServerConfig001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1EFEA88); }
        inline void* customnavsystem001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x1B7C698); }
    }

    namespace soundsystem_dll {
        inline void* SoundOpSystem001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x5129C0); }
        inline void* SoundOpSystemEdit001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x512880); }
        inline void* SoundSystem001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x512360); }
        inline void* VMixEditTool001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x59487BF); }
    }

    namespace steamaudio_dll {
        inline void* SteamAudio001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x25E620); }
    }

    namespace steamclient64_dll {
        inline void* IVALIDATE001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BE0B8); }
        inline void* SteamClient006(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB520); }
        inline void* SteamClient007(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB528); }
        inline void* SteamClient008(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB530); }
        inline void* SteamClient009(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB538); }
        inline void* SteamClient010(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB540); }
        inline void* SteamClient011(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB548); }
        inline void* SteamClient012(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB550); }
        inline void* SteamClient013(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB558); }
        inline void* SteamClient014(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB560); }
        inline void* SteamClient015(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB568); }
        inline void* SteamClient016(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB570); }
        inline void* SteamClient017(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB578); }
        inline void* SteamClient018(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB580); }
        inline void* SteamClient019(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB588); }
        inline void* SteamClient020(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB590); }
        inline void* SteamClient021(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB598); }
        inline void* SteamClient022(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB5A0); }
        inline void* SteamClient023(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16BB5A8); }
        inline void* p2pvoice002(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x14E627F); }
        inline void* p2pvoicesingleton002(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x16960F0); }
    }

    namespace tier0_dll {
        inline void* TestScriptMgr001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x39E6F0); }
        inline void* VEngineCvar007(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x3A93B0); }
        inline void* VProcessUtils002(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x39E690); }
        inline void* VStringTokenSystem001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x3D00B0); }
    }

    namespace v8system_dll {
        inline void* Source2V8System001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x31730); }
    }

    namespace vphysics2_dll {
        inline void* VPhysics2_Interface_001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x40DDA0); }
    }

    namespace vscript_dll {
        inline void* VScriptManager010(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x13B410); }
    }

    namespace vstdlib_s64_dll {
        inline void* IVALIDATE001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x6F990); }
        inline void* VEngineCvar002(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x6E070); }
    }

    namespace worldrenderer_dll {
        inline void* WorldRendererMgr001(std::uintptr_t module_base) noexcept { return reinterpret_cast<void*>(module_base + 0x225C40); }
    }

}
