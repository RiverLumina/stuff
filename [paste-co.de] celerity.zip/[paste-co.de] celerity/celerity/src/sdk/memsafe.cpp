#include "memsafe.hpp"

#define WIN32_LEAN_AND_MEAN
#include <Windows.h>

#include <cstring>

namespace memsafe {

bool read_bytes(const void* p, void* out, std::size_t n) noexcept {
	if (!out || !is_readable(p, n))
		return false;
	__try {
		std::memcpy(out, p, n);
		return true;
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {
		return false;
	}
}

} // namespace memsafe
