#pragma once

#include <cstdint>
#include <cstddef>
#include <cstring>

// Cheap pointer filters only. Do NOT probe memory here — unmapped pages AV,
// and VirtualQuery on hot path killed FPS. Callers must trust game pointers
// (local/entity list) or catch at a higher layer.
namespace memsafe {

constexpr std::uintptr_t k_min_user = 0x10000ull;
constexpr std::uintptr_t k_max_user = 0x00007FFFFFFFFFFFull;

[[nodiscard]] inline bool is_user_ptr(const void* p) noexcept {
	const auto a = reinterpret_cast<std::uintptr_t>(p);
	return a >= k_min_user && a <= k_max_user;
}

[[nodiscard]] inline bool is_aligned_ptr(const void* p, std::size_t align = alignof(void*)) noexcept {
	return (reinterpret_cast<std::uintptr_t>(p) % align) == 0;
}

[[nodiscard]] inline bool is_readable(const void* p, std::size_t size) noexcept {
	if (!p || size == 0)
		return false;
	const auto start = reinterpret_cast<std::uintptr_t>(p);
	if (start < k_min_user || start > k_max_user)
		return false;
	if (size > k_max_user || start + size < start || start + size - 1 > k_max_user)
		return false;
	return true;
}

[[nodiscard]] inline bool is_committed_readable(const void* p, std::size_t size) noexcept {
	return is_readable(p, size);
}

// Range-checked + SEH around the touch (freed heap still passes the range filter).
// Implemented in memsafe.cpp — inline memcpy AVs were escaping Present SEH frames.
[[nodiscard]] bool read_bytes(const void* p, void* out, std::size_t n) noexcept;

template <typename T>
[[nodiscard]] inline bool read(const void* p, T& out) noexcept {
	return read_bytes(p, &out, sizeof(T));
}

template <typename T>
[[nodiscard]] inline T read_or(const void* p, T fallback = T{}) noexcept {
	T v{};
	if (!read(p, v))
		return fallback;
	return v;
}

[[nodiscard]] inline void* read_ptr(const void* p) noexcept {
	return read_or<void*>(p, nullptr);
}

template <typename T>
[[nodiscard]] inline bool read_field(const void* base, std::size_t offset, T& out) noexcept {
	if (!is_user_ptr(base))
		return false;
	return read(reinterpret_cast<const std::uint8_t*>(base) + offset, out);
}

// Cheap: address looks like a heap/code user pointer. No memory touch.
[[nodiscard]] inline bool valid_entity(const void* ent) noexcept {
	return is_user_ptr(ent) && is_aligned_ptr(ent);
}

[[nodiscard]] inline bool valid_scene_node(const void* node) noexcept {
	return valid_entity(node);
}

} // namespace memsafe
