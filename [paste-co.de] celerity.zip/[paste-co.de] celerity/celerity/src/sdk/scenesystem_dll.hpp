﻿

#pragma once
#include "cs2sdk_macros.hpp"

namespace cs2::sdk::scenesystem {

    inline constexpr std::uint32_t CS2_BUILD = 14160;

    class CSSDSMsg_ViewTarget;
    class SceneViewId_t;
    class CSSDSEndFrameViewInfo;
    class CSSDSMsg_PostLayer;
    class CSSDSMsg_LayerBase;
    class CSSDSMsg_PreLayer;
    class CSSDSMsg_ViewTargetList;
    class CSSDSMsg_ViewRender;
    class CSSDSMsg_EndFrame;

    enum class ESceneViewDebugOverlaysListenerDataType_t : std::uint32_t {
        k_ESceneViewDebugOverlaysListenerDataType_Unknown = 0x0,
        k_ESceneViewDebugOverlaysListenerDataType_Sphere = 0x1,
        k_ESceneViewDebugOverlaysListenerDataType_Capsule = 0x2,
        k_ESceneViewDebugOverlaysListenerDataType_BoxAngles = 0x3,
        k_ESceneViewDebugOverlaysListenerDataType_Line = 0x4,
        k_ESceneViewDebugOverlaysListenerDataType_SolidBoxAngles = 0x5,
        k_ESceneViewDebugOverlaysListenerDataType_Text3D = 0x6,
    };

    enum class ESilhouetteType_t : std::uint32_t {
        SILHOUETTE_NONE = 0x0,
        SILHOUETTE_LIGHT = 0x1,
        SILHOUETTE_ENVMAP = 0x2,
        SILHOUETTE_LPV = 0x4,
    };

    enum class DisableShadows_t : std::uint8_t {
        kDisableShadows_None = 0x0,
        kDisableShadows_All = 0x1,
        kDisableShadows_Baked = 0x2,
        kDisableShadows_Realtime = 0x3,
        kDisableShadows_ReallyNone = 0x4,
    };

    enum class DecalRtEncoding_t : std::uint8_t {
        kDecalInvalid = 0xFF,
        kDecalMin = 0x0,
        kDecalBlood = 0x0,
        kDecalCloak = 0x1,
        kDecalMax = 0x2,
        kDecalDefault = 0x0,
    };

    enum class ESceneObjectVisualization : std::uint32_t {
        SCENEOBJECT_VIS_NONE = 0x0,
        SCENEOBJECT_VIS_OBJECT = 0x1,
        SCENEOBJECT_VIS_MATERIAL = 0x2,
        SCENEOBJECT_VIS_TEXTURE_SIZE = 0x3,
        SCENEOBJECT_VIS_LOD = 0x4,
        SCENEOBJECT_VIS_INSTANCING = 0x5,
    };

    class CSSDSEndFrameViewInfo {
    public:
        SCHEMA_FIELD(std::uint64_t                   , m_nViewId                                       , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_ViewName                                      , 0x8)
    };

    class CSSDSMsg_ViewTarget {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_Name                                          , 0x0)
        SCHEMA_FIELD(std::uint64_t                   , m_TextureId                                     , 0x8)
        SCHEMA_FIELD(std::int32_t                    , m_nWidth                                        , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nHeight                                       , 0x14)
        SCHEMA_FIELD(std::int32_t                    , m_nRequestedWidth                               , 0x18)
        SCHEMA_FIELD(std::int32_t                    , m_nRequestedHeight                              , 0x1C)
        SCHEMA_FIELD(std::int32_t                    , m_nNumMipLevels                                 , 0x20)
        SCHEMA_FIELD(std::int32_t                    , m_nDepth                                        , 0x24)
        SCHEMA_FIELD(std::int32_t                    , m_nMultisampleNumSamples                        , 0x28)
        SCHEMA_FIELD(std::int32_t                    , m_nFormat                                       , 0x2C)
    };

    class CSSDSMsg_ViewRender {
    public:
        SCHEMA_FIELD(SceneViewId_t                   , m_viewId                                        , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_ViewName                                      , 0x10)
    };

    class CSSDSMsg_LayerBase {
    public:
        SCHEMA_FIELD(SceneViewId_t                   , m_viewId                                        , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_ViewName                                      , 0x10)
        SCHEMA_FIELD(std::uint64_t                   , m_nLayerId                                      , 0x18)
        SCHEMA_FIELD(::CUtlString                    , m_LayerName                                     , 0x20)
        SCHEMA_FIELD(::CUtlString                    , m_displayText                                   , 0x28)
    };

    class CSSDSMsg_PreLayer {
    public:
    };

    class CSSDSMsg_ViewTargetList {
    public:
        SCHEMA_FIELD(SceneViewId_t                   , m_viewId                                        , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_ViewName                                      , 0x10)
        SCHEMA_FIELD(CUtlVector<CSSDSMsg_ViewTarget> , m_Targets                                       , 0x18)
    };

    class CSSDSMsg_EndFrame {
    public:
        SCHEMA_FIELD(CUtlVector<CSSDSEndFrameViewInfo>, m_Views                                         , 0x0)
    };

    class SceneViewId_t {
    public:
        SCHEMA_FIELD(std::uint64_t                   , m_nViewId                                       , 0x0)
        SCHEMA_FIELD(std::uint64_t                   , m_nFrameCount                                   , 0x8)
    };

    class CSSDSMsg_PostLayer {
    public:
    };

}
