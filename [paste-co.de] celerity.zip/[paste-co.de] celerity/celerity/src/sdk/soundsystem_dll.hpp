﻿

#pragma once
#include "cs2sdk_macros.hpp"

namespace cs2::sdk::soundsystem {

    inline constexpr std::uint32_t CS2_BUILD = 14160;

    class CVMixInputBase;
    class CVoiceContainerBlender;
    class CVMixPitchShiftProcessorDesc;
    class VMixFreeverbDesc_t;
    class CVoiceContainerStaticAdditiveSynth_CHarmonic;
    class CVoiceContainerStaticAdditiveSynth_CTone;
    class CSosGroupActionOcclusionSchema;
    class CVoiceContainerRandomSampler;
    class CVMixSteamAudioDirectProcessorDesc;
    class CVMixSteamAudioHRTFProcessorDesc;
    class CVoiceContainerDefault;
    class CVSound;
    class CDSPPresetMixgroupModifierTable;
    class CSosGroupActionSoundeventClusterSchema;
    class CSosGroupActionSetSoundeventParameterSchema;
    class CSoundContainerReference;
    class CVoiceContainerNull;
    class VMixSubgraphSwitchDesc_t;
    class CVoiceContainerAnalysisBase;
    class CSosGroupActionSoundeventMinMaxValuesSchema;
    class CVMixEnvelopeProcessorDesc;
    class CVMixCommand;
    class SamplerVoice_t;
    class CVMixControlInput;
    class CVMixBoxverbProcessorDesc;
    class CVMixDynamicsCompressorProcessorDesc;
    class VMixPannerDesc_t;
    class CSosGroupActionSoundeventPrioritySchema;
    class CVoiceContainerRealtimeFMSineWave;
    class SelectedEditItemInfo_t;
    class VMixModDelayDesc_t;
    class CSndSeqInstSndEvtSchema;
    class CVMixNameInputMeter;
    class CSndSeqInstruments;
    class CVMixDynamics3BandProcessorDesc;
    class VMixBoxverbDesc_t;
    class CSosGroupActionSchema;
    class CSosSoundEventGroupSchema;
    class CSndSeqInstMidiSampler;
    class CSndSeqInstBaseSchema;
    class VMixDynamics3BandDesc_t;
    class CVMixEQ8ProcessorDesc;
    class CDSPMixgroupModifier;
    class CAudioMorphData;
    class VMixDualCompressorDesc_t;
    class CVoiceContainerStaticAdditiveSynth;
    class CVoiceContainerShapedNoise;
    class CDspPresetModifierList;
    class CVoiceContainerBase;
    class CVMixDiffusorProcessorDesc;
    class CVMixUtilityProcessorDesc;
    class CVoiceContainerGranulator;
    class CVMixPresetDSPProcessorDesc;
    class VMixDelayDesc_t;
    class VMixEQ8Desc_t;
    class CVMixDynamicsProcessorDesc;
    class CVMixGraphDescData;
    class CVoiceContainerLoopXFade;
    class VMixPresetDSPDesc_t;
    class CAudioPhonemeTag;
    class CVMixControlInputArray;
    class CVMixNameInput;
    class CSosGroupActionSoundeventCountSchema;
    class CVoiceContainerEnvelopeAnalyzer;
    class CVMixBaseProcessorDesc;
    class CVMixImpulseResponseInput;
    class CVMixSteamAudioHybridReverbProcessorDesc;
    class CSoundEventMetaData;
    class VMixPitchShiftDesc_t;
    class CVMixControlOutput;
    class CVMixModDelayProcessorDesc;
    class CVMixShaperProcessorDesc;
    class CVMixAutomaticControlInput;
    class CAudioEmphasisSample;
    class CVMixOscProcessorDesc;
    class CVMixCurveHeader;
    class CVoiceContainerGenerator;
    class CVoiceContainerSet;
    class VMixConvolutionDesc_t;
    class CVoiceContainerSetElement;
    class CVoiceContainerAsyncGenerator;
    class CSoundInfoHeader;
    class SosEditItemInfo_t;
    class CVMixFlangerProcessorDesc;
    class CVMixEffectChainProcessorDesc;
    class KeyGroup_t;
    class CVMixFreeverbProcessorDesc;
    class VMixPlateverbDesc_t;
    class CVMixConvolutionProcessorDesc;
    class CSoundContainerReferenceArray;
    class CVMixFilterProcessorDesc;
    class CVMixAdditionalOutput;
    class CVoiceContainerTapePlayer;
    class CVMixSubgraphSwitchProcessorDesc;
    class VMixDiffusorDesc_t;
    class CVMixSteamAudioPathingProcessorDesc;
    class CVMixPannerProcessorDesc;
    class VMixDynamicsCompressorDesc_t;
    class CVMixStereoDelayProcessorDesc;
    class VMixShaperDesc_t;
    class VMixEnvelopeDesc_t;
    class CAudioSentence;
    class CVoiceContainerParameterBlender;
    class CVMixAudioMeter;
    class CVMixVocoderProcessorDesc;
    class CSosGroupActionLimitSchema;
    class CVoiceContainerAmpedDecayingSineWave;
    class CVoiceContainerEnvelope;
    class VMixAutoFilterDesc_t;
    class VMixDynamicsBand_t;
    class VMixEffectChainDesc_t;
    class CVMixPlateReverbProcessorDesc;
    class CVoiceContainerMultiBlender;
    class CVMixVsndInput;
    class CVoiceContainerStaticAdditiveSynth_CGainScalePerInstance;
    class VelocityZone_t;
    class CVoiceContainerSelector;
    class CSosGroupActionTimeBlockLimitSchema;
    class CSosGroupActionMemberCountEnvelopeSchema;
    class CVMixDualCompressorProcessorDesc;
    class CVoiceContainerSwitch;
    class CVMixControlMeter;
    class CVoiceContainerEnum;
    class CSosGroupActionTimeLimitSchema;
    class VMixVocoderDesc_t;
    class VMixUtilityDesc_t;
    class CVoiceContainerLoopTrigger;
    class CVoiceContainerDecayingSineWave;
    class CVMixDelayProcessorDesc;
    class CVMixBoxverb2ProcessorDesc;
    class VMixFilterDesc_t;
    class VMixOscDesc_t;
    class CVMixAutoFilterProcessorDesc;
    class ISndSeqInstruments;
    class VMixFlangerDesc_t;
    class VMixDynamicsDesc_t;

    enum class SndSeqInstrumentType_t : std::uint32_t {
        eSndSeqInstNull = 0x0,
        eSndSeqInstSndEvt = 0x1,
        eSndSeqInstMidiSampler = 0x2,
    };

    enum class EMode_t : std::uint32_t {
        Peak = 0x0,
        RMS = 0x1,
    };

    enum class VMixGraphCommandID_t : std::int32_t {
        CMD_INVALID = -1,
        CMD_CONTROL_INPUT_STORE = 0x1,
        CMD_CONTROL_INPUT_STORE_DB = 0x2,
        CMD_CONTROL_TRANSIENT_INPUT_STORE = 0x3,
        CMD_CONTROL_TRANSIENT_INPUT_RESET = 0x4,
        CMD_CONTROL_OUTPUT_STORE = 0x5,
        CMD_CONTROL_EVALUATE_CURVE = 0x6,
        CMD_CONTROL_COPY = 0x7,
        CMD_CONTROL_COND_COPY_IF_NEGATIVE = 0x8,
        CMD_CONTROL_REMAP_LINEAR = 0x9,
        CMD_CONTROL_REMAP_SINE = 0xA,
        CMD_CONTROL_REMAP_LOGLINEAR = 0xB,
        CMD_CONTROL_MAX = 0xC,
        CMD_CONTROL_RESET_TIMER = 0xD,
        CMD_CONTROL_INCREMENT_TIMER = 0xE,
        CMD_CONTROL_EVAL_ENVELOPE = 0xF,
        CMD_CONTROL_SINE_BLEND = 0x10,
        CMD_PROCESSOR_SET_CONTROL_VALUE = 0x11,
        CMD_PROCESSOR_SET_NAME_INPUT = 0x12,
        CMD_PROCESSOR_SET_CONTROL_ARRAYVALUE = 0x13,
        CMD_PROCESSOR_STORE_CONTROL_VALUE = 0x14,
        CMD_PROCESSOR_SET_VSND_VALUE = 0x15,
        CMD_SUBMIX_PROCESS = 0x16,
        CMD_SUBMIX_GENERATE = 0x17,
        CMD_SUBMIX_GENERATE_SIDECHAIN = 0x18,
        CMD_SUBMIX_DEBUG = 0x19,
        CMD_SUBMIX_MIX2x1 = 0x1A,
        CMD_SUBMIX_OUTPUT = 0x1B,
        CMD_SUBMIX_OUTPUTx2 = 0x1C,
        CMD_SUBMIX_COPY = 0x1D,
        CMD_SUBMIX_ACCUMULATE = 0x1E,
        CMD_SUBMIX_METER = 0x1F,
        CMD_SUBMIX_METER_SPECTRUM = 0x20,
        CMD_IMPULSERESPONSE_INPUT_STORE = 0x21,
        CMD_PROCESSOR_SET_IMPULSERESPONSE_VALUE = 0x22,
        CMD_REMAP_VSND_TO_IMPULSERESPONSE = 0x23,
        CMD_IMPULSERESPONSE_RESET = 0x24,
        CMD_BLEND_VSNDS_TO_IMPULSERESPONSE = 0x25,
        CMD_IMPULSERESPONSE_DELAY = 0x26,
    };

    enum class EWaveform : std::uint8_t {
        Sine = 0x0,
        Square = 0x1,
        Saw = 0x2,
        Triangle = 0x3,
        Noise = 0x4,
    };

    enum class VMixLFOShape_t : std::uint32_t {
        LFO_SHAPE_SINE = 0x0,
        LFO_SHAPE_SQUARE = 0x1,
        LFO_SHAPE_TRI = 0x2,
        LFO_SHAPE_SAW = 0x3,
        LFO_SHAPE_NOISE = 0x4,
    };

    enum class VMixFilterType_t : std::int16_t {
        FILTER_UNKNOWN = -1,
        FILTER_LOWPASS = 0x0,
        FILTER_HIGHPASS = 0x1,
        FILTER_BANDPASS = 0x2,
        FILTER_NOTCH = 0x3,
        FILTER_PEAKING_EQ = 0x4,
        FILTER_LOW_SHELF = 0x5,
        FILTER_HIGH_SHELF = 0x6,
        FILTER_ALLPASS = 0x7,
        FILTER_PASSTHROUGH = 0x8,
    };

    enum class SosActionStopType_t : std::uint32_t {
        SOS_STOPTYPE_NONE = 0x0,
        SOS_STOPTYPE_TIME = 0x1,
        SOS_STOPTYPE_OPVAR = 0x2,
    };

    enum class SndSeqTrackPlaybackType_t : std::uint32_t {
        eSndSeqTrackPlaybackTypeStep = 0x0,
        eSndSeqTrackPlaybackTypeFwd = 0x1,
    };

    enum class SosEditItemType_t : std::uint32_t {
        SOS_EDIT_ITEM_TYPE_SOUNDEVENTS = 0x0,
        SOS_EDIT_ITEM_TYPE_SOUNDEVENT = 0x1,
        SOS_EDIT_ITEM_TYPE_LIBRARYSTACKS = 0x2,
        SOS_EDIT_ITEM_TYPE_STACK = 0x3,
        SOS_EDIT_ITEM_TYPE_OPERATOR = 0x4,
        SOS_EDIT_ITEM_TYPE_FIELD = 0x5,
    };

    enum class SndSeqQuantizeType_t : std::int32_t {
        eSndSeqQuantizeInvalid = -1,
        eSndSeqQuantizeNone = 0x0,
        eSndSeqQuantizeBeat = 0x1,
        eSndSeqQuantizeBar = 0x2,
        eSndSeqQuantizeSequence = 0x3,
        eSndSeqQuantizeSeek = 0x4,
        eSndSeqQuantizeReset = 0x5,
    };

    enum class PlayBackMode_t : std::uint32_t {
        Random = 0x0,
        RandomNoRepeats = 0x1,
        RandomAvoidLast = 0x2,
        Sequential = 0x3,
        RandomWeights = 0x4,
    };

    enum class SosGroupFieldBehavior_t : std::uint32_t {
        kIgnore = 0x0,
        kBranch = 0x1,
        kMatch = 0x2,
    };

    enum class SndSeqSyncType_t : std::uint32_t {
        eSndSeqSyncTypeNone = 0x0,
        eSndSeqSyncTypeWait = 0x1,
        eSndSeqSyncTypeSeek = 0x2,
    };

    enum class soundlevel_t : std::uint32_t {
        SNDLVL_NONE = 0x0,
        SNDLVL_20dB = 0x14,
        SNDLVL_25dB = 0x19,
        SNDLVL_30dB = 0x1E,
        SNDLVL_35dB = 0x23,
        SNDLVL_40dB = 0x28,
        SNDLVL_45dB = 0x2D,
        SNDLVL_50dB = 0x32,
        SNDLVL_55dB = 0x37,
        SNDLVL_IDLE = 0x3C,
        SNDLVL_60dB = 0x3C,
        SNDLVL_65dB = 0x41,
        SNDLVL_STATIC = 0x42,
        SNDLVL_70dB = 0x46,
        SNDLVL_NORM = 0x4B,
        SNDLVL_75dB = 0x4B,
        SNDLVL_80dB = 0x50,
        SNDLVL_TALKING = 0x50,
        SNDLVL_85dB = 0x55,
        SNDLVL_90dB = 0x5A,
        SNDLVL_95dB = 0x5F,
        SNDLVL_100dB = 0x64,
        SNDLVL_105dB = 0x69,
        SNDLVL_110dB = 0x6E,
        SNDLVL_120dB = 0x78,
        SNDLVL_130dB = 0x82,
        SNDLVL_GUNFIRE = 0x8C,
        SNDLVL_140dB = 0x8C,
        SNDLVL_150dB = 0x96,
        SNDLVL_180dB = 0xB4,
    };

    enum class VMixPannerType_t : std::uint32_t {
        PANNER_TYPE_LINEAR = 0x0,
        PANNER_TYPE_EQUAL_POWER = 0x1,
    };

    enum class VMixChannelOperation_t : std::uint32_t {
        VMIX_CHAN_STEREO = 0x0,
        VMIX_CHAN_LEFT = 0x1,
        VMIX_CHAN_RIGHT = 0x2,
        VMIX_CHAN_SWAP = 0x3,
        VMIX_CHAN_MONO = 0x4,
        VMIX_CHAN_MID_SIDE = 0x5,
    };

    enum class EMidiNote : std::uint8_t {
        C = 0x0,
        C_Sharp = 0x1,
        D = 0x2,
        D_Sharp = 0x3,
        E = 0x4,
        F = 0x5,
        F_Sharp = 0x6,
        G = 0x7,
        G_Sharp = 0x8,
        A = 0x9,
        A_Sharp = 0xA,
        B = 0xB,
        Count = 0xC,
    };

    enum class SndSeqRegionType_t : std::uint32_t {
        eSndSeqRegionTypeNull = 0x0,
        eSndSeqRegionTypeSndEvt = 0x1,
        eSndSeqRegionTypeMidiSeq = 0x2,
    };

    enum class CVSoundFormat_t : std::uint8_t {
        PCM16 = 0x0,
        PCM8 = 0x1,
        MP3 = 0x2,
        ADPCM = 0x3,
    };

    enum class VMixFilterSlope_t : std::uint8_t {
        FILTER_SLOPE_1POLE_6dB = 0x0,
        FILTER_SLOPE_1POLE_12dB = 0x1,
        FILTER_SLOPE_1POLE_18dB = 0x2,
        FILTER_SLOPE_1POLE_24dB = 0x3,
        FILTER_SLOPE_12dB = 0x4,
        FILTER_SLOPE_24dB = 0x5,
        FILTER_SLOPE_36dB = 0x6,
        FILTER_SLOPE_48dB = 0x7,
        FILTER_SLOPE_MAX = 0x7,
    };

    enum class SndSeqPlayerType_t : std::uint32_t {
        eSndSeqPlayerNull = 0x0,
        eSndSeqPlayerSndEvt = 0x1,
        eSndSeqPlayerMidiSeq = 0x2,
    };

    enum class SosActionLimitSortType_t : std::uint32_t {
        SOS_LIMIT_SORTTYPE_HIGHEST = 0x0,
        SOS_LIMIT_SORTTYPE_LOWEST = 0x1,
    };

    enum class VMixSubgraphSwitchInterpolationType_t : std::uint32_t {
        SUBGRAPH_INTERPOLATION_TEMPORAL_CROSSFADE = 0x0,
        SUBGRAPH_INTERPOLATION_TEMPORAL_FADE_OUT = 0x1,
        SUBGRAPH_INTERPOLATION_KEEP_LAST_SUBGRAPH_RUNNING = 0x2,
    };

    enum class SosGroupType_t : std::uint32_t {
        SOS_GROUPTYPE_DYNAMIC = 0x0,
        SOS_GROUPTYPE_STATIC = 0x1,
    };

    enum class SosActionSetParamSortType_t : std::uint32_t {
        SOS_SETPARAM_SORTTYPE_HIGHEST = 0x0,
        SOS_SETPARAM_SORTTYPE_LOWEST = 0x1,
    };

    enum class SndSeqMidiStatusType_t : std::uint32_t {
        SndSeqMidiStatusNoteOff = 0x8,
        SndSeqMidiStatusNoteOn = 0x9,
        SndSeqMidiStatusKeyPressure = 0xA,
        SndSeqMidiStatusCtrlChange = 0xB,
        SndSeqMidiStatusProgramChange = 0xC,
        SndSeqMidiStatusChannelPressure = 0xD,
        SndSeqMidiStatusPitchBend = 0xE,
    };

    class CVMixDiffusorProcessorDesc {
    public:
        SCHEMA_FIELD(VMixDiffusorDesc_t              , m_desc                                          , 0x20)
    };

    class VMixDynamicsDesc_t {
    public:
        SCHEMA_FIELD(float                           , m_fldbGain                                      , 0x0)
        SCHEMA_FIELD(float                           , m_fldbNoiseGateThreshold                        , 0x4)
        SCHEMA_FIELD(float                           , m_fldbCompressionThreshold                      , 0x8)
        SCHEMA_FIELD(float                           , m_fldbLimiterThreshold                          , 0xC)
        SCHEMA_FIELD(float                           , m_fldbKneeWidth                                 , 0x10)
        SCHEMA_FIELD(float                           , m_flRatio                                       , 0x14)
        SCHEMA_FIELD(float                           , m_flLimiterRatio                                , 0x18)
        SCHEMA_FIELD(float                           , m_flAttackTimeMS                                , 0x1C)
        SCHEMA_FIELD(float                           , m_flReleaseTimeMS                               , 0x20)
        SCHEMA_FIELD(float                           , m_flRMSTimeMS                                   , 0x24)
        SCHEMA_FIELD(float                           , m_flWetMix                                      , 0x28)
        SCHEMA_FIELD(bool                            , m_bPeakMode                                     , 0x2C)
    };

    class CSosGroupActionSoundeventMinMaxValuesSchema {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_strQueryPublicFieldName                       , 0x8)
        SCHEMA_FIELD(::CUtlString                    , m_strDelayPublicFieldName                       , 0x10)
        SCHEMA_FIELD(bool                            , m_bExcludeStoppedSounds                         , 0x18)
        SCHEMA_FIELD(bool                            , m_bExcludeDelayedSounds                         , 0x19)
        SCHEMA_FIELD(bool                            , m_bExcludeSoundsBelowThreshold                  , 0x1A)
        SCHEMA_FIELD(float                           , m_flExcludeSoundsMinThresholdValue              , 0x1C)
        SCHEMA_FIELD(bool                            , m_bExcludSoundsAboveThreshold                   , 0x20)
        SCHEMA_FIELD(float                           , m_flExcludeSoundsMaxThresholdValue              , 0x24)
        SCHEMA_FIELD(::CUtlString                    , m_strMinValueName                               , 0x28)
        SCHEMA_FIELD(::CUtlString                    , m_strMaxValueName                               , 0x30)
    };

    class VMixDelayDesc_t {
    public:
        SCHEMA_FIELD(VMixFilterDesc_t                , m_feedbackFilter                                , 0x0)
        SCHEMA_FIELD(bool                            , m_bEnableFilter                                 , 0x10)
        SCHEMA_FIELD(float                           , m_flDelay                                       , 0x14)
        SCHEMA_FIELD(float                           , m_flDirectGain                                  , 0x18)
        SCHEMA_FIELD(float                           , m_flDelayGain                                   , 0x1C)
        SCHEMA_FIELD(float                           , m_flFeedbackGain                                , 0x20)
        SCHEMA_FIELD(float                           , m_flWidth                                       , 0x24)
    };

    class CVMixOscProcessorDesc {
    public:
        SCHEMA_FIELD(VMixOscDesc_t                   , m_desc                                          , 0x20)
    };

    class CVMixControlOutput {
    public:
        SCHEMA_FIELD(float                           , m_flDefaultValue                                , 0x10)
    };

    class CVoiceContainerBlender {
    public:
        SCHEMA_FIELD(CSoundContainerReference        , m_firstSound                                    , 0xA8)
        SCHEMA_FIELD(CSoundContainerReference        , m_secondSound                                   , 0xC8)
        SCHEMA_FIELD(float                           , m_flBlendFactor                                 , 0xE8)
    };

    class CAudioSentence {
    public:
        SCHEMA_FIELD(bool                            , m_bShouldVoiceDuck                              , 0x0)
        SCHEMA_FIELD(CUtlVector<CAudioPhonemeTag>    , m_RunTimePhonemes                               , 0x8)
        SCHEMA_FIELD(CUtlVector<CAudioEmphasisSample>, m_EmphasisSamples                               , 0x20)
        SCHEMA_FIELD(CAudioMorphData                 , m_morphData                                     , 0x38)
    };

    class CVMixAutoFilterProcessorDesc {
    public:
        SCHEMA_FIELD(VMixAutoFilterDesc_t            , m_desc                                          , 0x20)
    };

    class CVMixBaseProcessorDesc {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x8)
        SCHEMA_FIELD(std::int32_t                    , m_nChannels                                     , 0x14)
        SCHEMA_FIELD(float                           , m_flxfade                                       , 0x18)
    };

    class CVoiceContainerNull {
    public:
    };

    class CVoiceContainerLoopTrigger {
    public:
        SCHEMA_FIELD(CSoundContainerReference        , m_sound                                         , 0xA8)
        SCHEMA_FIELD(float                           , m_flRetriggerTimeMin                            , 0xC8)
        SCHEMA_FIELD(float                           , m_flRetriggerTimeMax                            , 0xCC)
        SCHEMA_FIELD(float                           , m_flFadeTime                                    , 0xD0)
        SCHEMA_FIELD(bool                            , m_bCrossFade                                    , 0xD4)
    };

    class CVoiceContainerEnvelopeAnalyzer {
    public:
        SCHEMA_FIELD(EMode_t                         , m_mode                                          , 0x50)
        SCHEMA_FIELD(float                           , m_fAnalysisWindowMs                             , 0x54)
        SCHEMA_FIELD(float                           , m_flThreshold                                   , 0x58)
    };

    class VMixEnvelopeDesc_t {
    public:
        SCHEMA_FIELD(float                           , m_flAttackTimeMS                                , 0x0)
        SCHEMA_FIELD(float                           , m_flHoldTimeMS                                  , 0x4)
        SCHEMA_FIELD(float                           , m_flReleaseTimeMS                               , 0x8)
    };

    class CVoiceContainerStaticAdditiveSynth {
    public:
        SCHEMA_FIELD(CUtlVector<CVoiceContainerStaticAdditiveSynth_CTone>, m_tones                                         , 0xB8)
    };

    class CVMixConvolutionProcessorDesc {
    public:
        SCHEMA_FIELD(VMixConvolutionDesc_t           , m_desc                                          , 0x20)
    };

    class CVMixAdditionalOutput {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
    };

    class CSosGroupActionTimeBlockLimitSchema {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nMaxCount                                     , 0x8)
        SCHEMA_FIELD(float                           , m_flMaxDuration                                 , 0xC)
    };

    class CSoundContainerReferenceArray {
    public:
        SCHEMA_FIELD(bool                            , m_bUseReference                                 , 0x0)
        SCHEMA_FIELD(CUtlVector<CStrongHandle<InfoForResourceTypeCVoiceContainerBase>>, m_sounds                                        , 0x8)
        SCHEMA_FIELD(CUtlVector<CVoiceContainerBase*>, m_pSounds                                       , 0x20)
    };

    class VMixDynamicsCompressorDesc_t {
    public:
        SCHEMA_FIELD(float                           , m_fldbOutputGain                                , 0x0)
        SCHEMA_FIELD(float                           , m_fldbCompressionThreshold                      , 0x4)
        SCHEMA_FIELD(float                           , m_fldbKneeWidth                                 , 0x8)
        SCHEMA_FIELD(float                           , m_flCompressionRatio                            , 0xC)
        SCHEMA_FIELD(float                           , m_flAttackTimeMS                                , 0x10)
        SCHEMA_FIELD(float                           , m_flReleaseTimeMS                               , 0x14)
        SCHEMA_FIELD(float                           , m_flRMSTimeMS                                   , 0x18)
        SCHEMA_FIELD(float                           , m_flWetMix                                      , 0x1C)
        SCHEMA_FIELD(bool                            , m_bPeakMode                                     , 0x20)
    };

    class CVMixDynamicsCompressorProcessorDesc {
    public:
        SCHEMA_FIELD(VMixDynamicsCompressorDesc_t    , m_desc                                          , 0x20)
    };

    class VMixUtilityDesc_t {
    public:
        SCHEMA_FIELD(VMixChannelOperation_t          , m_nOp                                           , 0x0)
        SCHEMA_FIELD(float                           , m_flInputPan                                    , 0x4)
        SCHEMA_FIELD(float                           , m_flOutputBalance                               , 0x8)
        SCHEMA_FIELD(float                           , m_fldbOutputGain                                , 0xC)
        SCHEMA_FIELD(bool                            , m_bBassMono                                     , 0x10)
        SCHEMA_FIELD(float                           , m_flBassFreq                                    , 0x14)
    };

    class CVMixBoxverb2ProcessorDesc {
    public:
        SCHEMA_FIELD(VMixBoxverbDesc_t               , m_desc                                          , 0x20)
    };

    class CVMixSteamAudioDirectProcessorDesc {
    public:
    };

    class CVoiceContainerBase {
    public:
        SCHEMA_FIELD(CVSound                         , m_vSound                                        , 0x28)
        SCHEMA_FIELD(CVoiceContainerAnalysisBase*    , m_pEnvelopeAnalyzer                             , 0xA0)
    };

    class CVMixSteamAudioPathingProcessorDesc {
    public:
    };

    class CVMixPresetDSPProcessorDesc {
    public:
        SCHEMA_FIELD(VMixPresetDSPDesc_t             , m_desc                                          , 0x20)
    };

    class CSosGroupActionSetSoundeventParameterSchema {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nMaxCount                                     , 0x8)
        SCHEMA_FIELD(float                           , m_flMinValue                                    , 0xC)
        SCHEMA_FIELD(float                           , m_flMaxValue                                    , 0x10)
        SCHEMA_FIELD(::CUtlString                    , m_opvarName                                     , 0x18)
        SCHEMA_FIELD(SosActionSetParamSortType_t     , m_nSortType                                     , 0x20)
    };

    class CVMixSteamAudioHRTFProcessorDesc {
    public:
    };

    class CVMixAutomaticControlInput {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nControlInputIndex                            , 0x8)
        SCHEMA_FIELD(bool                            , m_bIsTrackSend                                  , 0xC)
        SCHEMA_FIELD(bool                            , m_bIsStackVar                                   , 0xD)
    };

    class CVMixEnvelopeProcessorDesc {
    public:
        SCHEMA_FIELD(VMixEnvelopeDesc_t              , m_desc                                          , 0x20)
    };

    class CVMixDualCompressorProcessorDesc {
    public:
        SCHEMA_FIELD(VMixDualCompressorDesc_t        , m_desc                                          , 0x20)
    };

    class VMixDualCompressorDesc_t {
    public:
        SCHEMA_FIELD(float                           , m_flRMSTimeMS                                   , 0x0)
        SCHEMA_FIELD(float                           , m_fldbKneeWidth                                 , 0x4)
        SCHEMA_FIELD(float                           , m_flWetMix                                      , 0x8)
        SCHEMA_FIELD(bool                            , m_bPeakMode                                     , 0xC)
        SCHEMA_FIELD(VMixDynamicsBand_t              , m_bandDesc                                      , 0x10)
    };

    class CVMixCurveHeader {
    public:
        SCHEMA_FIELD(std::uint32_t                   , m_nControlPointCount                            , 0x0)
        SCHEMA_FIELD(std::uint32_t                   , m_nControlPointStart                            , 0x4)
    };

    class CVoiceContainerSet {
    public:
        SCHEMA_FIELD(CUtlVector<CVoiceContainerSetElement>, m_soundsToPlay                                  , 0xA8)
    };

    class CVMixVsndInput {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_defaultValue                                  , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nProcessor                                    , 0x18)
    };

    class CVMixEQ8ProcessorDesc {
    public:
        SCHEMA_FIELD(VMixEQ8Desc_t                   , m_desc                                          , 0x20)
    };

    class CVMixInputBase {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
    };

    class CDSPPresetMixgroupModifierTable {
    public:
        SCHEMA_FIELD(CUtlVector<CDspPresetModifierList>, m_table                                         , 0x0)
    };

    class CSosGroupActionTimeLimitSchema {
    public:
        SCHEMA_FIELD(float                           , m_flMaxDuration                                 , 0x8)
    };

    class CVMixVocoderProcessorDesc {
    public:
        SCHEMA_FIELD(VMixVocoderDesc_t               , m_desc                                          , 0x20)
    };

    class CSosGroupActionMemberCountEnvelopeSchema {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nBaseCount                                    , 0x8)
        SCHEMA_FIELD(std::int32_t                    , m_nTargetCount                                  , 0xC)
        SCHEMA_FIELD(float                           , m_flBaseValue                                   , 0x10)
        SCHEMA_FIELD(float                           , m_flTargetValue                                 , 0x14)
        SCHEMA_FIELD(float                           , m_flAttack                                      , 0x18)
        SCHEMA_FIELD(float                           , m_flDecay                                       , 0x1C)
        SCHEMA_FIELD(::CUtlString                    , m_resultVarName                                 , 0x20)
        SCHEMA_FIELD(bool                            , m_bSaveToGroup                                  , 0x28)
    };

    class CVoiceContainerDefault {
    public:
    };

    class CVoiceContainerLoopXFade {
    public:
        SCHEMA_FIELD(CSoundContainerReference        , m_sound                                         , 0xA8)
        SCHEMA_FIELD(float                           , m_flLoopEnd                                     , 0xC8)
        SCHEMA_FIELD(float                           , m_flLoopStart                                   , 0xCC)
        SCHEMA_FIELD(float                           , m_flFadeOut                                     , 0xD0)
        SCHEMA_FIELD(float                           , m_flFadeIn                                      , 0xD4)
        SCHEMA_FIELD(bool                            , m_bPlayHead                                     , 0xD8)
        SCHEMA_FIELD(bool                            , m_bPlayTail                                     , 0xD9)
        SCHEMA_FIELD(bool                            , m_bEqualPow                                     , 0xDA)
    };

    class VMixPitchShiftDesc_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nGrainSampleCount                             , 0x0)
        SCHEMA_FIELD(float                           , m_flPitchShift                                  , 0x4)
        SCHEMA_FIELD(std::int32_t                    , m_nQuality                                      , 0x8)
        SCHEMA_FIELD(std::int32_t                    , m_nProcType                                     , 0xC)
    };

    class CSndSeqInstMidiSampler {
    public:
        SCHEMA_FIELD(bool                            , m_bIsSoundEvent                                 , 0x20)
        SCHEMA_FIELD(bool                            , m_bStopPrevious                                 , 0x21)
        SCHEMA_FIELD(std::uint8_t                    , m_nMinNote                                      , 0x22)
        SCHEMA_FIELD(std::uint8_t                    , m_nMaxNote                                      , 0x23)
        SCHEMA_FIELD(float                           , m_flMinVelocityAtten                            , 0x24)
        SCHEMA_FIELD(float                           , m_flMaxVelocityAtten                            , 0x28)
        SCHEMA_FIELD(float                           , m_flAttack                                      , 0x2C)
        SCHEMA_FIELD(float                           , m_flRelease                                     , 0x30)
        SCHEMA_FIELD(bool                            , m_bBeatEnvelopes                                , 0x34)
        SCHEMA_FIELD(std::uint8_t                    , m_nNextVoiceSlot                                , 0xD4)
        SCHEMA_FIELD(std::uint32_t                   , m_hSoundEventHash                               , 0xD8)
    };

    class CVMixShaperProcessorDesc {
    public:
        SCHEMA_FIELD(VMixShaperDesc_t                , m_desc                                          , 0x20)
    };

    class VelocityZone_t {
    public:
        SCHEMA_FIELD(std::uint8_t                    , nMaxVel                                         , 0x0)
        SCHEMA_FIELD(std::uint8_t                    , nNextSelection                                  , 0x1)
        SCHEMA_FIELD(std::uint8_t                    , nNumSamples                                     , 0x2)
        SCHEMA_FIELD(std::uint32_t                   , pSamples                                        , 0x4)
    };

    class VMixAutoFilterDesc_t {
    public:
        SCHEMA_FIELD(float                           , m_flEnvelopeAmount                              , 0x0)
        SCHEMA_FIELD(float                           , m_flAttackTimeMS                                , 0x4)
        SCHEMA_FIELD(float                           , m_flReleaseTimeMS                               , 0x8)
        SCHEMA_FIELD(VMixFilterDesc_t                , m_filter                                        , 0xC)
        SCHEMA_FIELD(float                           , m_flLFOAmount                                   , 0x1C)
        SCHEMA_FIELD(float                           , m_flLFORate                                     , 0x20)
        SCHEMA_FIELD(float                           , m_flPhase                                       , 0x24)
        SCHEMA_FIELD(VMixLFOShape_t                  , m_nLFOShape                                     , 0x28)
    };

    class CVoiceContainerDecayingSineWave {
    public:
        SCHEMA_FIELD(float                           , m_flFrequency                                   , 0xA8)
        SCHEMA_FIELD(float                           , m_flDecayTime                                   , 0xAC)
    };

    class VMixOscDesc_t {
    public:
        SCHEMA_FIELD(VMixLFOShape_t                  , oscType                                         , 0x0)
        SCHEMA_FIELD(float                           , m_freq                                          , 0x4)
        SCHEMA_FIELD(float                           , m_flPhase                                       , 0x8)
    };

    class CSosGroupActionOcclusionSchema {
    public:
        SCHEMA_FIELD(float                           , m_flCalculationInterval                         , 0x8)
        SCHEMA_FIELD(float                           , m_flRadius                                      , 0xC)
        SCHEMA_FIELD(float                           , m_flOcclusionScale                              , 0x10)
        SCHEMA_FIELD(float                           , m_flOcclusionMin                                , 0x14)
        SCHEMA_FIELD(float                           , m_flOcclusionMax                                , 0x18)
        SCHEMA_FIELD(float                           , m_flTestDepth                                   , 0x1C)
    };

    class VMixDynamicsBand_t {
    public:
        SCHEMA_FIELD(float                           , m_fldbGainInput                                 , 0x0)
        SCHEMA_FIELD(float                           , m_fldbGainOutput                                , 0x4)
        SCHEMA_FIELD(float                           , m_fldbThresholdBelow                            , 0x8)
        SCHEMA_FIELD(float                           , m_fldbThresholdAbove                            , 0xC)
        SCHEMA_FIELD(float                           , m_flRatioBelow                                  , 0x10)
        SCHEMA_FIELD(float                           , m_flRatioAbove                                  , 0x14)
        SCHEMA_FIELD(float                           , m_flAttackTimeMS                                , 0x18)
        SCHEMA_FIELD(float                           , m_flReleaseTimeMS                               , 0x1C)
        SCHEMA_FIELD(bool                            , m_bEnable                                       , 0x20)
        SCHEMA_FIELD(bool                            , m_bSolo                                         , 0x21)
    };

    class CAudioPhonemeTag {
    public:
        SCHEMA_FIELD(float                           , m_flStartTime                                   , 0x0)
        SCHEMA_FIELD(float                           , m_flEndTime                                     , 0x4)
        SCHEMA_FIELD(std::int32_t                    , m_nPhonemeCode                                  , 0x8)
    };

    class CVoiceContainerAnalysisBase {
    public:
        SCHEMA_FIELD(bool                            , m_bRegenerateCurveOnCompile                     , 0x8)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_curve                                         , 0x10)
    };

    class CVoiceContainerGranulator {
    public:
        SCHEMA_FIELD(float                           , m_flGrainLength                                 , 0xB8)
        SCHEMA_FIELD(float                           , m_flGrainCrossfadeAmount                        , 0xBC)
        SCHEMA_FIELD(float                           , m_flStartJitter                                 , 0xC0)
        SCHEMA_FIELD(float                           , m_flPlaybackJitter                              , 0xC4)
        SCHEMA_FIELD(bool                            , m_bShouldWraparound                             , 0xC8)
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeCVoiceContainerBase>, m_sourceAudio                                   , 0xD0)
    };

    class CVMixSteamAudioHybridReverbProcessorDesc {
    public:
    };

    class CSndSeqInstSndEvtSchema {
    public:
    };

    class CVMixModDelayProcessorDesc {
    public:
        SCHEMA_FIELD(VMixModDelayDesc_t              , m_desc                                          , 0x20)
    };

    class VMixConvolutionDesc_t {
    public:
        SCHEMA_FIELD(float                           , m_fldbGain                                      , 0x0)
        SCHEMA_FIELD(float                           , m_flPreDelayMS                                  , 0x4)
        SCHEMA_FIELD(float                           , m_flWetMix                                      , 0x8)
        SCHEMA_FIELD(float                           , m_fldbLow                                       , 0xC)
        SCHEMA_FIELD(float                           , m_fldbMid                                       , 0x10)
        SCHEMA_FIELD(float                           , m_fldbHigh                                      , 0x14)
        SCHEMA_FIELD(float                           , m_flLowCutoffFreq                               , 0x18)
        SCHEMA_FIELD(float                           , m_flHighCutoffFreq                              , 0x1C)
    };

    class CVMixFilterProcessorDesc {
    public:
        SCHEMA_FIELD(VMixFilterDesc_t                , m_desc                                          , 0x20)
    };

    class CVoiceContainerAmpedDecayingSineWave {
    public:
        SCHEMA_FIELD(float                           , m_flGainAmount                                  , 0xB0)
    };

    class CVoiceContainerStaticAdditiveSynth_CGainScalePerInstance {
    public:
        SCHEMA_FIELD(float                           , m_flMinVolume                                   , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nInstancesAtMinVolume                         , 0x4)
        SCHEMA_FIELD(float                           , m_flMaxVolume                                   , 0x8)
        SCHEMA_FIELD(std::int32_t                    , m_nInstancesAtMaxVolume                         , 0xC)
    };

    class VMixPlateverbDesc_t {
    public:
        SCHEMA_FIELD(float                           , m_flPrefilter                                   , 0x0)
        SCHEMA_FIELD(float                           , m_flInputDiffusion1                             , 0x4)
        SCHEMA_FIELD(float                           , m_flInputDiffusion2                             , 0x8)
        SCHEMA_FIELD(float                           , m_flDecay                                       , 0xC)
        SCHEMA_FIELD(float                           , m_flDamp                                        , 0x10)
        SCHEMA_FIELD(float                           , m_flFeedbackDiffusion1                          , 0x14)
        SCHEMA_FIELD(float                           , m_flFeedbackDiffusion2                          , 0x18)
    };

    class VMixFilterDesc_t {
    public:
        SCHEMA_FIELD(VMixFilterType_t                , m_nFilterType                                   , 0x0)
        SCHEMA_FIELD(VMixFilterSlope_t               , m_nFilterSlope                                  , 0x2)
        SCHEMA_FIELD(bool                            , m_bEnabled                                      , 0x3)
        SCHEMA_FIELD(float                           , m_fldbGain                                      , 0x4)
        SCHEMA_FIELD(float                           , m_flCutoffFreq                                  , 0x8)
        SCHEMA_FIELD(float                           , m_flQ                                           , 0xC)
    };

    class CVMixCommand {
    public:
        SCHEMA_FIELD(VMixGraphCommandID_t            , m_nCommand                                      , 0x0)
        SCHEMA_FIELD(std::uint32_t                   , m_nParameterNameHash                            , 0x4)
        SCHEMA_FIELD(std::int32_t                    , m_nOutputSubmix                                 , 0x8)
        SCHEMA_FIELD(std::int32_t                    , m_nInputSubmix0                                 , 0xC)
        SCHEMA_FIELD(std::int32_t                    , m_nInputSubmix1                                 , 0x10)
        SCHEMA_FIELD(std::int32_t                    , m_nProcessor                                    , 0x14)
        SCHEMA_FIELD(std::int32_t                    , m_nInputValue0                                  , 0x18)
        SCHEMA_FIELD(std::int32_t                    , m_nInputValue1                                  , 0x1C)
    };

    class CVMixFlangerProcessorDesc {
    public:
        SCHEMA_FIELD(VMixFlangerDesc_t               , m_desc                                          , 0x20)
    };

    class SosEditItemInfo_t {
    public:
        SCHEMA_FIELD(SosEditItemType_t               , itemType                                        , 0x0)
        SCHEMA_FIELD(::CUtlString                    , itemName                                        , 0x8)
        SCHEMA_FIELD(::CUtlString                    , itemTypeName                                    , 0x10)
        SCHEMA_FIELD(::CUtlString                    , itemKVString                                    , 0x20)
        SCHEMA_FIELD(::Vector2D                      , itemPos                                         , 0x28)
    };

    class CVoiceContainerEnvelope {
    public:
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeCVoiceContainerBase>, m_sound                                         , 0xA8)
        SCHEMA_FIELD(CVoiceContainerAnalysisBase*    , m_analysisContainer                             , 0xB0)
    };

    class CSosGroupActionSoundeventCountSchema {
    public:
        SCHEMA_FIELD(bool                            , m_bExcludeStoppedSounds                         , 0x8)
        SCHEMA_FIELD(::CUtlString                    , m_strCountKeyName                               , 0x10)
    };

    class CVMixStereoDelayProcessorDesc {
    public:
    };

    class VMixFlangerDesc_t {
    public:
        SCHEMA_FIELD(bool                            , m_bPhaseInvert                                  , 0x0)
        SCHEMA_FIELD(float                           , m_flGlideTime                                   , 0x4)
        SCHEMA_FIELD(float                           , m_flDelay                                       , 0x8)
        SCHEMA_FIELD(float                           , m_flOutputGain                                  , 0xC)
        SCHEMA_FIELD(float                           , m_flFeedbackGain                                , 0x10)
        SCHEMA_FIELD(float                           , m_flFeedforwardGain                             , 0x14)
        SCHEMA_FIELD(float                           , m_flModRate                                     , 0x18)
        SCHEMA_FIELD(float                           , m_flModDepth                                    , 0x1C)
        SCHEMA_FIELD(bool                            , m_bApplyAntialiasing                            , 0x20)
    };

    class CVMixControlMeter {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nValueIndex                                   , 0x10)
    };

    class CVoiceContainerStaticAdditiveSynth_CHarmonic {
    public:
        SCHEMA_FIELD(EWaveform                       , m_nWaveform                                     , 0x0)
        SCHEMA_FIELD(EMidiNote                       , m_nFundamental                                  , 0x1)
        SCHEMA_FIELD(std::int32_t                    , m_nOctave                                       , 0x4)
        SCHEMA_FIELD(float                           , m_flCents                                       , 0x8)
        SCHEMA_FIELD(float                           , m_flPhase                                       , 0xC)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_curve                                         , 0x10)
        SCHEMA_FIELD(CVoiceContainerStaticAdditiveSynth_CGainScalePerInstance, m_volumeScaling                                 , 0x50)
    };

    class CVoiceContainerGenerator {
    public:
    };

    class CVMixDynamicsProcessorDesc {
    public:
        SCHEMA_FIELD(VMixDynamicsDesc_t              , m_desc                                          , 0x20)
    };

    class CSndSeqInstBaseSchema {
    public:
        SCHEMA_FIELD(SndSeqInstrumentType_t          , m_nType                                         , 0x8)
        SCHEMA_FIELD(SndSeqPlayerType_t              , m_nPlayerType                                   , 0xC)
        SCHEMA_FIELD(bool                            , m_bStopCurrentEvents                            , 0x12)
        SCHEMA_FIELD(float                           , m_flBPM                                         , 0x14)
        SCHEMA_FIELD(float                           , m_flBPMFactor                                   , 0x18)
        SCHEMA_FIELD(float                           , m_flBPMInvFactor                                , 0x1C)
    };

    class CVoiceContainerRandomSampler {
    public:
        SCHEMA_FIELD(float                           , m_flAmplitude                                   , 0xB8)
        SCHEMA_FIELD(float                           , m_flAmplitudeJitter                             , 0xBC)
        SCHEMA_FIELD(float                           , m_flTimeJitter                                  , 0xC0)
        SCHEMA_FIELD(float                           , m_flMaxLength                                   , 0xC4)
        SCHEMA_FIELD(std::int32_t                    , m_nNumDelayVariations                           , 0xC8)
        SCHEMA_FIELD(CUtlVector<CStrongHandle<InfoForResourceTypeCVoiceContainerBase>>, m_grainResources                                , 0xD0)
    };

    class CVMixBoxverbProcessorDesc {
    public:
        SCHEMA_FIELD(VMixBoxverbDesc_t               , m_desc                                          , 0x20)
    };

    class CVMixDynamics3BandProcessorDesc {
    public:
        SCHEMA_FIELD(VMixDynamics3BandDesc_t         , m_desc                                          , 0x20)
    };

    class VMixShaperDesc_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nShape                                        , 0x0)
        SCHEMA_FIELD(float                           , m_fldbDrive                                     , 0x4)
        SCHEMA_FIELD(float                           , m_fldbOutputGain                                , 0x8)
        SCHEMA_FIELD(float                           , m_flWetMix                                      , 0xC)
        SCHEMA_FIELD(std::int32_t                    , m_nOversampleFactor                             , 0x10)
    };

    class CVMixControlInputArray {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nArrayIndex                                   , 0x10)
    };

    class SelectedEditItemInfo_t {
    public:
        SCHEMA_FIELD(CUtlVector<SosEditItemInfo_t>   , m_EditItems                                     , 0x0)
    };

    class CVoiceContainerRealtimeFMSineWave {
    public:
        SCHEMA_FIELD(float                           , m_flCarrierFrequency                            , 0xA8)
        SCHEMA_FIELD(float                           , m_flModulatorFrequency                          , 0xAC)
        SCHEMA_FIELD(float                           , m_flModulatorAmount                             , 0xB0)
    };

    class CDspPresetModifierList {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_dspName                                       , 0x0)
        SCHEMA_FIELD(CUtlVector<CDSPMixgroupModifier>, m_modifiers                                     , 0x8)
    };

    class KeyGroup_t {
    public:
        SCHEMA_FIELD(std::uint8_t                    , nCenterNote                                     , 0x0)
        SCHEMA_FIELD(std::uint8_t                    , nMinNote                                        , 0x1)
        SCHEMA_FIELD(std::uint8_t                    , nMaxNote                                        , 0x2)
        SCHEMA_FIELD(std::uint8_t                    , nNumVelocityZones                               , 0x3)
        SCHEMA_FIELD(VelocityZone_t*                 , pVelocityZones                                  , 0x8)
    };

    class SamplerVoice_t {
    public:
        SCHEMA_FIELD(std::uint8_t                    , nNoteNum                                        , 0x0)
    };

    class VMixVocoderDesc_t {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nBandCount                                    , 0x0)
        SCHEMA_FIELD(float                           , m_flBandwidth                                   , 0x4)
        SCHEMA_FIELD(float                           , m_fldBModGain                                   , 0x8)
        SCHEMA_FIELD(float                           , m_flFreqRangeStart                              , 0xC)
        SCHEMA_FIELD(float                           , m_flFreqRangeEnd                                , 0x10)
        SCHEMA_FIELD(float                           , m_fldBUnvoicedGain                              , 0x14)
        SCHEMA_FIELD(float                           , m_flAttackTimeMS                                , 0x18)
        SCHEMA_FIELD(float                           , m_flReleaseTimeMS                               , 0x1C)
        SCHEMA_FIELD(std::int32_t                    , m_nDebugBand                                    , 0x20)
        SCHEMA_FIELD(bool                            , m_bPeakMode                                     , 0x24)
    };

    class CVMixEffectChainProcessorDesc {
    public:
        SCHEMA_FIELD(VMixEffectChainDesc_t           , m_desc                                          , 0x20)
    };

    class CAudioMorphData {
    public:
        SCHEMA_FIELD(CUtlVector<float32>             , m_times                                         , 0x0)
        SCHEMA_FIELD(CUtlVector<uint32>              , m_nameHashCodes                                 , 0x18)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_nameStrings                                   , 0x30)
        SCHEMA_FIELD(CUtlVector<CUtlVector<float32>> , m_samples                                       , 0x48)
        SCHEMA_FIELD(float                           , m_flEaseIn                                      , 0x60)
        SCHEMA_FIELD(float                           , m_flEaseOut                                     , 0x64)
    };

    class VMixEQ8Desc_t {
    public:
        SCHEMA_FIELD(VMixFilterDesc_t                , m_stages                                        , 0x0)
    };

    class VMixBoxverbDesc_t {
    public:
        SCHEMA_FIELD(float                           , m_flSizeMax                                     , 0x0)
        SCHEMA_FIELD(float                           , m_flSizeMin                                     , 0x4)
        SCHEMA_FIELD(float                           , m_flComplexity                                  , 0x8)
        SCHEMA_FIELD(float                           , m_flDiffusion                                   , 0xC)
        SCHEMA_FIELD(float                           , m_flModDepth                                    , 0x10)
        SCHEMA_FIELD(float                           , m_flModRate                                     , 0x14)
        SCHEMA_FIELD(bool                            , m_bParallel                                     , 0x18)
        SCHEMA_FIELD(VMixFilterDesc_t                , m_filterType                                    , 0x1C)
        SCHEMA_FIELD(float                           , m_flWidth                                       , 0x2C)
        SCHEMA_FIELD(float                           , m_flHeight                                      , 0x30)
        SCHEMA_FIELD(float                           , m_flDepth                                       , 0x34)
        SCHEMA_FIELD(float                           , m_flFeedbackScale                               , 0x38)
        SCHEMA_FIELD(float                           , m_flFeedbackWidth                               , 0x3C)
        SCHEMA_FIELD(float                           , m_flFeedbackHeight                              , 0x40)
        SCHEMA_FIELD(float                           , m_flFeedbackDepth                               , 0x44)
        SCHEMA_FIELD(float                           , m_flOutputGain                                  , 0x48)
        SCHEMA_FIELD(float                           , m_flTaps                                        , 0x4C)
    };

    class VMixModDelayDesc_t {
    public:
        SCHEMA_FIELD(VMixFilterDesc_t                , m_feedbackFilter                                , 0x0)
        SCHEMA_FIELD(bool                            , m_bPhaseInvert                                  , 0x10)
        SCHEMA_FIELD(float                           , m_flGlideTime                                   , 0x14)
        SCHEMA_FIELD(float                           , m_flDelay                                       , 0x18)
        SCHEMA_FIELD(float                           , m_flOutputGain                                  , 0x1C)
        SCHEMA_FIELD(float                           , m_flFeedbackGain                                , 0x20)
        SCHEMA_FIELD(float                           , m_flModRate                                     , 0x24)
        SCHEMA_FIELD(float                           , m_flModDepth                                    , 0x28)
        SCHEMA_FIELD(bool                            , m_bApplyAntialiasing                            , 0x2C)
    };

    class CVoiceContainerShapedNoise {
    public:
        SCHEMA_FIELD(bool                            , m_bUseCurveForFrequency                         , 0xA8)
        SCHEMA_FIELD(float                           , m_flFrequency                                   , 0xAC)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_frequencySweep                                , 0xB0)
        SCHEMA_FIELD(bool                            , m_bUseCurveForResonance                         , 0xF0)
        SCHEMA_FIELD(float                           , m_flResonance                                   , 0xF4)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_resonanceSweep                                , 0xF8)
        SCHEMA_FIELD(bool                            , m_bUseCurveForAmplitude                         , 0x138)
        SCHEMA_FIELD(float                           , m_flGainInDecibels                              , 0x13C)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_gainSweep                                     , 0x140)
    };

    class CVSound {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nRate                                         , 0x0)
        SCHEMA_FIELD(CVSoundFormat_t                 , m_nFormat                                       , 0x4)
        SCHEMA_FIELD(std::uint32_t                   , m_nChannels                                     , 0x8)
        SCHEMA_FIELD(std::int32_t                    , m_nLoopStart                                    , 0xC)
        SCHEMA_FIELD(std::uint32_t                   , m_nSampleCount                                  , 0x10)
        SCHEMA_FIELD(float                           , m_flDuration                                    , 0x14)
        SCHEMA_FIELD(CUtlVector<CAudioSentence>      , m_Sentences                                     , 0x18)
        SCHEMA_FIELD(std::uint32_t                   , m_nStreamingSize                                , 0x30)
        SCHEMA_FIELD(CUtlVector<int32>               , m_nSeekTable                                    , 0x38)
        SCHEMA_FIELD(std::int32_t                    , m_nLoopEnd                                      , 0x50)
        SCHEMA_FIELD(::CUtlBinaryBlock               , m_encodedHeader                                 , 0x58)
    };

    class CSoundInfoHeader {
    public:
    };

    class CVMixFreeverbProcessorDesc {
    public:
        SCHEMA_FIELD(VMixFreeverbDesc_t              , m_desc                                          , 0x20)
    };

    class VMixPresetDSPDesc_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_effectName                                    , 0x0)
    };

    class CVoiceContainerSetElement {
    public:
        SCHEMA_FIELD(CSoundContainerReference        , m_sound                                         , 0x0)
        SCHEMA_FIELD(float                           , m_flVolumeDB                                    , 0x20)
    };

    class CVMixPlateReverbProcessorDesc {
    public:
        SCHEMA_FIELD(VMixPlateverbDesc_t             , m_desc                                          , 0x20)
    };

    class CVoiceContainerStaticAdditiveSynth_CTone {
    public:
        SCHEMA_FIELD(CUtlVector<CVoiceContainerStaticAdditiveSynth_CHarmonic>, m_harmonics                                     , 0x0)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_curve                                         , 0x18)
        SCHEMA_FIELD(bool                            , m_bSyncInstances                                , 0x58)
    };

    class CVoiceContainerAsyncGenerator {
    public:
    };

    class CSosGroupActionLimitSchema {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nMaxCount                                     , 0x8)
        SCHEMA_FIELD(SosActionStopType_t             , m_nStopType                                     , 0xC)
        SCHEMA_FIELD(SosActionLimitSortType_t        , m_nSortType                                     , 0x10)
        SCHEMA_FIELD(bool                            , m_bStopImmediate                                , 0x14)
        SCHEMA_FIELD(bool                            , m_bCountStopped                                 , 0x15)
    };

    class CSosSoundEventGroupSchema {
    public:
        SCHEMA_FIELD(SosGroupType_t                  , m_nGroupType                                    , 0x8)
        SCHEMA_FIELD(bool                            , m_bBlocksEvents                                 , 0xC)
        SCHEMA_FIELD(std::int32_t                    , m_nBlockMaxCount                                , 0x10)
        SCHEMA_FIELD(float                           , m_flMemberLifespanTime                          , 0x14)
        SCHEMA_FIELD(bool                            , m_bInvertMatch                                  , 0x18)
        SCHEMA_FIELD(SosGroupFieldBehavior_t         , m_Behavior_EventName                            , 0x1C)
        SCHEMA_FIELD(::CUtlString                    , m_matchSoundEventName                           , 0x20)
        SCHEMA_FIELD(bool                            , m_bMatchEventSubString                          , 0x28)
        SCHEMA_FIELD(::CUtlString                    , m_matchSoundEventSubString                      , 0x30)
        SCHEMA_FIELD(SosGroupFieldBehavior_t         , m_Behavior_EntIndex                             , 0x38)
        SCHEMA_FIELD(float                           , m_flEntIndex                                    , 0x3C)
        SCHEMA_FIELD(SosGroupFieldBehavior_t         , m_Behavior_Opvar                                , 0x40)
        SCHEMA_FIELD(float                           , m_flOpvar                                       , 0x44)
        SCHEMA_FIELD(SosGroupFieldBehavior_t         , m_Behavior_String                               , 0x48)
        SCHEMA_FIELD(::CUtlString                    , m_opvarString                                   , 0x50)
        SCHEMA_FIELD(CUtlVector<CSosGroupActionSchema*>, m_vActions                                      , 0x58)
    };

    class CVoiceContainerMultiBlender {
    public:
        SCHEMA_FIELD(CSoundContainerReferenceArray   , m_soundsToPlay                                  , 0xA8)
        SCHEMA_FIELD(float                           , m_flBlendFactor                                 , 0xE0)
        SCHEMA_FIELD(float                           , m_flCrossover                                   , 0xE4)
    };

    class VMixEffectChainDesc_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_effectName                                    , 0x0)
    };

    class CVMixSubgraphSwitchProcessorDesc {
    public:
        SCHEMA_FIELD(VMixSubgraphSwitchDesc_t        , m_desc                                          , 0x20)
    };

    class CVoiceContainerSwitch {
    public:
        SCHEMA_FIELD(CUtlVector<CSoundContainerReference>, m_soundsToPlay                                  , 0xA8)
    };

    class CVMixDelayProcessorDesc {
    public:
        SCHEMA_FIELD(VMixDelayDesc_t                 , m_desc                                          , 0x20)
    };

    class CVMixControlInput {
    public:
        SCHEMA_FIELD(float                           , m_flDefaultValue                                , 0x10)
    };

    class CVMixPitchShiftProcessorDesc {
    public:
        SCHEMA_FIELD(VMixPitchShiftDesc_t            , m_desc                                          , 0x20)
    };

    class CVMixImpulseResponseInput {
    public:
    };

    class CVoiceContainerSelector {
    public:
        SCHEMA_FIELD(PlayBackMode_t                  , m_mode                                          , 0xA8)
        SCHEMA_FIELD(CSoundContainerReferenceArray   , m_soundsToPlay                                  , 0xB0)
        SCHEMA_FIELD(CUtlVector<float32>             , m_fProbabilityWeights                           , 0xE8)
    };

    class CVoiceContainerParameterBlender {
    public:
        SCHEMA_FIELD(CSoundContainerReference        , m_firstSound                                    , 0xA8)
        SCHEMA_FIELD(CSoundContainerReference        , m_secondSound                                   , 0xC8)
        SCHEMA_FIELD(bool                            , m_bEnableOcclusionBlend                         , 0xE8)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_curve1                                        , 0xF0)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_curve2                                        , 0x130)
        SCHEMA_FIELD(bool                            , m_bEnableDistanceBlend                          , 0x170)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_curve3                                        , 0x178)
        SCHEMA_FIELD(CPiecewiseCurve                 , m_curve4                                        , 0x1B8)
    };

    class CSndSeqInstruments {
    public:
    };

    class CSosGroupActionSoundeventPrioritySchema {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_priorityValue                                 , 0x8)
        SCHEMA_FIELD(::CUtlString                    , m_priorityVolumeScalar                          , 0x10)
        SCHEMA_FIELD(::CUtlString                    , m_priorityContributeButDontRead                 , 0x18)
        SCHEMA_FIELD(::CUtlString                    , m_bPriorityReadButDontContribute                , 0x20)
    };

    class CSosGroupActionSoundeventClusterSchema {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nMinNearby                                    , 0x8)
        SCHEMA_FIELD(float                           , m_flClusterEpsilon                              , 0xC)
        SCHEMA_FIELD(::CUtlString                    , m_shouldPlayOpvar                               , 0x10)
        SCHEMA_FIELD(::CUtlString                    , m_shouldPlayClusterChild                        , 0x18)
        SCHEMA_FIELD(::CUtlString                    , m_clusterSizeOpvar                              , 0x20)
        SCHEMA_FIELD(::CUtlString                    , m_groupBoundingBoxMinsOpvar                     , 0x28)
        SCHEMA_FIELD(::CUtlString                    , m_groupBoundingBoxMaxsOpvar                     , 0x30)
    };

    class CSosGroupActionSchema {
    public:
    };

    class CVMixUtilityProcessorDesc {
    public:
        SCHEMA_FIELD(VMixUtilityDesc_t               , m_desc                                          , 0x20)
    };

    class CVoiceContainerEnum {
    public:
        SCHEMA_FIELD(CSoundContainerReferenceArray   , m_soundsToPlay                                  , 0xA8)
        SCHEMA_FIELD(std::int32_t                    , m_iSelection                                    , 0xE0)
        SCHEMA_FIELD(float                           , m_flCrossfadeTime                               , 0xE4)
    };

    class CSoundContainerReference {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_namespace                                     , 0x0)
        SCHEMA_FIELD(bool                            , m_bUseReference                                 , 0x8)
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeCVoiceContainerBase>, m_sound                                         , 0x10)
        SCHEMA_FIELD(CVoiceContainerBase*            , m_pSound                                        , 0x18)
    };

    class CVMixGraphDescData {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(std::int32_t                    , m_nGraphOutputChannels                          , 0x8)
        SCHEMA_FIELD(bool                            , m_bIsMainGraph                                  , 0xC)
    };

    class VMixSubgraphSwitchDesc_t {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_effectName                                    , 0x8)
        SCHEMA_FIELD(CUtlVector<CUtlString>          , m_subgraphs                                     , 0x10)
        SCHEMA_FIELD(VMixSubgraphSwitchInterpolationType_t, m_interpolationMode                             , 0x28)
        SCHEMA_FIELD(bool                            , m_bOnlyTailsOnFadeOut                           , 0x2C)
        SCHEMA_FIELD(float                           , m_flInterpolationTime                           , 0x30)
    };

    class CVMixNameInput {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_defaultValue                                  , 0x10)
    };

    class CDSPMixgroupModifier {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_mixgroup                                      , 0x0)
        SCHEMA_FIELD(float                           , m_flModifier                                    , 0x8)
        SCHEMA_FIELD(float                           , m_flModifierMin                                 , 0xC)
        SCHEMA_FIELD(float                           , m_flSourceModifier                              , 0x10)
        SCHEMA_FIELD(float                           , m_flSourceModifierMin                           , 0x14)
        SCHEMA_FIELD(float                           , m_flListenerReverbModifierWhenSourceReverbIsActive, 0x18)
    };

    class CAudioEmphasisSample {
    public:
        SCHEMA_FIELD(float                           , m_flTime                                        , 0x0)
        SCHEMA_FIELD(float                           , m_flValue                                       , 0x4)
    };

    class VMixFreeverbDesc_t {
    public:
        SCHEMA_FIELD(float                           , m_flRoomSize                                    , 0x0)
        SCHEMA_FIELD(float                           , m_flDamp                                        , 0x4)
        SCHEMA_FIELD(float                           , m_flWidth                                       , 0x8)
        SCHEMA_FIELD(float                           , m_flLateReflections                             , 0xC)
    };

    class ISndSeqInstruments {
    public:
    };

    class CSoundEventMetaData {
    public:
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeCVMixListResource>, m_soundEventVMix                                , 0x0)
    };

    class CVMixNameInputMeter {
    public:
        SCHEMA_FIELD(std::int32_t                    , m_nValueIndex                                   , 0x10)
    };

    class CVMixPannerProcessorDesc {
    public:
        SCHEMA_FIELD(VMixPannerDesc_t                , m_desc                                          , 0x20)
    };

    class CVMixAudioMeter {
    public:
        SCHEMA_FIELD(::CUtlString                    , m_name                                          , 0x0)
        SCHEMA_FIELD(::CUtlString                    , m_displayName                                   , 0x8)
    };

    class VMixPannerDesc_t {
    public:
        SCHEMA_FIELD(VMixPannerType_t                , m_type                                          , 0x0)
        SCHEMA_FIELD(float                           , m_flStrength                                    , 0x4)
    };

    class VMixDynamics3BandDesc_t {
    public:
        SCHEMA_FIELD(float                           , m_fldbGainOutput                                , 0x0)
        SCHEMA_FIELD(float                           , m_flRMSTimeMS                                   , 0x4)
        SCHEMA_FIELD(float                           , m_fldbKneeWidth                                 , 0x8)
        SCHEMA_FIELD(float                           , m_flDepth                                       , 0xC)
        SCHEMA_FIELD(float                           , m_flWetMix                                      , 0x10)
        SCHEMA_FIELD(float                           , m_flTimeScale                                   , 0x14)
        SCHEMA_FIELD(float                           , m_flLowCutoffFreq                               , 0x18)
        SCHEMA_FIELD(float                           , m_flHighCutoffFreq                              , 0x1C)
        SCHEMA_FIELD(bool                            , m_bPeakMode                                     , 0x20)
        SCHEMA_FIELD(VMixDynamicsBand_t              , m_bandDesc                                      , 0x24)
    };

    class VMixDiffusorDesc_t {
    public:
        SCHEMA_FIELD(float                           , m_flSize                                        , 0x0)
        SCHEMA_FIELD(float                           , m_flComplexity                                  , 0x4)
        SCHEMA_FIELD(float                           , m_flFeedback                                    , 0x8)
        SCHEMA_FIELD(float                           , m_flOutputGain                                  , 0xC)
    };

    class CVoiceContainerTapePlayer {
    public:
        SCHEMA_FIELD(bool                            , m_bShouldWraparound                             , 0xB8)
        SCHEMA_FIELD(CStrongHandle<InfoForResourceTypeCVoiceContainerBase>, m_sourceAudio                                   , 0xC0)
        SCHEMA_FIELD(float                           , m_flTapeSpeedAttackTime                         , 0xC8)
        SCHEMA_FIELD(float                           , m_flTapeSpeedReleaseTime                        , 0xCC)
    };

}
