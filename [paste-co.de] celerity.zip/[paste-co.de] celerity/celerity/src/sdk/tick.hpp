#pragma once

#include <cmath>

// CS2 runs at 64 tick by default. Prefer globalvars when available.
inline constexpr float INTERVAL_PER_TICK = 0.015625f;
inline constexpr float TICK_INTERVAL     = INTERVAL_PER_TICK;

inline int TIME_TO_TICKS(float time) {
	return static_cast<int>(std::floor(time / TICK_INTERVAL + 0.5f));
}

inline float TICKS_TO_TIME(int ticks) {
	return static_cast<float>(ticks) * TICK_INTERVAL;
}
