﻿#pragma once

#include "../schema/schema.hpp"
#include "../../typedefs/c_handle.hpp"
#include "../../memsafe.hpp"
#include "game_enums.hpp"

#include <cmath>
#include <cstring>

class c_econ_item_definition;
class c_paint_kit;
class c_base_player_weapon;

static uint32_t murmur_hash2(const void* key, int len, uint32_t seed) {
	const uint32_t m = 0x5bd1e995;
	const int r = 24;
	uint32_t h = seed ^ len;
	const unsigned char* data = (const unsigned char*)key;

	while (len >= 4) {
		uint32_t k = *(uint32_t*)data;
		k *= m;
		k ^= k >> r;
		k *= m;
		h *= m;
		h ^= k;
		data += 4;
		len -= 4;
	}

	switch (len) {
	case 3: h ^= data[2] << 16; [[fallthrough]];
	case 2: h ^= data[1] << 8; [[fallthrough]];
	case 1: h ^= data[0]; h *= m;
	}

	h ^= h >> 13;
	h *= m;
	h ^= h >> 15;
	return h;
}

static uint32_t string_token_hash(const char* str) {
	if (!str) return 0;
	int len = (int)strlen(str);
	char* lower = (char*)_malloca(len + 1);
	if (!lower) return 0;
	for (int i = 0; i < len; i++) {
		char c = str[i];
		lower[i] = (c >= 'A' && c <= 'Z') ? (c + 32) : c;
	}
	lower[len] = '\0';
	uint32_t hash = murmur_hash2(lower, len, 0x31415926);
	_freea(lower);
	return hash;
}

enum EntityFlags_t : uint32_t {
	EF_IS_INVALID_EHANDLE = 0x1,
	EF_SPAWN_IN_PROGRESS = 0x2,
	EF_IN_STAGING_LIST = 0x4,
	EF_IN_POST_DATA_UPDATE = 0x8,
	EF_DELETE_IN_PROGRESS = 0x10,
	EF_IN_STASIS = 0x20,
	EF_IS_ISOLATED_ALLOCATION_NETWORKABLE = 0x40,
	EF_IS_DORMANT = 0x80,
	EF_IS_PRE_SPAWN = 0x100,
	EF_MARKED_FOR_DELETE = 0x200,
	EF_IS_CONSTRUCTION_IN_PROGRESS = 0x400,
	EF_IS_ISOLATED_ALLOCATION = 0x800,
	EF_HAS_BEEN_UNSERIALIZED = 0x1000,
	EF_IS_SUSPENDED = 0x2000,
	EF_IS_ANONYMOUS_ALLOCATION = 0x4000,
	EF_SUSPEND_OUTSIDE_PVS = 0x8000,
};

enum MoveType_t : int {
	MOVETYPE_NONE = 0,
	MOVETYPE_ISOMETRIC,
	MOVETYPE_WALK,
	MOVETYPE_STEP,
	MOVETYPE_FLY,
	MOVETYPE_FLYGRAVITY,
	MOVETYPE_VPHYSICS,
	MOVETYPE_PUSH,
	MOVETYPE_NOCLIP,
	MOVETYPE_LADDER,
	MOVETYPE_OBSERVER,
	MOVETYPE_CUSTOM,
};

enum Hitbox_t : int {
	HITBOX_HEAD = 0,
	HITBOX_NECK,
	HITBOX_PELVIS,
	HITBOX_STOMACH,
	HITBOX_LOWER_CHEST,
	HITBOX_CHEST,
	HITBOX_UPPER_CHEST,
	HITBOX_RIGHT_THIGH,
	HITBOX_LEFT_THIGH,
	HITBOX_RIGHT_CALF,
	HITBOX_LEFT_CALF,
	HITBOX_RIGHT_FOOT,
	HITBOX_LEFT_FOOT,
	HITBOX_RIGHT_HAND,
	HITBOX_LEFT_HAND,
	HITBOX_RIGHT_UPPER_ARM,
	HITBOX_RIGHT_FOREARM,
	HITBOX_LEFT_UPPER_ARM,
	HITBOX_LEFT_FOREARM,
	HITBOX_MAX
};

enum HitGroup_t : int {
	HITGROUP_GENERIC = 0,
	HITGROUP_HEAD,
	HITGROUP_CHEST,
	HITGROUP_STOMACH,
	HITGROUP_LEFTARM,
	HITGROUP_RIGHTARM,
	HITGROUP_LEFTLEG,
	HITGROUP_RIGHTLEG,
	HITGROUP_NECK,
	HITGROUP_GEAR = 10
};

class c_entity_identity {
public:
	SCHEMA(m_name, const char*, "CEntityIdentity", "m_name");
	SCHEMA(m_designer_name, const char*, "CEntityIdentity", "m_designerName");
	SCHEMA(m_flags, std::uint32_t, "CEntityIdentity", "m_flags");

	// Not in schema dump — packed handle index at +0x10 (sdk-info / Lefrizzel).
	std::uint32_t index_raw() const {
		std::uint32_t v = INVALID_EHANDLE_INDEX;
		if (!memsafe::valid_entity(this))
			return INVALID_EHANDLE_INDEX;
		if (!memsafe::read_field(this, 0x10, v))
			return INVALID_EHANDLE_INDEX;
		return v;
	}

	bool is_valid() {
		return index_raw() != INVALID_EHANDLE_INDEX;
	}

	bool is_in_staging_list() {
		if (!memsafe::valid_entity(this))
			return false;
		return (m_flags() & EF_IN_STAGING_LIST) != 0;
	}

	bool is_safe_to_modify() {
		if (!memsafe::valid_entity(this))
			return false;
		uint32_t flags = m_flags();
		uint32_t unsafe_flags = EF_IN_STAGING_LIST | EF_DELETE_IN_PROGRESS |
		                        EF_SPAWN_IN_PROGRESS | EF_IN_POST_DATA_UPDATE |
		                        EF_IS_CONSTRUCTION_IN_PROGRESS | EF_MARKED_FOR_DELETE;
		return (flags & unsafe_flags) == 0;
	}

	int get_entry_index() {
		if (!is_valid())
			return ENT_ENTRY_MASK;
		return static_cast<int>(index_raw() & ENT_ENTRY_MASK);
	}

	int get_serial_number() {
		return static_cast<int>(index_raw() >> NUM_SERIAL_NUM_SHIFT_BITS);
	}

	bool is_type(const char* name) {
		if (!memsafe::valid_entity(this) || !name)
			return false;
		return fnv1a::hash_64(name) == fnv1a::hash_64(m_designer_name());
	}

	// Legacy name kept for any OFFSET-style call sites.
	std::uint32_t m_index() const { return index_raw(); }
};

class c_entity_instance {
public:
	// sdk-info schemas.json: CEntityInstance::m_pEntity @ 16 (0x10).
	c_entity_identity* identity_ptr() const {
		if (!memsafe::valid_entity(this))
			return nullptr;
		c_entity_identity* identity = nullptr;
		if (!memsafe::read_field(this, 0x10, identity))
			return nullptr;
		if (!identity || !memsafe::valid_entity(identity))
			return nullptr;
		return identity;
	}

	static bool is_plausible_user_ptr(const void* p) {
		return memsafe::is_user_ptr(p);
	}

	c_base_handle get_handle() {
		// Lefrizzel / CS2: CBaseHandle(entry, serial - (flags&1)).
		c_entity_identity* identity = identity_ptr();
		if (!identity || !identity->is_valid())
			return c_base_handle();

		std::uint32_t flags = 0;
		if (!memsafe::read_field(identity, 0x30, flags)) // sdk-info: CEntityIdentity::m_flags @ 48
			return c_base_handle();

		return c_base_handle(
			identity->get_entry_index(),
			identity->get_serial_number() - static_cast<int>(flags & 1u));
	}

	const char* get_designer_name() {
		c_entity_identity* identity = identity_ptr();
		if (!identity)
			return nullptr;
		const char* name = nullptr;
		// sdk-info: m_designerName @ 32 (CUtlSymbolLarge → char*)
		if (!memsafe::read_field(identity, 0x20, name))
			return nullptr;
		return name;
	}

	struct c_schema_class_binding {
		void* m_parent;
		const char* m_binding_name;
		const char* m_dll_name;
		int m_size_of;
	};

	c_schema_class_binding* get_schema_class_binding() {
		c_schema_class_binding* binding = nullptr;
		vmt::call_virtual<void>(this, 44, &binding);
		return binding;
	}

	const char* get_class_name() {
		auto* binding = get_schema_class_binding();
		if (!binding)
			return nullptr;
		return binding->m_binding_name;
	}

	bool is_player_pawn() {
		const char* name = get_class_name();
		return name && strcmp(name, "C_CSPlayerPawn") == 0;
	}

	bool is_player_controller() {
		const char* class_name = get_class_name();
		const char* designer_name = get_designer_name();

		bool is_controller = false;
		if (class_name) {
			is_controller = strcmp(class_name, "CCSPlayerController") == 0;
		}
		if (!is_controller && designer_name) {
			is_controller = strcmp(designer_name, "cs_player_controller") == 0;
		}

		return is_controller;
	}

	bool is_weapon() {
		const char* name = get_designer_name();
		return name && strstr(name, "weapon_") != nullptr;
	}

	// Prefer safe identity_ptr — SCHEMA m_pEntity @ 0x10 (sdk-info).
	c_entity_identity* m_entity() { return identity_ptr(); }
};

class c_skeleton_instance;

// sdk-info: CHitBox size 112 (0x70). CUtlString fields are pointer-sized.
class c_hitbox {
public:
	static constexpr std::size_t k_stride = 0x70;
	static constexpr std::size_t k_off_bone_name = 0x10;
	static constexpr std::size_t k_off_mins = 0x18;
	static constexpr std::size_t k_off_maxs = 0x24;
	static constexpr std::size_t k_off_radius = 0x30;
	static constexpr std::size_t k_off_group = 0x38;

	const char* m_bone_name() const {
		const char* name = nullptr;
		memsafe::read_field(this, k_off_bone_name, name);
		return name;
	}

	vec3_t m_vec_min() const {
		vec3_t v{};
		memsafe::read_field(this, k_off_mins, v);
		return v;
	}

	vec3_t m_vec_max() const {
		vec3_t v{};
		memsafe::read_field(this, k_off_maxs, v);
		return v;
	}

	float m_shape_radius() const {
		float r = 0.f;
		memsafe::read_field(this, k_off_radius, r);
		return r;
	}

	int m_hitgroup() const {
		int g = 0;
		memsafe::read_field(this, k_off_group, g);
		return g;
	}
};

// sdk-info CHitBoxSet: m_HitBoxes CUtlVector @ 16.
// CS2 CUtlVector: size @ +0, elements @ +8 → set+0x10 count, set+0x18 array (Lefrizzel).
class c_hitbox_set {
public:
	static constexpr std::size_t k_off_count = 0x10;
	static constexpr std::size_t k_off_array = 0x18;

	int hitbox_count() const {
		if (!memsafe::is_committed_readable(this, 0x20))
			return 0;
		int count = 0;
		if (!memsafe::read_field(this, k_off_count, count))
			return 0;
		if (count <= 0 || count > 64)
			return 0;
		return count;
	}

	c_hitbox* hitboxes() const {
		if (!memsafe::is_committed_readable(this, 0x20))
			return nullptr;
		c_hitbox* arr = nullptr;
		if (!memsafe::read_field(this, k_off_array, arr))
			return nullptr;
		if (!arr || !memsafe::is_user_ptr(arr))
			return nullptr;
		return arr;
	}

	c_hitbox* get_hitbox(int index) {
		const int count = hitbox_count();
		if (index < 0 || index >= count)
			return nullptr;
		c_hitbox* arr = hitboxes();
		if (!arr)
			return nullptr;
		auto* hb = reinterpret_cast<c_hitbox*>(
			reinterpret_cast<std::uintptr_t>(arr) + static_cast<std::size_t>(index) * c_hitbox::k_stride);
		if (!memsafe::is_committed_readable(hb, c_hitbox::k_stride))
			return nullptr;
		return hb;
	}

	// Back-compat for old call sites that read members directly.
	int m_hitbox_count() const { return hitbox_count(); }
};

class c_model {
public:
	c_hitbox_set* get_hitbox_set() {
		// Prefer entity GetHitboxSet — model mesh walk is brittle across builds.
		return nullptr;
	}

	c_hitbox* get_hitbox(int index) {
		(void)index;
		return nullptr;
	}

	int get_hitbox_count() {
		return 0;
	}

	__declspec(noinline) const char** get_bone_names() {
		uintptr_t data = *reinterpret_cast<uintptr_t*>(reinterpret_cast<uintptr_t>(this) + 0x0);
		if (!data)
			return nullptr;
		return *reinterpret_cast<const char***>(data + 0x168);
	}

	__declspec(noinline) uint32_t get_bone_count() {
		uintptr_t data = *reinterpret_cast<uintptr_t*>(reinterpret_cast<uintptr_t>(this) + 0x0);
		if (!data)
			return 0;
		return *reinterpret_cast<uint32_t*>(data + 0x170);
	}

	int32_t bone_parent(int index) {

		uintptr_t model_addr = reinterpret_cast<uintptr_t>(this);

		uintptr_t bone_data_struct = *reinterpret_cast<uintptr_t*>(model_addr + 0x178);
		if (!bone_data_struct)
			return -1;

		uint32_t count = get_bone_count();
		if (index < 0 || static_cast<uint32_t>(index) >= count)
			return -1;

		int16_t* parent_array = *reinterpret_cast<int16_t**>(bone_data_struct + 0x8);
		if (!parent_array)
			return -1;

		return static_cast<int32_t>(parent_array[index]);
	}

};

template<typename T>
class c_strong_handle {
public:
	T* get() {
		return *reinterpret_cast<T**>(this);
	}

	operator T*() {
		return get();
	}

	T* operator->() {
		return get();
	}
};

class c_model_state {
public:
	SCHEMA(m_model, c_strong_handle<c_model>, "CModelState", "m_hModel");
	OFFSET(c_bone_data*, get_bone_data, 0x80);

	c_model* get_model() {

		uintptr_t model_ptr = *reinterpret_cast<uintptr_t*>(reinterpret_cast<uintptr_t>(this) + 0xC0);
		if (!model_ptr)
			return nullptr;
		return *reinterpret_cast<c_model**>(model_ptr);
	}
};

class c_skeleton_instance {
public:
	// sdk-info: m_modelState @ 0x140 (inherits CGameSceneNode layout above that).
	c_model_state& m_model_state() {
		return *reinterpret_cast<c_model_state*>(reinterpret_cast<std::uintptr_t>(this) + 0x140);
	}

	std::uint8_t m_hitbox_set() {
		std::uint8_t v = 0;
		memsafe::read_field(this, 0x3FC, v);
		return v;
	}

	void calc_world_space_bones(std::uint32_t bone_mask) {
		if (!memsafe::is_user_ptr(this))
			return;
		static const auto fn = reinterpret_cast<void(__fastcall*)(void*, unsigned int)>(
		    SIG("CalculateWorldSpaceBones")
		);
		if (fn) fn(this, bone_mask);
	}
};

class c_game_scene_node {
public:
	// sdk-info client.dll CGameSceneNode:
	//   m_pOwner       48  (0x30)
	//   m_pParent      56  (0x38)
	//   m_pChild       64  (0x40)
	//   m_pNextSibling 72  (0x48)
	//   m_vecAbsOrigin 200 (0xC8)  VectorWS
	c_entity_instance* m_owner() {
		if (!memsafe::valid_scene_node(this))
			return nullptr;
		c_entity_instance* owner = nullptr;
		if (!memsafe::read_field(this, 0x30, owner))
			return nullptr;
		if (owner && !memsafe::valid_entity(owner))
			return nullptr;
		return owner;
	}

	c_game_scene_node* m_child() {
		if (!memsafe::valid_scene_node(this))
			return nullptr;
		c_game_scene_node* child = nullptr;
		if (!memsafe::read_field(this, 0x40, child))
			return nullptr;
		if (child && !memsafe::valid_scene_node(child))
			return nullptr;
		return child;
	}

	c_game_scene_node* m_next_sibling() {
		if (!memsafe::valid_scene_node(this))
			return nullptr;
		c_game_scene_node* sib = nullptr;
		if (!memsafe::read_field(this, 0x48, sib))
			return nullptr;
		if (sib && !memsafe::valid_scene_node(sib))
			return nullptr;
		return sib;
	}

	vec3_t m_abs_origin() const {
		vec3_t out{};
		if (!memsafe::valid_scene_node(this))
			return out;
		if (!memsafe::read_field(this, 0xC8, out))
			return {};
		return out;
	}

	vec3_t m_origin() const { return m_abs_origin(); }

	// CS2: CSkeletonInstance : public CGameSceneNode.
	// For pawns, m_pGameSceneNode already IS the skeleton — no VMT call.
	c_skeleton_instance* get_skeleton_instance() {
		if (!memsafe::valid_scene_node(this))
			return nullptr;
		return reinterpret_cast<c_skeleton_instance*>(this);
	}

	void set_mesh_group_mask(uint64_t mask) {
		if (!memsafe::valid_scene_node(this))
			return;
		using fn_t = void(__fastcall*)(void*, uint64_t);
		static auto fn = reinterpret_cast<fn_t>(
			SIG("CSkeletonInstance::SetMeshGroupMask")
		);
		if (fn) {
			fn(this, mask);
		}
	}
};

class c_collision {
public:
	SCHEMA(m_mins, vec3_t, "CCollisionProperty", "m_vecMins");
	SCHEMA(m_maxs, vec3_t, "CCollisionProperty", "m_vecMaxs");
	SCHEMA(m_solid_flags, std::uint8_t, "CCollisionProperty", "m_usSolidFlags");
	SCHEMA(m_collision_group, std::uint8_t, "CCollisionProperty", "m_CollisionGroup");

	std::uint16_t get_collision_mask() {
		return *reinterpret_cast<std::uint16_t*>(reinterpret_cast<std::uintptr_t>(this) + 0x38);
	}
};

class c_cs_player_pawn;

class c_glow_property {
public:
	SCHEMA(m_is_glowing, bool, "CGlowProperty", "m_bGlowing");
	SCHEMA(m_glow_color_override, int, "CGlowProperty", "m_glowColorOverride");
	SCHEMA(m_glow_type, int32_t, "CGlowProperty", "m_iGlowType");
	SCHEMA(m_glow_team, int32_t, "CGlowProperty", "m_iGlowTeam");
	SCHEMA(m_glow_range, int32_t, "CGlowProperty", "m_nGlowRange");
	SCHEMA(m_glow_range_min, int32_t, "CGlowProperty", "m_nGlowRangeMin");
	SCHEMA(m_glow_time, float, "CGlowProperty", "m_flGlowTime");
	SCHEMA(m_glow_start_time, float, "CGlowProperty", "m_flGlowStartTime");

	c_cs_player_pawn* get_owner() {
		return *reinterpret_cast<c_cs_player_pawn**>(reinterpret_cast<uintptr_t>(this) + 0x18);
	}
};

class c_base_entity : public c_entity_instance {
public:
	SCHEMA(m_health, int, "C_BaseEntity", "m_iHealth");
	SCHEMA(m_team_num, int, "C_BaseEntity", "m_iTeamNum");
	SCHEMA(m_flags, int, "C_BaseEntity", "m_fFlags");
	SCHEMA(m_move_type, int, "C_BaseEntity", "m_MoveType");
	SCHEMA(m_nSubclassID, uint32_t, "C_BaseEntity", "m_nSubclassID");

	// sdk-info: C_BaseEntity::m_pGameSceneNode @ 0x330
	c_game_scene_node* m_scene_node() {
		if (!memsafe::valid_entity(this))
			return nullptr;
		c_game_scene_node* node = nullptr;
		if (!memsafe::read_field(this, 0x330, node))
			return nullptr;
		if (node && !memsafe::valid_scene_node(node))
			return nullptr;
		return node;
	}

	SCHEMA(m_owner_entity, c_base_handle, "C_BaseEntity", "m_hOwnerEntity");
	SCHEMA(m_collision, c_collision*, "C_BaseEntity", "m_pCollision");
	SCHEMA(m_vec_velocity, vec3_t, "C_BaseEntity", "m_vecVelocity");
	// sdk-info: m_vecAbsVelocity @ 0x3F8 (NOT 0x3FC — that overlaps other fields on some dumps).
	vec3_t m_vec_abs_velocity() {
		vec3_t v{};
		static std::uint32_t off = 0;
		if (!off) {
			off = schema_get_offset("client.dll", "C_BaseEntity", "m_vecAbsVelocity");
			if (!off || off == 0x3FC)
				off = 0x3F8;
		}
		if (!memsafe::read_field(this, off, v))
			return {};
		return v;
	}
	SCHEMA(m_sim_time, float, "C_BaseEntity", "m_flSimulationTime");
	SCHEMA(m_simulation_tick, int, "C_BaseEntity", "m_nSimulationTick");

	void set_model(const char* model_path) {
		static auto fn = reinterpret_cast<void(__fastcall*)(void*, const char*)>(
			SIG("SetModel")
		);
		if (fn) {
			fn(this, model_path);
		}
	}

	bool is_weapon() {
		return vmt::call_virtual<bool>(this, 158);
	}

	void remove() {
		vmt::call_virtual<void>(this, 151);
	}

	c_hitbox_set* get_hitbox_set(unsigned int index) {
		if (!memsafe::valid_entity(this))
			return nullptr;
		using fn_get_hitbox_set = c_hitbox_set*(__fastcall*)(void*, unsigned int);
		static auto fn = reinterpret_cast<fn_get_hitbox_set>(
			SIG("GetHitboxSet")
		);
		if (!fn)
			return nullptr;
		c_hitbox_set* set = fn(this, index);
		if (!set || !memsafe::is_committed_readable(set, 0x20))
			return nullptr;
		return set;
	}
};

class c_attribute_list {
public:
	SCHEMA(m_attributes, uintptr_t, "CAttributeList", "m_Attributes");
};

enum EItemQuality : int {
	QUALITY_DEFAULT = 0,
	QUALITY_GENUINE = 1,
	QUALITY_VINTAGE = 2,
	QUALITY_UNUSUAL = 3,
	QUALITY_UNIQUE = 4,
	QUALITY_COMMUNITY = 5,
	QUALITY_DEVELOPER = 6,
	QUALITY_SELFMADE = 7,
	QUALITY_CUSTOMIZED = 8,
	QUALITY_STRANGE = 9,
	QUALITY_COMPLETED = 10,
	QUALITY_HAUNTED = 11,
	QUALITY_TOURNAMENT = 12,
};

class c_econ_item_view {
public:
	SCHEMA(m_restore_custom_material_after_precache, bool, "C_EconItemView", "m_bRestoreCustomMaterialAfterPrecache");
	SCHEMA(m_definition_index, uint16_t, "C_EconItemView", "m_iItemDefinitionIndex");
	SCHEMA(m_entity_quality, int32_t, "C_EconItemView", "m_iEntityQuality");
	SCHEMA(m_item_id, uint64_t, "C_EconItemView", "m_iItemID");
	SCHEMA(m_item_id_high, uint32_t, "C_EconItemView", "m_iItemIDHigh");
	SCHEMA(m_item_id_low, uint32_t, "C_EconItemView", "m_iItemIDLow");
	SCHEMA(m_account_id, uint32_t, "C_EconItemView", "m_iAccountID");
	SCHEMA(m_initialized, bool, "C_EconItemView", "m_bInitialized");
	SCHEMA_ARRAY(m_attribute_list, c_attribute_list, "C_EconItemView", "m_AttributeList");
	SCHEMA_ARRAY(m_custom_name, char, "C_EconItemView", "m_szCustomName");
	SCHEMA(m_initialized_tags, bool, "C_EconItemView", "m_bInitializedTags");
	OFFSET(std::uintptr_t, m_name_description_ptr, 0x200);

	c_econ_item_definition* get_static_data() {
		return vmt::call_virtual<c_econ_item_definition*>(this, 13);
	}

	c_paint_kit* construct_paint_kit() {
		static auto fn = reinterpret_cast<c_paint_kit* (__fastcall*)(void*)>(
			SIG("CEconItemView::ConstructPaintKit")
		);
		if (fn) {
			return fn(this);
		}
		return nullptr;
	}

	int get_custom_paint_kit() {
		return vmt::call_virtual<int>(this, 2);
	}
};

class c_attribute_container {
public:
	SCHEMA_ARRAY(m_item, c_econ_item_view, "C_AttributeContainer", "m_Item");
};

class c_econ_entity : public c_base_entity {
public:
	SCHEMA(m_attributes_initialized, bool, "C_EconEntity", "m_bAttributesInitialized");
	SCHEMA_ARRAY(m_attribute_manager, c_attribute_container, "C_EconEntity", "m_AttributeManager");
	SCHEMA(m_original_owner_xuid_low, uint32_t, "C_EconEntity", "m_OriginalOwnerXuidLow");
	SCHEMA(m_original_owner_xuid_high, uint32_t, "C_EconEntity", "m_OriginalOwnerXuidHigh");
	SCHEMA(m_paint_kit, int, "C_EconEntity", "m_nFallbackPaintKit");
	SCHEMA(m_seed, int, "C_EconEntity", "m_nFallbackSeed");
	SCHEMA(m_wear, float, "C_EconEntity", "m_flFallbackWear");
	SCHEMA(m_statrack, int, "C_EconEntity", "m_nFallbackStatTrak");

	void update_subclass(uint16_t def_index = 0) {
		static auto fn = reinterpret_cast<void(__fastcall*)(void*)>(
			SIG("UpdateSubClass")
		);

		if (def_index != 0) {
			char buf[16];
			sprintf_s(buf, "%d", def_index);
			uint32_t hash = string_token_hash(buf);
			m_nSubclassID() = hash;
		}
		fn(this);
	}

	void update_skin(bool force = true) {

		vmt::call_virtual<void>(this, 110, force);
	}

	void regenerate_weapon_skin(bool force = true) {
		static auto fn = reinterpret_cast<void(__fastcall*)(void*, bool)>(
			SIG("RegenerateWeaponSkin")
		);
		if (fn)
			fn(this, force);
	}

	void apply_econ_customization(bool force = true) {
		static auto fn = reinterpret_cast<std::int64_t(__fastcall*)(void*, bool)>(
			SIG("ApplyEconCustomization")
		);
		if (fn)
			fn(this, force);
	}

	void update_weapon_data() {

		vmt::call_virtual<void*>(this, 195);
	}
};

class c_player_weapon_service {
public:
	SCHEMA(m_active_weapon, c_base_handle, "CPlayer_WeaponServices", "m_hActiveWeapon");
	SCHEMA(my_weapons, c_network_utl_vector<c_base_handle>, "CPlayer_WeaponServices", "m_hMyWeapons");
};

using firing_float_t = float[2];

class c_cs_weapon_base_v_data {
public:
	SCHEMA(m_max_clip1, int32_t, "CBasePlayerWeaponVData", "m_iMaxClip1");
	SCHEMA(m_max_clip2, int32_t, "CBasePlayerWeaponVData", "m_iMaxClip2");
	SCHEMA(m_default_clip1, int32_t, "CBasePlayerWeaponVData", "m_iDefaultClip1");
	SCHEMA(m_default_clip2, int32_t, "CBasePlayerWeaponVData", "m_iDefaultClip2");
	SCHEMA(m_weight, int32_t, "CBasePlayerWeaponVData", "m_iWeight");
	SCHEMA(m_name, const char*, "CCSWeaponBaseVData", "m_szName");
	SCHEMA(m_cycle_time, firing_float_t, "CCSWeaponBaseVData", "m_flCycleTime");
	SCHEMA(m_damage, int, "CCSWeaponBaseVData", "m_nDamage");
	SCHEMA(m_armor_ratio, float, "CCSWeaponBaseVData", "m_flArmorRatio");
	SCHEMA(m_range, float, "CCSWeaponBaseVData", "m_flRange");
	SCHEMA(m_range_modifier, float, "CCSWeaponBaseVData", "m_flRangeModifier");
	SCHEMA(m_penetration, float, "CCSWeaponBaseVData", "m_flPenetration");
	SCHEMA(m_headshot_multiplier, float, "CCSWeaponBaseVData", "m_flHeadshotMultiplier");
	SCHEMA(m_spread, float, "CCSWeaponBaseVData", "m_flSpread");
	SCHEMA(m_bullets, int, "CCSWeaponBaseVData", "m_nNumBullets");
	SCHEMA(m_weapon_type, int, "CCSWeaponBaseVData", "m_WeaponType");
	// sdk-info: CFiringModeFloat = float[2] (hip / alt). Offsets from CCSWeaponBaseVData.
	SCHEMA(m_max_speed, firing_float_t, "CCSWeaponBaseVData", "m_flMaxSpeed");
	SCHEMA(m_inaccuracy_stand, firing_float_t, "CCSWeaponBaseVData", "m_flInaccuracyStand");
	SCHEMA(m_inaccuracy_move, firing_float_t, "CCSWeaponBaseVData", "m_flInaccuracyMove");
	// sdk-info: plain float32 (not CFiringModeFloat).
	SCHEMA(m_recovery_time_stand, float, "CCSWeaponBaseVData", "m_flRecoveryTimeStand");
	SCHEMA(m_recovery_time_crouch, float, "CCSWeaponBaseVData", "m_flRecoveryTimeCrouch");
};

class c_base_player_weapon : public c_econ_entity {
public:
	SCHEMA(m_next_primary_attack, int32_t, "C_BasePlayerWeapon", "m_nNextPrimaryAttackTick");
	SCHEMA(m_next_primary_attack_ratio, float, "C_BasePlayerWeapon", "m_flNextPrimaryAttackTickRatio");
	SCHEMA(m_next_secondary_attack, int32_t, "C_BasePlayerWeapon", "m_nNextSecondaryAttackTick");
	SCHEMA(m_next_secondary_attack_ratio, float, "C_BasePlayerWeapon", "m_flNextSecondaryAttackTickRatio");
	SCHEMA(m_clip1, int32_t, "C_BasePlayerWeapon", "m_iClip1");
	SCHEMA(m_clip2, int32_t, "C_BasePlayerWeapon", "m_iClip2");
	SCHEMA(m_in_reload, bool, "C_CSWeaponBase", "m_bInReload");
	SCHEMA(m_burst_mode, bool, "C_CSWeaponBase", "m_bBurstMode");
	SCHEMA(m_burst_shots_remaining, int, "C_CSWeaponBaseGun", "m_iBurstShotsRemaining");

	SCHEMA_WITH_OFFSET(m_get_sub_class_id, void*, "C_BaseEntity", "m_nSubclassID", 0x8);

	c_cs_weapon_base_v_data* get_weapon_data() {
		return static_cast<c_cs_weapon_base_v_data*>(m_get_sub_class_id());
	}

	float get_max_speed() {
		return vmt::call_virtual<float>(this, 340);
	}
};

class c_cs_weapon_base : public c_base_player_weapon {
public:
	SCHEMA(m_zoom_level, int, "C_CSWeaponBaseGun", "m_zoomLevel");
	SCHEMA(m_postpone_fire_ready_ticks, int32_t, "C_CSWeaponBase", "m_nPostponeFireReadyTicks");
	SCHEMA(m_postpone_fire_ready_frac, float, "C_CSWeaponBase", "m_flPostponeFireReadyFrac");
	// Live accuracy penalty — the exact value the server decays toward the
	// stance baseline each tick (exp(-dt / recovery_time)).
	SCHEMA(m_accuracy_penalty, float, "C_CSWeaponBase", "m_fAccuracyPenalty");

	float get_spread() {
		using fn_t = float(__fastcall*)(void*);
		static fn_t fn = reinterpret_cast<fn_t>(
			SIG("PointerToGetSpreadFunction")
		);
		return fn ? fn(this) : 0.0f;
	}

	float get_inaccuracy() {
		using fn_t = float(__fastcall*)(void*, float*, float*);
		static fn_t fn = reinterpret_cast<fn_t>(
			SIG("PointerToGetInaccuracyFunction")
		);
		float move = 0.f, air = 0.f;
		return fn ? fn(this, &move, &air) : 0.0f;
	}

	void update_accuracy_penalty() {
		using fn_t = void(__fastcall*)(void*);
		// Weave pattern — VMT slot drifts and calling the wrong index mutates weapon state.
		static const auto fn = reinterpret_cast<fn_t>(SIG("UpdateAccuracy"));
		if (fn)
			fn(this);
	}
};

class c_base_cs_grenade : public c_cs_weapon_base {
public:
	SCHEMA(m_held_by_player, bool, "C_BaseCSGrenade", "m_bIsHeldByPlayer");
	SCHEMA(m_pin_pulled, bool, "C_BaseCSGrenade", "m_bPinPulled");
	SCHEMA(m_throw_time, float, "C_BaseCSGrenade", "m_fThrowTime");
	SCHEMA(m_throw_strength, float, "C_BaseCSGrenade", "m_flThrowStrength");
};

class c_cs_player_item_service {
public:
	SCHEMA(m_has_helmet, bool, "CCSPlayer_ItemServices", "m_bHasHelmet");
};

class c_player_movement_service {
public:
	SCHEMA(m_max_speed, float, "CPlayer_MovementServices", "m_flMaxspeed");
	SCHEMA(m_surface_friction, float, "CPlayer_MovementServices_Humanoid", "m_flSurfaceFriction");

	OFFSET(float, m_flFallVelocity, 0x25C)

	using set_pred_cmd_fn   = void(__fastcall*)(void*, c_user_cmd*);
	using reset_pred_cmd_fn = void(__fastcall*)(void*);

	// Darkside/sdk: these are scanned exports — NOT fixed VMT indices (43/44 drift and
	// calling the wrong slot corrupts local pawn / weapon / view state).
	void set_prediction_command(c_user_cmd* user_cmd) {
		static const auto fn = reinterpret_cast<set_pred_cmd_fn>(SIG("SetPredictionCommand"));
		if (fn)
			fn(this, user_cmd);
	}

	void reset_prediction_command() {
		static const auto fn = reinterpret_cast<reset_pred_cmd_fn>(SIG("ResetPredictionCommand"));
		if (fn)
			fn(this);
	}
};

class c_cs_player_modern_jump {
public:
	SCHEMA(m_last_landed_frac,       float, "CCSPlayerModernJump", "m_flLastLandedFrac");
	SCHEMA(m_last_landed_velocity_x, float, "CCSPlayerModernJump", "m_flLastLandedVelocityX");
	SCHEMA(m_last_landed_velocity_y, float, "CCSPlayerModernJump", "m_flLastLandedVelocityY");
	SCHEMA(m_last_landed_velocity_z, float, "CCSPlayerModernJump", "m_flLastLandedVelocityZ");
};

class c_cs_player_movement_services : public c_player_movement_service {
public:
	SCHEMA(m_duck_amount, float, "CCSPlayer_MovementServices", "m_flDuckAmount");
	SCHEMA(m_duck_speed, float, "CCSPlayer_MovementServices", "m_flDuckSpeed");
	SCHEMA(m_ducked, bool, "CCSPlayer_MovementServices", "m_bDucked");
	SCHEMA(m_ducking, bool, "CCSPlayer_MovementServices", "m_bDucking");
	SCHEMA(m_stamina, float, "CCSPlayer_MovementServices", "m_flStamina");
	SCHEMA(m_offset_tick_complete_time, float, "CCSPlayer_MovementServices", "m_flOffsetTickCompleteTime");
	SCHEMA(m_offset_tick_stashed_speed, float, "CCSPlayer_MovementServices", "m_flOffsetTickStashedSpeed");
	SCHEMA_ARRAY(m_arr_force_subtick_move_when, float, "CPlayer_MovementServices", "m_arrForceSubtickMoveWhen");

	c_cs_player_modern_jump* m_modern_jump() {
		static const std::uint32_t offset = schema_get_offset("CCSPlayer_MovementServices", "m_ModernJump");
		if (!offset)
			return nullptr;
		return reinterpret_cast<c_cs_player_modern_jump*>(reinterpret_cast<uintptr_t>(this) + offset);
	}
};

class c_player_observer_services {
public:
	SCHEMA(m_observer_mode, uint8_t, "CPlayer_ObserverServices", "m_iObserverMode");
	SCHEMA(m_observer_target, c_base_handle, "CPlayer_ObserverServices", "m_hObserverTarget");
};

class c_cs_player_pawn : public c_base_entity {
public:
	// sdk-info client.dll schemas.json: C_BasePlayerPawn::m_pWeaponServices = 4616 (0x1208).
	// client_dll.hpp 0x11E0 is stale — do NOT use it.
	c_player_weapon_service* m_weapon_services() {
		if (!this || !memsafe::is_user_ptr(this) || !memsafe::is_aligned_ptr(this))
			return nullptr;
		auto* svc = *reinterpret_cast<c_player_weapon_service* const*>(
			reinterpret_cast<const std::uint8_t*>(this) + 0x1208);
		if (svc && !memsafe::is_user_ptr(svc))
			return nullptr;
		return svc;
	}

	SCHEMA(m_camera_services, void*, "C_BasePlayerPawn", "m_pCameraServices");
	SCHEMA(m_controller, c_base_handle, "C_BasePlayerPawn", "m_hController");
	SCHEMA_ARRAY(m_econ_gloves, c_econ_item_view, "C_CSPlayerPawn", "m_EconGloves");
	SCHEMA(m_need_to_reapply_gloves, bool, "C_CSPlayerPawn", "m_bNeedToReApplyGloves");
	SCHEMA(m_econ_gloves_changed, std::uint8_t, "C_CSPlayerPawn", "m_nEconGlovesChanged");
	SCHEMA(m_hud_model_arms, c_base_handle, "C_CSPlayerPawn", "m_hHudModelArms");
	SCHEMA(m_last_spawn_time_index, float, "C_CSPlayerPawnBase", "m_flLastSpawnTimeIndex");
	SCHEMA(m_is_buy_menu_open, bool, "C_CSPlayerPawn", "m_bIsBuyMenuOpen");
	SCHEMA(m_armor_value, int, "C_CSPlayerPawn", "m_ArmorValue");
	SCHEMA(m_movement_services, c_player_movement_service*, "C_BasePlayerPawn", "m_pMovementServices");
	SCHEMA(m_item_services, c_cs_player_item_service*, "C_BasePlayerPawn", "m_pItemServices");
	SCHEMA(m_scoped, bool, "C_CSPlayerPawn", "m_bIsScoped");
	SCHEMA(m_observer_services, c_player_observer_services*, "C_BasePlayerPawn", "m_pObserverServices");
	SCHEMA(m_has_female_voice, bool, "C_CSPlayerPawn", "m_bHasFemaleVoice");
	SCHEMA(m_has_defuser, bool, "C_CSPlayerPawn", "m_bHasDefuser");

	bool is_alive() {
		if (!memsafe::valid_entity(this))
			return false;
		return m_health() > 0;
	}

	void set_body_group(const char* name = "first_or_third_person") {

		using fn_t = void(__fastcall*)(void*, const char*, unsigned int);
		static auto fn = reinterpret_cast<fn_t>(
			SIG("CBaseModelEntity::SetBodyGroup")
		);
		if (fn) {
			fn(this, name, 1);
		}
	}

vec3_t get_eye_pos() {
		vec3_t view_{};
		vmt::call_virtual<void>(this, 174, &view_);
		return view_;
	}

	// World eye / shoot origin. Prefer abs+viewoffset as truth, then accept shoot-history /
	// LocalData only when they sit near that eye (stale history causes peek misses).
	vec3_t get_eye_position_world() {
		if (!this || !memsafe::is_user_ptr(this))
			return {};

		auto plausible = [](const vec3_t& p) {
			if (!p.is_valid() || p.is_zero())
				return false;
			if (std::fabs(p.x) > 16384.f || std::fabs(p.y) > 16384.f || std::fabs(p.z) > 16384.f)
				return false;
			// Broken local-data / view-only pattern seen in rage logs: (0, height, 0)
			if (std::fabs(p.x) < 1.f && std::fabs(p.z) < 1.f)
				return false;
			return true;
		};

		// 1) Engine GetAbsOrigin (VectorWS) + m_vecViewOffset @ 0xE78 (sdk-info)
		vec3_t origin{};
		using fn_abs_t = vec3_t*(__fastcall*)(void*);
		static const auto get_abs = reinterpret_cast<fn_abs_t>(SIG("GetAbsOrigin"));
		if (get_abs) {
			if (vec3_t* p = get_abs(this)) {
				if (memsafe::is_user_ptr(p))
					origin = *p;
			}
		}
		if (!plausible(origin)) {
			if (auto* node = m_scene_node())
				origin = node->m_abs_origin();
		}
		if (!plausible(origin))
			return {};

		vec3_t view_off{};
		std::memcpy(&view_off,
			reinterpret_cast<const std::uint8_t*>(this) + 0xE78,
			sizeof(view_off));
		// Standing eye is ~Z up (0,0,54..72). Remap mistaken Y-only reads.
		if (view_off.is_valid()) {
			if (std::fabs(view_off.x) < 1.f && std::fabs(view_off.z) < 1.f
				&& view_off.y > 40.f && view_off.y < 80.f)
				view_off = { 0.f, 0.f, view_off.y };
			else if (!view_off.is_zero()
				&& (std::fabs(view_off.z) < 1.f && std::fabs(view_off.y) < 1.f))
				view_off = {};
		} else {
			view_off = {};
		}
		if (view_off.is_zero())
			view_off = { 0.f, 0.f, 64.f };

		const vec3_t eye_abs = origin + view_off;
		if (!plausible(eye_abs))
			return {};

		auto near_live_eye = [&](const vec3_t& p) {
			const vec3_t d = p - eye_abs;
			// Allow small pred / duck jitter — reject last-shot history from across the map.
			return d.length_sqr() <= (48.f * 48.f);
		};

		// 2) WeaponServices shoot-position history — only if still near live eye.
		{
			c_player_weapon_service* svc = m_weapon_services();
			if (svc && memsafe::is_user_ptr(svc)) {
				constexpr std::size_t k_hist = 0xE8;
				constexpr std::size_t k_head = 0x368;
				constexpr std::size_t k_count = 0x36C;
				constexpr int k_slots = 32;
				constexpr int k_entry = 20;
				const int head = *reinterpret_cast<const int*>(
					reinterpret_cast<const std::uint8_t*>(svc) + k_head);
				const int count = *reinterpret_cast<const int*>(
					reinterpret_cast<const std::uint8_t*>(svc) + k_count);
				if (count > 0 && count <= k_slots) {
					const int start = ((head % k_slots) + k_slots - 1) % k_slots;
					for (int n = 0; n < count; ++n) {
						const int slot = (start - n + k_slots * 4) % k_slots;
						const auto* e = reinterpret_cast<const std::uint8_t*>(svc) + k_hist
							+ static_cast<std::size_t>(slot) * k_entry;
						vec3_t pos{};
						std::memcpy(&pos.x, e + 8, 4);
						std::memcpy(&pos.y, e + 12, 4);
						std::memcpy(&pos.z, e + 16, 4);
						if (plausible(pos) && near_live_eye(pos))
							return pos;
					}
				}
			}
		}

		return eye_abs;
	}

	int get_bone_index(const char* name) {
		if (!this || !name || !c_entity_instance::is_plausible_user_ptr(this))
			return -1;
		// sdk-info: GetBonePositionByName / LookupBone / C_BaseEntity_GetBoneIdByName
		// (same body). Returns bone id, NOT a world position.
		static const auto fn = reinterpret_cast<int(__fastcall*)(void*, const char*)>(
			SIG("GetBonePositionByName")
		);
		if (!fn)
			return -1;
		return fn(this, name);
	}

	// Prefer bone array (CModelState +0x80) — GetBonePosition SIG is NOT in sdk-info
	// and crashes when scene/skeleton is missing (AV @ 0xE).
	vec3_t get_bone_position(int index) {
		if (!this || index < 0 || index >= 128
			|| !c_entity_instance::is_plausible_user_ptr(this))
			return {};

		auto* node = m_scene_node();
		if (!node || !c_entity_instance::is_plausible_user_ptr(node))
			return {};

		auto* skeleton = node->get_skeleton_instance();
		if (!skeleton || !c_entity_instance::is_plausible_user_ptr(skeleton))
			return {};

		c_bone_data* bones = skeleton->m_model_state().get_bone_data();
		if (!bones || !c_entity_instance::is_plausible_user_ptr(bones))
			return {};

		const vec3_t pos = bones[index].m_pos;
		if (pos.is_valid() && !pos.is_zero())
			return pos;
		return {};
	}

	c_base_player_weapon* get_active_weapon() {
		if (!this || !memsafe::is_user_ptr(this))
			return nullptr;

		c_player_weapon_service* weapon_services = this->m_weapon_services();
		if (!weapon_services || !memsafe::is_user_ptr(weapon_services))
			return nullptr;

		// sdk-info: CPlayer_WeaponServices::m_hActiveWeapon = 0x60
		const c_base_handle h = *reinterpret_cast<const c_base_handle*>(
			reinterpret_cast<const std::uint8_t*>(weapon_services) + 0x60);
		if (!h.is_valid())
			return nullptr;

		extern void* get_entity_by_index(int index);
		void* ent = get_entity_by_index(h.get_entry_index());
		if (!ent || !memsafe::is_user_ptr(ent))
			return nullptr;
		return reinterpret_cast<c_base_player_weapon*>(ent);
	}

	bool has_armor(int hitgroup) {
		if (hitgroup == HITGROUP_HEAD)
			return this->m_item_services() && this->m_item_services()->m_has_helmet();
		return this->m_armor_value() > 0;
	}

	bool is_throwing() {
		c_base_player_weapon* active_weapon = this->get_active_weapon();
		if (!active_weapon)
			return false;

		c_base_cs_grenade* grenade = reinterpret_cast<c_base_cs_grenade*>(active_weapon);
		c_cs_weapon_base_v_data* weapon_data = active_weapon->get_weapon_data();

		if (!grenade || !weapon_data)
			return false;

		if (weapon_data->m_weapon_type() == WEAPONTYPE_GRENADE && grenade->m_throw_time() != 0.f)
			return true;

		return false;
	}

	bool is_spotted_by_local(c_cs_player_pawn* local_pawn);
};

class c_in_game_money_services {
public:
	SCHEMA(m_account, int32_t, "CCSPlayerController_InGameMoneyServices", "m_iAccount");
};

class c_cs_player_controller : public c_entity_instance {
public:
	SCHEMA(m_pawn, c_base_handle, "CBasePlayerController", "m_hPawn");
	SCHEMA(m_pawn_is_alive, bool, "CCSPlayerController", "m_bPawnIsAlive");
	SCHEMA(m_tick_base, uint32_t, "CBasePlayerController", "m_nTickBase");
	SCHEMA(m_steam_id, uint64_t, "CBasePlayerController", "m_steamID");
	SCHEMA_ARRAY(m_player_name, char, "CBasePlayerController", "m_iszPlayerName");
	SCHEMA(m_ping, uint32_t, "CCSPlayerController", "m_iPing");
	SCHEMA(m_money_services, c_in_game_money_services*, "CCSPlayerController", "m_pInGameMoneyServices");

	void physics_run_think() {
		using fn_t = void(__fastcall*)(void*);
		static const auto fn = reinterpret_cast<fn_t>(SIG("PhysicsRunThink_Ctrl"));
		if (fn)
			fn(this);
	}
};

inline bool c_cs_player_pawn::is_spotted_by_local(c_cs_player_pawn* local_pawn) {
	if (!local_pawn)
		return false;

	static const std::uint32_t offset = schema_get_offset("C_CSPlayerPawn", "m_entitySpottedState");
	if (!offset)
		return false;

	const auto spotted_state_addr = reinterpret_cast<std::uintptr_t>(this) + offset;
	const bool is_spotted = *reinterpret_cast<bool*>(spotted_state_addr + 0x8);
	if (is_spotted)
		return true;

	extern void* get_entity_by_index(int index);
	auto* local_controller = reinterpret_cast<c_cs_player_controller*>(
		get_entity_by_index(local_pawn->m_controller().get_entry_index())
	);
	if (!local_controller)
		return false;

	auto* local_identity = local_controller->m_entity();
	if (!local_identity)
		return false;

	const int local_index = local_identity->get_entry_index() - 1;
	if (local_index < 0 || local_index >= 64)
		return false;

	const auto* spotted_by_mask = reinterpret_cast<std::uint32_t*>(spotted_state_addr + 0xC);
	const int word_index = local_index / 32;
	const int bit_index = local_index % 32;

	return (spotted_by_mask[word_index] & (1u << bit_index)) != 0;
}

class c_econ_item_definition {
public:
	bool is_knife(bool exclude_default) {
		static auto csgo_type_knife = fnv1a::hash_64("#CSGO_Type_Knife");
		if (fnv1a::hash_64(m_item_type_name) != csgo_type_knife)
			return false;

		return exclude_default ? m_definition_index >= 500 : true;
	}

	bool is_glove(bool exclude_default) {
		static auto type_hands = fnv1a::hash_64("#Type_Hands");
		if (fnv1a::hash_64(m_item_type_name) != type_hands)
			return false;

		const bool default_glove = m_definition_index == 5028 || m_definition_index == 5029;
		return exclude_default ? !default_glove : true;
	}

	bool is_agent() {
		static auto type_custom_player = fnv1a::hash_64("#Type_CustomPlayer");
		return fnv1a::hash_64(m_item_type_name) == type_custom_player;
	}

	const char* get_model_name() {
		return *reinterpret_cast<const char**>((uintptr_t)(this) + 0x148);
	}

	const char* get_simple_weapon_name() {
		return *reinterpret_cast<const char**>((uintptr_t)(this) + 0x230);
	}

	const char* get_weapon_name() {
		return *reinterpret_cast<const char**>((uintptr_t)(this) + 0x248);
	}

	const char* get_item_name() {
		return *reinterpret_cast<const char**>((uintptr_t)(this) + 0x260);
	}

	const char* get_view_model() {
		return *reinterpret_cast<const char**>((uintptr_t)(this) + 0x348);
	}

	const char* get_vo_prefix() {
		return *reinterpret_cast<const char**>((uintptr_t)(this) + 0xEB0);
	}

public:
	std::byte pad_001[0x8];
	void* m_kv_item;
	std::uint16_t m_definition_index;
	std::byte pad_002[0x1e];
	bool m_enabled;
	std::byte pad_003[0xf];
	std::uint8_t m_min_item_level;
	std::uint8_t m_max_item_level;
	std::uint8_t m_item_rarity;
	std::uint8_t m_item_quality;
	std::byte pad_004[0x2c];
	char* m_item_base_name;
	std::byte pad_005[0x8];
	char* m_item_type_name;
	std::byte pad_006[0x8];
	char* m_item_desc;
};
