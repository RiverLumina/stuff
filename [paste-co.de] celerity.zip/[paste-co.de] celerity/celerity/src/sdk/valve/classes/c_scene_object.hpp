﻿#pragma once
#include <cstddef>
#include <cstdint>
#include "c_scene_light_obj.hpp"

class c_scene_animatable_object {
public:
	std::uint8_t pad_0[0x78];
	std::uint32_t m_flags;
	std::uint8_t pad_1[0x44];
	void* m_owner; // handle @ 0xC0 (also probe nearby offsets at runtime)
	std::uint8_t pad_2[0x88];
};

struct c_mesh_primitive_color {
	std::uint8_t r, g, b, a;
};

// GeneratePrimitives output primitive — colour INLINE at 0x40 (same as DrawObject mesh).
class c_mesh_primitive {
public:
	std::uint8_t pad_0[0x18];                              // 0x00
	c_scene_animatable_object* m_scene_animatable_object;  // 0x18
	c_material_2* m_material;                              // 0x20
	c_material_2* m_material2;                             // 0x28
	std::uint8_t pad_1[0x10];                              // 0x30
	c_mesh_primitive_color m_color;                        // 0x40
	std::uint8_t pad_2[0x24];                              // 0x44 → sizeof 0x68
};
static_assert(sizeof(c_mesh_primitive) == 0x68, "c_mesh_primitive stride must match game");
static_assert(offsetof(c_mesh_primitive, m_color) == 0x40, "colour must be at 0x40");

class c_mesh_primitive_output_buffer {
public:
	c_mesh_primitive* m_mesh_primitive_array;
	std::uint8_t pad_0[4];
	int m_arr_size;

	c_mesh_primitive* get_primitive(int index) {
		return &m_mesh_primitive_array[index];
	}
};

class c_animatable_scene_object_desc {
public:
	std::uint8_t pad_0[0x10];
};
