﻿#include "../../../core/main.hpp"

void* get_entity_by_index(int index) {
	if (!g_interfaces || !g_interfaces->m_entity_system)
		return nullptr;
	return g_interfaces->m_entity_system->get_base_entity(index);
}

#define CHECK(name, arg) \
	if ((arg) == nullptr) { \
		LOG_ERROR(xorstr_("[-] Failed to get: %s"), name); \
		MessageBoxA(NULL, name, "Failed to initialize", MB_OK | MB_ICONERROR); \
		return false; \
	}

bool c_interfaces::initialize()
{
	const auto client_base = g_modules->m_modules.client_dll.get();

	// Prefer sdk-info RVAs; fall back to live pattern scan if the pointer is still null.
	if (client_base)
		m_csgo_input = reinterpret_cast<i_csgo_input*>(client_base + offsets::client::CSGOInput);
	if (!m_csgo_input) {
		if (auto* csgo_input_ptr = reinterpret_cast<i_csgo_input**>(SIG("CSGOInput_ptr")))
			m_csgo_input = *csgo_input_ptr;
	}
	diagnostics::g_diagnostics->mark_interface("CCSGOInput", m_csgo_input != nullptr, true);
	CHECK(xorstr_("CCSGOInput"), m_csgo_input);

	if (client_base)
		m_entity_system = *reinterpret_cast<i_entity_system**>(client_base + offsets::client::GameEntitySystem);
	if (!m_entity_system) {
		if (auto* entity_system_address = SIG("EntitySystem"))
			m_entity_system = *reinterpret_cast<i_entity_system**>(entity_system_address);
	}
	diagnostics::g_diagnostics->mark_interface("EntitySystem", m_entity_system != nullptr, true);
	CHECK(xorstr_("Entity System"), m_entity_system);

	m_schema_system = get_interface<i_schema_system>(&g_modules->m_modules.schemasystem_dll, xorstr_("SchemaSystem_001"));
	diagnostics::g_diagnostics->mark_interface("SchemaSystem_001", m_schema_system != nullptr, true);
	CHECK(xorstr_("Schema System"), m_schema_system);

	m_input_system = get_interface(&g_modules->m_modules.input_system, xorstr_("InputSystemVersion001"));
	diagnostics::g_diagnostics->mark_interface("InputSystemVersion001", m_input_system != nullptr, true);
	CHECK(xorstr_("Input System"), m_input_system);

	m_source2_client = get_interface<c_source2_client>(&g_modules->m_modules.client_dll, xorstr_("Source2Client002"));
	diagnostics::g_diagnostics->mark_interface("Source2Client002", m_source2_client != nullptr, true);
	CHECK(xorstr_("Source2Client"), m_source2_client);

	m_file_system = get_interface<i_file_system>(&g_modules->m_modules.filesystem_stdio, xorstr_("VFileSystem017"));
	diagnostics::g_diagnostics->mark_interface("VFileSystem017", m_file_system != nullptr, true);
	CHECK(xorstr_("FileSystem"), m_file_system);

	m_scene_system = get_interface<c_scene_system>(&g_modules->m_modules.scenesystem_dll, xorstr_("SceneSystem_002"));
	diagnostics::g_diagnostics->mark_interface("SceneSystem_002", m_scene_system != nullptr, true);

	m_engine = get_interface<i_engine_client>(&g_modules->m_modules.engine2_dll, xorstr_("Source2EngineToClient001"));
	diagnostics::g_diagnostics->mark_interface("Source2EngineToClient001", m_engine != nullptr, false);

	if (client_base)
		m_global_vars = *reinterpret_cast<i_global_vars**>(client_base + offsets::client::GlobalVars);
	diagnostics::g_diagnostics->mark_interface("GlobalVars", m_global_vars != nullptr, false);

	return true;
}
