#pragma once

#include "../../../typedefs/vec_t.hpp"
#include "../../../vfunc/vfunc.hpp"
#include "../../../memsafe.hpp"

#include <cmath>
#include <cstdint>
#include <cstring>

// Filled by Source2EngineToClient001::GetNetworkedClientInfo (vfunc 179).
// Keep this object alive while reading m_local_data — it may point into this buffer.
struct c_engine_local_data {
	char   pad_0000[0xC];
	vec3_t m_eye_pos; // 0x000C — LocalData.ShootPosition (UC / Lefrizzel)
};

struct c_networked_client_info {
	char                 pad_0000[0x4];
	std::int32_t         m_render_tick;          // 0x0004
	float                m_render_tick_fraction; // 0x0008
	std::int32_t         m_player_tick_count;    // 0x000C
	float                m_player_tick_fraction; // 0x0010
	char                 pad_0014[0x4];
	c_engine_local_data* m_local_data;           // 0x0018
	char                 pad_0020[0x28];
};

class i_engine_client {
public:
	bool is_in_game() {
		return vmt::call_virtual<bool>(this, 39);
	}

	bool is_connected() {
		return vmt::call_virtual<bool>(this, 40);
	}

	// Engine writes into `out`. Copy needed fields immediately; do not stash `out.m_local_data`.
	bool get_networked_client_info(c_networked_client_info& out) {
		std::memset(&out, 0, sizeof(out));
		vmt::call_virtual<void*>(this, 179, &out);
		return out.m_local_data != nullptr
			|| (out.m_render_tick > 0 && out.m_player_tick_count > 0);
	}

	static bool valid_shoot_vec(const vec3_t& sp) {
		if (!sp.is_valid() || sp.is_zero())
			return false;
		if (std::fabs(sp.x) > 16384.f || std::fabs(sp.y) > 16384.f || std::fabs(sp.z) > 16384.f)
			return false;
		if (std::fabs(sp.x) < 1.f && std::fabs(sp.z) < 1.f)
			return false;
		return true;
	}

	// Engine local shoot origin (post-pred). Prefer over stale weapon-history alone.
	bool get_local_shoot_position(vec3_t& out) {
		out = {};
		c_networked_client_info info{};
		if (!get_networked_client_info(info))
			return false;

		const auto* base = reinterpret_cast<const std::uint8_t*>(&info);
		for (int poff = 0x14; poff <= 0x28; poff += 8) {
			void* ld = nullptr;
			std::memcpy(&ld, base + poff, sizeof(ld));
			if (!ld || !memsafe::is_user_ptr(ld))
				continue;
			const auto* ldb = reinterpret_cast<const std::uint8_t*>(ld);
			for (int voff = 0; voff <= 0x18; voff += 4) {
				vec3_t sp{};
				std::memcpy(&sp, ldb + voff, sizeof(sp));
				if (valid_shoot_vec(sp)) {
					out = sp;
					return true;
				}
			}
		}
		return false;
	}
};
