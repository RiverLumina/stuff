#pragma once

#include <cstdint>

class i_global_vars {
public:
	float     m_real_time;                         // 0x0000
	std::int32_t m_frame_count;                    // 0x0004
	float     m_absolute_frame_time;               // 0x0008
	float     m_absolute_frame_start_time_std_dev; // 0x000C
	std::int32_t m_max_clients;                    // 0x0010
	std::int16_t m_tickbase;                       // 0x0014
	char      pad_0016[0x16];                      // 0x0016
	float     m_frame_time;                        // 0x002C
	float     m_current_time;                      // 0x0030
	float     m_player_time;                       // 0x0034
	char      pad_0038[0x10];                      // 0x0038
	std::int32_t m_tick_count;                     // 0x0048
	float     m_tick_fraction;                     // 0x004C
};
