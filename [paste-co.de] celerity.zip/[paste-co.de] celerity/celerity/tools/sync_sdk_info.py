#!/usr/bin/env python3
"""Sync signatures.cpp + offsets from sdk-info/ into src/sdk/."""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SDK_INFO = ROOT / "sdk-info"
SIG_CPP = ROOT / "src" / "sdk" / "valve" / "signatures" / "signatures.cpp"
OFFSETS_HPP = ROOT / "src" / "sdk" / "offsets.hpp"
OFFSETS_JSON = ROOT / "src" / "sdk" / "offsets.json"

# project signature name -> preferred sdk-info pattern names (same module preferred)
ALIASES: dict[str, list[str]] = {
    "EntitySystem": ["pGameEntitySystem", "pEntitySystem"],
    "CSGOInput_ptr": ["pCSGOInput", "CInputPtrGlobal"],
    "view_matrix_ptr": ["pViewMatrix", "pWorldToProjectionMatrix", "ViewMatrix"],
    "CSkeletonInstance::SetMeshGroupMask": ["SetMeshGroupMask"],
    "CBaseModelEntity::SetBodyGroup": ["SetBodyGroup", "SetBodygroup"],
    "CGlowProperty_OnGlowTypeChanged": ["OnGlowTypeChanged"],
    "CCSGOInput::ProcessInput": ["ProcessInput"],
    "C_EconEntity_BuildModernWeaponSkinMaterial": ["C_EconEntity_BuildModernWeaponSkinMaterial"],
    "CUtlVector_CompositeMaterialInput_AddToTail": ["CompositeMaterialInput_AddToTail"],
    "PointerToGetInaccuracyFunction": ["GetInaccuracy"],
    "PointerToGetSpreadFunction": ["CalcSpread"],
    "FirstPersonLegs": ["DrawLegs"],
    "CreateParticle": ["CacheParticleEffect", "CreateParticleEffect"],
    "SetParticleSettings": ["CreateParticleEffect"],
    "GetViewModelOffsets": ["GetViewModelOffsets", "CalcViewmodel"],
    "ManageGlowSceneObjectPointer": ["ManageGlowSceneObject"],
    "SceneSystem_ptr": ["pSceneSystem", "SceneSystem"],
    "QueueForceSubtickMove": ["QueueForceSubtickMove"],
    "RegenerateWeaponSkin": ["RegenerateWeaponSkin"],
    "FindHudElement": ["FindHudElement"],
    "ClearHUDWeaponIcon": ["ClearHUDWeaponIcon"],
    "SetViewAngle": ["SetViewAngle"],
    "GetViewAngles": ["GetViewAngles"],
    "PhysicsRunThink_Ctrl": ["PhysicsRunThink_Ctrl"],
    "SetPredictionCommand": ["SetPredictionCommand"],
    "ResetPredictionCommand": ["ResetPredictionCommand"],
    "LevelInit": ["LevelInit"],
    "FrameStageNotify": ["FrameStageNotify"],
    "CreateMove": ["CreateMove"],
    "SetModel": ["SetModel", "ChangeModel"],
    "GetEntityByIndex": ["GetEntityByIndex"],
    "CalculateWorldSpaceBones": ["CalculateWorldSpaceBones"],
    "ApplyEconCustomization": ["ApplyEconCustomization"],
    "TraceShape": ["TraceShape", "TraceShape_Client"],
    "OverrideView": ["OverrideView"],
    "DestroyParticle": ["DestroyParticle"],
    "GetHitboxSet": ["GetHitboxSet"],
}

ENTRY_RE = re.compile(
    r'\{\s*"(?P<name>[^"]+)",\s*"(?P<module>[^"]+)",\s*"(?P<pattern>[^"]+)"sv,\s*'
    r"signature_resolve_kind::(?P<kind>\w+),\s*(?P<rel>-?\d+|0x[0-9A-Fa-f]+),\s*"
    r"(?P<extra>-?\d+|0x[0-9A-Fa-f]+)\s*\}",
    re.MULTILINE,
)


def load_patterns() -> dict[str, list[dict]]:
    # sdk-info dumps hex literals (0x...) which are not valid JSON.
    raw = (SDK_INFO / "patterns.json").read_text(encoding="utf-8")
    fixed = re.sub(r":\s*(0x[0-9A-Fa-f]+)", r': "\1"', raw)
    data = json.loads(fixed)
    by_name: dict[str, list[dict]] = {}
    for p in data["patterns"]:
        rva = p.get("rva", 0)
        if isinstance(rva, str):
            p["rva"] = int(rva, 16) if rva.startswith(("0x", "0X")) else int(rva)
        by_name.setdefault(p["name"], []).append(p)
    return by_name


def pick_pattern(by_name: dict[str, list[dict]], name: str, module: str) -> dict | None:
    candidates = [name] + ALIASES.get(name, [])
    matches: list[dict] = []
    for c in candidates:
        matches.extend(by_name.get(c, []))
    if not matches:
        return None
    same = [m for m in matches if m["module"] == module]
    return same[0] if same else matches[0]


def sync_signatures(dry_run: bool = False) -> list[str]:
    by_name = load_patterns()
    text = SIG_CPP.read_text(encoding="utf-8")
    changes: list[str] = []

    def repl(m: re.Match[str]) -> str:
        name = m.group("name")
        module = m.group("module")
        old_pat = m.group("pattern")
        old_kind = m.group("kind")
        rel = m.group("rel")
        extra = m.group("extra")

        hit = pick_pattern(by_name, name, module)
        if not hit:
            changes.append(f"MISSING  {name} ({module})")
            return m.group(0)

        new_pat = hit["pattern"]
        new_kind = hit["resolve"]
        # keep existing rel/extra unless resolve kind implies standard riprel/rel32 offsets
        new_rel = rel
        new_extra = extra
        if new_kind in ("riprel", "rel32") and old_kind != new_kind:
            new_rel = "3" if new_kind == "riprel" else "1"
            # preserve intentional extra offsets like -0x52
            if extra in ("0", "0x0"):
                new_extra = "0"

        if new_pat == old_pat and new_kind == old_kind:
            return m.group(0)

        changes.append(
            f"UPDATE  {name}: {old_kind}->{new_kind} via {hit['name']} "
            f"(rva={hex(hit['rva'])})"
        )
        return (
            f'{{ "{name}", "{module}", "{new_pat}"sv, '
            f"signature_resolve_kind::{new_kind}, {new_rel}, {new_extra} }}"
        )

    new_text = ENTRY_RE.sub(repl, text)
    if not dry_run and new_text != text:
        SIG_CPP.write_text(new_text, encoding="utf-8", newline="\n")
    return changes


def sync_offsets() -> None:
    # Prefer full generated offsets.hpp from sdk-info, but keep cs2_dumper aliases
    # that the project already uses for dw* style access.
    src_hpp = (SDK_INFO / "offsets.hpp").read_text(encoding="utf-8")
    src_json = json.loads((SDK_INFO / "offsets.json").read_text(encoding="utf-8"))

    # Build a cs2_dumper-compatible trailing section from offsets.json
    lines = [
        "",
        "namespace cs2_dumper {",
        "    namespace offsets {",
        "",
    ]
    for module, vals in src_json.items():
        ns = module.replace(".", "_")
        lines.append(f"        namespace {ns} {{")
        for k, v in vals.items():
            lines.append(f"            constexpr std::ptrdiff_t {k} = {v};")
        lines.append("        }")
        lines.append("")
    lines.append("    }")
    lines.append("}")
    lines.append("")

    # Also keep legacy cs2::offsets aliases used elsewhere by rewriting key pointers
    # into a thin compatibility layer that mirrors previous names.
    compat = """
namespace cs2::offsets {
    namespace client {
        constexpr uintptr_t GameEntitySystemPtr = ::offsets::client::GameEntitySystem;
        constexpr uintptr_t EntityList_ptr = ::offsets::client::EntityList;
        constexpr uintptr_t CSGOInput_ptr = ::offsets::client::CSGOInput;
        constexpr uintptr_t ViewMatrix_addr = ::offsets::client::ViewMatrix;
        constexpr uintptr_t LocalPlayerController_ptr = ::offsets::client::LocalPlayerController;
        constexpr uintptr_t GlobalVariables_ptr = ::offsets::client::GlobalVars;
        constexpr uintptr_t GlowManager_ptr = ::offsets::client::GlowManager;
        constexpr uintptr_t Prediction_ptr = ::offsets::client::Prediction;
        constexpr uintptr_t Sensitivity_ptr = ::offsets::client::Sensitivity;
        constexpr uintptr_t ViewRender_ptr = ::offsets::client::ViewRender;
        constexpr uintptr_t WeaponC4_ptr = ::offsets::client::WeaponC4;
        constexpr uintptr_t EntitySystemPointer = ::offsets::client::pEntitySystem;
        constexpr uintptr_t CInputPtrGlobal = ::offsets::client::CInputPtrGlobal;
        constexpr uintptr_t ManageGlowSceneObjectPointer = ::offsets::client::ManageGlowSceneObject;
        constexpr uintptr_t SetSceneObjectAttributeFloat4 = ::offsets::client::SetSceneObjectAttributeFloat4;
        constexpr uintptr_t GetAbsOriginFunction = ::offsets::client::GetAbsOrigin;
        constexpr uintptr_t GetBombsiteACenter = ::offsets::client::GetBombsiteACenter;
        constexpr uintptr_t GetBombsiteBCenter = ::offsets::client::GetBombsiteBCenter;
        constexpr uintptr_t SetItemItemIdFunction = ::offsets::client::SetItemItemIdFunction;
        constexpr uintptr_t TransformScale3dVMT = ::offsets::client::TransformScale3dVMT;
        constexpr uintptr_t TransformTranslate3dVMT = ::offsets::client::TransformTranslate3dVMT;
        constexpr uintptr_t WorldToProjectionMatrixPointer = ::offsets::client::pWorldToProjectionMatrix;
        constexpr uintptr_t ViewToProjectionMatrixPointer = ::offsets::client::pViewToProjectionMatrix;
        constexpr uintptr_t view_matrix_ptr = ::offsets::client::ViewMatrix;
        constexpr uintptr_t local_controller = ::offsets::client::LocalPlayerController;
    }
}
"""

    out = src_hpp.rstrip() + "\n" + compat + "\n".join(lines)
    OFFSETS_HPP.write_text(out, encoding="utf-8", newline="\n")
    OFFSETS_JSON.write_text(
        json.dumps(src_json, indent=2) + "\n", encoding="utf-8", newline="\n"
    )


def main() -> None:
    print("=== signature sync ===")
    changes = sync_signatures(dry_run=False)
    for c in changes:
        print(c)
    print(f"{len(changes)} signature notes")
    print("=== offsets sync ===")
    sync_offsets()
    print(f"wrote {OFFSETS_HPP}")
    print(f"wrote {OFFSETS_JSON}")


if __name__ == "__main__":
    main()
