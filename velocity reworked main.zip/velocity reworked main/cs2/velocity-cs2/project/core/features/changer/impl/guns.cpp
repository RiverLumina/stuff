#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/addresses/addresses.hpp>
#include <core/systems/systems.hpp>
#include <core/features/features.hpp>
#include <core/settings.hpp>
#include <protection/game_addresses.hpp>
namespace features::changer {

	namespace detail {

		// Generate a unique faux item ID per weapon handle so inventory items never collide.
		// High nibble 0xF marks the item as client-fabricated.
		inline static std::uint64_t make_faux_item_id( std::uint32_t handle )
		{
			return 0xf000000000000000ull | static_cast< std::uint64_t >( handle );
		}

		// Hash all mutable skin fields into one value for fast change detection.
		inline static std::size_t skin_config_hash( const settings::changer::applied_skin& skin )
		{
			auto h = std::hash<int>{}( skin.paint_kit_id );
			h ^= std::hash<int>{}( skin.seed ) + 0x9e3779b9 + ( h << 6 ) + ( h >> 2 );
			h ^= std::hash<int>{}( skin.stattrak_count ) + 0x9e3779b9 + ( h << 6 ) + ( h >> 2 );
			h ^= std::hash<float>{}( skin.wear ) + 0x9e3779b9 + ( h << 6 ) + ( h >> 2 );
			if ( !skin.nametag.empty( ) )
				h ^= std::hash<std::string>{}( skin.nametag ) + 0x9e3779b9 + ( h << 6 ) + ( h >> 2 );
			return h;
		}

		// Write a nametag string into C_EconItemView::m_szCustomName (char[161]).
		inline static void write_nametag( std::uintptr_t iv, const std::string& nametag )
		{
			const auto name_offset = SCHEMA( "C_EconItemView", "m_szCustomName"_hash );
			if ( !name_offset )
				return;

			constexpr std::size_t max_len{ 160 };
			const auto len = ( std::min )( nametag.size( ), max_len );

			for ( std::size_t i = 0; i < len; ++i )
				memory::write<char>( iv + name_offset + i, nametag[ i ] );

			memory::write<char>( iv + name_offset + len, '\0' );
		}

		// Clear the nametag field (zero fill the first byte).
		inline static void clear_nametag( std::uintptr_t iv )
		{
			const auto name_offset = SCHEMA( "C_EconItemView", "m_szCustomName"_hash );
			if ( name_offset )
				memory::write<char>( iv + name_offset, '\0' );
		}

	} // namespace detail

	void guns::on_frame_stage_notify( )
	{
		this->process_hud_clear( );

		const auto local = systems::g_local.get( );
		if ( !local.is_alive || systems::g_local.is_in_cinematic( ) || !local.pawn || !local.controller )
		{
			// Restore m_bDisallowSOC = false on every tracked weapon BEFORE
			// clearing the map.  client.dll's death cleanup dereferences
			// GetSOCData() without a null check — if m_bDisallowSOC is still
			// true the short-circuit returns nullptr → ACCESS_VIOLATION.
			// Knives/gloves survive because they have restore(); guns need
			// the same treatment.
			for ( const auto& [wep_handle, _] : this->m_applied_weapons )
			{
				const auto wep = systems::g_entities.lookup( wep_handle );
				if ( !wep )
					continue;

				const auto wep_iv = wep + SCHEMA( "C_EconEntity", "m_AttributeManager"_hash )
					+ SCHEMA( "C_AttributeContainer", "m_Item"_hash );

				memory::write<bool>( wep_iv + SCHEMA( "C_EconItemView", "m_bDisallowSOC"_hash ), false );
				memory::write<bool>( wep_iv + SCHEMA( "C_EconItemView", "m_bRestoreCustomMaterialAfterPrecache"_hash ), false );
			}

			if ( !this->m_applied_weapons.empty( ) )
				this->m_applied_weapons.clear( );

			this->m_last_active_handle = 0;
			this->m_tracked_pawn = 0;
			return;
		}

		const auto weapon_services = memory::read<std::uintptr_t>( local.pawn + SCHEMA( "C_BasePlayerPawn", "m_pWeaponServices"_hash ) );
		if ( !weapon_services )
		{
			return;
		}

		const auto weapons_base = weapon_services + SCHEMA( "CPlayer_WeaponServices", "m_hMyWeapons"_hash );
		const auto weapons_size = memory::read<int>( weapons_base );
		const auto weapons_data = memory::read<std::uintptr_t>( weapons_base + 0x8 );

		if ( !weapons_data || weapons_size <= 0 )
		{
			return;
		}

		const auto steam_id = memory::read<std::uintptr_t>( local.controller + SCHEMA( "CBasePlayerController", "m_steamID"_hash ) );
		const auto account_id = static_cast< std::uint32_t >( steam_id & 0xffffffff );
		const auto active_handle = memory::read<std::uint32_t>( weapon_services + SCHEMA( "CPlayer_WeaponServices", "m_hActiveWeapon"_hash ) );
		const auto active_weapon = systems::g_entities.lookup( active_handle );

		if ( this->m_tracked_pawn != local.pawn )
		{
			this->m_applied_weapons.clear( );
			this->m_last_active_handle = 0;
			this->m_tracked_pawn = local.pawn;
		}

		for ( auto i = 0; i < weapons_size; ++i )
		{
			const auto handle = memory::read<std::uint32_t>( weapons_data + i * sizeof( std::uint32_t ) );
			const auto weapon = systems::g_entities.lookup( handle );

			if ( !weapon )
			{
				continue;
			}

			const auto iv = weapon + SCHEMA( "C_EconEntity", "m_AttributeManager"_hash ) + SCHEMA( "C_AttributeContainer", "m_Item"_hash );
			const auto current_def_index = memory::read<std::uint16_t>( iv + SCHEMA( "C_EconItemView", "m_iItemDefinitionIndex"_hash ) );
			const auto current_def = g_econ_item_system.find_def( static_cast< std::int16_t >( current_def_index ) );

			if ( !current_def || current_def->category != econ_item_system::item_category::gun )
			{
				continue;
			}

			const auto skin_it = settings::g_changer.skins.data.find( current_def_index );
			if ( skin_it == settings::g_changer.skins.data.end( ) )
			{
				continue;
			}

			const auto& skin = skin_it->second;
			const auto config_hash = detail::skin_config_hash( skin );
			const auto applied_it = this->m_applied_weapons.find( handle );

			// Config unchanged AND the game still holds our paint kit -> nothing to do.
			// If a network update reset the fallback fields (paint kit back to 0 or
			// another value) the cached hash alone would skip it forever, which is
			// why only the name stuck. Re-apply in that case.
			const auto live_paint_kit = memory::read<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackPaintKit"_hash ) );
			if ( applied_it != this->m_applied_weapons.end( ) && applied_it->second == config_hash
				&& live_paint_kit == skin.paint_kit_id )
			{
				continue;
			}

			if ( !memory::read<std::uintptr_t>( weapon + SCHEMA( "C_BaseEntity", "m_nSubclassID"_hash ) + 0x8 ) )
			{
				continue;
			}

			this->apply( weapon, iv, handle, active_handle, local.pawn, &skin, account_id );
			this->m_applied_weapons[ handle ] = config_hash;
		}

		if ( active_handle != this->m_last_active_handle )
		{
			this->m_last_active_handle = active_handle;

			if ( active_weapon )
			{
				const auto iv = active_weapon + SCHEMA( "C_EconEntity", "m_AttributeManager"_hash ) + SCHEMA( "C_AttributeContainer", "m_Item"_hash );
				const auto def_index = memory::read<std::uint16_t>( iv + SCHEMA( "C_EconItemView", "m_iItemDefinitionIndex"_hash ) );
				const auto def = g_econ_item_system.find_def( static_cast< std::int16_t >( def_index ) );

				if ( def && def->category == econ_item_system::item_category::gun )
				{
					const auto paint_kit_id = memory::read<int>( active_weapon + SCHEMA( "C_EconEntity", "m_nFallbackPaintKit"_hash ) );
					const auto pk = g_econ_item_system.find_paint_kit( paint_kit_id );
					this->update_view_model( local.pawn, pk );
				}
			}
		}
	}

	void guns::apply( std::uintptr_t weapon, std::uintptr_t iv, std::uint32_t handle, std::uint32_t active_handle, std::uintptr_t pawn, const settings::changer::applied_skin* skin, std::uint32_t account_id )
	{
		this->m_pending_hud_iv = 0;

		// --- inventory-style item identity ---
		const auto faux_id = detail::make_faux_item_id( handle );
		memory::write<std::uint64_t>( iv + SCHEMA( "C_EconItemView", "m_iItemID"_hash ), faux_id );
		memory::write<std::uint32_t>( iv + SCHEMA( "C_EconItemView", "m_iItemIDHigh"_hash ), static_cast< std::uint32_t >( faux_id >> 32 ) );
		memory::write<std::uint32_t>( iv + SCHEMA( "C_EconItemView", "m_iItemIDLow"_hash ), static_cast< std::uint32_t >( faux_id ) );
		memory::write<std::uint32_t>( iv + SCHEMA( "C_EconItemView", "m_iAccountID"_hash ), account_id );
		memory::write<bool>( iv + SCHEMA( "C_EconItemView", "m_bInitialized"_hash ), true );

		// --- skin data via fallback fields ---
		memory::write<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackPaintKit"_hash ), skin->paint_kit_id );
		memory::write<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackSeed"_hash ), skin->seed );
		memory::write<float>( weapon + SCHEMA( "C_EconEntity", "m_flFallbackWear"_hash ), skin->wear );
		memory::write<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackStatTrak"_hash ), skin->stattrak ? skin->stattrak_count : -1 );

		// --- paint kit as item view attribute (drives composite material system) ---
		// The composite material system reads paint data from item view attributes
		// ("set item texture prefab"), NOT just from fallback fields.  Without this
		// the composite regenerates with paint kit 0 → stock texture.
		// This is the EXACT pattern that makes gloves work (see gloves::apply).
		const auto set_attribute = PATTERN( patterns::econ_item_view_set_attribute );
		if ( set_attribute )
		{
			memory::call<void>( set_attribute, iv, "set item texture prefab",
				static_cast< float >( skin->paint_kit_id ) );
			memory::call<void>( set_attribute, iv, "set item texture seed",
				static_cast< float >( skin->seed ) );
			memory::call<void>( set_attribute, iv, "set item texture wear",
				skin->wear );
		}

		// --- nametag ---
		if ( !skin->nametag.empty( ) )
			detail::write_nametag( iv, skin->nametag );
		else
			detail::clear_nametag( iv );

		const auto pk = g_econ_item_system.find_paint_kit( skin->paint_kit_id );

		this->rebuild_paint( weapon, handle, active_handle, pawn, pk, skin->paint_kit_id );

		// Set m_bDisallowSOC = true AFTER rebuild_paint() so that
		// ApplyEconCustomization / PostDataUpdate (which internally call
		// GetSOCData()) run while SOC is still allowed.  Setting this flag
		// before those calls caused GetSOCData() to return nullptr →
		// ACCESS_VIOLATION at client.dll+0xB21E53 (read of field at
		// offset 0x251 from null).
		//
		// The flag must still be set so the composite material system
		// falls back to our fallback fields on subsequent frames.
		// Death-crash safety: on_frame_stage_notify() restores this to
		// false when the player dies.
		memory::write<bool>( iv + SCHEMA( "C_EconItemView", "m_bDisallowSOC"_hash ), true );
		// The glove changer (works) sets this too; the game rebuilds the custom
		// material from the attributes above when it is set.
		memory::write<bool>( iv + SCHEMA( "C_EconItemView", "m_bRestoreCustomMaterialAfterPrecache"_hash ), true );

		this->schedule_hud_clear( iv );
	}

	void guns::rebuild_paint( std::uintptr_t weapon, std::uint32_t handle, std::uint32_t active_handle, std::uintptr_t pawn, const econ_item_system::paint_kit* pk, int paint_kit_id )
	{
		const auto is_legacy = pk && pk->legacy_model;
		const auto mesh_group = is_legacy ? std::uint64_t{ 2 } : std::uint64_t{ 1 };

		if ( handle == active_handle )
		{
			this->update_view_model( pawn, pk );
		}

		const auto weapon_scene_node = memory::read<std::uintptr_t>( weapon + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
		if ( weapon_scene_node )
		{
			memory::call<void>( PATTERN( patterns::weapon_set_mesh_group_mask ), weapon_scene_node, mesh_group );
		}

		// Same rebuild chain the knife changer uses (known stable). The old
		// apply_econ_customization(weapon, paint_kit_id) call and the vfunc 10
		// call on the scene node were the crash source: both walk the item's
		// SOC data, which is null for a fabricated gun item -> read of
		// null+0x251 at client.dll+0xB21E53 as soon as a skin was selected.
		(void)paint_kit_id;
		memory::call<void>( PATTERN( patterns::weapon_update_composite_material ), weapon + 0x608, true );
		memory::call_vfunc<void>( weapon, 10, 1 );
		memory::call<void>( PATTERN( patterns::weapon_update_skin ), weapon, true );
	}

	void guns::update_view_model( std::uintptr_t pawn, const econ_item_system::paint_kit* pk )
	{
		const auto view_model = this->find_hud_model_weapon( pawn );
		if ( !view_model )
		{
			return;
		}

		const auto view_model_scene_node = memory::read<std::uintptr_t>( view_model + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
		if ( !view_model_scene_node )
		{
			return;
		}

		const auto is_legacy = pk && pk->legacy_model;
		memory::call<void>( PATTERN( patterns::weapon_set_mesh_group_mask ), view_model_scene_node, is_legacy ? std::uint64_t{ 2 } : std::uint64_t{ 1 } );
	}

	std::uintptr_t guns::find_hud_model_weapon( std::uintptr_t pawn )
	{
		const auto arms_handle = memory::read<std::uint32_t>( pawn + SCHEMA( "C_CSPlayerPawn", "m_hHudModelArms"_hash ) );
		if ( !arms_handle )
		{
			return 0;
		}

		const auto arms = systems::g_entities.lookup( arms_handle );
		if ( !arms )
		{
			return 0;
		}

		const auto arms_scene_node = memory::read<std::uintptr_t>( arms + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
		if ( !arms_scene_node )
		{
			return 0;
		}

		auto child = memory::read<std::uintptr_t>( arms_scene_node + SCHEMA( "CGameSceneNode", "m_pChild"_hash ) );

		while ( child && child > 0x10000 )
		{
			const auto owner = memory::read<std::uintptr_t>( child + SCHEMA( "CGameSceneNode", "m_pOwner"_hash ) );
			if ( owner && owner > 0x10000 )
			{
				const auto name = systems::g_entities.get_schema_name( owner );
				if ( name && fnv1a::runtime_hash( name ) == "C_CS2HudModelWeapon"_hash )
				{
					return owner;
				}
			}

			child = memory::read<std::uintptr_t>( child + SCHEMA( "CGameSceneNode", "m_pNextSibling"_hash ) );
		}

		return 0;
	}

	void guns::clear_hud_icon( std::uintptr_t iv )
	{
		const auto invalidate = PATTERN( patterns::econ_item_view_invalidate_description );
		if ( iv && invalidate )
		{
			memory::call<void>( invalidate, iv );
		}
	}

	void guns::schedule_hud_clear( std::uintptr_t iv )
	{
		this->clear_hud_icon( iv );
		this->m_pending_hud_iv = 0;
	}

	void guns::process_hud_clear( )
	{
		this->m_pending_hud_iv = 0;
	}

} // namespace features::changer
