#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/hooking/hooking.hpp>
#include <utilities/addresses/addresses.hpp>
#include <core/systems/systems.hpp>
#include <core/features/features.hpp>
#include <core/settings.hpp>
#include <protection/game_addresses.hpp>

namespace features::changer {

	// -----------------------------------------------------------------------
	// File-local hook object for GetItemInLoadout detour.
	// -----------------------------------------------------------------------
	static hooking::jmp s_get_item_in_loadout{};

	// Attribute names used by the econ system for paint data.
	namespace attr {
		constexpr const char* texture_prefab = "set item texture prefab";
		constexpr const char* texture_seed   = "set item texture seed";
		constexpr const char* texture_wear   = "set item texture wear";
	}

	// -----------------------------------------------------------------------
	// CS2 loadout slot constants — from the game's item schema.
	// Used for equipping items in the correct slot after SOC injection.
	// -----------------------------------------------------------------------
	namespace loadout_slot {
		constexpr std::uint32_t melee_ct{ 0 };
		constexpr std::uint32_t melee_t{ 16 };
		constexpr std::uint32_t secondary0{ 1 };
		constexpr std::uint32_t secondary1{ 2 };
		constexpr std::uint32_t secondary2{ 3 };
		constexpr std::uint32_t secondary3{ 4 };
		constexpr std::uint32_t secondary4{ 5 };
		constexpr std::uint32_t smg0{ 6 };
		constexpr std::uint32_t smg1{ 7 };
		constexpr std::uint32_t smg2{ 8 };
		constexpr std::uint32_t smg3{ 9 };
		constexpr std::uint32_t smg4{ 10 };
		constexpr std::uint32_t smg5{ 11 };
		constexpr std::uint32_t heavy0{ 12 };
		constexpr std::uint32_t heavy1{ 13 };
		constexpr std::uint32_t heavy2{ 14 };
		constexpr std::uint32_t heavy3{ 15 };
		constexpr std::uint32_t rifle0{ 17 };
		constexpr std::uint32_t rifle1{ 18 };
		constexpr std::uint32_t rifle2{ 19 };
		constexpr std::uint32_t rifle3{ 20 };
		constexpr std::uint32_t rifle4{ 21 };
		constexpr std::uint32_t gloves{ 41 };
		constexpr std::uint32_t clothing_hands{ 41 };
		constexpr std::uint32_t flair0{ 54 };        // display item (coin/medal)
		constexpr std::uint32_t musickit{ 55 };
	}

	// SOC item type ID for econ items.
	constexpr std::uint32_t soc_type_econ_item{ 1 };

	// Faux item ID base for SOC-injected items — high nibble marks them as ours.
	constexpr std::uint64_t faux_id_base{ 0xF000000000000000ull };

	// CEconItem field offsets (stable across recent builds, from RE).
	// These are offsets within a CEconItem object, NOT schema offsets.
	namespace econ_item_offsets {
		constexpr std::ptrdiff_t account_id{ 0x8 };
		constexpr std::ptrdiff_t item_id{ 0x10 };
		constexpr std::ptrdiff_t def_index{ 0x24 };
		constexpr std::ptrdiff_t paint_kit{ 0x30 };
		constexpr std::ptrdiff_t seed{ 0x34 };
		constexpr std::ptrdiff_t wear{ 0x38 };
		constexpr std::ptrdiff_t quality{ 0x28 };
		constexpr std::ptrdiff_t rarity{ 0x2A };
		constexpr std::ptrdiff_t origin{ 0x2B };
		constexpr std::ptrdiff_t inventory{ 0x18 };   // inventory position (loadout slot encoding)
		constexpr std::ptrdiff_t flags{ 0x20 };
		constexpr std::ptrdiff_t stattrak{ 0x3C };
		constexpr std::ptrdiff_t custom_name{ 0x48 }; // inline char[161] in some builds, or CUtlString
	}

	// -----------------------------------------------------------------------
	// resolve_inventory_manager
	//
	// pCSInventoryManager is a RIP-relative MOV:  48 8B 05 [rel32] ...
	// -----------------------------------------------------------------------
	std::uintptr_t inventory::resolve_inventory_manager( ) const
	{
		const auto instr = PATTERN( patterns::inventory_manager );
		if ( !instr )
			return 0;

		const auto rel = memory::read<std::int32_t>( instr + 3 );
		const auto ptr_addr = instr + 7 + rel;
		return memory::read<std::uintptr_t>( ptr_addr );
	}

	// -----------------------------------------------------------------------
	// find_local_soc_cache
	//
	// Walks CCSInventoryManager → local player inventory → GC client →
	// finds the SOC cache for our Steam ID.
	// -----------------------------------------------------------------------
	std::uintptr_t inventory::find_local_soc_cache( ) const
	{
		const auto inv_mgr = this->resolve_inventory_manager( );
		if ( !inv_mgr )
			return 0;

		const auto find_cache_fn = PATTERN( patterns::find_so_cache );
		if ( !find_cache_fn )
			return 0;

		const auto local = systems::g_local.get( );
		if ( !local.controller )
			return 0;

		const auto steam_id = memory::read<std::uint64_t>(
			local.controller + SCHEMA( "CBasePlayerController", "m_steamID"_hash ) );
		if ( !steam_id )
			return 0;

		const auto gc_client = memory::read<std::uintptr_t>( inv_mgr + 0x80 );
		if ( !gc_client )
			return 0;

		struct alignas(8) cache_params
		{
			std::uint64_t steam_id;
		} params{ steam_id };

		const auto cache = memory::call<std::uintptr_t>(
			find_cache_fn, gc_client, reinterpret_cast< std::uintptr_t >( &params ), 1, 1 );

		return cache;
	}

	// -----------------------------------------------------------------------
	// inject_soc_items
	// -----------------------------------------------------------------------
	void inventory::inject_soc_items( )
	{
		const auto soc_cache = this->find_local_soc_cache( );
		if ( !soc_cache )
			return;

		const auto create_econ_item_fn = PATTERN( patterns::create_so_econ_item );
		const auto so_created_fn = PATTERN( patterns::so_created );
		if ( !create_econ_item_fn || !so_created_fn )
			return;

		const auto local = systems::g_local.get( );
		if ( !local.controller )
			return;

		const auto steam_id = memory::read<std::uint64_t>(
			local.controller + SCHEMA( "CBasePlayerController", "m_steamID"_hash ) );
		const auto account_id = static_cast< std::uint32_t >( steam_id );

		std::uint64_t item_counter{ 1 };

		for ( const auto& [def_index, skin] : settings::g_changer.skins.data )
		{
			if ( skin.paint_kit_id <= 0 )
				continue;

			const auto econ_item = memory::call<std::uintptr_t>( create_econ_item_fn );
			if ( !econ_item )
				continue;

			const auto faux_id = faux_id_base | item_counter++;

			memory::write<std::uint32_t>( econ_item + econ_item_offsets::account_id, account_id );
			memory::write<std::uint64_t>( econ_item + econ_item_offsets::item_id, faux_id );
			memory::write<std::uint16_t>( econ_item + econ_item_offsets::def_index,
				static_cast< std::uint16_t >( def_index ) );
			memory::write<std::uint8_t>( econ_item + econ_item_offsets::quality, 4 );

			const auto combined_rarity = g_econ_item_system.combined_rarity( def_index, skin.paint_kit_id );
			memory::write<std::uint8_t>( econ_item + econ_item_offsets::rarity,
				static_cast< std::uint8_t >( combined_rarity > 0 ? combined_rarity : 1 ) );

			memory::write<std::uint8_t>( econ_item + econ_item_offsets::origin, 8 );
			memory::write<std::uint32_t>( econ_item + econ_item_offsets::paint_kit,
				static_cast< std::uint32_t >( skin.paint_kit_id ) );
			memory::write<std::uint32_t>( econ_item + econ_item_offsets::seed,
				static_cast< std::uint32_t >( skin.seed ) );
			memory::write<float>( econ_item + econ_item_offsets::wear, skin.wear );

			if ( skin.stattrak )
			{
				memory::write<std::uint8_t>( econ_item + econ_item_offsets::quality, 9 );
				memory::write<std::int32_t>( econ_item + econ_item_offsets::stattrak, skin.stattrak_count );
			}

			memory::write<std::uint32_t>( econ_item + econ_item_offsets::inventory, 0 );

			struct alignas(16) so_notify
			{
				std::uint32_t type_id;
				std::uint32_t pad0;
				std::uintptr_t object;
			} notify{ soc_type_econ_item, 0, econ_item };

			memory::call<void>( so_created_fn, soc_cache, econ_item,
				reinterpret_cast< std::uintptr_t >( &notify ) );

			const auto def = g_econ_item_system.find_def( def_index );
			const auto slot = def ? static_cast< std::uint32_t >( def->loadout_slot ) : 0u;

			this->m_injected_items.push_back( {
				econ_item, faux_id, def_index, slot
			} );
		}

		const auto& fp = settings::g_changer.fake_profile;
		if ( fp.enabled.value && fp.coin_id.value > 0 )
		{
			const auto econ_item = memory::call<std::uintptr_t>( create_econ_item_fn );
			if ( econ_item )
			{
				const auto faux_id = faux_id_base | item_counter++;

				memory::write<std::uint32_t>( econ_item + econ_item_offsets::account_id, account_id );
				memory::write<std::uint64_t>( econ_item + econ_item_offsets::item_id, faux_id );
				memory::write<std::uint16_t>( econ_item + econ_item_offsets::def_index,
					static_cast< std::uint16_t >( fp.coin_id.value ) );
				memory::write<std::uint8_t>( econ_item + econ_item_offsets::quality, 4 );
				memory::write<std::uint8_t>( econ_item + econ_item_offsets::rarity, 6 );
				memory::write<std::uint8_t>( econ_item + econ_item_offsets::origin, 2 );
				memory::write<std::uint32_t>( econ_item + econ_item_offsets::inventory, 0 );

				struct alignas(16) so_notify
				{
					std::uint32_t type_id;
					std::uint32_t pad0;
					std::uintptr_t object;
				} notify{ soc_type_econ_item, 0, econ_item };

				memory::call<void>( so_created_fn, soc_cache, econ_item,
					reinterpret_cast< std::uintptr_t >( &notify ) );

				this->m_injected_items.push_back( {
					econ_item, faux_id, static_cast< std::int16_t >( fp.coin_id.value ),
					loadout_slot::flair0
				} );
			}
		}

		this->m_soc_injected = !this->m_injected_items.empty( );
	}

	// -----------------------------------------------------------------------
	// clear_soc_items
	// -----------------------------------------------------------------------
	void inventory::clear_soc_items( )
	{
		this->m_injected_items.clear( );
		this->m_soc_injected = false;
	}

	// -----------------------------------------------------------------------
	// apply_profile_data  (client-side only)
	//
	// Patches CCSPlayerController schema fields for fake XP, level,
	// commends, and competitive wins.  Visible on the local scoreboard;
	// the server overwrites these for other clients, so only we see it.
	//
	// Every SCHEMA() call is null-checked: if the field doesn't exist in
	// this CS2 build the write is silently skipped instead of corrupting
	// the vtable at ctrl + 0.
	// -----------------------------------------------------------------------
	void inventory::apply_profile_data( ) const
	{
		const auto& fp = settings::g_changer.fake_profile;
		if ( !fp.enabled.value )
			return;

		const auto local = systems::g_local.get( );
		if ( !local.controller )
			return;

		const auto ctrl = local.controller;

		// Player level (profile rank 1-40).
		{
			const auto off = SCHEMA( "CCSPlayerController", "m_nPersonaDataPublicLevel"_hash );
			if ( off )
				memory::write<std::int32_t>( ctrl + off, fp.level.value );
		}

		// XP within the current level.
		{
			const auto off = SCHEMA( "CCSPlayerController", "m_nPersonaDataPublicXpTrailLevel"_hash );
			if ( off )
				memory::write<std::int32_t>( ctrl + off, fp.xp.value );
		}

		// Competitive wins.
		{
			const auto off = SCHEMA( "CCSPlayerController", "m_iCompetitiveWins"_hash );
			if ( off )
				memory::write<std::int32_t>( ctrl + off, fp.wins.value );
		}

		// Commendation counts — each guarded independently.
		{
			const auto off = SCHEMA( "CCSPlayerController", "m_nPersonaDataPublicCommendsLeader"_hash );
			if ( off )
				memory::write<std::int32_t>( ctrl + off, fp.leader.value );
		}
		{
			const auto off = SCHEMA( "CCSPlayerController", "m_nPersonaDataPublicCommendsTeacher"_hash );
			if ( off )
				memory::write<std::int32_t>( ctrl + off, fp.teaching.value );
		}
		{
			const auto off = SCHEMA( "CCSPlayerController", "m_nPersonaDataPublicCommendsFriendly"_hash );
			if ( off )
				memory::write<std::int32_t>( ctrl + off, fp.friendly.value );
		}
	}

	// -----------------------------------------------------------------------
	// install_hooks / remove_hooks
	// -----------------------------------------------------------------------
	bool inventory::install_hooks( )
	{
		if ( this->m_hooks_installed )
			return true;

		const auto target = PATTERN( patterns::get_item_in_loadout );
		if ( !target )
			return false;

		if ( !s_get_item_in_loadout.create(
				reinterpret_cast< void* >( target ),
				reinterpret_cast< void* >( &inventory::hk_get_item_in_loadout ) ) )
		{
			return false;
		}

		if ( !s_get_item_in_loadout.enable( ) )
		{
			s_get_item_in_loadout.reset( );
			return false;
		}

		this->m_hooks_installed = true;
		return true;
	}

	void inventory::remove_hooks( )
	{
		if ( !this->m_hooks_installed )
			return;

		s_get_item_in_loadout.disable( );
		s_get_item_in_loadout.reset( );
		this->m_hooks_installed = false;
	}

	// -----------------------------------------------------------------------
	// hk_get_item_in_loadout  (static — detour callback)
	//
	// Phase 2: intercepts every loadout query — buy menu, loadout UI,
	// weapon inspect, HUD icons.  Patches the returned CEconItemView
	// with configured skin data.
	// -----------------------------------------------------------------------
	std::uintptr_t __fastcall inventory::hk_get_item_in_loadout(
		std::uintptr_t mgr, std::uint32_t team, std::uint32_t loadout_slot )
	{
		const auto result = s_get_item_in_loadout.call<std::uintptr_t>( mgr, team, loadout_slot );

		if ( !result )
			return result;

		// --- guard: never patch item views while dead/spectating ---
		// The alive check + unhook-on-death in on_frame_stage_notify
		// prevent writes during death transitions.  Without this guard
		// there's a race window between death and the next FSN call.
		const auto local = systems::g_local.get( );
		if ( !local.is_alive || !local.pawn )
			return result;

		const auto off_def_index   = SCHEMA( "C_EconItemView", "m_iItemDefinitionIndex"_hash );
		const auto off_item_id     = SCHEMA( "C_EconItemView", "m_iItemID"_hash );
		const auto off_item_id_hi  = SCHEMA( "C_EconItemView", "m_iItemIDHigh"_hash );
		const auto off_item_id_lo  = SCHEMA( "C_EconItemView", "m_iItemIDLow"_hash );
		const auto off_initialized = SCHEMA( "C_EconItemView", "m_bInitialized"_hash );

		if ( !off_def_index )
			return result;

		const auto def_index = memory::read<std::uint16_t>( result + off_def_index );
		if ( def_index == 0 )
			return result;

		const auto skin_it = settings::g_changer.skins.data.find( def_index );
		if ( skin_it == settings::g_changer.skins.data.end( ) )
			return result;

		const auto& skin = skin_it->second;
		if ( skin.paint_kit_id <= 0 )
			return result;

		// -----------------------------------------------------------------
		// Identity fields — needed to trigger composite material rebuild
		// for gun skins.  Without a changed m_iItemID the composite
		// system thinks nothing changed and keeps the stock texture.
		//
		// IMPORTANT: we do NOT set m_bDisallowSOC.  That flag was the
		// death-crash vector — it makes GetSOCData() return nullptr
		// immediately, and client.dll's death cleanup dereferences
		// the result without a null-check.  Leaving it false lets
		// the SOC lookup run normally (returns null for our fake ID,
		// but callers on this path handle that gracefully).
		// -----------------------------------------------------------------
		if ( off_item_id && off_item_id_hi && off_item_id_lo && off_initialized )
		{
			const auto faux_id = faux_id_base | static_cast< std::uint64_t >( def_index );

			memory::write<std::uint64_t>( result + off_item_id, faux_id );
			memory::write<std::uint32_t>( result + off_item_id_hi,
				static_cast< std::uint32_t >( faux_id >> 32 ) );
			memory::write<std::uint32_t>( result + off_item_id_lo,
				static_cast< std::uint32_t >( faux_id ) );
			memory::write<bool>( result + off_initialized, true );
		}

		// --- paint attributes via the econ attribute system ---
		const auto set_attribute = PATTERN( patterns::econ_item_view_set_attribute );
		if ( set_attribute )
		{
			memory::call<void>( set_attribute, result, attr::texture_prefab,
				static_cast< float >( skin.paint_kit_id ) );
			memory::call<void>( set_attribute, result, attr::texture_seed,
				static_cast< float >( skin.seed ) );
			memory::call<void>( set_attribute, result, attr::texture_wear,
				skin.wear );
		}

		// --- nametag ---
		if ( !skin.nametag.empty( ) )
		{
			const auto name_offset = SCHEMA( "C_EconItemView", "m_szCustomName"_hash );
			if ( name_offset )
			{
				constexpr std::size_t max_len{ 160 };
				const auto len = ( std::min )( skin.nametag.size( ), max_len );

				for ( std::size_t i = 0; i < len; ++i )
					memory::write<char>( result + name_offset + i, skin.nametag[ i ] );

				memory::write<char>( result + name_offset + len, '\0' );
			}
		}

		return result;
	}

	// -----------------------------------------------------------------------
	// on_frame_stage_notify  —  called at stage 6 (FRAME_RENDER_START)
	// -----------------------------------------------------------------------
	void inventory::on_frame_stage_notify( )
	{
		const auto local = systems::g_local.get( );

		// Fake profile data only needs the controller (works while dead /
		// spectating so the scoreboard shows our values).
		if ( local.controller )
		{
			this->apply_profile_data( );
		}

		if ( !local.is_alive || !local.pawn || !local.controller )
		{
			// Unhook during death so the game's cleanup code gets
			// unmodified GetItemInLoadout results.  Do NOT call
			// force_full_update() here — engine2.dll crashes when
			// processing a delta-tick reset during death (read:0xFFFFFFFFFFFFFFFF).
			// The hook reinstalls on the next alive frame automatically.
			if ( this->m_hooks_installed )
			{
				this->remove_hooks( );
			}

			this->m_initialized = false;
			return;
		}

		// Install the GetItemInLoadout hook on first valid frame.
		if ( !this->m_hooks_installed )
		{
			this->install_hooks( );
		}

		this->check_config_change( );

		// With paint-only approach (no identity field writes), config
		// changes take effect on the next GetItemInLoadout call
		// automatically — no full entity rebuild needed.
		//
		// force_full_update() is disabled: the cl_fullupdate console
		// command crashes engine2.dll in recent CS2 builds (sets delta
		// tick to -1 which gets dereferenced as a pointer at
		// engine2.dll+0x73788).  Phase 3 SOC injection will handle
		// model changes (gloves, knives) that require entity recreation.
		if ( this->m_needs_full_update )
		{
			this->m_needs_full_update = false;
		}

		// Phase 3 SOC injection disabled — needs proper RE of CEconItem
		// constructor and GC client pointer chain for this build.
		// The GetItemInLoadout hook (Phase 2) still covers buy menu /
		// loadout / weapon inspect.  Re-enable once offsets are verified:
		//
		// if ( !this->m_soc_injected && !settings::g_changer.skins.data.empty( ) )
		// {
		//     this->inject_soc_items( );
		// }

		this->m_initialized = true;
	}

	void inventory::on_level_shutdown( )
	{
		// SOC cleanup disabled while injection is disabled.
		// if ( this->m_soc_injected )
		// {
		//     this->clear_soc_items( );
		// }

		this->remove_hooks( );
		this->m_last_config_hash = 0;
		this->m_needs_full_update = false;
		this->m_initialized = false;
	}

	// -----------------------------------------------------------------------
	// check_config_change — hashes the full config each frame.
	// -----------------------------------------------------------------------
	void inventory::check_config_change( )
	{
		std::size_t hash{ 0xcbf29ce484222325ull };

		for ( const auto& [def, skin] : settings::g_changer.skins.data )
		{
			hash ^= std::hash<int>{}( def ) + 0x9e3779b9 + ( hash << 6 ) + ( hash >> 2 );
			hash ^= std::hash<int>{}( skin.paint_kit_id ) + 0x9e3779b9 + ( hash << 6 ) + ( hash >> 2 );
			hash ^= std::hash<int>{}( skin.seed ) + 0x9e3779b9 + ( hash << 6 ) + ( hash >> 2 );
			hash ^= std::hash<float>{}( skin.wear ) + 0x9e3779b9 + ( hash << 6 ) + ( hash >> 2 );
			hash ^= std::hash<int>{}( skin.stattrak_count ) + 0x9e3779b9 + ( hash << 6 ) + ( hash >> 2 );

			if ( !skin.nametag.empty( ) )
				hash ^= std::hash<std::string>{}( skin.nametag ) + 0x9e3779b9 + ( hash << 6 ) + ( hash >> 2 );
		}

		hash ^= std::hash<int>{}( settings::g_changer.agents.ct_def ) + 0x9e3779b9 + ( hash << 6 ) + ( hash >> 2 );
		hash ^= std::hash<int>{}( settings::g_changer.agents.t_def ) + 0x9e3779b9 + ( hash << 6 ) + ( hash >> 2 );

		// Include fake profile settings in the config hash so changes trigger re-injection.
		const auto& fp = settings::g_changer.fake_profile;
		hash ^= std::hash<bool>{}( fp.enabled.value ) + 0x9e3779b9 + ( hash << 6 ) + ( hash >> 2 );
		hash ^= std::hash<int>{}( fp.coin_id.value ) + 0x9e3779b9 + ( hash << 6 ) + ( hash >> 2 );
		hash ^= std::hash<int>{}( fp.level.value ) + 0x9e3779b9 + ( hash << 6 ) + ( hash >> 2 );
		hash ^= std::hash<int>{}( fp.wins.value ) + 0x9e3779b9 + ( hash << 6 ) + ( hash >> 2 );

		if ( this->m_initialized && hash != this->m_last_config_hash )
		{
			this->m_needs_full_update = true;
		}

		this->m_last_config_hash = hash;
	}

	// -----------------------------------------------------------------------
	// force_full_update — requests cl_fullupdate so all weapon entities are
	// re-created, picking up our inventory-level modifications.
	// -----------------------------------------------------------------------
	void inventory::force_full_update( )
	{
		const auto engine_cmd = PATTERN( patterns::engine_client_cmd );
		if ( !engine_cmd )
			return;

		memory::call<void>( engine_cmd, 0, "cl_fullupdate", true );
	}

} // namespace features::changer
