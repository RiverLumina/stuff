#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/addresses/addresses.hpp>
#include <utilities/game_path.hpp>
#include <utilities/logging/logging.hpp>
#include <core/systems/systems.hpp>
#include <core/features/features.hpp>
#include <core/settings.hpp>
#include <protection/game_addresses.hpp>

namespace features::changer {

	namespace {

		// Only keep files that can actually be worn by a player pawn. A csgo/
		// scan otherwise lists every weapon, prop, glove and particle model.
		bool looks_like_player_model( const std::string& res )
		{
			std::string lower{ res };
			for ( auto& c : lower )
			{
				c = static_cast<char>( ( c >= 'A' && c <= 'Z' ) ? c + 32 : c );
			}

			// Must live in a folder where player/character models go.
			const char* const allowed_roots[ ]{
				"characters/models/",
				"agents/models/",
				"models/player",
				"models/players",
				"characters/player",
			};
			bool root_ok{ false };
			for ( const auto* r : allowed_roots )
			{
				if ( lower.find( r ) != std::string::npos )
				{
					root_ok = true;
					break;
				}
			}
			if ( !root_ok )
			{
				return false;
			}

			// Things that sit under characters/ but aren't wearable bodies.
			const char* const blocked[ ]{
				"weapons/", "/weapon", "props", "gloves", "/arms/", "_arms",
				"wearables", "vehicles", "/w_", "/v_", "parachute", "backpack",
				"headgear", "/head/", "/hat", "_hat.", "_mask.", "attach", "shell",
			};
			for ( const auto* b : blocked )
			{
				if ( lower.find( b ) != std::string::npos )
				{
					return false;
				}
			}
			return true;
		}

	} // namespace

	bool model_changer::is_override_active( int team ) const
	{
		if ( !settings::g_changer.model_changer.enabled.value )
		{
			return false;
		}
		if ( team != 2 && team != 3 )
		{
			return false;
		}
		return !resolve_wanted( team ).empty( );
	}

	void model_changer::refresh_models( )
	{
		std::vector<entry> out{};
		out.reserve( 128 );

		std::unordered_set<std::string> seen{};
		auto push = [ & ]( std::string name, std::string path, entry_source source )
		{
			if ( path.empty( ) || !seen.insert( path ).second )
			{
				return;
			}
			if ( name.empty( ) )
			{
				name = path;
			}
			out.push_back( { std::move( name ), std::move( path ), source } );
		};

		// ---------------------------------------------------------------
		// 1. Stock agents from the econ item system (always available).
		// ---------------------------------------------------------------
		for ( const auto* def : g_econ_item_system.agents( ) )
		{
			if ( !def || def->model_player.empty( ) )
			{
				continue;
			}
			std::string name = !def->localized_name.empty( ) ? def->localized_name : def->name;
			if ( name.empty( ) )
			{
				name = def->model_player;
			}
			push( name, def->model_player, entry_source::stock_agent );
		}

		// ---------------------------------------------------------------
		// 2. A handful of known extras that aren't listed as agents.
		// ---------------------------------------------------------------
		push( "Chicken", "characters/models/chicken/chicken.vmdl", entry_source::stock_extra );
		push( "Hostage", "characters/models/hostages/hostage/hostage.vmdl", entry_source::stock_extra );

		// ---------------------------------------------------------------
		// 3. Scan the csgo content directory for user-dropped custom
		//    models.  Custom model packs are typically extracted to
		//    <game>/csgo/ and contain a mix of:
		//
		//        agents/         characters/       materials/
		//        models/         particles/        phase2/
		//
		//    We walk every one of these roots looking for .vmdl_c files,
		//    convert the path to a resource-style string, and list them.
		//    This means models placed mid-game appear after "refresh".
		//
		//    We try game_path::csgo_directory() first (derived from
		//    loaded client.dll), then fall back to known Steam library
		//    locations in case the dynamic lookup fails.
		// ---------------------------------------------------------------
		{
			// Collect all csgo content directories to scan — dynamic first,
			// then hardcoded fallbacks.  Duplicates are harmless because
			// the `seen` set in `push` deduplicates by resource path.
			std::vector<std::filesystem::path> csgo_roots{};

			if ( const auto csgo = game_path::csgo_directory( ) )
			{
				csgo_roots.push_back( *csgo );
			}

			// Hardcoded fallback paths for common Steam library locations.
			const wchar_t* const fallback_paths[ ]{
				L"D:\\SteamLibrary\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo",
				L"C:\\Program Files (x86)\\Steam\\steamapps\\common\\Counter-Strike Global Offensive\\game\\csgo",
			};

			for ( const auto* fb : fallback_paths )
			{
				std::filesystem::path fbp{ fb };
				std::error_code ec{};
				if ( std::filesystem::exists( fbp, ec ) && !ec )
				{
					// Avoid scanning the same directory twice.
					bool already = false;
					for ( const auto& existing : csgo_roots )
					{
						std::error_code eq_ec{};
						if ( std::filesystem::equivalent( existing, fbp, eq_ec ) && !eq_ec )
						{
							already = true;
							break;
						}
					}
					if ( !already )
					{
						csgo_roots.push_back( std::move( fbp ) );
					}
				}
			}

			// Directories that custom model packs drop into the csgo root.
			const char* const scan_roots[ ]{
				"agents",
				"characters",
				"models",
				"particles",
				"phase2"
			};

			std::size_t total_count{ 0 };
			constexpr std::size_t k_max_custom_models{ 4096 };

			for ( const auto& csgo : csgo_roots )
			{
				for ( const auto* root_name : scan_roots )
				{
					if ( total_count >= k_max_custom_models )
					{
						break;
					}

					const std::filesystem::path root = csgo / root_name;
					std::error_code ec{};
					if ( !std::filesystem::exists( root, ec ) || ec )
					{
						continue;
					}

					std::error_code iter_ec{};
					auto it = std::filesystem::recursive_directory_iterator(
						root,
						std::filesystem::directory_options::skip_permission_denied,
						iter_ec
					);
					const auto end = std::filesystem::recursive_directory_iterator( );

					for ( ; !iter_ec && it != end && total_count < k_max_custom_models; it.increment( iter_ec ) )
					{
						std::error_code file_ec{};
						if ( !it->is_regular_file( file_ec ) || file_ec )
						{
							continue;
						}

						const auto& p = it->path( );
						const auto ext = p.extension( ).string( );

						if ( ext != ".vmdl_c" && ext != ".vmdl" )
						{
							continue;
						}

						// Build the resource path: relative to csgo dir, forward slashes.
						std::error_code rel_ec{};
						auto rel = std::filesystem::relative( p, csgo, rel_ec );
						if ( rel_ec )
						{
							continue;
						}

						std::string res = rel.generic_string( );

						// Strip trailing _c so we get a clean .vmdl resource path.
						if ( res.size( ) > 7 && res.compare( res.size( ) - 7, 7, ".vmdl_c" ) == 0 )
						{
							res.erase( res.end( ) - 2, res.end( ) );
						}

						// Skip obvious non-player supporting assets (arms, sleeves,
						// weapon viewmodels, debris, LODs) that would never work on
						// a pawn.  Keep the filter light so custom models pass through.
						if ( is_supporting_asset( res ) || !looks_like_player_model( res ) )
						{
							continue;
						}

						// Derive a human-friendly name from the file stem.
						const auto filename = p.stem( ).stem( ).string( ); // strips .vmdl_c -> .vmdl -> stem
						push( filename + " (custom)", res, entry_source::custom );
						++total_count;
					}
				}
			}
		}

		// Sort: stock agents first, then stock extras, then custom (alphabetical within each).
		std::sort( out.begin( ), out.end( ), [ ]( const entry& a, const entry& b )
		{
			if ( a.source != b.source )
			{
				return static_cast<int>( a.source ) < static_cast<int>( b.source );
			}
			return a.name < b.name;
		} );

		{
			std::scoped_lock lock( this->m_models_mtx );
			// Carry over verification results so a refresh doesn't forget them.
			for ( auto& e : out )
			{
				if ( const auto it = this->m_verified.find( e.path ); it != this->m_verified.end( ) )
				{
					e.status = it->second;
				}
			}
			this->m_models = std::move( out );
			this->m_has_scanned = true;
			this->m_validate_index = 0; // any in-flight validation restarts on the new list
		}
	}

	void model_changer::start_validation( )
	{
		std::scoped_lock lock( this->m_models_mtx );
		this->m_verified.clear( );
		for ( auto& e : this->m_models )
		{
			e.status = 0;
		}
		this->m_validate_index = 0;
		this->m_validating = true;
	}

	bool model_changer::is_validating( ) const
	{
		std::scoped_lock lock( this->m_models_mtx );
		return this->m_validating;
	}

	std::array<std::size_t, 3> model_changer::validation_progress( ) const
	{
		std::scoped_lock lock( this->m_models_mtx );
		std::size_t checked{ 0 }, broken{ 0 };
		for ( const auto& e : this->m_models )
		{
			if ( e.status != 0 )
			{
				++checked;
			}
			if ( e.status < 0 )
			{
				++broken;
			}
		}
		return { checked, this->m_models.size( ), broken };
	}

	void model_changer::run_validation_step( )
	{
		// One model per frame: each test-load can hitch, so spread them out.
		std::string path{};
		{
			std::scoped_lock lock( this->m_models_mtx );
			if ( !this->m_validating )
			{
				return;
			}
			while ( this->m_validate_index < this->m_models.size( ) && this->m_models[ this->m_validate_index ].status != 0 )
			{
				++this->m_validate_index;
			}
			if ( this->m_validate_index >= this->m_models.size( ) )
			{
				this->m_validating = false;
				std::size_t broken{ 0 };
				for ( const auto& e : this->m_models )
				{
					broken += e.status < 0 ? 1u : 0u;
				}
				logging::console::print( "[model_changer] verify done: {} of {} models failed to load and are hidden",
					broken, this->m_models.size( ) );
				return;
			}
			path = this->m_models[ this->m_validate_index ].path;
		}

		// A path the changer would reject anyway counts as broken without loading.
		const bool ok = is_valid_model_path( path ) && precache_model( path );

		std::scoped_lock lock( this->m_models_mtx );
		const std::int8_t status = ok ? 1 : -1;
		this->m_verified[ path ] = status;
		if ( this->m_validate_index < this->m_models.size( ) && this->m_models[ this->m_validate_index ].path == path )
		{
			this->m_models[ this->m_validate_index ].status = status;
		}
		++this->m_validate_index;
	}

	std::vector<model_changer::entry> model_changer::models_snapshot( ) const
	{
		{
			std::scoped_lock lock( this->m_models_mtx );
			if ( this->m_has_scanned )
			{
				return this->m_models;
			}
		}
		// Lazy first scan so dropdown is never empty.
		const_cast<model_changer*>( this )->refresh_models( );
		std::scoped_lock lock( this->m_models_mtx );
		return this->m_models;
	}

	void model_changer::on_level_shutdown( )
	{
		this->m_last_precached.clear( );
		this->m_last_applied.clear( );
		this->m_original_model.clear( );
		this->m_tracked_pawn = 0;
		this->m_applied_handle = 0;
		this->m_tracked_team = 0;
		this->m_overridden = false;
	}

	bool model_changer::is_valid_model_path( const std::string& path ) const
	{
		if ( path.empty( ) || path.size( ) < 6 || path.size( ) > 512 )
		{
			return false;
		}

		if ( path.find( ".." ) != std::string::npos )
		{
			return false;
		}

		if ( path.find( ".vmdl" ) == std::string::npos )
		{
			return false;
		}

		const auto ends_with_vmdl = path.size( ) >= 5 &&
			path.compare( path.size( ) - 5, 5, ".vmdl" ) == 0;
		if ( !ends_with_vmdl )
		{
			return false;
		}

		for ( const auto c : path )
		{
			const auto ok = ( c >= 'a' && c <= 'z' ) ||
				( c >= 'A' && c <= 'Z' ) ||
				( c >= '0' && c <= '9' ) ||
				c == '/' || c == '_' || c == '-' || c == '.';
			if ( !ok )
			{
				return false;
			}
		}

		return true;
	}

	bool model_changer::is_supporting_asset( const std::string& path ) const
	{
		// Lowercase the path for substring matching.
		std::string lower{};
		lower.resize( path.size( ) );
		for ( std::size_t i = 0; i < path.size( ); ++i )
		{
			auto c = path[ i ];
			lower[ i ] = static_cast<char>( ( c >= 'A' && c <= 'Z' ) ? c + 32 : c );
		}

		// These are attachment / viewmodel / junk assets that will never
		// work on a pawn — they don't have a full skeleton, or they are
		// LODs / shadow proxies.
		const char* const blocked[ ]{
			"/v_",           // viewmodel prefix (v_knife, v_ak47 etc.)
			"_arms",         // arm sleeves
			"sleeve",
			"/hand",
			"_hand",
			"finger",
			"patch/",
			"pin/",
			"coin/",
			"medal/",
			"debris",
			"gib/",
			"_gib",
			"_shadow",
			"_lod",
		};

		for ( const auto* b : blocked )
		{
			if ( lower.find( b ) != std::string::npos )
			{
				return true;
			}
		}
		return false;
	}

	std::string model_changer::resolve_wanted( int team ) const
	{
		const auto& cfg = settings::g_changer.model_changer;
		if ( !cfg.enabled.value )
		{
			return {};
		}

		std::string wanted = ( team == 3 ) ? cfg.ct_model.value : cfg.t_model.value;
		if ( wanted.empty( ) )
		{
			return {};
		}

		// Allow "path.vmdl_c" pasted from dumps — strip trailing _c.
		if ( wanted.size( ) > 7 && wanted.compare( wanted.size( ) - 7, 7, ".vmdl_c" ) == 0 )
		{
			wanted.erase( wanted.end( ) - 2, wanted.end( ) );
		}

		if ( !is_valid_model_path( wanted ) )
		{
			return {};
		}

		return wanted;
	}

	bool model_changer::precache_model( const std::string& path )
	{
		struct buffer_string
		{
			std::uint32_t m_unknown1{};
			std::uint32_t m_unknown2{ 0xc00000c8 };

			union
			{
				std::uintptr_t m_str_ptr;
				std::uint8_t data[ 0xc8 ];
			};

			std::uintptr_t m_unknown3{};
			std::uintptr_t m_unknown4{};
		} buffer{};

		const auto init_path_buffer = PATTERN( patterns::init_particle_path_buffer );
		const auto precache_resource = PATTERN( patterns::resource_system_precache );
		if ( !init_path_buffer || !precache_resource || !addresses::globals::resource_system )
		{
			return false;
		}

		memory::call<void>( init_path_buffer, &buffer, path.c_str( ) );
		// 'ldmv' = "vmdl" reversed.
		buffer.m_unknown4 = 'ldmv';

		memory::call<void>( precache_resource, addresses::globals::resource_system, &buffer, "" );

		// Verify the model actually loaded — if binding is null the path
		// is bogus and SetModel would just flicker.
		memory::call<void>( init_path_buffer, &buffer, path.c_str( ) );
		buffer.m_unknown4 = 'ldmv';
		const auto binding = memory::call_vfunc<std::uintptr_t>( addresses::globals::resource_system, 79, &buffer, 0ll );
		const auto texture = binding ? memory::safe_read<std::uintptr_t>( binding ) : std::nullopt;
		if ( !texture || !*texture )
		{
			return false;
		}

		this->m_last_precached = path;
		return true;
	}

	void model_changer::on_frame_stage_notify( )
	{
		// Runs before the alive check so "verify models" also works while dead or
		// spectating (this hook only fires once you're in a map).
		this->run_validation_step( );

		const auto local = systems::g_local.get( );
		if ( !local.is_alive || systems::g_local.is_in_cinematic( ) || !local.pawn )
		{
			return;
		}

		if ( this->m_tracked_pawn != local.pawn )
		{
			this->m_original_model.clear( );
			this->m_last_applied.clear( );
			this->m_applied_handle = 0;
			this->m_tracked_team = 0;
			this->m_overridden = false;
			this->m_tracked_pawn = local.pawn;
		}

		const auto team = memory::read<int>( local.pawn + SCHEMA( "C_BaseEntity", "m_iTeamNum"_hash ) );
		const auto wanted = resolve_wanted( team );

		const auto game_scene_node = memory::read<std::uintptr_t>( local.pawn + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
		if ( !game_scene_node )
		{
			return;
		}

		const auto model_state = game_scene_node + SCHEMA( "CSkeletonInstance", "m_modelState"_hash );

		if ( wanted.empty( ) )
		{
			if ( this->m_overridden && !this->m_original_model.empty( ) )
			{
				const auto set_model = PATTERN( patterns::set_player_model );
				if ( set_model )
				{
					memory::call<void>( set_model, local.pawn, this->m_original_model.c_str( ) );
				}

				this->m_last_applied.clear( );
				this->m_applied_handle = 0;
				this->m_tracked_team = 0;
				this->m_overridden = false;
			}
			return;
		}

		if ( !this->m_overridden && this->m_original_model.empty( ) )
		{
			const auto model_name_ptr = memory::read<std::uintptr_t>( model_state + SCHEMA( "CModelState", "m_ModelName"_hash ) );
			if ( model_name_ptr )
			{
				this->m_original_model = memory::read_string( model_name_ptr );
			}
		}

		const auto current_handle = memory::read<std::uintptr_t>( model_state + SCHEMA( "CModelState", "m_hModel"_hash ) );
		if ( this->m_overridden &&
			this->m_last_applied == wanted &&
			this->m_tracked_team == team &&
			this->m_applied_handle != 0 &&
			current_handle == this->m_applied_handle )
		{
			return;
		}

		if ( this->m_last_precached != wanted )
		{
			if ( !precache_model( wanted ) )
			{
				return;
			}
		}

		const auto set_model = PATTERN( patterns::set_player_model );
		if ( !set_model )
		{
			return;
		}

		memory::call<void>( set_model, local.pawn, wanted.c_str( ) );

		// Keep player collision bounds so custom props (chicken, etc)
		// don't sink you into the ground.
		const auto collision = local.pawn + SCHEMA( "C_BaseModelEntity", "m_Collision"_hash );
		memory::write<math::vector3>( collision + SCHEMA( "CCollisionProperty", "m_vecMins"_hash ), math::vector3( -16.0f, -16.0f, 0.0f ) );
		memory::write<math::vector3>( collision + SCHEMA( "CCollisionProperty", "m_vecMaxs"_hash ), math::vector3( 16.0f, 16.0f, 72.0f ) );

		this->m_applied_handle = memory::read<std::uintptr_t>( model_state + SCHEMA( "CModelState", "m_hModel"_hash ) );
		this->m_last_applied = wanted;
		this->m_tracked_team = team;
		this->m_overridden = true;
	}

} // namespace features::changer
