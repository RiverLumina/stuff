#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/addresses/addresses.hpp>
#include <utilities/logging/logging.hpp>
#include <core/systems/systems.hpp>
#include <core/settings.hpp>

#include "../misc.hpp"
#include <protection/game_addresses.hpp>

namespace features::misc {
	namespace {
		constexpr std::ptrdiff_t k_fov_offset{ 0x498 };
		constexpr std::ptrdiff_t k_aspect_ratio_offset{ 0x4d4 };
		constexpr std::ptrdiff_t k_view_flags_offset{ 0x551 };
		constexpr std::uint8_t k_explicit_aspect_ratio_flag{ 1u << 1 };

		[[nodiscard]] float scale_horizontal_fov( float fov, float aspect_ratio )
		{
			constexpr auto degrees_to_half_radians{ std::numbers::pi_v<float> / 360.0f };
			constexpr auto half_radians_to_degrees{ 360.0f / std::numbers::pi_v<float> };
			constexpr auto four_by_three_inverse{ 0.75f };

			return std::atan( std::tan( fov * degrees_to_half_radians ) * aspect_ratio * four_by_three_inverse ) * half_radians_to_degrees;
		}

		// CViewSetup: fov 0x498, viewmodel fov 0x49C, origin 0x4A0, angles 0x4B8
		// (origin/angles offsets are the ones thirdperson/no-recoil already use).
		constexpr std::ptrdiff_t k_viewmodel_fov_offset{ 0x49c };

		// Current zoom level of the active weapon (0 = not zoomed, 1, 2).
		[[nodiscard]] int active_zoom_level( std::uintptr_t pawn )
		{
			if ( !pawn || !memory::read<bool>( pawn + SCHEMA( "C_CSPlayerPawn", "m_bIsScoped"_hash ) ) )
			{
				return 0;
			}
			const auto weapon_services = memory::read<std::uintptr_t>( pawn + SCHEMA( "C_BasePlayerPawn", "m_pWeaponServices"_hash ) );
			if ( !weapon_services )
			{
				return 1;
			}
			const auto handle = memory::read<std::uint32_t>( weapon_services + SCHEMA( "CPlayer_WeaponServices", "m_hActiveWeapon"_hash ) );
			const auto weapon = handle ? systems::g_entities.lookup( handle ) : 0;
			if ( !weapon )
			{
				return 1;
			}
			const auto level = memory::read<int>( weapon + SCHEMA( "C_CSWeaponBaseGun", "m_zoomLevel"_hash ) );
			return std::clamp( level, 1, 2 );
		}

		// True when the user asked to remove the zoom for the current level.
		[[nodiscard]] bool zoom_removed( std::uintptr_t pawn )
		{
			const auto& rem = settings::g_misc.m_removals;
			if ( !rem.zoom_first.value && !rem.zoom_second.value )
			{
				return false;
			}
			const auto level = active_zoom_level( pawn );
			return ( level == 1 && rem.zoom_first.value ) || ( level == 2 && rem.zoom_second.value );
		}
	}

	void camera::on_override_view( std::uintptr_t view_setup )
	{
		const auto local = systems::g_local.get( );
		if ( local.is_alive && !systems::g_local.is_in_cinematic( ) && local.team >= 2 && local.pawn )
		{
			this->do_thirdperson( view_setup, local.pawn );
			this->do_fov_change( view_setup, local.pawn );

			// Remove scope zoom: keep the normal (or custom) FOV while scoped.
			if ( zoom_removed( local.pawn ) )
			{
				const auto& cfg = settings::g_misc.m_camera;
				memory::write<float>( view_setup + k_fov_offset, cfg.change_fov.value ? cfg.fov.value : 90.0f );
			}

			// Viewmodel FOV straight into the view setup, which isn't clamped to
			// the game's 54-68 like the viewmodel_fov convar. Only written if the
			// field currently holds a plausible FOV, as a guard on the offset.
			const auto& vm = settings::g_misc.m_viewmodel_adjust;
			if ( vm.enabled.value )
			{
				this->do_viewmodel_extra_offset( view_setup, local.pawn );

				const auto current = memory::read<float>( view_setup + k_viewmodel_fov_offset );
				if ( current >= 20.0f && current <= 170.0f )
				{
					memory::write<float>( view_setup + k_viewmodel_fov_offset, std::clamp( vm.fov.value, 20.0f, 170.0f ) );
				}
			}
		}

		// Aspect conversion must run after the base FOV has been selected.
		this->do_aspect_ratio_change( view_setup );
	}

	void camera::update_fov_sensitivity( std::uintptr_t player_pawn ) const
	{
		const auto local = systems::g_local.get( );
		if ( player_pawn != local.pawn )
		{
			return;
		}

		// Zoom removed: the view isn't zoomed, so don't let the game slow the
		// mouse down to zoomed sensitivity either.
		if ( zoom_removed( player_pawn ) )
		{
			memory::write<float>( player_pawn + SCHEMA( "C_BasePlayerPawn", "m_flFOVSensitivityAdjust"_hash ), 1.0f );
			this->m_cached_fov_sensitivity = -1.0f;
			return;
		}

		if ( !settings::g_misc.m_camera.change_fov.value )
		{
			return;
		}

		const auto& cfg = settings::g_misc.m_camera;
		const auto is_scoped = memory::read<bool>( player_pawn + SCHEMA( "C_CSPlayerPawn", "m_bIsScoped"_hash ) );
		const auto target_fov = ( is_scoped && cfg.scoped_fov_override.value ) ? cfg.scoped_fov.value : cfg.fov.value;

		if ( is_scoped == this->m_cached_scoped && target_fov == this->m_cached_target_fov && this->m_cached_fov_sensitivity >= 0.0f )
		{
			const auto current_adjust = memory::read<float>( player_pawn + SCHEMA( "C_BasePlayerPawn", "m_flFOVSensitivityAdjust"_hash ) );
			if ( std::fabsf( current_adjust - this->m_cached_fov_sensitivity ) < 0.0001f )
			{
				return;
			}
		}

		this->m_cached_scoped = is_scoped;
		this->m_cached_target_fov = target_fov;

		const auto ratio = CONVAR ("zoom_sensitivity_ratio")->get<float>( );
		const auto desired = ratio * ( target_fov / 90.0f );

		this->m_cached_fov_sensitivity = desired;
		memory::write<float>( player_pawn + SCHEMA( "C_BasePlayerPawn", "m_flFOVSensitivityAdjust"_hash ), desired );
	}

	void camera::do_viewmodel_extra_offset( std::uintptr_t view_setup, std::uintptr_t local_pawn ) const
	{
		const auto& vm = settings::g_misc.m_viewmodel_adjust;

		// Offsets past the game's clamp (x +-2.5, y/z +-2). When the
		// CalcViewModel hook is installed it applies these instead.
		const bool hooked = s_calc_viewmodel_hooked.load( std::memory_order_relaxed );
		const auto extra_x = hooked ? 0.0f : vm.offset_x.value - std::clamp( vm.offset_x.value, -2.5f, 2.5f ); // right
		const auto extra_y = hooked ? 0.0f : vm.offset_y.value - std::clamp( vm.offset_y.value, -2.0f, 2.0f ); // forward
		const auto extra_z = hooked ? 0.0f : vm.offset_z.value - std::clamp( vm.offset_z.value, -2.0f, 2.0f ); // up
		const bool has_offset = extra_x != 0.0f || extra_y != 0.0f || extra_z != 0.0f;

		// Rotation: CalcViewModel's 3rd argument is the FOV on this build, so the
		// rotation is applied to the viewmodel's scene node here instead.
		const bool has_rotation = vm.rot_x.value != 0.0f || vm.rot_y.value != 0.0f || vm.rot_z.value != 0.0f;
		if ( !has_offset && !has_rotation )
		{
			return;
		}

		const auto vm_services = memory::read<std::uintptr_t>( local_pawn + SCHEMA( "C_CSPlayerPawnBase", "m_pViewModelServices"_hash ) );
		if ( !vm_services )
		{
			return;
		}
		const auto handle = memory::read<std::uint32_t>( vm_services + SCHEMA( "CCSPlayer_ViewModelServices", "m_hViewModel"_hash ) );
		const auto viewmodel = handle ? systems::g_entities.lookup( handle ) : 0;
		if ( !viewmodel )
		{
			return;
		}
		const auto node = memory::read<std::uintptr_t>( viewmodel + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
		if ( !node )
		{
			return;
		}
		const auto n2w_off = SCHEMA( "CGameSceneNode", "m_nodeToWorld"_hash ); // CTransform: pos (16 bytes) + quat
		constexpr auto deg2rad{ std::numbers::pi_v<float> / 180.0f };

		if ( has_offset )
		{
			// Camera axes from the view setup's angles (0x4B8).
			const auto angles = memory::read<math::vector3>( view_setup + 0x4b8 );
			const auto sp = std::sinf( angles.x * deg2rad ), cp = std::cosf( angles.x * deg2rad );
			const auto sy = std::sinf( angles.y * deg2rad ), cy = std::cosf( angles.y * deg2rad );
			const math::vector3 forward{ cp * cy, cp * sy, -sp };
			const math::vector3 right{ sy, -cy, 0.0f };
			const math::vector3 up{ sp * cy, sp * sy, cp };
			const auto shift = right * extra_x + forward * extra_y + up * extra_z;

			// The game recomputes these every frame, so this doesn't accumulate.
			const auto abs_off = SCHEMA( "CGameSceneNode", "m_vecAbsOrigin"_hash );
			memory::write<math::vector3>( node + abs_off, memory::read<math::vector3>( node + abs_off ) + shift );
			if ( n2w_off > 0 )
			{
				memory::write<math::vector3>( node + n2w_off, memory::read<math::vector3>( node + n2w_off ) + shift );
			}
		}

		// Rotation is applied at render start (frame_stage_notify, stage 12), after
		// the engine has finished writing the viewmodel node for the frame.
		(void)has_rotation;
	}

	void camera::apply_viewmodel_rotation( std::uintptr_t local_pawn )
	{
		const auto& vm = settings::g_misc.m_viewmodel_adjust;
		if ( !local_pawn || ( vm.rot_x.value == 0.0f && vm.rot_y.value == 0.0f && vm.rot_z.value == 0.0f ) )
		{
			return;
		}
		const auto vm_services = memory::read<std::uintptr_t>( local_pawn + SCHEMA( "C_CSPlayerPawnBase", "m_pViewModelServices"_hash ) );
		if ( !vm_services )
		{
			return;
		}
		const auto handle = memory::read<std::uint32_t>( vm_services + SCHEMA( "CCSPlayer_ViewModelServices", "m_hViewModel"_hash ) );
		const auto viewmodel = handle ? systems::g_entities.lookup( handle ) : 0;
		if ( !viewmodel )
		{
			return;
		}
		const auto node = memory::read<std::uintptr_t>( viewmodel + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
		if ( !node )
		{
			return;
		}
		const auto rot_off = SCHEMA( "CGameSceneNode", "m_angAbsRotation"_hash );
		if ( rot_off <= 0 )
		{
			return;
		}
		const auto n2w_off = SCHEMA( "CGameSceneNode", "m_nodeToWorld"_hash );
		constexpr auto deg2rad{ std::numbers::pi_v<float> / 180.0f };

		// x = pitch, y = yaw, z = roll (degrees), added to the node's angles.
		auto ang = memory::read<math::vector3>( node + rot_off );
		ang.x += vm.rot_x.value;
		ang.y += vm.rot_y.value;
		ang.z += vm.rot_z.value;
		memory::write<math::vector3>( node + rot_off, ang );

		// Same angles as a quaternion into node-to-world (Source AngleQuaternion).
		if ( n2w_off > 0 )
		{
			const auto hp = ang.x * deg2rad * 0.5f, hy = ang.y * deg2rad * 0.5f, hr = ang.z * deg2rad * 0.5f;
			const auto sp = std::sinf( hp ), cp = std::cosf( hp );
			const auto sy = std::sinf( hy ), cy = std::cosf( hy );
			const auto sr = std::sinf( hr ), cr = std::cosf( hr );
			const float quat[ 4 ]
			{
				sr * cp * cy - cr * sp * sy,
				cr * sp * cy + sr * cp * sy,
				cr * cp * sy - sr * sp * cy,
				cr * cp * cy + sr * sp * sy,
			};
			for ( int i = 0; i < 4; ++i )
			{
				memory::write<float>( node + n2w_off + 16 + i * 4, quat[ i ] );
			}
		}
	}

	void camera::do_thirdperson( std::uintptr_t view_setup, std::uintptr_t local_pawn ) const
	{
		const auto& cfg = settings::g_misc.m_camera;
		if ( !cfg.thirdperson.value )
		{
			return;
		}

		const auto game_scene_node = memory::read<std::uintptr_t>( local_pawn + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
		const auto origin = memory::read<math::vector3>( game_scene_node + SCHEMA( "CGameSceneNode", "m_vecAbsOrigin"_hash ) );
		const auto view_offset = memory::read<math::vector3>( local_pawn + SCHEMA( "C_BaseModelEntity", "m_vecViewOffset"_hash ) );
		const auto eye_position = origin + view_offset;
		const auto view_angles = systems::g_input.get_view_angles( );

		math::vector3 forward{};
		{
			math::helpers::angle_vectors_left( view_angles, &forward );
		}

		auto camera_position = eye_position - forward * cfg.thirdperson_distance;
		const auto hull = math::vector3{ -cfg.thirdperson_hull_size, -cfg.thirdperson_hull_size, -cfg.thirdperson_hull_size };
		const auto result = systems::g_tracing.trace_hull( eye_position, camera_position, hull, hull, local_pawn );

		if ( result.fraction < 1.0f )
		{
			const auto world = systems::g_entities.get_by_index( 0 );
			if ( result.hit_entity == world )
			{
				camera_position = eye_position + ( camera_position - eye_position ) * result.fraction;
			}
		}

		memory::write<math::vector3>( view_setup + 0x4a0, camera_position );
	}

	void camera::do_fov_change( std::uintptr_t view_setup, std::uintptr_t local_pawn ) const
	{
		const auto& cfg = settings::g_misc.m_camera;
		if ( !cfg.change_fov.value )
		{
			return;
		}

		const auto is_scoped = memory::read<bool>( local_pawn + SCHEMA( "C_CSPlayerPawn", "m_bIsScoped"_hash ) );
		const auto target_fov = ( is_scoped && cfg.scoped_fov_override.value ) ? cfg.scoped_fov.value : cfg.fov.value;

		memory::write<float>( view_setup + k_fov_offset, target_fov );

		this->update_fov_sensitivity( local_pawn );
	}

	void camera::do_aspect_ratio_change( std::uintptr_t view_setup )
	{
		const auto& cfg = settings::g_misc.m_camera;

		if ( cfg.change_aspect_ratio.value )
		{
			const auto base_fov = memory::read<float>( view_setup + k_fov_offset );
			const auto flags = memory::read<std::uint8_t>( view_setup + k_view_flags_offset );

			// Explicit aspect bypasses the game's native 4:3-based FOV conversion.
			memory::write<float>( view_setup + k_fov_offset, scale_horizontal_fov( base_fov, cfg.aspect_ratio ) );
			memory::write<float>( view_setup + k_aspect_ratio_offset, cfg.aspect_ratio );
			memory::write<std::uint8_t>( view_setup + k_view_flags_offset, flags | k_explicit_aspect_ratio_flag );
		}
		else
		{
			const auto flags = memory::read<std::uint8_t>( view_setup + k_view_flags_offset );
			memory::write<std::uint8_t>( view_setup + k_view_flags_offset,
				flags & static_cast<std::uint8_t>( ~k_explicit_aspect_ratio_flag ) );
		}
	}

} // namespace features::misc
