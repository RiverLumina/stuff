#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/addresses/addresses.hpp>
#include <core/settings.hpp>

#include "../misc.hpp"

namespace features::misc {

	void removals::on_prepare_scene_material( std::uintptr_t material ) const
	{
		if ( !settings::g_misc.m_removals.skybox_fog.value )
		{
			return;
		}

		const auto parameters = memory::read<std::uintptr_t>( material + 0x20 );
		if ( !parameters )
		{
			return;
		}

		const auto count = memory::read<std::uint32_t>( material + 0x18 );

		for ( auto i = 0u; i < count; i++ )
		{
			const auto parameter = parameters + ( static_cast< std::size_t >( i ) * 0x40 );
			const auto name_ptr = memory::read<const char*>( parameter + 0x28 );

			if ( !name_ptr )
			{
				continue;
			}

			const auto param_hash = fnv1a::runtime_hash( name_ptr );
			if ( param_hash == "g_flBrightnessExposureBias"_hash || param_hash == "g_flRenderOnlyExposureBias"_hash )
			{
				memory::write<float>( parameter, -6.0f );
			}
		}
	}

	void removals::on_frame_stage_notify( ) const
	{
		struct entry
		{
			std::uint32_t hash;
			c_convar* cvar;
			bool applied;
		};

		// removal value -> restored default when the option is turned off again.
		static entry entries[ ] = {
			{ "r_csgo_postprocess_enable"_hash, nullptr, false },
			{ "r_drawparticles"_hash, nullptr, false },
			{ "r_drawworld"_hash, nullptr, false },
			{ "r_drawcsplayers"_hash, nullptr, false },
			{ "cl_draw_only_deathnotices"_hash, nullptr, false },
			{ "r_drawviewmodel"_hash, nullptr, false },
			{ "mat_fullbright"_hash, nullptr, false },
		};

		if ( !addresses::globals::cvar )
		{
			return;
		}

		const auto& r = settings::g_misc.m_removals;

		// {wanted, value while active, value when restored}
		const struct { bool want; bool on; bool off; } desired[ ] = {
			{ r.post_processing.value, false, true },
			{ r.particles.value, false, true },
			{ r.world.value, false, true },
			{ r.players.value, false, true },
			{ r.hud.value, true, false },
			{ r.viewmodel.value, false, true },
			{ r.fullbright.value, true, false },
		};

		for ( auto i = 0u; i < std::size( entries ); ++i )
		{
			auto& e = entries[ i ];
			const auto& d = desired[ i ];

			if ( !d.want && !e.applied )
			{
				continue;
			}

			if ( !e.cvar )
			{
				e.cvar = addresses::globals::cvar->find( e.hash );
				if ( !e.cvar )
				{
					continue;
				}
			}

			// Re-written every frame while active: the game and the server's
			// replicated cvars can flip these back.
			e.cvar->m_value.i1 = d.want ? d.on : d.off;
			e.applied = d.want;
		}
	}

	void removals::on_override_view( std::uintptr_t view_setup ) const
	{
		const auto want_punch = settings::g_misc.m_removals.remove_punch.value;
		const auto want_recoil = settings::g_misc.m_removals.recoil.value;

		if ( !want_punch && !want_recoil )
		{
			return;
		}

		const auto local = systems::g_local.get( );
		if ( !local.is_alive || systems::g_local.is_in_cinematic( ) || local.team < 2 )
		{
			return;
		}

		if ( want_recoil )
		{
			// Full recoil removal: slam the view setup angles back to
			// the raw input view angles — removes both visual punch and
			// any recoil spread the engine applied.
			memory::write<math::vector3>( view_setup + 0x4b8, systems::g_input.get_view_angles( ) );
		}
		else if ( want_punch )
		{
			// Visual punch removal. The old version subtracted m_aimPunchAngle * 2,
			// but the engine's view punch isn't a fixed multiple of that field
			// (it's smoothed/cached), so it under- or over-corrected and the
			// camera still kicked. Instead measure what the camera actually adds
			// on top of the player's own view angles and take exactly that out.
			// Pitch/yaw go back to the input angles; roll is left to the game.
			const auto base = systems::g_input.get_view_angles( );
			auto angles = memory::read<math::vector3>( view_setup + 0x4b8 );

			angles.x = base.x;
			angles.y = base.y;

			memory::write<math::vector3>( view_setup + 0x4b8, angles );
		}
	}

} // namespace features::misc