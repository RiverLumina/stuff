#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/logging/logging.hpp>
#include <core/systems/systems.hpp>
#include <core/features/features.hpp>
#include <core/settings.hpp>
#include <protection/game_addresses.hpp>
#include <core/rendering/rendering.hpp>

namespace features::movement {

	void airstrafe::on_create_move( systems::input::usercmd* cmd )
	{
		if ( features::movement::g_jumpbug.active_this_tick( ) )
		{
			return;
		}

		if ( features::movement::g_bhop.landing_jump_this_tick( ) )
		{
			return;
		}

		const auto base = cmd->csgo_user_cmd.mutable_base( );
		if ( !base )
		{
			return;
		}

		const auto current_buttons = cmd->buttons.value;
		const bool shift_held = current_buttons & static_cast< std::uintptr_t >( cstypes::command_buttons::in_sprint );

		const auto& prestate = systems::g_prediction.pre( );
		const bool in_air = !( prestate.flags & cstypes::entity_flags::on_ground );

		if ( shift_held && in_air )
		{
			const auto& vel = prestate.networked_velocity;
			float forward_move = 0.0f;
			float left_move = 0.0f;

			if ( vel.length_2d( ) > 10.0f )
			{
				const auto vel_yaw = std::atan2f( vel.y, vel.x )
					* ( 180.0f / std::numbers::pi_v<float> );

				const auto view_yaw = base->viewangles( )->y( );
				const auto relative_yaw = ( vel_yaw - view_yaw )
					* ( std::numbers::pi_v<float> / 180.0f );

				const auto fwd_x = std::cosf( relative_yaw );
				const auto fwd_y = std::sinf( relative_yaw );

				forward_move = std::clamp( -fwd_x, -1.0f, 1.0f );
				left_move = std::clamp( -fwd_y, -1.0f, 1.0f ); // negated
			}

			base->set_forwardmove( forward_move );
			base->set_leftmove( left_move );

			// write subtick entries so the engine respects the input precisely 
			const auto subtick_moves = base->mutable_subtick_moves( );
			if ( subtick_moves )
			{
				const auto step = systems::g_input.acquire_subtick_step( subtick_moves );
				if ( step )
				{
					step->set_button( 0 );
					step->set_pressed( false );
					step->set_when( 0.0f );
					step->set_analog_forward_delta( forward_move - prestate.last_movement_impulses.x );
					step->set_analog_left_delta( left_move - prestate.last_movement_impulses.y );
				}
			}
			return;
		}

		const auto wants_stop = features::combat::g_rage.should_stop( ) || features::misc::g_projectile_trajectory.should_stop( );

		// Track button state early (before any early exits) using pre-anti-aim buttons.
		if ( !wants_stop )
		{
			this->check_button( this->m_real_buttons, cstypes::command_buttons::in_moveleft );
			this->check_button( this->m_real_buttons, cstypes::command_buttons::in_moveright );
			this->check_button( this->m_real_buttons, cstypes::command_buttons::in_forward );
			this->check_button( this->m_real_buttons, cstypes::command_buttons::in_back );
			this->m_last_buttons = this->m_real_buttons;
		}

		if ( ( !settings::g_movement.airstrafe.value && !wants_stop ) || features::combat::g_rage.is_firing_this_tick( ) )
		{
			return;
		}

		const auto local = systems::g_local.get( );
		if ( !local.pawn )
		{
			return;
		}

		const auto move_type = memory::read<std::uint8_t>( local.pawn + SCHEMA( "CBaseEntity", "m_nActualMoveType"_hash ) );
		if ( move_type == cstypes::move_type::ladder || move_type == cstypes::move_type::noclip )
		{
			return;
		}

		if ( settings::g_movement.m_test_strafer.enabled.value && features::movement::g_test_strafer.handled_this_tick( ) )
		{
			// "sub tick strafer" owns movement this tick; airstrafe's key logic
			// never runs. Turn it off to use the directional airstrafe.
			static std::uint64_t last_log_ms{ 0 };
			if ( GetTickCount64( ) - last_log_ms > 3000ull )
			{
				last_log_ms = GetTickCount64( );
				logging::console::print( "[airstrafe] skipped: sub tick strafer is enabled and handled this tick" );
			}
			return;
		}

		if ( prestate.flags & cstypes::entity_flags::on_ground )
		{
			return;
		}

		if ( current_buttons & static_cast< std::uintptr_t >( cstypes::command_buttons::in_sprint ) )
		{
			return;
		}

		const auto subtick_moves = base->mutable_subtick_moves( );
		if ( !subtick_moves )
		{
			return;
		}

		const auto movement_services = memory::read<std::uintptr_t>( local.pawn + SCHEMA( "C_BasePlayerPawn", "m_pMovementServices"_hash ) );
		if ( !movement_services )
		{
			return;
		}

		const auto sv_airaccelerate = CONVAR ("sv_airaccelerate")->get<float>( );
		const auto sv_air_max_wishspeed = CONVAR ("sv_air_max_wishspeed")->get<float>( );
		const auto sv_gravity = CONVAR ("sv_gravity")->get<float>( );
		const auto sv_staminarecoveryrate = CONVAR ("sv_staminarecoveryrate")->get<float>( );

		const auto view_angles = this->m_angles;
		const auto cmd_move_backup = math::vector3{ base->forwardmove( ), base->leftmove( ), 0.0f };
		const auto effective_maxspeed = memory::read<float>( movement_services + SCHEMA( "CPlayer_MovementServices", "m_flMaxspeed"_hash ) );
		(void)sv_gravity;
		(void)sv_staminarecoveryrate;

		constexpr auto subtick_count{ 32 };
		constexpr auto frame_time{ cstypes::tick_interval / static_cast< float >( subtick_count ) };
		constexpr auto rad2deg{ 180.0f / std::numbers::pi_v<float> };
		constexpr auto deg2rad{ std::numbers::pi_v<float> / 180.0f };

		// ------------------------------------------------------------------
		// Desired direction. Buttons first (last-pressed wins on opposite keys),
		// falling back to the game's own analog movement captured before
		// anti-aim, so keys still register if the button bits are missing.
		// ------------------------------------------------------------------
		float key_fwd{ 0.0f }, key_left{ 0.0f };
		const char* key_source{ "none" };
		if ( !wants_stop )
		{
			// 1) button bits from the cmd (last-pressed wins on opposite keys)
			if ( this->m_last_pressed & cstypes::command_buttons::in_forward ) { key_fwd += 1.0f; }
			if ( this->m_last_pressed & cstypes::command_buttons::in_back ) { key_fwd -= 1.0f; }
			if ( this->m_last_pressed & cstypes::command_buttons::in_moveleft ) { key_left += 1.0f; }
			if ( this->m_last_pressed & cstypes::command_buttons::in_moveright ) { key_left -= 1.0f; }
			if ( key_fwd != 0.0f || key_left != 0.0f )
			{
				key_source = "buttons";
			}

			// 2) the game's analog forward/left from before anti-aim
			if ( key_fwd == 0.0f && key_left == 0.0f &&
				( std::fabsf( this->m_real_move.x ) > 0.1f || std::fabsf( this->m_real_move.y ) > 0.1f ) )
			{
				key_fwd = this->m_real_move.x;
				key_left = this->m_real_move.y;
				key_source = "analog";
			}

			// 3) physical WASD, only while CS2 has focus and the menu is closed.
			//    Last resort for when the game hands us neither of the above.
			if ( key_fwd == 0.0f && key_left == 0.0f && !rendering::g_menu.is_open( ) &&
				GetForegroundWindow( ) == rendering::g_context.get_window( ) )
			{
				const auto down = [ ]( int vk ) { return ( GetAsyncKeyState( vk ) & 0x8000 ) != 0; };
				if ( down( 'W' ) ) { key_fwd += 1.0f; }
				if ( down( 'S' ) ) { key_fwd -= 1.0f; }
				if ( down( 'A' ) ) { key_left += 1.0f; }
				if ( down( 'D' ) ) { key_left -= 1.0f; }
				if ( key_fwd != 0.0f || key_left != 0.0f )
				{
					key_source = "wasd";
				}
			}
		}
		const auto has_direction_input = std::fabsf( key_fwd ) > 0.1f || std::fabsf( key_left ) > 0.1f;

		// Once a second while airborne: what each key source saw. Paste this line
		// if the strafer still ignores keys.
		{
			static std::uint64_t last_log_ms{ 0 };
			const auto now = GetTickCount64( );
			if ( now - last_log_ms > 1000ull )
			{
				last_log_ms = now;
				logging::console::print( "[airstrafe] buttons=0x{:X} pressed=0x{:X} analog=({:.2f},{:.2f}) -> src={} dir=({:.1f},{:.1f}) stop={}",
					static_cast<std::uint64_t>( this->m_real_buttons ), static_cast<std::uint64_t>( this->m_last_pressed ),
					this->m_real_move.x, this->m_real_move.y, key_source, key_fwd, key_left, wants_stop ? 1 : 0 );
			}
		}

		auto velocity = prestate.networked_velocity;
		const auto surface_friction = prestate.surface_friction;
		auto last_impulses = prestate.last_movement_impulses;

		if ( wants_stop && velocity.length_2d( ) <= 10.0f )
		{
			this->rotate_to_stop( base, velocity );
			return;
		}

		// Where we want to end up going (world yaw):
		//  - keys held: camera yaw + key direction (A = left, S = back, W+D = 45 right, ...)
		//  - no keys, fully directional: hold the current heading (used to BRAKE
		//    here, which is what was killing your speed)
		//  - no keys otherwise: classic autostrafe toward where you look
		auto desired_yaw = view_angles.y;
		if ( has_direction_input )
		{
			desired_yaw += std::atan2f( key_left, key_fwd ) * rad2deg;
		}
		else if ( settings::g_movement.airstrafe_fully_directional.value && velocity.length_2d( ) > 10.0f )
		{
			desired_yaw = std::atan2f( velocity.y, velocity.x ) * rad2deg;
		}
		math::helpers::normalize_angle( desired_yaw );

		// The engine interprets forward/left relative to the cmd's viewangles
		// (the anti-aim angle at this point; the spin remap later re-expresses
		// movement for the final angle), so build movement against that.
		const auto cmd_yaw = base->viewangles( )->y( );
		const auto air_cap = sv_air_max_wishspeed;
		const auto accel_step = sv_airaccelerate * effective_maxspeed * frame_time * surface_friction * 0.5f;

		for ( auto i = 0; i < subtick_count; ++i )
		{
			const auto speed = std::sqrtf( velocity.x * velocity.x + velocity.y * velocity.y );
			float fm{ cmd_move_backup.x }, lm{ cmd_move_backup.y };

			if ( wants_stop )
			{
				this->rotate_to_stop( base, velocity );
				fm = base->forwardmove( );
				lm = base->leftmove( );
			}
			else if ( speed < 30.0f )
			{
				// Too slow for air-strafing to matter: push straight at the target.
				if ( has_direction_input )
				{
					const auto rel = ( desired_yaw - cmd_yaw ) * deg2rad;
					fm = std::cosf( rel );
					lm = std::sinf( rel );
				}
			}
			else
			{
				// Optimal wish angle to velocity: speed after the step is maximised
				// when v*cos(phi) = cap - accel. phi <= 90, so every step GAINS speed
				// while turning toward the chosen side.
				const auto cos_phi = std::clamp( ( air_cap - accel_step ) / speed, -1.0f, 1.0f );
				const auto phi = std::acosf( cos_phi );
				const auto step_turn = std::atan2f( accel_step * std::sinf( phi ), speed + accel_step * cos_phi ) * rad2deg;

				const auto vel_yaw = std::atan2f( velocity.y, velocity.x ) * rad2deg;
				auto delta = desired_yaw - vel_yaw;
				math::helpers::normalize_angle( delta );

				float side{};
				if ( std::fabsf( delta ) <= step_turn * 1.5f )
				{
					// On course: alternate sides so we gain speed without drifting.
					side = this->m_side_switch ? 1.0f : -1.0f;
					this->m_side_switch = !this->m_side_switch;
				}
				else
				{
					side = delta > 0.0f ? 1.0f : -1.0f; // positive yaw = turn left
				}

				const auto wish_yaw = vel_yaw + side * phi * rad2deg;
				const auto rel = ( wish_yaw - cmd_yaw ) * deg2rad;
				fm = std::cosf( rel );
				lm = std::sinf( rel ); // leftmove + = left
			}

			fm = std::clamp( fm, -1.0f, 1.0f );
			lm = std::clamp( lm, -1.0f, 1.0f );
			base->set_forwardmove( fm );
			base->set_leftmove( lm );

			// Advance the simulated velocity with the same air-accel model as
			// before, so the next subtick steers from where we'll actually be.
			{
				math::vector3 f{}, l{};
				math::helpers::angle_vectors_2d( cmd_yaw, f, l ); // l is the LEFT vector
				auto wx = f.x * fm + l.x * lm;
				auto wy = f.y * fm + l.y * lm;
				const auto wlen = std::sqrtf( wx * wx + wy * wy );
				if ( wlen > 0.0001f )
				{
					wx /= wlen;
					wy /= wlen;
					const auto wish_speed = std::fminf( wlen * effective_maxspeed, effective_maxspeed );
					const auto capped = std::fminf( wish_speed, air_cap );
					const auto add = capped - ( velocity.x * wx + velocity.y * wy );
					if ( add > 0.0f )
					{
						const auto gain = std::fminf( accel_step, add );
						velocity.x += wx * gain;
						velocity.y += wy * gain;
					}
				}
			}

			const auto step = systems::g_input.acquire_subtick_step( subtick_moves );
			if ( !step )
			{
				continue;
			}

			step->set_button( 0 );
			step->set_pressed( false );
			step->set_when( static_cast< float >( i ) / static_cast< float >( subtick_count ) );
			step->set_analog_forward_delta( fm - last_impulses.x );
			step->set_analog_left_delta( lm - last_impulses.y );

			last_impulses.x = fm;
			last_impulses.y = lm;
		}
	}

	void airstrafe::store_angles( )
	{
		this->m_angles = systems::g_input.get_view_angles( );
	}

	void airstrafe::store_buttons( systems::input::usercmd* cmd )
	{
		this->m_real_buttons = cmd->buttons.value;
		this->m_real_move = {};
		if ( const auto base = cmd->csgo_user_cmd.mutable_base( ) )
		{
			this->m_real_move = { base->forwardmove( ), base->leftmove( ) };
		}
	}

	void airstrafe::check_button( std::uintptr_t current_buttons, std::uintptr_t button )
	{
		constexpr auto moveleft = static_cast< std::uintptr_t >( cstypes::command_buttons::in_moveleft );
		constexpr auto moveright = static_cast< std::uintptr_t >( cstypes::command_buttons::in_moveright );
		constexpr auto forward = static_cast< std::uintptr_t >( cstypes::command_buttons::in_forward );
		constexpr auto back = static_cast< std::uintptr_t >( cstypes::command_buttons::in_back );

		if ( current_buttons & button && ( !( this->m_last_buttons & button ) || ( button & moveleft && !( this->m_last_pressed & moveright ) ) || ( button & moveright && !( this->m_last_pressed & moveleft ) ) || ( button & forward && !( this->m_last_pressed & back ) ) || ( button & back && !( this->m_last_pressed & forward ) ) ) )
		{
			if ( button & moveleft )
			{
				this->m_last_pressed &= ~moveright;
			}
			else if ( button & moveright )
			{
				this->m_last_pressed &= ~moveleft;
			}
			else if ( button & forward )
			{
				this->m_last_pressed &= ~back;
			}
			else if ( button & back )
			{
				this->m_last_pressed &= ~forward;
			}

			this->m_last_pressed |= button;
		}
		else if ( !( current_buttons & button ) )
		{
			this->m_last_pressed &= ~button;
		}
	}

	void airstrafe::rotate_movement( proto::base_usercmd_pb* base, float target_yaw, float view_yaw ) const
	{
		const auto forward_move = base->forwardmove( );
		const auto side_move = base->leftmove( );

		math::vector3 target_forward{}, target_right{};
		math::helpers::angle_vectors_2d( target_yaw, target_forward, target_right );

		math::vector3 view_forward{}, view_right{};
		math::helpers::angle_vectors_2d( view_yaw, view_forward, view_right );

		const auto tf = target_forward * forward_move;
		const auto tr = target_right * side_move;

		const auto corrected_forward = view_forward.dot( tf ) + view_forward.dot( tr );
		const auto corrected_side = view_right.dot( tf ) + view_right.dot( tr );

		base->set_forwardmove( std::clamp( -corrected_forward, -1.0f, 1.0f ) );
		base->set_leftmove( std::clamp( -corrected_side, -1.0f, 1.0f ) );
	}

	void airstrafe::rotate_to_stop( proto::base_usercmd_pb* base, const math::vector3& velocity ) const
	{
		const auto speed = velocity.length_2d( );
		const auto wish_yaw = std::atan2f( velocity.y, velocity.x ) * ( 180.0f / std::numbers::pi_v<float> ) + 180.0f;

		{
			const auto& ctx = features::combat::g_shared.ctx( );
			const auto max_speed = ( ctx.valid && ctx.weapon_vdata ) ? memory::read<float>( ctx.weapon_vdata + SCHEMA( "CCSWeaponBaseVData", "m_flMaxSpeed"_hash ) ) : 250.0f;

			base->set_forwardmove( std::clamp( speed / max_speed, 0.0f, 1.0f ) );
			base->set_leftmove( 0.0f );
		}

		const auto rotation = ( base->viewangles( )->y( ) - wish_yaw ) * ( std::numbers::pi_v<float> / 180.0f );
		const auto fwd = base->forwardmove( );
		const auto side = base->leftmove( );

		base->set_forwardmove( std::clamp( std::cosf( rotation ) * fwd - std::sinf( rotation ) * side, -1.0f, 1.0f ) );
		base->set_leftmove( std::clamp( ( std::sinf( rotation ) * fwd + std::cosf( rotation ) * side ) * -1.0f, -1.0f, 1.0f ) );
	}

} // namespace features::movement
