#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <core/systems/systems.hpp>
#include <core/features/features.hpp>
#include <core/settings.hpp>

#include "../movement.hpp"
#include <protection/game_addresses.hpp>

namespace features::movement {

	namespace {

		[[nodiscard]] std::optional<float> predict_landing_fraction(
			std::uintptr_t local_pawn,
			std::uintptr_t movement_services,
			const systems::prediction::state& prestate,
			bool holding_duck )
		{
			if ( prestate.networked_velocity.z > 0.0f )
			{
				return std::nullopt;
			}

			const auto duck_amount = memory::read<float>( movement_services + SCHEMA( "CCSPlayer_MovementServices", "m_flDuckAmount"_hash ) );
			const auto mins = memory::read<math::vector3>( local_pawn + SCHEMA( "C_BaseModelEntity", "m_Collision"_hash ) + SCHEMA( "CCollisionProperty", "m_vecMins"_hash ) );
			auto maxs = memory::read<math::vector3>( local_pawn + SCHEMA( "C_BaseModelEntity", "m_Collision"_hash ) + SCHEMA( "CCollisionProperty", "m_vecMaxs"_hash ) );

			auto trace_origin = prestate.networked_origin;
			if ( holding_duck && duck_amount > 0.0f )
			{
				const auto standing_height{ 72.0f };
				const auto duck_hull_diff = standing_height - maxs.z;
				trace_origin.z -= duck_hull_diff * 0.5f;
				maxs.z = standing_height;
			}

			const auto filter = systems::g_tracing.make_player_movement_filter( local_pawn );
			const auto sv_gravity = CONVAR ("sv_gravity")->get<float>( );
			const auto sv_standable_normal = CONVAR ("sv_standable_normal")->get<float>( );
			const auto gravity_scale = memory::read<float>( local_pawn + SCHEMA( "C_BaseEntity", "m_flGravityScale"_hash ) );

			auto velocity = prestate.networked_velocity;
			velocity.z -= ( gravity_scale * sv_gravity * cstypes::tick_interval ) * 0.5f;

			const math::vector3 trace_start = trace_origin;
			math::vector3 trace_end{};

			trace_end.x = trace_origin.x + velocity.x * cstypes::tick_interval;
			trace_end.y = trace_origin.y + velocity.y * cstypes::tick_interval;
			trace_end.z = trace_origin.z + velocity.z * cstypes::tick_interval;
			trace_end.z -= 2.0f;

			const auto result = systems::g_tracing.trace_player_bbox( trace_start, trace_end, { mins, maxs }, filter, movement_services );
			if ( result.fraction <= 0.0f || result.fraction >= 1.0f || result.normal.z < sv_standable_normal )
			{
				return std::nullopt;
			}

			return std::clamp( std::round( result.fraction * 64.0f ) / 64.0f, 1.0f / 64.0f, 63.0f / 64.0f );
		}

		void apply_landing_jump( proto::base_usercmd_pb* base, float when )
		{
			const auto subtick_moves = base->mutable_subtick_moves( );
			const auto release_when = std::clamp( when - 1.0f / 64.0f, 1.0f / 64.0f, 63.0f / 64.0f );

			if ( release_when < when )
			{
				if ( const auto jump_up = systems::g_input.acquire_subtick_step( subtick_moves ) )
				{
					jump_up->set_button( cstypes::command_buttons::in_jump );
					jump_up->set_pressed( false );
					jump_up->set_when( release_when );
					jump_up->set_analog_forward_delta( 0.0f );
					jump_up->set_analog_left_delta( 0.0f );
				}
			}

			if ( const auto jump_down = systems::g_input.acquire_subtick_step( subtick_moves ) )
			{
				jump_down->set_button( cstypes::command_buttons::in_jump );
				jump_down->set_pressed( true );
				jump_down->set_when( when );
				jump_down->set_analog_forward_delta( 0.0f );
				jump_down->set_analog_left_delta( 0.0f );
			}
		}

	} // namespace

	void bhop::on_create_move( systems::input::usercmd* cmd )
	{
		this->m_landing_jump_this_tick = false;
		this->m_landing_fraction = 1.0f;

		if ( !settings::g_movement.bhop.value )
		{
			return;
		}

		if (CONVAR ("sv_autobunnyhopping")->get<bool>( ) )
		{
			return;
		}

		if ( !( cmd->buttons.value & cstypes::command_buttons::in_jump ) )
		{
			return;
		}

		if ( features::movement::g_jumpbug.active_this_tick( ) )
		{
			return;
		}

		const auto local = systems::g_local.get( );
		if ( !local.pawn )
		{
			return;
		}

		const auto move_type = memory::read<std::uint8_t>( local.pawn + SCHEMA( "C_BaseEntity", "m_nActualMoveType"_hash ) );
		if ( move_type == cstypes::move_type::ladder || move_type == cstypes::move_type::noclip )
		{
			return;
		}

		const auto& prestate = systems::g_prediction.pre( );
		if ( prestate.flags & cstypes::entity_flags::on_ground )
		{
			return;
		}

		// Crouch bhop: auto-hold duck while airborne during bhop so
		// the player stays crouched mid-air for maximum speed.
		// Legit bhop: randomly miss jumps to appear human-like.
		// ~15% miss chance per tick makes perfect chains rare.
		if ( settings::g_movement.legit_bhop.value )
		{
			// Simple PRNG — xorshift on a static seed, no <random> needed.
			static std::uint32_t s_rng_state{ 0xDEADBEEFu };
			s_rng_state ^= s_rng_state << 13;
			s_rng_state ^= s_rng_state >> 17;
			s_rng_state ^= s_rng_state << 5;
			if ( ( s_rng_state % 100u ) < 15u )
			{
				// Intentionally miss this jump — strip in_jump and bail.
				cmd->buttons.value &= ~cstypes::command_buttons::in_jump;
				return;
			}
		}

		cmd->buttons.value &= ~cstypes::command_buttons::in_jump;

		const auto movement_services = memory::read<std::uintptr_t>( local.pawn + SCHEMA( "C_BasePlayerPawn", "m_pMovementServices"_hash ) );
		if ( !movement_services )
		{
			return;
		}

		// Holding space+crouch by hand bhops normally: the landing trace uses the
		// pawn's real hull (no hull adjustment).
		const auto landing = predict_landing_fraction( local.pawn, movement_services, prestate, false );
		if ( !landing )
		{
			return;
		}

		const auto base = cmd->csgo_user_cmd.mutable_base( );
		if ( !base )
		{
			return;
		}

		// Legit bhop: skip subtick prediction and use a regular jump
		// command instead.  This produces a more human-like, imperfect
		// bhop because it doesn't nail the exact subtick landing.
		if ( settings::g_movement.legit_bhop.value )
		{
			cmd->buttons.value |= cstypes::command_buttons::in_jump;
			this->m_landing_jump_this_tick = true;
			this->m_landing_fraction = *landing;
			return;
		}

		apply_landing_jump( base, *landing );
		this->m_landing_jump_this_tick = true;
		this->m_landing_fraction = *landing;
	}

} // namespace features::movement
