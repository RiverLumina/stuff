#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <core/systems/systems.hpp>
#include <core/settings.hpp>
#include <core/features/features.hpp>
#include <protection/game_addresses.hpp>

namespace features::movement {

	void slowwalk::on_create_move( systems::input::usercmd* cmd ) const
	{
		if ( !settings::g_movement.slowwalk.value )
		{
			return;
		}

		const auto local = systems::g_local.get( );
		if ( !local.pawn )
		{
			return;
		}

		const auto& prestate = systems::g_prediction.pre( );
		if ( !( prestate.flags & cstypes::entity_flags::on_ground ) )
		{
			return;
		}

		const auto base = cmd->csgo_user_cmd.mutable_base( );
		const auto forward_move = base->forwardmove( );
		const auto side_move = base->leftmove( );

		if ( forward_move == 0.0f && side_move == 0.0f )
		{
			return;
		}

		const auto target_ratio = settings::g_movement.slowwalk_speed / 100.0f;
		const auto move_length = std::sqrtf( forward_move * forward_move + side_move * side_move );

		if ( move_length < 0.001f )
		{
			return;
		}

		const auto scaled = std::fminf( move_length, target_ratio );

		base->set_forwardmove( ( forward_move / move_length ) * scaled );
		base->set_leftmove( ( side_move / move_length ) * scaled );
	}

	void quickstop::on_create_move( systems::input::usercmd* cmd ) const
	{
		if ( !settings::g_movement.quickstop.value )
		{
			return;
		}

		const auto local = systems::g_local.get( );
		if ( !local.pawn || !local.is_alive )
		{
			return;
		}

		const auto& prestate = systems::g_prediction.pre( );
		if ( !( prestate.flags & cstypes::entity_flags::on_ground ) )
		{
			return;
		}

		// Leave jumps (bhop), ladders and noclip alone.
		if ( cmd->buttons.value & cstypes::command_buttons::in_jump )
		{
			return;
		}
		const auto move_type = memory::read<std::uint8_t>( local.pawn + SCHEMA( "CBaseEntity", "m_nActualMoveType"_hash ) );
		if ( move_type == cstypes::move_type::ladder || move_type == cstypes::move_type::noclip )
		{
			return;
		}

		const auto base = cmd->csgo_user_cmd.mutable_base( );
		if ( !base )
		{
			return;
		}

		// Only when no movement key is held (checked on the buttons, like your
		// snippet, not on forward/left which other features may have touched).
		constexpr auto movement_buttons = cstypes::command_buttons::in_forward | cstypes::command_buttons::in_back |
			cstypes::command_buttons::in_moveleft | cstypes::command_buttons::in_moveright;
		if ( cmd->buttons.value & movement_buttons )
		{
			return;
		}

		const auto& vel = prestate.networked_velocity;
		const auto speed = std::sqrtf( vel.x * vel.x + vel.y * vel.y );
		if ( speed < 10.0f )
		{
			return;
		}

		const auto movement_services = memory::read<std::uintptr_t>( local.pawn + SCHEMA( "C_BasePlayerPawn", "m_pMovementServices"_hash ) );
		const auto max_speed = movement_services
			? memory::read<float>( movement_services + SCHEMA( "CPlayer_MovementServices", "m_flMaxspeed"_hash ) )
			: 250.0f;

		// Push straight against the velocity. Scale the push down near the end
		// so one tick of ground accel can't overshoot into moving backwards.
		const auto accel_per_tick = CONVAR ("sv_accelerate")->get<float>( ) * std::fmaxf( max_speed, 1.0f ) * cstypes::tick_interval * prestate.surface_friction;
		const auto magnitude = accel_per_tick > 0.001f ? std::clamp( speed / accel_per_tick, 0.0f, 1.0f ) : 1.0f;

		constexpr auto rad2deg{ 180.0f / std::numbers::pi_v<float> };
		constexpr auto deg2rad{ std::numbers::pi_v<float> / 180.0f };
		const auto against_yaw = std::atan2f( vel.y, vel.x ) * rad2deg + 180.0f;
		// Movement is relative to the cmd's viewangles (anti-aim safe).
		const auto rel = ( against_yaw - base->viewangles( )->y( ) ) * deg2rad;
		const auto fm = std::clamp( std::cosf( rel ) * magnitude, -1.0f, 1.0f );
		const auto lm = std::clamp( std::sinf( rel ) * magnitude, -1.0f, 1.0f );

		base->set_forwardmove( fm );
		base->set_leftmove( lm );

		// CS2 moves you from the subtick analog impulses, not the base fields;
		// that's why the first version did nothing. Write a step at the start
		// of the tick that sets the impulse to our counter-strafe.
		if ( const auto subtick_moves = base->mutable_subtick_moves( ) )
		{
			if ( const auto step = systems::g_input.acquire_subtick_step( subtick_moves ) )
			{
				step->set_button( 0 );
				step->set_pressed( false );
				step->set_when( 0.0f );
				step->set_analog_forward_delta( fm - prestate.last_movement_impulses.x );
				step->set_analog_left_delta( lm - prestate.last_movement_impulses.y );
			}
		}
	}

} // namespace features::movement
