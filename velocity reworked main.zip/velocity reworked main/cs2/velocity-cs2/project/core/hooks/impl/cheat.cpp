#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/addresses/addresses.hpp>
#include <utilities/diag.hpp>
#include <utilities/hooking/hooking.hpp>
#include <utilities/logging/logging.hpp>
#include <utilities/security/security.hpp>
#include <core/rendering/rendering.hpp>
#include <core/rendering/motion_blur.hpp>
#include <core/systems/systems.hpp>
#include <core/features/features.hpp>
#include <protection/game_addresses.hpp>
#include "../hooks.hpp"

namespace hooks {

	namespace {

		// Scan client.dll's executable sections for a byte signature ("??" =
		// wildcard). Returns the address only if it matches EXACTLY once: a
		// short prologue signature that hits several functions would hook the
		// wrong one and crash, so ambiguity means "don't hook".
		std::uintptr_t find_unique_code( std::uintptr_t module, std::string_view sig, int& matches )
		{
			matches = 0;
			if ( !module )
			{
				return 0;
			}

			std::vector<int> pat{};
			for ( std::size_t i = 0; i < sig.size( ); )
			{
				if ( sig[ i ] == ' ' ) { ++i; continue; }
				if ( sig[ i ] == '?' )
				{
					pat.push_back( -1 );
					i += ( i + 1 < sig.size( ) && sig[ i + 1 ] == '?' ) ? 2 : 1;
					continue;
				}
				pat.push_back( std::stoi( std::string{ sig.substr( i, 2 ) }, nullptr, 16 ) );
				i += 2;
			}
			if ( pat.empty( ) )
			{
				return 0;
			}

			const auto dos = reinterpret_cast<const IMAGE_DOS_HEADER*>( module );
			const auto nt = reinterpret_cast<const IMAGE_NT_HEADERS64*>( module + dos->e_lfanew );
			auto section = IMAGE_FIRST_SECTION( nt );
			std::uintptr_t found{ 0 };
			for ( WORD s = 0; s < nt->FileHeader.NumberOfSections; ++s, ++section )
			{
				if ( !( section->Characteristics & IMAGE_SCN_MEM_EXECUTE ) )
				{
					continue;
				}
				const auto begin = reinterpret_cast<const std::uint8_t*>( module + section->VirtualAddress );
				const auto size = static_cast<std::size_t>( section->Misc.VirtualSize );
				if ( size < pat.size( ) )
				{
					continue;
				}
				for ( std::size_t i = 0; i + pat.size( ) <= size; ++i )
				{
					bool ok{ true };
					for ( std::size_t j = 0; j < pat.size( ); ++j )
					{
						if ( pat[ j ] >= 0 && begin[ i + j ] != static_cast<std::uint8_t>( pat[ j ] ) )
						{
							ok = false;
							break;
						}
					}
					if ( ok )
					{
						++matches;
						found = reinterpret_cast<std::uintptr_t>( begin + i );
						if ( matches > 1 )
						{
							return 0;
						}
					}
				}
			}
			return matches == 1 ? found : 0;
		}

	} // namespace

	bool cheat::initialize () {
		if (!hooking::manager::create ({
			{ &m_present, &present, xs ("present"), addresses::functions::present },
			{ &m_resize_buffers, &resize_buffers, xs ("resize_buffers"), addresses::functions::resize_buffers }
			})) {
			return false;
		}

		const hooking::manager::entry feature_hooks[] {
			{ &m_cmd_interpreter, &cmd_interpreter, xs ("cmd_interpreter"), PATTERN (patterns::cmd_interpreter) },
			{ &m_frame_stage_notify, &frame_stage_notify, xs ("frame_stage_notify"), PATTERN (patterns::frame_stage_notify) },
			{ &m_create_move, &create_move, xs ("create_move"), PATTERN (patterns::create_move) },
			{ &m_handle_view_angles, &handle_view_angles, xs ("handle_view_angles"), PATTERN (patterns::handle_view_angles) },
			{ &m_add_entity, &add_entity, xs ("add_entity"), PATTERN (patterns::add_entity) },
			{ &m_remove_entity, &remove_entity, xs ("remove_entity"), PATTERN (patterns::remove_entity) },
			{ &m_render_view, &render_view, xs ("render_view"), PATTERN (patterns::render_view) },
			{ &m_draw_skybox_array, &draw_skybox_array, xs ("draw_skybox_array"), PATTERN (patterns::draw_skybox_array) },
			{ &m_light_scene_object, &light_scene_object, xs ("light_scene_object"), PATTERN (patterns::light_scene_object) },
			{ &m_draw_scene_object_array, &draw_scene_object_array, xs ("draw_scene_object_array"), PATTERN (patterns::draw_scene_object_array) },
			{ &m_draw_scene_object, &draw_scene_object, xs ("draw_scene_object"), PATTERN (patterns::draw_scene_object) },
			{ &m_is_glowing, &is_glowing, xs ("is_glowing"), PATTERN (patterns::is_glowing) },
			{ &m_get_glow_color, &get_glow_color, xs ("get_glow_color"), PATTERN (patterns::get_glow_color) },
			{ &m_generate_primitives, &generate_primitives, xs ("generate_primitives"), PATTERN (patterns::generate_primitives) },
			// get_resource_view: signature in patterns.cpp is outdated (not found on
			// the 2026-09 build). The ESP preview now captures its texture via the
			// OMSetRenderTargets hook instead (see model_preview::on_set_render_targets).
			// Re-enable once the pattern is refreshed.
			// { &m_get_resource_view, &get_resource_view, xs ("get_resource_view"), PATTERN (patterns::get_resource_view) },
			{ &m_parse_report_hit, &parse_report_hit, xs ("parse_report_hit"), PATTERN (patterns::parse_report_hit) },
			{ &m_setup_fog, &setup_fog, xs ("setup_fog"), PATTERN (patterns::setup_fog) },
			{ &m_set_shader_param, &set_shader_param, xs ("set_shader_param"), PATTERN (patterns::set_shader_param) },
			{ &m_set_postprocess_vec, &set_postprocess_vec, xs ("set_postprocess_vec"), PATTERN (patterns::set_postprocess_vec) },
			{ &m_override_view, &override_view, xs ("override_view"), PATTERN (patterns::override_view) },
			{ &m_update_fov_sensitivity, &update_fov_sensitivity, xs ("update_fov_sensitivity"), PATTERN (patterns::update_fov_sensitivity) },
			{ &m_render_scope, &render_scope, xs ("render_scope"), PATTERN (patterns::render_scope) },
			{ &m_render_crosshair, &render_crosshair, xs ("render_crosshair"), PATTERN (patterns::render_crosshair) },
			{ &m_prepare_scene_material, &prepare_scene_material, xs ("prepare_scene_material"), PATTERN (patterns::prepare_scene_material) },
			{ &m_post_network_data_received, &post_network_data_received, xs ("post_network_data_received"), PATTERN (patterns::post_network_data_received) },
			{ &m_draw_overhead, &draw_overhead, xs ("draw_overhead"), PATTERN (patterns::draw_overhead) },
			{ &m_draw_legs, &draw_legs, xs ("draw_legs"), PATTERN (patterns::draw_legs) },
			{ &m_get_transforms_for_hitbox_list, &get_transforms_for_hitbox_list, xs ("get_transforms_for_hitbox_list"), PATTERN (patterns::get_transforms_for_hitbox_list) },
			{ &m_sort_primitives, &sort_primitives, xs ("sort_primitives"), PATTERN (patterns::sort_primitives) },
			{ &m_get_interpolated_shoot_position, &get_interpolated_shoot_position, xs ("get_interpolated_shoot_position"), PATTERN (patterns::get_interpolated_shoot_position) },
			{ &m_level_initialization, &level_initialization, xs ("level_initialization"), PATTERN (patterns::level_initialization) },
			{ &m_level_shutdown, &level_shutdown, xs ("level_shutdown"), PATTERN (patterns::level_shutdown) },
			{ &m_read_frame_input, &read_frame_input, xs ("read_frame_input"), PATTERN (patterns::read_frame_input) },
			{ &m_process_input_event, &process_input_event, xs ("process_input_event"), PATTERN (patterns::process_input_event) },
			{ &m_prediction_effects_suppressed, &prediction_effects_suppressed, xs ("prediction_effects_suppressed"), PATTERN (patterns::prediction_effects_suppressed) },
			{ &m_render_decals, &render_decals, xs ("render_decals"), PATTERN (patterns::render_decals) },
			{ &m_render_smoke, &render_smoke, xs ("render_smoke"), PATTERN (patterns::render_smoke) },
			{ &m_draw_flash_effect, &draw_flash_effect, xs ("draw_flash_effect"), PATTERN (patterns::draw_flash_effect) },
			{ &m_set_info, &set_info, xs ("set_info"), PATTERN (patterns::set_info) }
		};

		auto unavailable_hooks = 0u;
		for (const auto& entry : feature_hooks) {
			if (!hooking::manager::create ({ entry })) {
				++unavailable_hooks;
				logging::console::print (xs ("skipping unavailable hook: {}"), entry.name);
			}
		}

		// CalcViewModel (cspatterns.dev CALCVIEWMODEL_PATTERN). Viewmodel offsets
		// past the game's clamp + rotation. Only hooked if the signature is unique.
		{
			int matches{ 0 };
			const auto addr = find_unique_code( addresses::modules::client, "40 55 53 56 41 56 41 57 48 8B EC", matches );
			if ( addr && hooking::manager::create( { { &m_calc_viewmodel, &calc_viewmodel, xs ("calc_viewmodel"), addr } } ) )
			{
				features::misc::camera::s_calc_viewmodel_hooked.store( true, std::memory_order_relaxed );
				logging::console::print( xs ("calc_viewmodel hooked") );
			}
			else
			{
				logging::console::print( xs ("calc_viewmodel not hooked: signature matched {} time(s) (need exactly 1)"), matches );
			}
		}

		// UpdateAndSetupView(C_CSPlayerPawn*, float* pos, float* ang, u8 flag).
		// PASTE THE IDA-STYLE SIGNATURE HERE (must match exactly once in client.dll).
		// While empty, rotation falls back to the scene-node method at stage 12.
		{
			constexpr const char* k_update_and_setup_view_sig{ "48 8B C4 44 88 48 20 48 89 50 10 55" };
			if ( k_update_and_setup_view_sig[ 0 ] != '\0' )
			{
				int matches{ 0 };
				const auto addr = find_unique_code( addresses::modules::client, k_update_and_setup_view_sig, matches );
				if ( addr && hooking::manager::create( { { &m_update_and_setup_view, &update_and_setup_view, xs ("update_and_setup_view"), addr } } ) )
				{
					features::misc::camera::s_update_view_hooked.store( true, std::memory_order_relaxed );
					logging::console::print( xs ("update_and_setup_view hooked") );
				}
				else
				{
					logging::console::print( xs ("update_and_setup_view not hooked: signature matched {} time(s) (need exactly 1)"), matches );
				}
			}
			else
			{
				logging::console::print( xs ("update_and_setup_view: no signature set, using scene-node rotation") );
			}
		}

		if (unavailable_hooks) {
			logging::console::print (
				xs ("feature hooks initialized with {} unavailable"),
				unavailable_hooks);
		}

		return true;
	}

	void cheat::shutdown( )
	{
		rendering::g_motion_blur.cleanup( );
		m_wnd_proc.reset( );
		m_om_set_render_targets.reset( );
		m_present.reset( );
		m_resize_buffers.reset( );
		m_cmd_interpreter.reset( );
		m_frame_stage_notify.reset( );
		m_create_move.reset( );
		m_handle_view_angles.reset( );
		m_add_entity.reset( );
		m_remove_entity.reset( );
		m_render_view.reset( );
		m_draw_skybox_array.reset( );
		m_light_scene_object.reset( );
		m_draw_scene_object_array.reset( );
		m_draw_scene_object.reset( );
		m_is_glowing.reset( );
		m_get_glow_color.reset( );
		m_generate_primitives.reset( );
		m_get_resource_view.reset( );
		m_parse_report_hit.reset( );
		m_setup_fog.reset( );
		m_set_shader_param.reset( );
		m_set_postprocess_vec.reset( );
		m_override_view.reset( );
		m_update_fov_sensitivity.reset( );
		m_render_scope.reset( );
		m_calc_viewmodel.reset( );
		features::misc::camera::s_calc_viewmodel_hooked.store( false, std::memory_order_relaxed );
		m_update_and_setup_view.reset( );
		features::misc::camera::s_update_view_hooked.store( false, std::memory_order_relaxed );
		m_render_crosshair.reset( );
		m_prepare_scene_material.reset( );
		m_post_network_data_received.reset( );
		m_draw_overhead.reset( );
		m_draw_legs.reset( );
		m_get_transforms_for_hitbox_list.reset( );
		m_sort_primitives.reset( );
		m_get_inaccuracy.reset( );
		m_get_interpolated_shoot_position.reset( );
		m_level_initialization.reset( );
		m_read_frame_input.reset( );
		m_process_input_event.reset( );
		m_prediction_effects_suppressed.reset( );
		m_render_decals.reset( );
		m_render_smoke.reset( );
		m_render_smoke_map.reset( );
		m_render_smoke_unmap.reset( );
		m_draw_flash_effect.reset( );
		m_set_info.reset( );
	}

	HRESULT __fastcall cheat::present( IDXGISwapChain* thisptr, UINT sync_interval, UINT flags )
	{
		// Motion blur runs on the finished game frame, before our overlay/menu is
		// drawn on top so those stay sharp.
		{
			const auto& blur = settings::g_misc.m_motion_blur;
			if ( blur.enabled.value )
			{
				rendering::g_motion_blur.apply( thisptr, std::clamp( blur.strength.value / 100.0f, 0.0f, 0.95f ) );
			}
			else if ( rendering::g_motion_blur.is_initialized( ) )
			{
				rendering::g_motion_blur.cleanup( );
			}
		}

		rendering::g_context.on_present( thisptr );

		if ( !m_wnd_proc.is_enabled( ) && rendering::g_context.get_window( ) )
		{
			if ( m_wnd_proc.create( reinterpret_cast< void* >( GetWindowLongPtrW( rendering::g_context.get_window( ), GWLP_WNDPROC ) ), &wnd_proc ) )
			{
				m_wnd_proc.enable( );
			}
		}

		if ( !m_om_set_render_targets.is_enabled( ) && rendering::g_context.is_initialized( ) )
		{
			const auto om_addr = memory::get_vfunc( reinterpret_cast< std::uintptr_t >( rendering::g_context.get_context( ) ), 33 );
			if ( m_om_set_render_targets.create( reinterpret_cast< void* >( om_addr ), &om_set_render_targets ) )
			{
				m_om_set_render_targets.enable( );
			}
		}

		return m_present.call<HRESULT>( thisptr, sync_interval, flags );
	}

	HRESULT __fastcall cheat::resize_buffers( IDXGISwapChain* thisptr, UINT buffer_count, UINT width, UINT height, DXGI_FORMAT new_format, UINT swap_chain_flags )
	{
		rendering::g_motion_blur.cleanup( );
		rendering::g_context.on_resize_buffers( );

		const auto result = m_resize_buffers.call<long>( thisptr, buffer_count, width, height, new_format, swap_chain_flags );
		if ( SUCCEEDED( result ) )
		{
			rendering::g_context.on_resize_buffers_post( thisptr );
		}

		return result;
	}

	LRESULT __stdcall cheat::wnd_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
	{
		if ( msg == WM_ACTIVATE && LOWORD( wparam ) != WA_INACTIVE && rendering::g_menu.is_open( ) && rendering::g_context.get_window( ) == hwnd )
		{
			if ( addresses::globals::input_system )
			{
				memory::call_vfunc<void>( addresses::globals::input_system, 76, false );
			}

			SetCursor( LoadCursor( nullptr, IDC_ARROW ) );
			rendering::g_menu.apply_saved_cursor( );
		}

		if ( msg == WM_KEYDOWN && !( lparam & ( 1 << 30 ) ) && static_cast< int >( wparam ) == settings::g_misc.menu_key )
		{
			rendering::g_menu.toggle( );
			return 0;
		}

		xui::wndproc( msg, wparam, lparam );

		if ( rendering::g_menu.is_open( ) )
		{
			switch ( msg )
			{
			case WM_LBUTTONDOWN: case WM_LBUTTONUP: case WM_LBUTTONDBLCLK:
			case WM_RBUTTONDOWN: case WM_RBUTTONUP: case WM_RBUTTONDBLCLK:
			case WM_MBUTTONDOWN: case WM_MBUTTONUP: case WM_MBUTTONDBLCLK:
			case WM_MOUSEWHEEL: case WM_MOUSEHWHEEL:
			case WM_MOUSEMOVE:
				return 0;
			default:
				break;
			}
		}

		return m_wnd_proc.call<LRESULT>( hwnd, msg, wparam, lparam );
	}

	void __stdcall cheat::om_set_render_targets( ID3D11DeviceContext* ctx, UINT num_views, ID3D11RenderTargetView* const* rtvs, ID3D11DepthStencilView* dsv )
	{
		m_om_set_render_targets.call<void>( ctx, num_views, rtvs, dsv );

		// ESP preview: recognise the offscreen agent render target by its shape.
		// Only while the menu is open, since that's the only time it's shown.
		if ( rendering::g_menu.is_open( ) )
		{
			systems::g_model_preview.on_set_render_targets( num_views, rtvs );
		}
	}

	void __fastcall cheat::cmd_interpreter( std::uintptr_t render_thread, std::uintptr_t item, std::uint8_t flag )
	{
		m_cmd_interpreter.call<void>( render_thread, item, flag );
	}

	void __fastcall cheat::frame_stage_notify( std::uintptr_t thisptr, int stage )
	{
		if ( systems::g_entities.is_empty( ) )
		{
			systems::g_entities.force_update( );
		}

		systems::g_local.update( );

		// Match-found popup lives in the main menu, so this runs outside the in-game gate.
		if ( stage == 7 )
		{
			features::misc::g_other.do_auto_accept( );
		}

		if ( systems::g_local.get( ).is_valid( ) && systems::g_view.has_camera( ) )
		{
			if ( stage == 6 )
			{
				features::changer::g_inventory.on_frame_stage_notify( );
			}

			if ( stage == 7 )
			{
				features::changer::g_agents.on_frame_stage_notify( );
				features::changer::g_model_changer.on_frame_stage_notify( );
				features::changer::g_gloves.on_frame_stage_notify( );
				// Guns now run at the same stage as the knife/glove changers (which
				// show their skins). At stage 6 the net update that follows rewrote
				// the fallback fields and the skin never became visible.
				features::changer::g_guns.on_frame_stage_notify( );
				features::changer::g_knives.on_frame_stage_notify( );

				features::world::g_scene.on_frame_stage_notify( );
				features::world::g_weather.on_frame_stage_notify( );
				features::misc::g_other.on_frame_stage_notify( );
				features::misc::g_impacts.on_frame_stage_notify( );
				features::misc::g_removals.on_frame_stage_notify( );

				systems::g_model_preview.update_preview_panel( );
			}
		}

		{
			static auto was_active{ false };
			const auto is_active = settings::g_misc.m_removals.skybox_3d.value;

			if ( is_active != was_active )
			{
				CONVAR ("r_draw3dskybox")->m_value.i1 = is_active;
				was_active = is_active;
			}
		}

		// Source 2 copies dynamic-light entries into scene objects during this stage.
		// Publish our entry first, while keeping all manager mutations on the game thread.
		if ( stage == 6 )
		{
			features::misc::g_dlight.on_frame_stage_notify( );
		}

		m_frame_stage_notify.call<void>( thisptr, stage );

		// The current frame's world-to-projection matrix is published by the
		// engine during render-start stage 12.
		if ( stage == 12 )
		{
			systems::g_view.update_matrix( );
			systems::g_frame_data.update( );

			// Viewmodel rotation, after the engine has set the viewmodel node for
			// this frame and before the scene is drawn. The engine rebuilds the
			// node every frame, so this doesn't accumulate.
			const auto local_for_vm = systems::g_local.get( );
			if ( local_for_vm.is_alive && local_for_vm.pawn && settings::g_misc.m_viewmodel_adjust.enabled.value
				&& !features::misc::camera::s_update_view_hooked.load( std::memory_order_relaxed ) )
			{
				features::misc::camera::apply_viewmodel_rotation( local_for_vm.pawn );
			}
		}

		if (systems::g_local.get ().is_valid () && systems::g_view.has_camera ()) {
			if (stage == 6) {
				// Capture lag records only after Source 2 has committed this network update,
				// so the simulation timestamp, world origin and evaluated bones agree.
				features::combat::g_shared.lc( ).run( );
				features::esp::player::g_chams.bt( ).update( );
				features::esp::player::g_chams.os ().update ();

				features::misc::g_scoreboard_weapons.on_frame_stage_notify ();
				features::misc::g_other.do_kill_feed_preservation( );
			}
		}
	}

	void __fastcall cheat::create_move( std::uintptr_t thisptr, int slot, bool active )
	{
		const auto local = systems::g_local.get( );

		if ( !local.pawn || !local.controller )
		{
			return m_create_move.call<void>( thisptr, slot, active );
		}

		const auto cmd = systems::g_input.get_current_cmd( local.controller );
		if ( cmd && systems::g_input.is_subtick_overwrite( cmd ) )
		{
			systems::g_input.set_weapon_select( cmd, thisptr );
			return;
		}

		m_create_move.call<void>( thisptr, slot, active );

		{
			features::combat::g_shared.invalidate_if_needed( );
			features::combat::g_legit.invalidate_if_needed( );
			features::combat::g_misc.quickpeek( ).reset_if_needed( );
		}

		if ( !local.is_alive || !systems::g_view.has_camera( ) )
		{
			return;
		}

		const auto movement_services = memory::read<std::uintptr_t>( local.pawn + SCHEMA( "C_BasePlayerPawn", "m_pMovementServices"_hash ) );
		if ( !movement_services )
		{
			return;
		}

		const auto last_cmd_processed = memory::read<std::uint32_t>( movement_services + SCHEMA( "CPlayer_MovementServices", "m_nLastCommandNumberProcessed"_hash ) );
		if ( !last_cmd_processed )
		{
			return;
		}

		systems::g_input.update( );
		{
			const auto current_cmd = systems::g_input.get( );
			if ( !current_cmd || !current_cmd->csgo_user_cmd.has_base( ) )
			{
				return;
			}

			static std::atomic_bool first_create_move_traced{};
			const auto trace = !first_create_move_traced.exchange( true, std::memory_order_relaxed );
			diag::exception_scope exception_scope{ "create_move: desubtick" };
			if ( trace )
			{
				diag::step( "create_move: feature pipeline begin" );
			}

			settings::enforce_insecure_lock( );
			systems::g_input.desubtick( current_cmd );
			systems::g_prediction.capture_prestate( local.pawn, movement_services );

			{
				diag::set_exception_phase( "create_move: shared update" );
				features::movement::g_airstrafe.store_angles( );
				features::movement::g_airstrafe.store_buttons( current_cmd );
				features::combat::g_shared.update( );

				diag::set_exception_phase( "create_move: combat misc" );
				features::combat::g_misc.antiaim( ).on_create_move( current_cmd );
				features::combat::g_misc.autostop( ).on_create_move( current_cmd );
			}
			if ( trace )
			{
				diag::step( "create_move: shared and combat misc ready" );
			}

			{
				diag::set_exception_phase( "create_move: pre-combat movement" );
				features::movement::g_slowwalk.on_create_move( current_cmd );
				// Before bhop: bhop clears in_jump, and quickstop must see a held jump
				// so it never brakes a bunnyhop landing.
				features::movement::g_quickstop.on_create_move( current_cmd );
				features::movement::g_edgebug.on_create_move( current_cmd );
				features::movement::g_edgejump.on_create_move( current_cmd );
				features::movement::g_edgestop.on_create_move( current_cmd );
				features::movement::g_jumpbug.on_create_move( current_cmd );
				features::movement::g_bhop.on_create_move( current_cmd );
				features::movement::g_fastladder.on_create_move( current_cmd );
				if ( trace )
				{
					diag::step( "create_move: pre-combat movement end" );
					diag::step( "create_move: rage begin" );
				}

				{
					diag::set_exception_phase( "create_move: rage" );
					features::combat::g_rage.on_create_move( current_cmd );
					if ( trace )
					{
						diag::step( "create_move: rage end" );
						diag::step( "create_move: legit begin" );
					}
					diag::set_exception_phase( "create_move: legit" );
					features::combat::g_legit.on_create_move( current_cmd );
					if ( trace )
					{
						diag::step( "create_move: legit end" );
					}
				}

				diag::set_exception_phase( "create_move: post-combat movement" );
				features::combat::g_misc.duckpeek( ).on_create_move( current_cmd );
				features::movement::g_test_strafer.on_create_move( current_cmd );
				features::movement::g_airstrafe.on_create_move( current_cmd );
				features::misc::g_projectile_trajectory.on_create_move( current_cmd );
			}
			if ( trace )
			{
				diag::step( "create_move: post-combat movement end" );
			}

			diag::set_exception_phase( "create_move: quickpeek" );
			features::combat::g_misc.quickpeek( ).on_create_move( current_cmd );
			if ( trace )
			{
				diag::step( "create_move: quickpeek end" );
				diag::step( "create_move: final subtick begin" );
			}

			// Apply spin rotation: remap movement from backwards-space to spin-space.
			// This runs after ALL movement features are done, so bhop, airstrafe,
			// test_strafer and quickpeek all computed correct movement against the
			// stable backwards angle. Now we rotate everything to the spinning
			// viewangle and set that as the final viewangle.
			{
				auto& aa = features::combat::g_misc.antiaim( );
				if ( aa.has_pending_spin( ) )
				{
					const auto spin_yaw = aa.pending_spin_yaw( );
					aa.clear_pending_spin( );

					const auto spin_base = current_cmd->csgo_user_cmd.mutable_base( );
					if ( spin_base )
					{
						const auto current_yaw = spin_base->viewangles( )->y( );
						auto delta = spin_yaw - current_yaw;
						while ( delta > 180.0f ) delta -= 360.0f;
						while ( delta < -180.0f ) delta += 360.0f;

						const auto rad = delta * ( std::numbers::pi_v<float> / 180.0f );
						const auto c = std::cosf( rad );
						const auto s = std::sinf( rad );

						// Rotate base forwardmove/leftmove
						const auto fwd = spin_base->forwardmove( );
						const auto side = spin_base->leftmove( );
						spin_base->set_forwardmove( std::clamp( fwd * c + side * s, -1.0f, 1.0f ) );
						spin_base->set_leftmove( std::clamp( -fwd * s + side * c, -1.0f, 1.0f ) );

						// Subtick analog values are DELTAS from the previous impulse,
						// and that previous impulse (last tick's) was rotated by a
						// different spin angle. Rotating the deltas themselves
						// therefore pointed the rebuilt movement the wrong way, which
						// is why bhop/strafe lost speed with anti-aim on. Instead:
						// rebuild the absolute impulse after each step in the
						// features' space, rotate THAT, and re-derive the deltas
						// from the real previous impulse.
						{
							const auto& impulses = systems::g_prediction.pre( ).last_movement_impulses;
							const float base_f = impulses.x, base_l = impulses.y;
							float pre_f = base_f, pre_l = base_l;   // absolute, features' space
							float prev_f = base_f, prev_l = base_l; // absolute, final space
							for ( auto i = 0; i < spin_base->subtick_moves_size( ); ++i )
							{
								const auto step = spin_base->mutable_subtick_moves( i );
								if ( !step )
								{
									continue;
								}
								pre_f += step->analog_forward_delta( );
								pre_l += step->analog_left_delta( );
								const auto rot_f = std::clamp( pre_f * c + pre_l * s, -1.0f, 1.0f );
								const auto rot_l = std::clamp( -pre_f * s + pre_l * c, -1.0f, 1.0f );
								step->set_analog_forward_delta( rot_f - prev_f );
								step->set_analog_left_delta( rot_l - prev_l );
								prev_f = rot_f;
								prev_l = rot_l;
							}
						}

						// Set viewangle to spin yaw
						spin_base->mutable_viewangles( )->set_y( spin_yaw );
					}
				}
			}

			diag::set_exception_phase( "create_move: final subtick" );
			const auto final_base = current_cmd->csgo_user_cmd.mutable_base( );
			if ( final_base && final_base->subtick_moves_size( ) > 0
				&& !features::movement::g_test_strafer.handled_this_tick( ) )
			{
				final_base->set_forwardmove( 0.0f );
				final_base->set_leftmove( 0.0f );
			}
			if ( trace )
			{
				diag::step( "create_move: final subtick end" );
			}

			//systems::g_legit_input.on_create_move( current_cmd );
		}
		static std::atomic_bool first_input_apply_traced{};
		const auto trace_apply =
			!first_input_apply_traced.exchange( true, std::memory_order_relaxed );
		if ( trace_apply )
		{
			diag::step( "create_move: input apply begin" );
		}
		diag::exception_scope exception_scope{ "create_move: input apply" };
		systems::g_input.apply( );
		if ( trace_apply )
		{
			diag::step( "create_move: input apply end" );
		}
	}

	void __fastcall cheat::handle_view_angles( std::uintptr_t thisptr, int a2 )
	{
		const auto view_angles = systems::g_input.get_view_angles( );

		m_handle_view_angles.call<void>( thisptr, a2 );

		systems::g_input.set_view_angles( view_angles );
	}

	void __fastcall cheat::add_entity( std::uintptr_t thisptr, std::uintptr_t entity, std::uint32_t handle )
	{
		systems::g_entities.on_add_entity( entity, handle );

		m_add_entity.call<void>( thisptr, entity, handle );
	}

	void __fastcall cheat::remove_entity( std::uintptr_t thisptr, std::uintptr_t entity, std::uint32_t handle )
	{
		systems::g_entities.on_remove_entity( entity, handle );

		m_remove_entity.call<void>( thisptr, entity, handle );
	}

	void __fastcall cheat::render_view( std::uintptr_t thisptr )
	{
		m_render_view.call<void>( thisptr );

		systems::g_view.update( thisptr + 0x10 );
		systems::g_frame_data.update( );
	}

	void __fastcall cheat::draw_skybox_array( std::uintptr_t thisptr, std::uintptr_t a2, std::uintptr_t mesh_array, int mesh_count, int a5, std::uintptr_t a6, std::uintptr_t a7, std::uintptr_t a8 )
	{
		// Full skybox removal: skip the entire draw call so no skybox
		// geometry is rendered — gives a solid background.
		if ( settings::g_misc.m_removals.remove_skybox.value )
		{
			return;
		}

		features::world::g_scene.on_draw_skybox_array_pre( mesh_array, mesh_count );

		m_draw_skybox_array.call<void>( thisptr, a2, mesh_array, mesh_count, a5, a6, a7, a8 );

		features::world::g_scene.on_draw_skybox_array_post( );
	}

	std::uintptr_t __fastcall cheat::light_scene_object( std::uintptr_t thisptr, std::uintptr_t object, std::uintptr_t a3 )
	{
		features::world::g_scene.on_light_scene_object_pre( object );
		features::misc::g_dlight.apply_scene_color( object );

		const auto result = m_light_scene_object.call<std::uintptr_t>( thisptr, object, a3 );

		features::world::g_scene.on_light_scene_object_post( object );

		return result;
	}

	void __fastcall cheat::draw_scene_object_array( std::uintptr_t thisptr, std::uintptr_t a2, std::uintptr_t object_array )
	{
		m_draw_scene_object_array.call<void>( thisptr, a2, object_array );

		diag::exception_scope exception_scope{ "world: aggregate records" };
		features::world::g_scene.on_draw_scene_object_array( object_array );
	}

	std::uintptr_t __fastcall cheat::draw_scene_object( std::uintptr_t a1, std::uintptr_t a2, std::uintptr_t batch, int batch_count, int a5, std::uintptr_t a6, std::uintptr_t a7, std::uintptr_t a8 )
	{
		{
			diag::exception_scope exception_scope{ "world: primitive tint" };
			features::world::g_scene.on_draw_scene_object( batch, batch_count );
		}

		return m_draw_scene_object.call<std::uintptr_t>( a1, a2, batch, batch_count, a5, a6, a7, a8 );
	}

	bool __fastcall cheat::is_glowing( std::uintptr_t glow_property )
	{
		if ( glow_property )
		{
			const auto owner_entity = memory::read<std::uintptr_t>( glow_property + 0x18 );
			if ( owner_entity )
			{
				const auto schema_name = systems::g_entities.get_schema_name( owner_entity );
				if ( schema_name )
				{
					const auto owner_hash = fnv1a::runtime_hash( schema_name );
					if ( owner_hash )
					{
						if ( features::esp::player::g_glow.on_is_glowing( owner_entity, owner_hash ) )
						{
							return true;
						}

						if ( features::esp::item::g_glow.on_is_glowing( owner_entity, owner_hash ) )
						{
							return true;
						}
					}
				}
			}
		}

		return m_is_glowing.call<bool>( glow_property );
	}

	void __fastcall cheat::get_glow_color( std::uintptr_t glow_property, float* color )
	{
		if ( glow_property )
		{
			const auto owner_entity = memory::read<std::uintptr_t>( glow_property + 0x18 );
			if ( owner_entity )
			{
				const auto schema_name = systems::g_entities.get_schema_name( owner_entity );
				if ( schema_name )
				{
					const auto owner_hash = fnv1a::runtime_hash( schema_name );
					if ( owner_hash )
					{
						if ( features::esp::player::g_glow.on_get_glow_color( owner_entity, owner_hash, color ) )
						{
							return;
						}

						if ( features::esp::item::g_glow.on_get_glow_color( owner_entity, owner_hash, color ) )
						{
							return;
						}
					}
				}
			}
		}

		m_get_glow_color.call<void>( glow_property, color );
	}

	void __fastcall cheat::generate_primitives( std::uintptr_t thisptr, std::uintptr_t scene_object, std::uintptr_t scene_view, std::uintptr_t primitive_buffer )
	{
		diag::exception_scope exception_scope{ "chams: generate primitives" };

		if ( scene_object )
		{
			if ( features::esp::player::g_chams.bt( ).is_active( scene_object ) )
			{
				return;
			}

			if ( features::esp::player::g_chams.os( ).is_active( scene_object ) ) 
			{
				return;
			}

			const auto owner_handle = memory::read<std::uint32_t>( scene_object + 0xc0 );
			if ( owner_handle )
			{
				const auto owner_entity = systems::g_entities.lookup( owner_handle );
				if ( owner_entity )
				{
					const auto schema_name = systems::g_entities.get_schema_name( owner_entity );
					if ( schema_name )
					{
						const auto owner_hash = fnv1a::runtime_hash( schema_name );
						if ( owner_hash )
						{
							if ( features::esp::player::g_chams.on_generate_primitives( owner_entity, owner_hash, scene_object, primitive_buffer, m_generate_primitives.original<void( __fastcall* )( std::uintptr_t, std::uintptr_t, std::uintptr_t, std::uintptr_t )>( ), thisptr, scene_view ) )
							{
								return;
							}

							if ( features::esp::item::g_chams.on_generate_primitives( owner_entity, owner_hash, scene_object, primitive_buffer, m_generate_primitives.original<void( __fastcall* )( std::uintptr_t, std::uintptr_t, std::uintptr_t, std::uintptr_t )>( ), thisptr, scene_view ) )
							{
								return;
							}

							systems::g_model_preview.on_generate_primitives(
								owner_entity,
								owner_hash,
								scene_object,
								primitive_buffer,
								m_generate_primitives.original<void( __fastcall* )( std::uintptr_t, std::uintptr_t, std::uintptr_t, std::uintptr_t )>( ),
								thisptr,
								scene_view
							);
						}
					}
				}
			}
		}

		m_generate_primitives.call<void>( thisptr, scene_object, scene_view, primitive_buffer );
	}

	ID3D11ShaderResourceView* __fastcall cheat::get_resource_view( void* thisptr, int** texture, char a3, char a4, const char* a5 )
	{
		auto* srv = m_get_resource_view.original<ID3D11ShaderResourceView*( __fastcall* )( void*, int**, char, char, const char* )>( )(
			thisptr, texture, a3, a4, a5 );
		if ( !srv || !rendering::g_menu.is_open( ) )
		{
			return srv;
		}

		// Copy a C string out of game memory without ever dereferencing it raw
		// (the old code handed an unvalidated char* straight to strstr).
		const auto safe_cstr = []( std::uintptr_t p ) -> std::string
		{
			std::string out{};
			if ( p < 0x10000ull || p >= 0x7FFFFFFFFFFFull )
			{
				return out;
			}
			for ( std::uintptr_t i = 0; i < 96; ++i )
			{
				const auto ch = memory::safe_read<std::uint8_t>( p + i );
				if ( !ch || !*ch )
				{
					break;
				}
				if ( *ch < 0x20 || *ch > 0x7E )
				{
					return {};
				}
				out.push_back( static_cast<char>( *ch ) );
			}
			return out.size( ) >= 3 ? out : std::string{};
		};
		const auto rd = []( std::uintptr_t p ) -> std::uintptr_t
		{
			return ( p > 0x10000ull && p < 0x7FFFFFFFFFFFull ) ? memory::safe_read<std::uintptr_t>( p ).value_or( 0 ) : 0;
		};

		// Resolve the texture's name. Two layouts are tried:
		//   A: ***texture + 8 -> char*  (UC 765023 layout)
		//   B:  **texture + 8 -> char*
		const auto t = rd( reinterpret_cast<std::uintptr_t>( texture ) );
		const auto base = rd( t );
		std::string tex_name = safe_cstr( rd( base + sizeof( std::uintptr_t ) ) );
		if ( tex_name.empty( ) )
		{
			tex_name = safe_cstr( rd( t + sizeof( std::uintptr_t ) ) );
		}

		// Diagnostics: log the first few distinct names so we can confirm the
		// name chain works on this build (should see ordinary texture paths).
		{
			static std::mutex log_mtx{};
			static std::vector<std::string> seen{};
			std::scoped_lock lock( log_mtx );
			const std::string key = tex_name.empty( ) ? std::string{ "<unreadable>" } : tex_name;
			const bool ours = key.find( "velocity" ) != std::string::npos;
			if ( ( seen.size( ) < 12 || ours ) && std::find( seen.begin( ), seen.end( ), key ) == seen.end( ) )
			{
				seen.push_back( key );
				logging::console::print( "[get_resource_view] name='{}' a3={} a4={}", key,
					static_cast<int>( a3 ), static_cast<int>( a4 ) );
			}
		}

		// UC 765023: a4 == 0 is the colour target; others are depth/mips.
		if ( a4 == 0 && tex_name.find( "velocity_esp_preview" ) != std::string::npos )
		{
			systems::g_model_preview.set_composition_srv( srv );
		}
		return srv;
	}

	std::uintptr_t __fastcall cheat::parse_report_hit( std::uintptr_t thisptr, std::uint8_t deleting )
	{
		// Capture the protobuf fields before the deleting destructor can free them.
		features::misc::g_impacts.on_report_hit( thisptr );

		return m_parse_report_hit.call<std::uintptr_t>( thisptr, deleting );
	}

	std::uintptr_t __fastcall cheat::setup_fog( __m128i* output, int* mode )
	{
		if ( features::world::g_scene.on_setup_fog( output, mode ) )
		{
			return 0;
		}

		return m_setup_fog.call<std::uintptr_t>( output, mode );
	}

	std::uintptr_t __fastcall cheat::set_shader_param( __m128i* map, std::uint32_t hash, __m128i* value )
	{
		features::world::g_scene.on_set_shader_param( value, hash );

		return m_set_shader_param.call<std::uintptr_t>( map, hash, value );
	}

	std::uintptr_t __fastcall cheat::set_postprocess_vec( __m128i* map, std::uint32_t hash, __m128i* value )
	{
		constexpr std::uint32_t dof_ranges{ 0x2ACAB07C };

		// The engine only publishes DofRanges when the active camera enables DOF.
		// Insert it alongside any post-process vector, matching Artisan's live path.
		if ( settings::g_world.m_scene.dof.value && hash != dof_ranges )
		{
			__m128i* dof_value{};
			features::world::g_scene.on_set_shader_param( dof_value, dof_ranges );
			if ( dof_value )
			{
				m_set_postprocess_vec.call<std::uintptr_t>( map, dof_ranges, dof_value );
			}
		}

		features::world::g_scene.on_set_shader_param( value, hash );
		return m_set_postprocess_vec.call<std::uintptr_t>( map, hash, value );
	}

	void __fastcall cheat::override_view( std::uintptr_t thisptr, std::uintptr_t view_setup )
	{
		m_override_view.call<void>( thisptr, view_setup );

		features::misc::g_camera.on_override_view( view_setup );
		features::misc::g_removals.on_override_view( view_setup );
		features::combat::g_misc.duckpeek( ).on_override_view( view_setup );
	}

	void __fastcall cheat::update_fov_sensitivity( std::uintptr_t thisptr )
	{
		m_update_fov_sensitivity.call<void>( thisptr );

		features::misc::g_camera.update_fov_sensitivity( thisptr );
	}

	void __fastcall cheat::update_and_setup_view( std::uintptr_t entity, float* position, float* angles, std::uint8_t flag )
	{
		const auto& vm = settings::g_misc.m_viewmodel_adjust;
		if ( vm.enabled.value && angles )
		{
			angles[ 0 ] += vm.rot_x.value;
			angles[ 1 ] = std::remainderf( angles[ 1 ] + vm.rot_y.value, 360.0f );
			angles[ 2 ] += vm.rot_z.value;
		}

		m_update_and_setup_view.call<void>( entity, position, angles, flag );
	}

	void* __fastcall cheat::calc_viewmodel( void* a1, float* offsets, float* third )
	{
		const auto& vm = settings::g_misc.m_viewmodel_adjust;
		if ( !vm.enabled.value )
		{
			return m_calc_viewmodel.call<void*>( a1, offsets, third );
		}

		// Two UC versions disagree on the 3rd argument: viewmodel FOV (one float)
		// or rotation (three floats). Decide ONCE on the first call and never
		// re-guess: re-checking every call let a later call "look like" rotation
		// once the FOV slider differed from the convar, and writing 3 floats into
		// a 1-float FOV slot smashed the stack (the crash when moving rotation).
		// On this build it's the FOV, so rotation is done on the scene node
		// instead (camera::do_viewmodel_extra_offset).
		static int third_mode{ -1 }; // -1 unknown, 0 fov, 1 unknown/other -> never written
		if ( third && third_mode < 0 )
		{
			// Exact-match against the viewmodel_fov convar failed whenever the convar
			// differed from the first value passed (the log showed 68.0 here), which
			// left the FOV slider dead. A plausible FOV in slot 0 is enough; this
			// build passes (fov, 0, <junk>) so only slot 0 is ever written.
			const auto first = third[ 0 ];
			third_mode = ( first >= 20.0f && first <= 170.0f ) ? 0 : 1;
			logging::console::print( "[viewmodel] calc_viewmodel 3rd arg treated as {}", third_mode == 0 ? "fov" : "unknown (left untouched)" );
		}
		const bool third_is_fov = third_mode == 0;

		auto* result = m_calc_viewmodel.call<void*>( a1, offsets, third );

		// Diagnostics: the first few calls' arguments, so the 3rd argument can be
		// identified (1 float = FOV; 3 plausible angles = rotation).
		{
			static int logged{ 0 };
			if ( logged < 4 )
			{
				++logged;
				const auto rd = [ ]( const float* p, int i ) { return p ? memory::safe_read<float>( reinterpret_cast<std::uintptr_t>( p + i ) ).value_or( -9999.0f ) : -9999.0f; };
				logging::console::print( "[viewmodel] call {}: offsets=({:.2f},{:.2f},{:.2f}) third=({:.2f},{:.2f},{:.2f})",
					logged, rd( offsets, 0 ), rd( offsets, 1 ), rd( offsets, 2 ), rd( third, 0 ), rd( third, 1 ), rd( third, 2 ) );
			}
		}

		// Rotation is NOT applied here. This function only produces the offset/FOV
		// numbers; the engine sets the viewmodel's scene-node angles afterwards, so
		// anything written to the node at this point was overwritten before
		// rendering (rotation did nothing). It's applied at render start in
		// frame_stage_notify instead.

		// Offsets: the convar already supplies up to the game's clamp, so only
		// add what's past it (x +-2.5, y/z +-2).
		if ( offsets )
		{
			offsets[ 0 ] += vm.offset_x.value - std::clamp( vm.offset_x.value, -2.5f, 2.5f );
			offsets[ 1 ] += vm.offset_y.value - std::clamp( vm.offset_y.value, -2.0f, 2.0f );
			offsets[ 2 ] += vm.offset_z.value - std::clamp( vm.offset_z.value, -2.0f, 2.0f );
		}
		if ( third && third_is_fov )
		{
			third[ 0 ] = vm.fov.value;
		}
		return result;
	}

	void __fastcall cheat::render_scope( std::uintptr_t a1, std::uintptr_t a2 )
	{
		m_render_scope.call<void>( a1, a2 );

		if ( settings::g_misc.m_removals.scope.value )
		{
			memory::write<std::uint8_t>( a2 + 4, 0 );
		}
	}

	bool __fastcall cheat::render_crosshair( std::uintptr_t a1 )
	{
		if ( settings::g_misc.m_removals.crosshair.value )
		{
			return false;
		}

		return m_render_crosshair.call<bool>( a1 );
	}

	float __fastcall cheat::prepare_scene_material( std::uintptr_t material, void* a2, float a3 )
	{
		features::misc::g_removals.on_prepare_scene_material( material );

		return m_prepare_scene_material.call<float>( material, a2, a3 );
	}

	void __fastcall cheat::post_network_data_received( std::uintptr_t thisptr )
	{
		m_post_network_data_received.call<void>( thisptr );
	}

	bool __fastcall cheat::draw_overhead( std::uintptr_t pawn, std::uint32_t player_slot )
	{
		if ( settings::g_misc.m_removals.overhead.value && pawn == systems::g_local.get( ).pawn )
		{
			return false;
		}

		return m_draw_overhead.call<bool>( pawn, player_slot );
	}

	std::uintptr_t __fastcall cheat::draw_legs( std::uintptr_t a1, std::uintptr_t a2, std::uintptr_t a3, std::uintptr_t a4, std::uintptr_t a5 )
	{
		if ( settings::g_misc.m_removals.legs.value )
		{
			return 0;
		}

		return m_draw_legs.call<std::uintptr_t>( a1, a2, a3, a4, a5 );
	}

	bool __fastcall cheat::get_transforms_for_hitbox_list( std::uintptr_t a1, std::uintptr_t a2, int* a3 )
	{
		if ( !features::combat::g_shared.autowalling( ) )
		{
			return m_get_transforms_for_hitbox_list.call<bool>( a1, a2, a3 );
		}

		const auto record = features::combat::g_shared.current_autowall_record( );
		if ( !record || !record->valid )
		{
			return m_get_transforms_for_hitbox_list.call<bool>( a1, a2, a3 );
		}

		const auto count = memory::safe_read<int>( reinterpret_cast< std::uintptr_t >( a3 ) ).value_or( 0 );
		const auto shape_array = memory::safe_read<std::uintptr_t>( reinterpret_cast< std::uintptr_t >( a3 ) + 8 ).value_or( 0 );
		const auto entity_bone_cache = memory::safe_read<std::uintptr_t>( a1 + 0x1c0 ).value_or( 0 );
		const auto model_handle = memory::safe_read<std::uintptr_t>( a1 + 0x1e0 ).value_or( 0 );
		const auto model = model_handle ? memory::safe_read<std::uintptr_t>( model_handle ).value_or( 0 ) : 0;

		if ( count <= 0 || count > 256 || !shape_array || !entity_bone_cache || !model )
		{
			return false;
		}

		static const auto get_bone_index = PATTERN( patterns::get_bone_index );
		if ( !get_bone_index )
		{
			return false;
		}

		// The client dereferences every resolved transform without checking the
		// backing cache. Reject a stale scene node instead of faulting in it.
		for ( auto i = 0; i < count; ++i )
		{
			const auto shape_ptr = shape_array + 16ull * i;
			const auto bone_index = memory::call<int>( get_bone_index, model, shape_ptr );

			if ( bone_index >= 0 &&
				( bone_index >= 256 ||
					!memory::safe_read<systems::bones::data>( entity_bone_cache + sizeof( systems::bones::data ) * bone_index ) ) )
			{
				return false;
			}
		}

		const auto target_scene = record->game_scene_node ? record->game_scene_node : memory::read<std::uintptr_t>( record->pawn + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
		const auto target_bone_cache = target_scene ? memory::safe_read<std::uintptr_t>( target_scene + SCHEMA( "CSkeletonInstance", "m_modelState"_hash ) + 0x80 ).value_or( 0 ) : 0;
		const auto result = m_get_transforms_for_hitbox_list.call<bool>( a1, a2, a3 );

		if ( !result )
		{
			return false;
		}

		const auto is_plausible = [ ]( std::uintptr_t ptr ) noexcept -> bool
			{
				return ptr >= 0x10000ull && ptr < 0x00007FFFFFFFFFFFull;
			};

		if ( !is_plausible( entity_bone_cache ) || !is_plausible( target_bone_cache ) || entity_bone_cache != target_bone_cache )
		{
			return result;
		}

		const auto output_array = memory::safe_read<std::uintptr_t>( a2 + 16 ).value_or( 0 );

		if ( !output_array || count <= 0 )
		{
			return result;
		}

		for ( auto i = 0; i < count; ++i )
		{
			const auto shape_ptr = shape_array + 16ull * i;
			const auto bone_index = memory::call<int>( get_bone_index, model, shape_ptr );

			if ( bone_index < 0 || bone_index >= record->bone_count )
			{
				continue;
			}

			const auto dst = output_array + 32ull * i;
			std::memcpy( reinterpret_cast< void* >( dst ), &record->bones[ bone_index ], 32 );
		}

		return true;
	}

	void __fastcall cheat::sort_primitives( std::uintptr_t thisptr, std::uintptr_t a2, std::uintptr_t a3, std::uint32_t a4 )
	{
		m_sort_primitives.call<void>( thisptr, a2, a3, a4 );

		diag::exception_scope exception_scope{ "chams: sort primitives" };
		features::esp::player::g_chams.on_sort_primitives( a3, a4 );
	}

	float __fastcall cheat::get_inaccuracy( std::uintptr_t thisptr, float* a2, float* a3 )
	{
		const auto result = m_get_inaccuracy.call<float>( thisptr, a2, a3 );

#if defined(__clang__) || defined(__GNUC__)
		const auto result_address = reinterpret_cast< std::uintptr_t >( __builtin_return_address( 0 ) );
#else
		const auto result_address = reinterpret_cast< std::uintptr_t >( _ReturnAddress( ) );
#endif

		static const auto base_fire_guns_get_inaccuracy = PATTERN( patterns::base_fire_guns_get_inaccuracy );
		if ( base_fire_guns_get_inaccuracy &&
			result_address > base_fire_guns_get_inaccuracy &&
			result_address < base_fire_guns_get_inaccuracy + 0x600 )
		{
			features::misc::g_impacts.on_base_fire_guns_get_inaccuracy( thisptr, result );
		}

		return result;
	}

	float* __fastcall cheat::get_interpolated_shoot_position( std::uintptr_t thisptr, float* out, int* tick_frac )
	{
		const auto result = m_get_interpolated_shoot_position.call<float*>( thisptr, out, tick_frac );

		// Prediction calls this helper while building the next command as well.
		// Only the call made for an actual rage shot is its authoritative origin.
		if ( features::combat::g_rage.is_firing_this_tick( ) )
		{
			features::misc::g_impacts.on_get_interpolated_shoot_position( thisptr, out );
		}

		return result;
	}

	std::uintptr_t __fastcall cheat::level_initialization( std::uintptr_t a1, const char* new_map )
	{
		if ( new_map && new_map[ 0 ] )
		{
			const char* leaf = std::strrchr( new_map, '/' );
			rendering::g_widgets.s_map_name = leaf ? leaf + 1 : new_map;
		}
		else
		{
			rendering::g_widgets.s_map_name.clear( );
		}

		features::world::g_scene.reset_skybox_state( );
		features::misc::g_impacts.on_level_change( );
		features::misc::g_scoreboard_weapons.on_level_change( );

		return m_level_initialization.call<std::uintptr_t>( a1, new_map );
	}

	std::uintptr_t __fastcall cheat::level_shutdown( std::uintptr_t a1 )
	{
		rendering::g_widgets.s_map_name.clear();

		// Release feature-owned scene objects before Source 2 tears their parents down.
		features::misc::g_dlight.on_level_shutdown( );
		features::changer::g_inventory.on_level_shutdown( );
		features::changer::g_model_changer.on_level_shutdown( );
		// Panorama discards preview children on level shutdown; re-ensure next frames.
		systems::g_model_preview.reset( );

		// clear all local player data on level shutdown
		systems::g_local.reset();

		return m_level_shutdown.call<std::uintptr_t>( a1 );
	}

	void __fastcall cheat::read_frame_input( std::uintptr_t a1, std::uint32_t a2 )
	{
		m_read_frame_input.call<void>( a1, a2 );
	}

	void __fastcall cheat::process_input_event( std::uintptr_t csgo_input, int slot, float frametime )
	{
		m_process_input_event.call<void>( csgo_input, slot, frametime );
		// Apply queued aim to the frame the engine just created, not its predecessor.
		systems::g_legit_input.on_process_input_event( csgo_input, slot );
	}

	bool __fastcall cheat::prediction_effects_suppressed( std::uintptr_t thisptr )
	{
		// Native effect scopes can bypass the cached flag during speculative movement.
		if ( systems::g_prediction.is_simulating( ) )
		{
			return true;
		}

		// Preserve this leaf getter directly: its short branch lands inside the patch.
		constexpr std::uintptr_t effect_scope_depth_offset = 0x10;
		constexpr std::uintptr_t suppress_effects_offset = 0x14;
		return memory::read<int>( thisptr + effect_scope_depth_offset ) <= 0
			&& memory::read<bool>( thisptr + suppress_effects_offset );
	}

	std::uintptr_t __fastcall cheat::render_decals( std::uintptr_t render_context, std::uintptr_t** render_view, bool pass_flag_a, bool pass_flag_b )
	{
		if ( settings::g_misc.m_removals.decals.value )
		{
			return 0;
		}

		return m_render_decals.call<std::uintptr_t>( render_context, render_view, pass_flag_a, pass_flag_b );
	}

	void __fastcall cheat::render_smoke( std::uintptr_t a1, std::uintptr_t a2, int a3, int a4, std::uintptr_t a5, std::uintptr_t a6 )
	{
		static std::once_flag alright;
		std::call_once( alright, [ & ]
			{
				if ( !a2 )
				{
					return;
				}

				if ( m_render_smoke_map.create( reinterpret_cast< void* >( memory::get_vfunc( a2, 32 ) ), &render_smoke_map ) )
				{
					m_render_smoke_map.enable( );
				}

				if ( m_render_smoke_unmap.create( reinterpret_cast< void* >( memory::get_vfunc( a2, 33 ) ), &render_smoke_unmap ) )
				{
					m_render_smoke_unmap.enable( );
				}
			} );

		if ( settings::g_misc.m_removals.smoke.value )
		{
			return;
		}

		m_render_smoke.call<void>( a1, a2, a3, a4, a5, a6 );
	}

	std::uintptr_t __fastcall cheat::render_smoke_map( std::uintptr_t thisptr, std::size_t size, std::uintptr_t* out_ptr )
	{
		const auto result = m_render_smoke_map.call<std::uintptr_t>( thisptr, size, out_ptr );

		features::world::g_smoke.on_map( result, size, out_ptr && *out_ptr ? *out_ptr : 0 );

		return result;
	}

	void __fastcall cheat::render_smoke_unmap( std::uintptr_t thisptr, std::uintptr_t ctx, std::size_t size )
	{
		features::world::g_smoke.on_unmap( ctx );
		m_render_smoke_unmap.call<void>( thisptr, ctx, size );
	}

	char __fastcall cheat::set_info( std::uintptr_t rcx, std::uintptr_t a2 )
	{
		const auto& cfg = settings::g_misc.m_name_changer;
		const auto should_override = cfg.clantag.value || cfg.override_name.value || features::misc::other::s_name_change_pending;
		if ( should_override && a2 )
		{
			const auto arg_list = memory::safe_read<std::uintptr_t>( a2 + 0x440 ).value_or( 0 );
			const auto key = arg_list
				? memory::safe_read<const char*>( arg_list + 0x8 ).value_or( nullptr )
				: nullptr;

			if ( key && _stricmp( key, "name" ) == 0 )
			{
				constexpr std::uint64_t fcvar_protected = 1ull << 5;
				constexpr std::uint64_t fcvar_userinfo = 1ull << 9;
				constexpr std::uint64_t fcvar_registry_restricted = 1ull << 10;

				if ( addresses::globals::cvar )
				{
					if ( const auto name_cvar = addresses::globals::cvar->find( "name"_hash ) )
					{
						const auto flags_address = reinterpret_cast<std::uintptr_t>( name_cvar ) + offsetof( c_convar, m_flags );
						if ( const auto flags = memory::safe_read<std::uint64_t>( flags_address ) )
						{
							static_cast<void>( memory::safe_write<std::uint64_t>( flags_address,
								( *flags | fcvar_userinfo ) & ~( fcvar_protected | fcvar_registry_restricted ) ) );
						}
					}
				}

				const auto& display = features::misc::other::s_display_name;
				if ( !display.empty( ) )
				{
					static_cast<void>( memory::safe_write<const char*>( arg_list + 0x10, display.c_str( ) ) );
				}
			}
		}

		return m_set_info.call<char>( rcx, a2 );
	}

	void __fastcall cheat::draw_flash_effect( std::uintptr_t a1, int a2, std::uintptr_t* a3, std::uintptr_t a4, __m128* a5 )
	{
		if ( settings::g_misc.m_removals.flash_alpha.value < 100.0f && settings::g_misc.m_removals.flash_alpha.value != 0.0f )
		{
			const auto view_pawn = systems::g_local.get( ).view_pawn( );
			if ( view_pawn )
			{
				const auto max = settings::g_misc.m_removals.flash_alpha.value / 100.0f * 255.0f;
				memory::write<float>( view_pawn + SCHEMA( "C_CSPlayerPawnBase", "m_flFlashMaxAlpha"_hash ), max );
			}
		}

		if ( settings::g_misc.m_removals.flash_alpha.value != 0.0f )
		{
			m_draw_flash_effect.call<void>( a1, a2, a3, a4, a5 );
		}
	}

} // namespace hooks
