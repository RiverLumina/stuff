#pragma once

// Motion blur (D3D11 frame-feedback blur), header-only so no project file edits
// are needed. Ported from the supplied motion_blur.cpp. Differences: it creates
// its own device/context from the swap chain, re-creates itself when the back
// buffer size changes, and saves/restores viewport + rasterizer state because it
// runs inside the game's Present, where those can be anything.

#include <d3d11.h>
#include <dxgi.h>
#include <d3dcompiler.h>
#include <cstring>

#pragma comment(lib, "d3dcompiler.lib")

namespace rendering {

	class c_motion_blur
	{
	public:
		~c_motion_blur( ) = default;

		[[nodiscard]] bool is_initialized( ) const { return this->m_initialized; }

		// Call every frame while the effect is on.
		void apply( IDXGISwapChain* swap_chain, float strength )
		{
			if ( !swap_chain || strength <= 0.0f )
			{
				return;
			}

			DXGI_SWAP_CHAIN_DESC desc{};
			if ( FAILED( swap_chain->GetDesc( &desc ) ) )
			{
				return;
			}

			if ( this->m_initialized && ( static_cast< int >( desc.BufferDesc.Width ) != this->m_width || static_cast< int >( desc.BufferDesc.Height ) != this->m_height || desc.BufferDesc.Format != this->m_format ) )
			{
				this->cleanup( );
			}

			if ( !this->m_initialized )
			{
				if ( this->m_init_failed_frames > 0 )
				{
					--this->m_init_failed_frames;
					return;
				}

				ID3D11Device* device = nullptr;
				if ( FAILED( swap_chain->GetDevice( __uuidof( ID3D11Device ), reinterpret_cast< void** >( &device ) ) ) || !device )
				{
					return;
				}

				ID3D11DeviceContext* context = nullptr;
				device->GetImmediateContext( &context );

				const auto ok = context && this->initialize( device, context, swap_chain );
				if ( context )
				{
					context->Release( );
				}

				device->Release( );

				if ( !ok )
				{
					this->m_init_failed_frames = 300;
					return;
				}
			}

			this->render( swap_chain, strength );
		}

		void cleanup( )
		{
			this->m_initialized = false;
			this->m_first_frame = true;

			const auto release = [ ]( auto*& p )
			{
				if ( p )
				{
					p->Release( );
					p = nullptr;
				}
			};

			release( this->m_vs );
			release( this->m_ps );
			release( this->m_sampler );
			release( this->m_blend_state );
			release( this->m_raster );
			release( this->m_cb );
			release( this->m_frame_copy );
			release( this->m_frame_copy_srv );
			release( this->m_accum );
			release( this->m_accum_srv );
			release( this->m_output );
			release( this->m_output_rtv );
			release( this->m_output_srv );

			this->m_device = nullptr;
			this->m_context = nullptr;
		}

	private:
		bool initialize( ID3D11Device* device, ID3D11DeviceContext* context, IDXGISwapChain* swap_chain )
		{
			this->cleanup( );

			DXGI_SWAP_CHAIN_DESC sc_desc{};
			if ( FAILED( swap_chain->GetDesc( &sc_desc ) ) )
			{
				return false;
			}

			this->m_device = device;
			this->m_context = context;
			this->m_width = static_cast< int >( sc_desc.BufferDesc.Width );
			this->m_height = static_cast< int >( sc_desc.BufferDesc.Height );
			this->m_format = sc_desc.BufferDesc.Format;

			if ( !this->create_shaders( ) || !this->create_resources( ) )
			{
				this->cleanup( );
				return false;
			}

			this->m_initialized = true;
			return true;
		}

		bool create_shaders( )
		{
			static const char* vs_src = R"(
struct VS_OUT {
    float4 pos : SV_POSITION;
    float2 uv  : TEXCOORD0;
};
VS_OUT vs_main(uint id : SV_VertexID) {
    VS_OUT o;
    o.uv  = float2(id & 1, (id >> 1) & 1);
    o.pos = float4(o.uv.x * 2.0f - 1.0f, 1.0f - o.uv.y * 2.0f, 0.0f, 1.0f);
    return o;
}
)";

			static const char* ps_src = R"(
Texture2D<float4> tex_current : register(t0);
Texture2D<float4> tex_accum   : register(t1);
SamplerState samp : register(s0);

cbuffer cb : register(b0) {
    float2 texel_size;
    float  strength;
    float  _padding;
};

struct PS_IN {
    float4 pos : SV_POSITION;
    float2 uv  : TEXCOORD0;
};

float4 ps_main(PS_IN input) : SV_TARGET {
    float4 current = tex_current.Sample(samp, input.uv);
    float4 accum   = tex_accum.Sample(samp, input.uv);
    return lerp(current, accum, saturate(strength));
}
)";

			ID3DBlob* vs_blob = nullptr;
			ID3DBlob* ps_blob = nullptr;
			ID3DBlob* err = nullptr;

			auto hr = D3DCompile( vs_src, std::strlen( vs_src ), nullptr, nullptr, nullptr, "vs_main", "vs_5_0", 0, 0, &vs_blob, &err );
			if ( err )
			{
				err->Release( );
				err = nullptr;
			}

			if ( FAILED( hr ) || !vs_blob )
			{
				return false;
			}

			hr = this->m_device->CreateVertexShader( vs_blob->GetBufferPointer( ), vs_blob->GetBufferSize( ), nullptr, &this->m_vs );
			vs_blob->Release( );
			if ( FAILED( hr ) )
			{
				return false;
			}

			hr = D3DCompile( ps_src, std::strlen( ps_src ), nullptr, nullptr, nullptr, "ps_main", "ps_5_0", 0, 0, &ps_blob, &err );
			if ( err )
			{
				err->Release( );
			}

			if ( FAILED( hr ) || !ps_blob )
			{
				return false;
			}

			hr = this->m_device->CreatePixelShader( ps_blob->GetBufferPointer( ), ps_blob->GetBufferSize( ), nullptr, &this->m_ps );
			ps_blob->Release( );
			return SUCCEEDED( hr );
		}

		bool create_resources( )
		{
			D3D11_TEXTURE2D_DESC desc{};
			desc.Width = static_cast< UINT >( this->m_width );
			desc.Height = static_cast< UINT >( this->m_height );
			desc.MipLevels = 1;
			desc.ArraySize = 1;
			desc.Format = this->m_format;
			desc.SampleDesc.Count = 1;
			desc.Usage = D3D11_USAGE_DEFAULT;
			desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

			D3D11_SHADER_RESOURCE_VIEW_DESC srv_desc{};
			srv_desc.Format = desc.Format;
			srv_desc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
			srv_desc.Texture2D.MipLevels = 1;

			if ( FAILED( this->m_device->CreateTexture2D( &desc, nullptr, &this->m_frame_copy ) ) ) return false;
			if ( FAILED( this->m_device->CreateShaderResourceView( this->m_frame_copy, &srv_desc, &this->m_frame_copy_srv ) ) ) return false;
			if ( FAILED( this->m_device->CreateTexture2D( &desc, nullptr, &this->m_accum ) ) ) return false;
			if ( FAILED( this->m_device->CreateShaderResourceView( this->m_accum, &srv_desc, &this->m_accum_srv ) ) ) return false;

			desc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
			if ( FAILED( this->m_device->CreateTexture2D( &desc, nullptr, &this->m_output ) ) ) return false;

			D3D11_RENDER_TARGET_VIEW_DESC rtv_desc{};
			rtv_desc.Format = desc.Format;
			rtv_desc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
			if ( FAILED( this->m_device->CreateRenderTargetView( this->m_output, &rtv_desc, &this->m_output_rtv ) ) ) return false;
			if ( FAILED( this->m_device->CreateShaderResourceView( this->m_output, &srv_desc, &this->m_output_srv ) ) ) return false;

			D3D11_SAMPLER_DESC samp_desc{};
			samp_desc.Filter = D3D11_FILTER_MIN_MAG_LINEAR_MIP_POINT;
			samp_desc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
			samp_desc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
			samp_desc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
			samp_desc.MaxLOD = D3D11_FLOAT32_MAX;
			if ( FAILED( this->m_device->CreateSamplerState( &samp_desc, &this->m_sampler ) ) ) return false;

			D3D11_BLEND_DESC blend_desc{};
			blend_desc.RenderTarget[ 0 ].BlendEnable = FALSE;
			blend_desc.RenderTarget[ 0 ].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
			if ( FAILED( this->m_device->CreateBlendState( &blend_desc, &this->m_blend_state ) ) ) return false;

			D3D11_RASTERIZER_DESC raster_desc{};
			raster_desc.FillMode = D3D11_FILL_SOLID;
			raster_desc.CullMode = D3D11_CULL_NONE;
			raster_desc.DepthClipEnable = TRUE;
			if ( FAILED( this->m_device->CreateRasterizerState( &raster_desc, &this->m_raster ) ) ) return false;

			D3D11_BUFFER_DESC cb_desc{};
			cb_desc.ByteWidth = sizeof( float ) * 4;
			cb_desc.Usage = D3D11_USAGE_DYNAMIC;
			cb_desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
			cb_desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
			return SUCCEEDED( this->m_device->CreateBuffer( &cb_desc, nullptr, &this->m_cb ) );
		}

		void render( IDXGISwapChain* swap_chain, float strength )
		{
			if ( !this->m_initialized )
			{
				return;
			}

			ID3D11Texture2D* backbuffer = nullptr;
			if ( FAILED( swap_chain->GetBuffer( 0, __uuidof( ID3D11Texture2D ), reinterpret_cast< void** >( &backbuffer ) ) ) || !backbuffer )
			{
				return;
			}

			auto* ctx = this->m_context;

			// Save the state we touch.
			ID3D11RenderTargetView* old_rtv = nullptr;
			ID3D11DepthStencilView* old_dsv = nullptr;
			ID3D11ShaderResourceView* old_srvs[ 2 ] = {};
			ID3D11Buffer* old_cb = nullptr;
			ID3D11SamplerState* old_sampler = nullptr;
			ID3D11BlendState* old_blend = nullptr;
			ID3D11RasterizerState* old_raster = nullptr;
			ID3D11VertexShader* old_vs = nullptr;
			ID3D11PixelShader* old_ps = nullptr;
			ID3D11InputLayout* old_layout = nullptr;
			D3D11_PRIMITIVE_TOPOLOGY old_topology = D3D11_PRIMITIVE_TOPOLOGY_UNDEFINED;
			UINT old_sample_mask = 0;
			float old_blend_factor[ 4 ] = {};
			UINT old_viewport_count = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
			D3D11_VIEWPORT old_viewports[ D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE ] = {};

			ctx->OMGetRenderTargets( 1, &old_rtv, &old_dsv );
			ctx->VSGetShader( &old_vs, nullptr, nullptr );
			ctx->PSGetShader( &old_ps, nullptr, nullptr );
			ctx->PSGetShaderResources( 0, 2, old_srvs );
			ctx->PSGetConstantBuffers( 0, 1, &old_cb );
			ctx->PSGetSamplers( 0, 1, &old_sampler );
			ctx->OMGetBlendState( &old_blend, old_blend_factor, &old_sample_mask );
			ctx->RSGetState( &old_raster );
			ctx->RSGetViewports( &old_viewport_count, old_viewports );
			ctx->IAGetInputLayout( &old_layout );
			ctx->IAGetPrimitiveTopology( &old_topology );

			ctx->CopyResource( this->m_frame_copy, backbuffer );

			if ( this->m_first_frame )
			{
				ctx->CopyResource( this->m_accum, backbuffer );
				ctx->CopyResource( this->m_output, backbuffer );
				this->m_first_frame = false;
			}
			else
			{
				D3D11_MAPPED_SUBRESOURCE mapped{};
				if ( SUCCEEDED( ctx->Map( this->m_cb, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped ) ) )
				{
					auto* data = static_cast< float* >( mapped.pData );
					data[ 0 ] = 1.0f / static_cast< float >( this->m_width );
					data[ 1 ] = 1.0f / static_cast< float >( this->m_height );
					data[ 2 ] = strength;
					data[ 3 ] = 0.0f;
					ctx->Unmap( this->m_cb, 0 );
				}

				D3D11_VIEWPORT viewport{};
				viewport.Width = static_cast< float >( this->m_width );
				viewport.Height = static_cast< float >( this->m_height );
				viewport.MaxDepth = 1.0f;

				const float blend_factor[ 4 ] = { 1.0f, 1.0f, 1.0f, 1.0f };
				ID3D11ShaderResourceView* srvs[ 2 ] = { this->m_frame_copy_srv, this->m_accum_srv };

				ctx->PSSetShaderResources( 0, 2, srvs );
				ctx->PSSetConstantBuffers( 0, 1, &this->m_cb );
				ctx->PSSetSamplers( 0, 1, &this->m_sampler );
				ctx->VSSetShader( this->m_vs, nullptr, 0 );
				ctx->PSSetShader( this->m_ps, nullptr, 0 );
				ctx->IASetInputLayout( nullptr );
				ctx->IASetPrimitiveTopology( D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP );
				ctx->OMSetBlendState( this->m_blend_state, blend_factor, 0xFFFFFFFF );
				ctx->RSSetState( this->m_raster );
				ctx->RSSetViewports( 1, &viewport );
				ctx->OMSetRenderTargets( 1, &this->m_output_rtv, nullptr );

				ctx->Draw( 4, 0 );

				// Unbind the SRVs so the next copy into them doesn't hit a hazard.
				ID3D11ShaderResourceView* null_srvs[ 2 ] = {};
				ctx->PSSetShaderResources( 0, 2, null_srvs );

				ctx->CopyResource( backbuffer, this->m_output );
				ctx->CopyResource( this->m_accum, this->m_output );
			}

			// Restore.
			ctx->OMSetRenderTargets( 1, &old_rtv, old_dsv );
			ctx->VSSetShader( old_vs, nullptr, 0 );
			ctx->PSSetShader( old_ps, nullptr, 0 );
			ctx->PSSetShaderResources( 0, 2, old_srvs );
			ctx->PSSetConstantBuffers( 0, 1, &old_cb );
			ctx->PSSetSamplers( 0, 1, &old_sampler );
			ctx->OMSetBlendState( old_blend, old_blend_factor, old_sample_mask );
			ctx->RSSetState( old_raster );
			ctx->RSSetViewports( old_viewport_count, old_viewports );
			ctx->IASetInputLayout( old_layout );
			ctx->IASetPrimitiveTopology( old_topology );

			const auto release = [ ]( auto* p )
			{
				if ( p )
				{
					p->Release( );
				}
			};

			release( old_srvs[ 0 ] );
			release( old_srvs[ 1 ] );
			release( old_rtv );
			release( old_dsv );
			release( old_cb );
			release( old_sampler );
			release( old_blend );
			release( old_raster );
			release( old_vs );
			release( old_ps );
			release( old_layout );
			backbuffer->Release( );
		}

		ID3D11Device* m_device{ nullptr };
		ID3D11DeviceContext* m_context{ nullptr };
		ID3D11VertexShader* m_vs{ nullptr };
		ID3D11PixelShader* m_ps{ nullptr };
		ID3D11SamplerState* m_sampler{ nullptr };
		ID3D11BlendState* m_blend_state{ nullptr };
		ID3D11RasterizerState* m_raster{ nullptr };
		ID3D11Buffer* m_cb{ nullptr };
		ID3D11Texture2D* m_frame_copy{ nullptr };
		ID3D11ShaderResourceView* m_frame_copy_srv{ nullptr };
		ID3D11Texture2D* m_accum{ nullptr };
		ID3D11ShaderResourceView* m_accum_srv{ nullptr };
		ID3D11Texture2D* m_output{ nullptr };
		ID3D11RenderTargetView* m_output_rtv{ nullptr };
		ID3D11ShaderResourceView* m_output_srv{ nullptr };

		int m_width{ 0 };
		int m_height{ 0 };
		DXGI_FORMAT m_format{ DXGI_FORMAT_UNKNOWN };
		int m_init_failed_frames{ 0 };
		bool m_initialized{ false };
		bool m_first_frame{ true };
	};

	inline c_motion_blur g_motion_blur{};

} // namespace rendering
