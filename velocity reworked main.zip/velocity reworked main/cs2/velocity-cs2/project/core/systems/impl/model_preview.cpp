#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/addresses/addresses.hpp>
#include <utilities/logging/logging.hpp>
#include <core/systems/systems.hpp>
#include <core/rendering/rendering.hpp>

namespace
{
    // Every ID3D11ShaderResourceView created by the game's device shares one
    // vtable (d3d11.dll's SRV class). We create a throwaway 1x1 SRV once and
    // remember that vtable; any candidate pointer we dig out of game memory must
    // match it exactly before we AddRef it. This lets us probe several layouts
    // without ever touching a garbage pointer.
    std::atomic<std::uintptr_t> g_srv_vtable{ 0 };

    std::uintptr_t reference_srv_vtable( )
    {
        if ( const auto cached = g_srv_vtable.load( std::memory_order_relaxed ) )
        {
            return cached;
        }
        auto* device = rendering::g_context.get_device( );
        if ( !device )
        {
            return 0;
        }
        D3D11_TEXTURE2D_DESC td{};
        td.Width = 1;
        td.Height = 1;
        td.MipLevels = 1;
        td.ArraySize = 1;
        td.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        td.SampleDesc.Count = 1;
        td.Usage = D3D11_USAGE_DEFAULT;
        td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        ID3D11Texture2D* tex{ nullptr };
        if ( FAILED( device->CreateTexture2D( &td, nullptr, &tex ) ) || !tex )
        {
            return 0;
        }
        ID3D11ShaderResourceView* srv{ nullptr };
        const auto hr = device->CreateShaderResourceView( tex, nullptr, &srv );
        tex->Release( );
        if ( FAILED( hr ) || !srv )
        {
            return 0;
        }
        const auto vt = *reinterpret_cast<const std::uintptr_t*>( srv );
        srv->Release( );
        g_srv_vtable.store( vt, std::memory_order_relaxed );
        return vt;
    }

    bool looks_like_ptr( std::uintptr_t p )
    {
        return p > 0x10000ull && p < 0x7FFFFFFFFFFFull;
    }

    // Returns the pointer only if it is a live D3D11 SRV from the game device.
    ID3D11ShaderResourceView* validate_srv( std::uintptr_t candidate, std::uintptr_t ref_vt )
    {
        if ( !ref_vt || !looks_like_ptr( candidate ) )
        {
            return nullptr;
        }
        const auto vt = memory::safe_read<std::uintptr_t>( candidate ).value_or( 0 );
        return ( vt == ref_vt ) ? reinterpret_cast<ID3D11ShaderResourceView*>( candidate ) : nullptr;
    }

    // If panel creation ever faults we stop trying for the session.
    std::atomic<bool> g_panel_disabled{ false };

    // SEH-guarded calls: no C++ objects with destructors in these frames.
    // A wrong vtable index then logs and disables instead of crashing CS2.
    bool guarded_get_ui_engine( std::uintptr_t fn, std::uintptr_t self, std::uintptr_t& out )
    {
        __try
        {
            out = reinterpret_cast<std::uintptr_t( __fastcall* )( std::uintptr_t )>( fn )( self );
            return true;
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            out = 0;
            return false;
        }
    }

    bool guarded_run_script( std::uintptr_t fn, std::uintptr_t engine, std::uintptr_t panel, const char* script, const char* origin )
    {
        __try
        {
            reinterpret_cast<void( __fastcall* )( std::uintptr_t, std::uintptr_t, const char*, const char*, std::uint64_t )>( fn )(
                engine, panel, script, origin, 1ull );
            return true;
        }
        __except ( EXCEPTION_EXECUTE_HANDLER )
        {
            return false;
        }
    }

    std::string read_layer_name( std::uintptr_t layer )
    {
        // c_scene_layer::m_layer_name is an inline char[64] at +0x4A0.
        std::string out{};
        for ( std::uintptr_t i = 0; i < 63; ++i )
        {
            const auto ch = memory::safe_read<std::uint8_t>( layer + 0x4A0 + i );
            if ( !ch || !*ch )
            {
                break;
            }
            const auto c = static_cast<char>( *ch );
            if ( c < 0x20 || c > 0x7E )
            {
                return {}; // not a string -> not a layer at this address
            }
            out.push_back( c );
        }
        return out;
    }
}

namespace systems
{
    bool model_preview::initialize( )
    {
        std::scoped_lock lock( this->m_preview_mtx );
        m_initialized = true;
        m_current_texture = nullptr;
        m_composition_srv = nullptr;
        m_live = {};
        logging::console::print( "[model_preview] initialized (esp preview ready)" );
        return true;
    }

    void model_preview::shutdown( )
    {
        std::scoped_lock lock( this->m_preview_mtx );
        if ( m_composition_srv )
        {
            m_composition_srv->Release( );
            m_composition_srv = nullptr;
        }
        m_composition_res = nullptr;
        m_srv_from_rt = false;
        m_rt_rejected.clear( );
        m_current_texture = nullptr;
        m_live = {};
        m_initialized = false;
        m_ensured_team = -1;
    }

    void model_preview::reset( )
    {
        std::scoped_lock lock( this->m_preview_mtx );
        m_current_texture = nullptr;
        // Keep composition SRV across level changes (panorama owns it);
        // drop live bones so a stale pose can't stick in the menu.
        m_live = {};
        m_ensured_team = -1;
    }

    void model_preview::set_menu_preview_team( int team )
    {
        m_menu_team.store( ( team == 1 ) ? 1 : 0, std::memory_order_relaxed );
    }

    void model_preview::update_preview_panel( )
    {
        // Re-enabled: panel creation + texture hook for live 3D model preview.
        if ( !m_initialized )
        {
            return;
        }
        const auto team = m_menu_team.load( std::memory_order_relaxed );
        const auto now = GetTickCount64( );
        const auto last = m_last_ensure_ms.load( std::memory_order_relaxed );
        if ( team == m_ensured_team && ( now - last ) < 5000ull )
        {
            return;
        }

        // Log why the panel wasn't created, once per distinct reason.
        const auto bail = []( const char* why )
        {
            static std::string last{};
            if ( last != why )
            {
                last = why;
                logging::console::print( "[model_preview] panel not created: {}", why );
            }
        };

        // Panorama HUD root hosts the script. In the main menu the HUD may not
        // exist yet — the game's own menu agent still feeds GeneratePrimitives,
        // so skipping here is safe (dummy fallback covers it).
        const auto hud_base = memory::safe_read<std::uintptr_t>( addresses::globals::hud );
        if ( !hud_base || !*hud_base )
        {
            bail( "no hud (main menu? join a match/bot game)" );
            return;
        }
        const auto panel = memory::safe_read<std::uintptr_t>( *hud_base + 0x8 );
        if ( !panel || !*panel )
        {
            bail( "hud root panel null" );
            return;
        }
        if ( !memory::safe_read<std::uintptr_t>( *panel ).value_or( 0 ) )
        {
            bail( "hud root panel has no vtable" );
            return;
        }
        // addresses::globals::panorama IS the PanoramaUIEngine001 object (the
        // scoreboard feature uses it directly and its injection works). This
        // used to read through it once more, treating the object's vtable as
        // the object, which is why vfunc 13 "wasn't in panorama.dll".
        const std::optional<std::uintptr_t> panorama{ addresses::globals::panorama };
        if ( !panorama || !*panorama )
        {
            bail( "panorama global null" );
            return;
        }
        // Validate vfunc 13 (GetUIEngine) lives in panorama.dll before calling.
        const auto pan_begin = addresses::modules::panorama;
        const auto pan_size = pan_begin ? memory::get_module_size( pan_begin ) : 0;
        if ( !pan_begin || !pan_size )
        {
            bail( "panorama module not found" );
            return;
        }
        const auto pan_vt = memory::safe_read<std::uintptr_t>( *panorama ).value_or( 0 );
        if ( !pan_vt )
        {
            bail( "panorama vtable null" );
            return;
        }
        if ( g_panel_disabled.load( std::memory_order_relaxed ) )
        {
            return;
        }

        const auto in_panorama = [ & ]( std::uintptr_t p ) { return p >= pan_begin && p < pan_begin + pan_size; };
        // A UI engine candidate is plausible if its vtable AND its RunScript
        // slot (77) both live in panorama.dll.
        const auto engine_ok = [ & ]( std::uintptr_t eng ) -> bool
        {
            if ( !looks_like_ptr( eng ) )
            {
                return false;
            }
            const auto vt = memory::safe_read<std::uintptr_t>( eng ).value_or( 0 );
            if ( !in_panorama( vt ) )
            {
                return false;
            }
            return in_panorama( memory::safe_read<std::uintptr_t>( vt + 77 * sizeof( std::uintptr_t ) ).value_or( 0 ) );
        };

        std::uintptr_t ui_engine{ 0 };
        const char* engine_source{ "" };

        // (a) GetUIEngine vfunc 13, when it points into panorama.dll.
        const auto get_engine_fn = memory::safe_read<std::uintptr_t>( pan_vt + 13 * sizeof( std::uintptr_t ) ).value_or( 0 );
        if ( in_panorama( get_engine_fn ) )
        {
            std::uintptr_t eng{ 0 };
            if ( guarded_get_ui_engine( get_engine_fn, *panorama, eng ) && engine_ok( eng ) )
            {
                ui_engine = eng;
                engine_source = "vfunc 13";
            }
        }

        // (b) CPanoramaUIEngine keeps the engine as a member (0x28 on recent
        //     builds); probe nearby slots with the same plausibility check.
        if ( !ui_engine )
        {
            for ( const std::uintptr_t off : { 0x28ull, 0x20ull, 0x30ull, 0x18ull, 0x38ull, 0x10ull, 0x40ull, 0x8ull } )
            {
                const auto eng = memory::safe_read<std::uintptr_t>( *panorama + off ).value_or( 0 );
                if ( engine_ok( eng ) )
                {
                    ui_engine = eng;
                    engine_source = off == 0x28 ? "member +0x28" : "member (probed)";
                    break;
                }
            }
        }

        // (c) RTTI: find the engine class's vtable by name in panorama.dll (done
        //     once, it's a full-module scan), then find the object using it,
        //     either referenced from the PanoramaUIEngine interface or as a global.
        if ( !ui_engine )
        {
            static bool rtti_done{ false };
            static std::uintptr_t rtti_engine{ 0 };
            static std::string rtti_name{};
            if ( !rtti_done )
            {
                rtti_done = true;
                for ( const char* name : { "CUIEngine@panorama", "CUIEngineSource2@panorama", "CUIEngineSource2", "CUIEngine" } )
                {
                    const auto vt = memory::find_vtable_by_rtti( pan_begin, name );
                    if ( !vt )
                    {
                        continue;
                    }
                    logging::console::print( "[model_preview] rtti: {} vtable found", name );

                    // Referenced from the interface object?
                    for ( std::uintptr_t off = 0; off < 0x400 && !rtti_engine; off += 8 )
                    {
                        const auto cand = memory::safe_read<std::uintptr_t>( *panorama + off ).value_or( 0 );
                        if ( looks_like_ptr( cand ) && memory::safe_read<std::uintptr_t>( cand ).value_or( 0 ) == vt )
                        {
                            rtti_engine = cand;
                        }
                    }
                    // Or a global instance in panorama.dll.
                    if ( !rtti_engine )
                    {
                        rtti_engine = memory::find_global_instance_by_vtable( pan_begin, vt );
                    }
                    if ( rtti_engine )
                    {
                        rtti_name = name;
                        break;
                    }
                }
                if ( !rtti_engine )
                {
                    logging::console::print( "[model_preview] rtti: no UI engine instance found" );
                }
            }
            if ( rtti_engine && engine_ok( rtti_engine ) )
            {
                ui_engine = rtti_engine;
                engine_source = "rtti";
            }
            else if ( rtti_engine )
            {
                static bool logged{ false };
                if ( !logged )
                {
                    logged = true;
                    logging::console::print( "[model_preview] rtti: {} instance found but RunScript slot 77 isn't in panorama.dll", rtti_name );
                }
            }
        }

        if ( !ui_engine )
        {
            bail( "no UI engine found (vfunc 13, member probe and rtti all failed)" );
            return;
        }
        const auto engine_vt = memory::safe_read<std::uintptr_t>( ui_engine ).value_or( 0 );
        const auto run_fn = memory::safe_read<std::uintptr_t>( engine_vt + 77 * sizeof( std::uintptr_t ) ).value_or( 0 );
        {
            static bool logged{ false };
            if ( !logged )
            {
                logged = true;
                logging::console::print( "[model_preview] ui engine via {}", engine_source );
            }
        }

        // UC 765023: dedicated MapPlayerPreviewPanel with our composition layer.
        // knife_idle needs no equipped item; CT/T model matches the sequence prefix
        // so we never sit in bind pose. All JS errors are contained in Panorama.
        const char* model = ( team == 1 )
            ? "agents/models/tm_professional/tm_professional_varf.vmdl"
            : "agents/models/ctm_st6/ctm_st6_variante.vmdl";
        const char* seq = ( team == 1 ) ? "t_main_menu_knife_idle" : "ct_main_menu_knife_idle";

        char script[ 2048 ]{};
        _snprintf_s( script, sizeof( script ), _TRUNCATE,
            "(function(){try{"
            "var root=$.GetContextPanel();if(!root||!root.IsValid())return;"
            "var cid='velocity_esp_preview_container';"
            "var c=root.FindChildTraverse(cid);"
            "if(!c||!c.IsValid()){c=$.CreatePanel('Panel',root,cid);}"
            // Container must be as big as the preview: Panorama's default overflow
            // squishes children to the parent, which starved the render target.
            // Sizes are re-applied every run because the panel survives re-injects.
            "c.style.width='%upx';c.style.height='%upx';"
            "c.style.overflow='noclip';"
            "c.style.opacity='0.01';c.style.visibility='visible';"
            "c.style.position='-1200px -1200px 0px';"
            "var pid='velocity_esp_preview';"
            "var p=c.FindChildTraverse(pid);"
            "if(!p||!p.IsValid()){"
            "p=$.CreatePanel('MapPlayerPreviewPanel',c,pid,"
            "{'require-composition-layer':'true','composition-layer-texture-name':'velocity_esp_preview'});}"
            // Unusual 0.49 aspect: matches the docked ESP panel and lets
            // on_set_render_targets recognise our render target by shape alone.
            "p.style.width='%upx';p.style.height='%upx';"
            "var m='%s';var s='%s';"
            "$.Schedule(0.25,function(){try{"
            "if(p&&p.IsValid()){try{p.SetPlayerModel(m);}catch(e){}"
            "try{p.PlaySequence(s,true);}catch(e){}}"
            "}catch(e){}});"
            "}catch(e){}})();",
            k_panel_w, k_panel_h, k_panel_w, k_panel_h, model, seq );

        static constexpr char origin_file[ ]{ "" };
        if ( !guarded_run_script( run_fn, ui_engine, *panel, script, origin_file ) )
        {
            g_panel_disabled.store( true, std::memory_order_relaxed );
            logging::console::print( "[model_preview] RunScript faulted (vtable index 77 is wrong on this build); preview panel disabled for this session" );
            return;
        }
        if ( m_ensured_team != team )
        {
            logging::console::print( "[model_preview] preview panel script sent (team {}, {}x{})", team, k_panel_w, k_panel_h );
        }

        m_ensured_team = team;
        m_last_ensure_ms.store( now, std::memory_order_relaxed );
    }

    void model_preview::set_composition_srv( void* srv )
    {
        auto* as_srv = static_cast<ID3D11ShaderResourceView*>( srv );
        {
            std::scoped_lock lock( this->m_preview_mtx );
            if ( m_composition_srv == as_srv )
            {
                return;
            }
        }

        // Query the texture size outside the lock (cheap, only on change).
        std::uint32_t w{ 0 }, h{ 0 };
        if ( as_srv )
        {
            ID3D11Resource* res{ nullptr };
            as_srv->GetResource( &res );
            if ( res )
            {
                ID3D11Texture2D* t2d{ nullptr };
                if ( SUCCEEDED( res->QueryInterface( __uuidof( ID3D11Texture2D ), reinterpret_cast<void**>( &t2d ) ) ) && t2d )
                {
                    D3D11_TEXTURE2D_DESC desc{};
                    t2d->GetDesc( &desc );
                    w = desc.Width;
                    h = desc.Height;
                    t2d->Release( );
                }
                res->Release( );
            }
        }

        std::scoped_lock lock( this->m_preview_mtx );
        if ( m_composition_srv == as_srv )
        {
            return;
        }
        if ( as_srv )
        {
            as_srv->AddRef( );
        }
        if ( m_composition_srv )
        {
            m_composition_srv->Release( );
        }
        m_composition_srv = as_srv;
        m_composition_w = w;
        m_composition_h = h;
        logging::console::print( "[model_preview] composition srv captured via get_resource_view ({}x{})", w, h );
    }

    void model_preview::on_set_render_targets( UINT num_views, ID3D11RenderTargetView* const* rtvs )
    {
        if ( !m_initialized || num_views == 0 || !rtvs || !rtvs[ 0 ] )
        {
            return;
        }
        auto* rtv = rtvs[ 0 ];

        // Fast path: this is called hundreds of times per frame. Skip RTVs we
        // already rejected; flush the list every 2s since views get recycled.
        {
            std::scoped_lock lock( this->m_preview_mtx );
            const auto now = GetTickCount64( );
            if ( now - m_rt_cache_reset_ms > 2000ull || m_rt_rejected.size( ) > 512 )
            {
                m_rt_rejected.clear( );
                m_rt_cache_reset_ms = now;
            }
            if ( std::find( m_rt_rejected.begin( ), m_rt_rejected.end( ), rtv ) != m_rt_rejected.end( ) )
            {
                return;
            }
        }

        const auto reject = [ & ]( )
        {
            std::scoped_lock lock( this->m_preview_mtx );
            m_rt_rejected.push_back( rtv );
        };

        D3D11_RENDER_TARGET_VIEW_DESC rtv_desc{};
        rtv->GetDesc( &rtv_desc );
        if ( rtv_desc.ViewDimension != D3D11_RTV_DIMENSION_TEXTURE2D )
        {
            reject( );
            return;
        }

        ID3D11Resource* res{ nullptr };
        rtv->GetResource( &res );
        if ( !res )
        {
            reject( );
            return;
        }
        ID3D11Texture2D* tex{ nullptr };
        if ( FAILED( res->QueryInterface( __uuidof( ID3D11Texture2D ), reinterpret_cast<void**>( &tex ) ) ) || !tex )
        {
            res->Release( );
            reject( );
            return;
        }
        D3D11_TEXTURE2D_DESC td{};
        tex->GetDesc( &td );

        // Shape test. Panorama scales CSS px by the UI scale, so compare the
        // aspect ratio rather than raw size. Must be sampleable and not MSAA.
        const float want = static_cast<float>( k_panel_w ) / static_cast<float>( k_panel_h );
        const float have = td.Height ? static_cast<float>( td.Width ) / static_cast<float>( td.Height ) : 0.0f;
        const bool shape_ok = td.Height >= 200 && td.Height <= 4096 && std::fabs( have - want ) < 0.006f;
        const bool usable = ( td.BindFlags & D3D11_BIND_SHADER_RESOURCE ) && td.SampleDesc.Count == 1 && td.ArraySize == 1;

        // Diagnostics: log the first distinct render-target sizes we see, so if
        // the shape match misses we can read the real preview size off the log.
        {
            static std::mutex diag_mtx{};
            static std::vector<std::uint64_t> seen{};
            const auto key = ( static_cast<std::uint64_t>( td.Width ) << 32 ) | td.Height;
            std::scoped_lock lock( diag_mtx );
            if ( seen.size( ) < 40 && td.Height >= 128 && std::find( seen.begin( ), seen.end( ), key ) == seen.end( ) )
            {
                seen.push_back( key );
                logging::console::print( "[model_preview] rt seen {}x{} fmt {} samples {} srv {} aspect {:.3f}{}",
                    td.Width, td.Height, static_cast<int>( td.Format ), td.SampleDesc.Count,
                    ( td.BindFlags & D3D11_BIND_SHADER_RESOURCE ) ? 1 : 0, have, shape_ok ? "  <-- match" : "" );
            }
        }

        bool already{ false };
        {
            std::scoped_lock lock( this->m_preview_mtx );
            already = ( m_composition_res == res ) && m_composition_srv;
        }
        if ( !shape_ok || !usable || already )
        {
            tex->Release( );
            res->Release( );
            if ( !already )
            {
                reject( );
            }
            return;
        }

        // Build our own SRV over the target. Use the RTV's typed format so
        // TYPELESS textures still get a valid view.
        ID3D11ShaderResourceView* srv{ nullptr };
        if ( auto* device = rendering::g_context.get_device( ) )
        {
            D3D11_SHADER_RESOURCE_VIEW_DESC sd{};
            sd.Format = ( rtv_desc.Format != DXGI_FORMAT_UNKNOWN ) ? rtv_desc.Format : td.Format;
            sd.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
            sd.Texture2D.MostDetailedMip = 0;
            sd.Texture2D.MipLevels = 1;
            if ( FAILED( device->CreateShaderResourceView( tex, &sd, &srv ) ) )
            {
                srv = nullptr;
            }
        }
        tex->Release( );

        if ( !srv )
        {
            res->Release( );
            reject( );
            logging::console::print( "[model_preview] matched {}x{} target but SRV creation failed (fmt {})",
                td.Width, td.Height, static_cast<int>( td.Format ) );
            return;
        }

        {
            std::scoped_lock lock( this->m_preview_mtx );
            if ( m_composition_srv )
            {
                m_composition_srv->Release( );
            }
            m_composition_srv = srv; // owns the reference from CreateShaderResourceView
            m_composition_res = res;
            m_composition_w = td.Width;
            m_composition_h = td.Height;
            m_srv_from_rt = true;
        }
        res->Release( ); // the SRV keeps the texture alive
        logging::console::print( "[model_preview] captured preview render target {}x{} fmt {}",
            td.Width, td.Height, static_cast<int>( rtv_desc.Format ) );
    }

    void* model_preview::get_composition_srv( ) const
    {
        std::scoped_lock lock( this->m_preview_mtx );
        return m_composition_srv;
    }

    std::pair<std::uint32_t, std::uint32_t> model_preview::get_composition_size( ) const
    {
        std::scoped_lock lock( this->m_preview_mtx );
        return { m_composition_w, m_composition_h };
    }

    model_preview::live_snapshot model_preview::get_live_snapshot( ) const
    {
        std::scoped_lock lock( this->m_preview_mtx );
        return m_live;
    }

    [[maybe_unused]] static bool layer_name_has_preview( const char* name )
    {
        if ( !name || !name[ 0 ] )
        {
            return false;
        }
        // Panorama appends "_X" suffixes; substring match is intentional.
        // Keep it tight so we only grab player preview layers, not skybox/scene.
        char lower[ 64 ]{};
        for ( int i = 0; i < 63 && name[ i ]; ++i )
        {
            auto c = name[ i ];
            lower[ i ] = static_cast<char>( ( c >= 'A' && c <= 'Z' ) ? c + 32 : c );
        }
        const auto has = [ & ]( const char* needle )
        {
            return std::strstr( lower, needle ) != nullptr;
        };
        return has( "preview" ) || has( "player3d" ) || has( "portrait" );
    }

    bool model_preview::on_generate_primitives(
        std::uintptr_t owner_entity,
        std::uint32_t owner_hash,
        std::uintptr_t scene_object,
        std::uintptr_t primitive_buffer,
        void( __fastcall* original_fn )( std::uintptr_t, std::uintptr_t, std::uintptr_t, std::uintptr_t ),
        std::uintptr_t a1,
        std::uintptr_t scene_view )
    {
        (void)primitive_buffer;
        (void)original_fn;
        (void)a1;
        (void)scene_view;

        if ( !m_initialized || !owner_entity || !scene_object )
            return false;

        if ( owner_hash != "C_CSGO_PreviewPlayer"_hash )
            return false;

        // Resolve display model path (informational; any preview model is accepted).
        std::string model_path{};
        if ( const auto mesh_instance = memory::safe_read<std::uintptr_t>( owner_entity + SCHEMA( "C_BaseEntity", "m_pMeshInstance"_hash ) ) )
        {
            if ( const auto mesh_cache = memory::safe_read<std::uintptr_t>( *mesh_instance + 0x8 ) )
            {
                if ( mesh_cache && mesh_cache < 0x7FFFFFFFFFFFull )
                {
                    if ( const auto model_imp = memory::safe_read<std::uintptr_t>( *mesh_cache ) )
                    {
                        if ( model_imp && *model_imp && *model_imp < 0x7FFFFFFFFFFFull )
                        {
                            if ( const auto path_ptr = memory::safe_read<std::uintptr_t>( *model_imp + 0x8 ) )
                            {
                                if ( path_ptr && *path_ptr && *path_ptr < 0x7FFFFFFFFFFFull )
                                {
                                    char buf[ 129 ]{};
                                    for ( int i = 0; i < 128; ++i )
                                    {
                                        const auto ch = memory::safe_read<std::uint8_t>( *path_ptr + static_cast<std::uintptr_t>( i ) );
                                        if ( !ch || !*ch )
                                        {
                                            break;
                                        }
                                        buf[ i ] = static_cast<char>( *ch );
                                    }
                                    if ( buf[ 0 ] )
                                    {
                                        model_path.assign( buf );
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Snapshot bones for the menu ESP preview. Finalized bones keep animating;
        // the menu re-reads this snapshot every frame (UC: don't cache first sample).
        std::array<bones::data, 27> bones{};
        int bone_count{ 0 };
        {
            const auto skel = g_bones.get_skeleton( owner_entity );
            bones = skel;
            // Count usable bones (non-zero positions).
            for ( const auto& b : skel )
            {
                if ( b.position.length_sqr( ) > 1.0f )
                {
                    ++bone_count;
                }
            }
        }

        // Composition texture capture.
        //
        // The old path read the layer from scene_object + 0x10, but scene_object is
        // the CSceneObject (owner handle lives at +0xC0, past the end of
        // c_generate_primitives_data), so +0x10 was never a c_scene_layer. The
        // struct whose +0x10 is m_scene_layer is the generate-primitives data the
        // hook calls "scene_view". We probe all plausible sources and only accept
        // a pointer whose vtable matches a real D3D11 SRV (see validate_srv).
        //
        // Chain per layer: m_texture_handle (+0x7D8, or +0x818 for the 2nd target)
        //   -> texture_dx11_handle_t -> m_texture (c_texture_dx11*) -> +0x10 SRV0.
        ID3D11ShaderResourceView* layer_srv{ nullptr };
        std::string capture_log{};
        if ( const auto ref_vt = reference_srv_vtable( ) )
        {
            struct layer_src { std::uintptr_t base; std::uintptr_t off; const char* tag; };
            const layer_src sources[ ]
            {
                { scene_view, 0x10, "data+10" },
                { scene_view, 0x98, "data+98" },
                { scene_object, 0x10, "obj+10" },
            };
            constexpr std::uintptr_t handle_offsets[ ]{ 0x7D8, 0x818 };

            int best_score{ 0 };
            for ( const auto& src : sources )
            {
                if ( !looks_like_ptr( src.base ) )
                {
                    continue;
                }
                const auto layer = memory::safe_read<std::uintptr_t>( src.base + src.off ).value_or( 0 );
                if ( !looks_like_ptr( layer ) )
                {
                    continue;
                }
                // Don't require a readable name: the +0x4A0 offset may be stale on
                // this build. Log what we saw either way, then still probe handles.
                const auto name = read_layer_name( layer );
                capture_log += std::string{ src.tag } + "=" + ( name.empty( ) ? "<no name>" : "'" + name + "'" ) + " ";

                // Prefer our own layer, then any preview layer, then anything valid.
                int name_score = 1;
                if ( name.find( "velocity" ) != std::string::npos )
                {
                    name_score = 3;
                }
                else if ( name.find( "review" ) != std::string::npos || name.find( "layer" ) != std::string::npos )
                {
                    name_score = 2;
                }

                for ( const auto hoff : handle_offsets )
                {
                    const auto handle = memory::safe_read<std::uintptr_t>( layer + hoff ).value_or( 0 );
                    if ( !looks_like_ptr( handle ) )
                    {
                        continue;
                    }
                    const auto tex = memory::safe_read<std::uintptr_t>( handle ).value_or( 0 );
                    ID3D11ShaderResourceView* found{ nullptr };
                    if ( looks_like_ptr( tex ) )
                    {
                        found = validate_srv( memory::safe_read<std::uintptr_t>( tex + 0x10 ).value_or( 0 ), ref_vt );
                    }
                    if ( !found )
                    {
                        // Some builds store c_texture_dx11 inline instead of behind a pointer.
                        found = validate_srv( memory::safe_read<std::uintptr_t>( handle + 0x10 ).value_or( 0 ), ref_vt );
                    }
                    if ( !found )
                    {
                        continue;
                    }
                    const int score = name_score * 10 + ( hoff == 0x7D8 ? 1 : 0 );
                    if ( score > best_score )
                    {
                        best_score = score;
                        layer_srv = found;
                        capture_log += std::string{ "[srv@" } + ( hoff == 0x7D8 ? "7D8" : "818" ) + "] ";
                    }
                }
            }
            capture_log += layer_srv ? "-> captured" : "-> no valid srv";
        }
        else
        {
            capture_log = "no d3d device yet";
        }

        // Texture size for aspect-correct drawing (only when the SRV changes).
        std::uint32_t tex_w{ 0 }, tex_h{ 0 };
        bool srv_changed{ false };
        {
            std::scoped_lock lock( this->m_preview_mtx );
            srv_changed = layer_srv && layer_srv != m_composition_srv;
        }
        if ( srv_changed )
        {
            ID3D11Resource* res{ nullptr };
            layer_srv->GetResource( &res );
            if ( res )
            {
                ID3D11Texture2D* t2d{ nullptr };
                if ( SUCCEEDED( res->QueryInterface( __uuidof( ID3D11Texture2D ), reinterpret_cast<void**>( &t2d ) ) ) && t2d )
                {
                    D3D11_TEXTURE2D_DESC desc{};
                    t2d->GetDesc( &desc );
                    tex_w = desc.Width;
                    tex_h = desc.Height;
                    t2d->Release( );
                }
                res->Release( );
            }
        }

        {
            std::scoped_lock lock( this->m_preview_mtx );
            m_live.has_live = bone_count > 4;
            m_live.entity = owner_entity;
            m_live.last_update = static_cast<double>( GetTickCount64( ) ) / 1000.0;
            m_live.bones = bones;
            m_live.bone_count = bone_count;
            m_live.has_matrix = false;
            m_live.model_path = std::move( model_path );
            // Never let the (unreliable) layer probe replace a render-target capture.
            if ( layer_srv && layer_srv != m_composition_srv && !m_srv_from_rt )
            {
                layer_srv->AddRef( );
                if ( m_composition_srv )
                {
                    m_composition_srv->Release( );
                }
                m_composition_srv = layer_srv;
                if ( tex_w && tex_h )
                {
                    m_composition_w = tex_w;
                    m_composition_h = tex_h;
                }
            }
            // Log only when the result changes, so the console tells us exactly
            // which layer/offset worked (or what names it saw) without spamming.
            if ( capture_log != m_last_capture_log )
            {
                m_last_capture_log = capture_log;
                logging::console::print( "[model_preview] {} ({}x{})", capture_log, m_composition_w, m_composition_h );
            }
        }

        return false;
    }
}
